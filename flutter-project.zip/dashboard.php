<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$settings = json_decode(file_get_contents('data/settings.json'), true);
$users = json_decode(file_get_contents('data/users.json'), true);
$my_id = $_SESSION['user_id'];

// Jika data session hilang dari JSON karena dihapus admin, paksa buat ulang
if (!isset($users[$my_id])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

$user_data = $users[$my_id];
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]" . dirname($_SERVER['PHP_SELF']) . "/index.php?ref=" . $my_id;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard E-Wallet Affiliate</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Roboto, sans-serif; }
        body { background: #f4f7fe; padding: 20px; display: flex; justify-content: center; }
        .container { width: 100%; max-width: 450px; display: flex; flex-direction: column; gap: 20px; }
        
        /* Header Wallet Card */
        .wallet-card { background: linear-gradient(135deg, #1565c0, #0d47a1); color: white; border-radius: 24px; padding: 30px 25px; box-shadow: 0 10px 25px rgba(21, 101, 192, 0.35); position: relative; overflow: hidden; }
        .wallet-card::before { content: ''; position: absolute; top: -50px; right: -50px; width: 150px; height: 150px; background: rgba(255,255,255,0.05); border-radius: 50%; }
        .wallet-title { font-size: 14px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; }
        .wallet-balance { font-size: 36px; font-weight: 700; margin-bottom: 20px; }
        .wallet-info { display: flex; justify-content: space-between; border-top: 1px solid rgba(255,255,255,0.15); padding-top: 15px; }
        .info-box text { font-size: 12px; opacity: 0.8; display: block; }
        .info-box val { font-size: 18px; font-weight: 600; }

        /* General Card UI */
        .card { background: white; border-radius: 20px; padding: 25px 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.02); }
        .card-title { font-size: 16px; font-weight: 700; color: #1a237e; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
        
        /* Input & Link Style */
        .link-box { background: #f8f9fa; border: 1px dashed #ced4da; padding: 15px; border-radius: 12px; font-size: 14px; word-break: break-all; color: #495057; user-select: all; text-align: center; font-weight: 500; }
        
        /* Buttons */
        .btn { display: block; width: 100%; border: none; padding: 18px; border-radius: 16px; font-size: 16px; font-weight: 600; text-align: center; text-decoration: none; transition: all 0.2s; cursor: pointer; margin-bottom: 12px; }
        .btn:last-child { margin-bottom: 0; }
        .btn-wa { background: #25d366; color: white; box-shadow: 0 5px 15px rgba(37, 211, 102, 0.2); }
        .btn-wd { background: #2979ff; color: white; box-shadow: 0 5px 15px rgba(41, 121, 255, 0.2); }
        .btn-disabled { background: #e0e0e0; color: #9e9e9e; cursor: not-allowed; box-shadow: none; }
        
        /* Fullscreen Popup */
        .popup-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); display: flex; align-items: flex-end; z-index: 1000; }
        .popup-content { background: white; width: 100%; border-top-left-radius: 28px; border-top-right-radius: 28px; padding: 40px 25px; text-align: center; box-shadow: 0 -10px 25px rgba(0,0,0,0.1); }
        .popup-icon { font-size: 50px; margin-bottom: 15px; }
        .popup-content h2 { font-size: 22px; color: #1a237e; margin-bottom: 10px; }
        .popup-content p { color: #666; font-size: 15px; line-height: 1.5; margin-bottom: 25px; }
    </style>
</head>
<body>

<div class="container">
    <div class="wallet-card">
        <div class="wallet-title">Total Saldo Anda</div>
        <div class="wallet-balance">Rp <?php echo number_format($user_data['saldo'], 0, ',', '.'); ?></div>
        <div class="wallet-info">
            <div class="info-box">
                <text>ID ANDA</text>
                <val><?php echo $my_id; ?></val>
            </div>
            <div class="info-box" style="text-align: right;">
                <text>TOTAL REFERRAL</text>
                <val><?php echo $user_data['referral']; ?> Orang</val>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-title">🔗 Link Referral Anda</div>
        <div class="link-box" onclick="navigator.clipboard.writeText('<?php echo $actual_link; ?>'); alert('Link berhasil disalin!');">
            <?php echo $actual_link; ?>
        </div>
        <p style="font-size: 12px; color: #888; text-align: center; margin-top: 8px;">Sentuh teks di atas untuk menyalin link.</p>
    </div>

    <div class="card" style="background: transparent; box-shadow: none; padding: 0;">
        <a href="join.php" class="btn btn-wa" target="_blank">💬 Gabung Grup WhatsApp</a>
        
        <?php if ($user_data['saldo'] >= 210000 && $user_data['joined_group']): ?>
            <a href="withdraw.php" class="btn btn-wd">💸 Tarik Saldo</a>
        <?php else: ?>
            <button class="btn btn-disabled" onclick="alert('Syarat Tarik Saldo:\n1. Minimal Saldo Rp 210.000\n2. Wajib bergabung ke Grup WhatsApp.')">💸 Tarik Saldo (Terkunci)</button>
        <?php endif; ?>
    </div>
</div>

<?php if (!$user_data['joined_group']): ?>
<div class="popup-overlay">
    <div class="popup-content">
        <div class="popup-icon">📢</div>
        <h2>Langkah Wajib!</h2>
        <p>Untuk mengaktifkan fitur penarikan dan memvalidasi akun Anda, silakan bergabung dengan grup resmi WhatsApp kami terlebih dahulu.</p>
        <a href="join.php" class="btn btn-wa" target="_blank" style="margin-bottom: 0;">Gabung Sekarang</a>
    </div>
</div>
<?php endif; ?>

</body>
</html>
