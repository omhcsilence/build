// ignore_for_file: use_build_context_synchronously
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';

const String baseUrl = "https://omhc-host-premium.yakuza.biz.id";
const String _bgVideoUrl = 'https://files.catbox.moe/tgh344.mp4';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final confirmPassController = TextEditingController();
  String? androidId;
  bool _isObscure = true;
  bool _isObscureConfirm = true;
  bool _isLoading = false;
  String? _errorMsg;
  bool _isRegisterMode = false;

  // Video background
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  // Fade-in animation
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  // Slide-up animation
  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1200),
    );
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);

    _slideController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 800),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));

    _initBgVideo();
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _fadeController.forward();
      if (mounted) _slideController.forward();
    });

    _tryAutoLogin();
  }

  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.networkUrl(Uri.parse(_bgVideoUrl))
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  @override
  void dispose() {
    _bgVideoController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    userController.dispose();
    passController.dispose();
    confirmPassController.dispose();
    super.dispose();
  }

  // ── Auto Login ──────────────────────────────────────────────────
  Future<void> _tryAutoLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      try {
        final res = await http.get(Uri.parse(
          "$baseUrl/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
        ));
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          Navigator.pushReplacementNamed(context, '/splash', arguments: {
            'username': savedUser, 'password': savedPass,
            'role': data['role'], 'key': data['key'],
            'expiredDate': data['expiredDate'],
            'listBug': data['listBug'] ?? [],
            'listPayload': data['listPayload'] ?? [],
            'listDDoS': data['listDDoS'] ?? [],
            'news': data['news'] ?? [],
          });
        }
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final android = await deviceInfo.androidInfo;
      return android.id;
    } catch (_) {
      return 'unknown_device';
    }
  }

  // ── Register ───────────────────────────────────────────────────
  Future<void> _handleRegister() async {
    final username = userController.text.trim();
    final password = passController.text.trim();
    final confirmPass = confirmPassController.text.trim();

    if (username.isEmpty || password.isEmpty || confirmPass.isEmpty) {
      setState(() => _errorMsg = 'Semua field wajib diisi');
      return;
    }

    if (username.length < 3) {
      setState(() => _errorMsg = 'Username minimal 3 karakter');
      return;
    }

    if (password.length < 6) {
      setState(() => _errorMsg = 'Password minimal 6 karakter');
      return;
    }

    if (password != confirmPass) {
      setState(() => _errorMsg = 'Password dan konfirmasi tidak cocok');
      return;
    }

    if (!RegExp(r'^[a-zA-Z0-9_]+$').hasMatch(username)) {
      setState(() => _errorMsg = 'Username hanya boleh huruf, angka, dan _');
      return;
    }

    setState(() { _isLoading = true; _errorMsg = null; });

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/api/auth/register"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );
      final data = jsonDecode(res.body);

      if (data['success'] != true) {
        setState(() {
          _isLoading = false;
          _errorMsg = data['message'] ?? 'Registrasi gagal';
        });
        return;
      }

      // Registration success - auto login
      setState(() {
        _isLoading = false;
        _errorMsg = null;
      });

      // Switch to login mode and auto-login
      _handleLogin();

    } catch (_) {
      setState(() {
        _isLoading = false;
        _errorMsg = 'Gagal terhubung ke server. Coba lagi nanti.';
      });
    }
  }

  // ── Login ───────────────────────────────────────────────────────
  Future<void> _handleLogin() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      setState(() => _errorMsg = 'Username dan password harus diisi');
      return;
    }

    setState(() { _isLoading = true; _errorMsg = null; });

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/api/auth/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );
      final data = jsonDecode(validate.body);

      if (data['expired'] == true) {
        setState(() {
          _isLoading = false;
          _errorMsg = 'Akses kamu sudah expired. Hubungi admin untuk perpanjang.';
        });
        return;
      }

      if (data['valid'] != true) {
        setState(() {
          _isLoading = false;
          _errorMsg = 'Username atau password salah. Coba lagi.';
        });
        return;
      }

      // Valid - save credentials
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString("username", username);
      await prefs.setString("password", password);
      await prefs.setString("key", data['key']);

      if (mounted) {
        Navigator.pushReplacementNamed(context, '/splash', arguments: {
          'username': username, 'password': password,
          'role': data['role'], 'key': data['key'],
          'expiredDate': data['expiredDate'],
          'listBug': data['listBug'] ?? [],
          'listPayload': data['listPayload'] ?? [],
          'listDDoS': data['listDDoS'] ?? [],
          'news': data['news'] ?? [],
        });
      }
    } catch (_) {
      setState(() {
        _isLoading = false;
        _errorMsg = 'Gagal terhubung ke server. Coba lagi nanti.';
      });
    }
  }

  void _toggleMode() {
    setState(() {
      _isRegisterMode = !_isRegisterMode;
      _errorMsg = null;
      userController.clear();
      passController.clear();
      confirmPassController.clear();
    });
  }

  void _openTelegram() async {
    final uri = Uri.parse("tg://resolve?domain=YakuzaXSilence");
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      await launchUrl(Uri.parse("https://t.me/YakuzaXSilence"), mode: LaunchMode.externalApplication);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final sw = mq.size.width;
    final sh = mq.size.height;

    return Scaffold(
      backgroundColor: const Color(0xFF070710),
      body: Stack(
        children: [
          // ── Video Background ──
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0a0a1a), Color(0xFF070710), Color(0xFF0d0b1e)],
                ),
              ),
            ),

          // ── Dark overlay ──
          Container(color: Colors.black.withOpacity(0.55)),

          // ── Subtle radial glow ──
          Positioned(
            top: -sh * 0.15,
            right: -sw * 0.2,
            child: Container(
              width: sw * 0.8,
              height: sw * 0.8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF6366F1).withOpacity(0.08),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // ── Content ──
          FadeTransition(
            opacity: _fadeAnimation,
            child: SlideTransition(
              position: _slideAnimation,
              child: SafeArea(
                child: Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 40),

                        const SizedBox(height: 16),

                        // ── App Name ──
                        const Text(
                          'YakuzaXsilence',
                          style: TextStyle(
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 26,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                            letterSpacing: 4,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _isRegisterMode ? 'CREATE ACCOUNT' : 'SECURE ACCESS PORTAL',
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 10,
                            letterSpacing: 4,
                            color: Colors.white.withOpacity(0.35),
                          ),
                        ),

                        const SizedBox(height: 48),

                        // ── Login/Register Card ──
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.06),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.08),
                              width: 0.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.3),
                                blurRadius: 20,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              // Mode toggle header
                              Row(
                                children: [
                                  Expanded(
                                  child: GestureDetector(
                                    onTap: _isRegisterMode ? _toggleMode : null,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: 10),
                                      decoration: BoxDecoration(
                                        border: Border(
                                          bottom: BorderSide(
                                            color: !_isRegisterMode
                                                ? const Color(0xFF6366F1)
                                                : Colors.transparent,
                                            width: 2,
                                          ),
                                        ),
                                      ),
                                      child: Text(
                                        'SIGN IN',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontFamily: 'MADEEvolveSansEVO',
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 2,
                                          color: !_isRegisterMode
                                              ? Colors.white
                                              : Colors.white.withOpacity(0.35),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                  child: GestureDetector(
                                    onTap: !_isRegisterMode ? _toggleMode : null,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: 10),
                                      decoration: BoxDecoration(
                                        border: Border(
                                          bottom: BorderSide(
                                            color: _isRegisterMode
                                                ? const Color(0xFF6366F1)
                                                : Colors.transparent,
                                            width: 2,
                                          ),
                                        ),
                                      ),
                                      child: Text(
                                        'REGISTER',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontFamily: 'MADEEvolveSansEVO',
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 2,
                                          color: _isRegisterMode
                                              ? Colors.white
                                              : Colors.white.withOpacity(0.35),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),

                              const SizedBox(height: 24),

                              // Username
                              _buildInputField(
                                controller: userController,
                                icon: FontAwesomeIcons.user,
                                hint: 'Username',
                                obscure: false,
                              ),
                              const SizedBox(height: 16),

                              // Password
                              _buildInputField(
                                controller: passController,
                                icon: FontAwesomeIcons.lock,
                                hint: 'Password',
                                obscure: _isObscure,
                                suffix: GestureDetector(
                                  onTap: () => setState(() => _isObscure = !_isObscure),
                                  child: Icon(
                                    _isObscure ? FontAwesomeIcons.eyeSlash : FontAwesomeIcons.eye,
                                    color: Colors.white.withOpacity(0.3),
                                    size: 16,
                                  ),
                                ),
                              ),

                              // Confirm Password (register only)
                              if (_isRegisterMode) ...[
                                const SizedBox(height: 16),
                                _buildInputField(
                                  controller: confirmPassController,
                                  icon: FontAwesomeIcons.lock,
                                  hint: 'Confirm Password',
                                  obscure: _isObscureConfirm,
                                  suffix: GestureDetector(
                                    onTap: () => setState(() => _isObscureConfirm = !_isObscureConfirm),
                                    child: Icon(
                                      _isObscureConfirm ? FontAwesomeIcons.eyeSlash : FontAwesomeIcons.eye,
                                      color: Colors.white.withOpacity(0.3),
                                      size: 16,
                                    ),
                                  ),
                                ),

                                const SizedBox(height: 12),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF6366F1).withOpacity(0.08),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: const Color(0xFF6366F1).withOpacity(0.15),
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(
                                        FontAwesomeIcons.circleInfo,
                                        color: const Color(0xFF6366F1).withOpacity(0.6),
                                        size: 12,
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          'Akun free trial 1 hari. Hubungi @kiuchan11 untuk upgrade.',
                                          style: TextStyle(
                                            fontFamily: 'ShareTechMono',
                                            fontSize: 9,
                                            color: Colors.white.withOpacity(0.4),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],

                              // Error message
                              if (_errorMsg != null) ...[
                                const SizedBox(height: 14),
                                Row(
                                  children: [
                                    const Icon(Icons.error_outline_rounded, color: Color(0xFFFF6B8A), size: 16),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        _errorMsg!,
                                        style: const TextStyle(
                                          color: Color(0xFFFF6B8A),
                                          fontSize: 12,
                                          fontFamily: 'ShareTechMono',
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],

                              const SizedBox(height: 24),

                              // Login/Register Button
                              _buildActionButton(),

                              const SizedBox(height: 16),

                              // Contact Admin
                              Center(
                                child: GestureDetector(
                                  onTap: _openTelegram,
                                  child: Text(
                                    'Need help? Contact @kiuchan11',
                                    style: TextStyle(
                                      color: const Color(0xFF6366F1).withOpacity(0.7),
                                      fontSize: 11,
                                      fontFamily: 'ShareTechMono',
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 32),

                        // ── Version tag ──
                        Text(
                          'v4.2.0 · ENCRYPTED',
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 8,
                            letterSpacing: 3,
                            color: Colors.white.withOpacity(0.1),
                          ),
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Action Button (Login or Register) ──────────────────────────
  Widget _buildActionButton() {
    final label = _isRegisterMode ? 'CREATE ACCOUNT' : 'SIGN IN';
    return GestureDetector(
      onTap: _isLoading ? null : (_isRegisterMode ? _handleRegister : _handleLogin),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: 52,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: _isLoading
                ? [const Color(0xFF4338CA), const Color(0xFF4338CA)]
                : [const Color(0xFF6366F1), const Color(0xFF7C3AED)],
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF6366F1).withOpacity(_isLoading ? 0.1 : 0.35),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: _isLoading
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'MADEEvolveSansEVO',
                    letterSpacing: 3,
                  ),
                ),
        ),
      ),
    );
  }

  // ── Input Field (iOS Style) ─────────────────────────────────────
  Widget _buildInputField({
    required TextEditingController controller,
    required IconData icon,
    required String hint,
    required bool obscure,
    Widget? suffix,
  }) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06), width: 0.5),
      ),
      child: Row(
        children: [
          const SizedBox(width: 16),
          Icon(icon, color: Colors.white.withOpacity(0.25), size: 16),
          const SizedBox(width: 12),
          Expanded(
            child: TextField(
              controller: controller,
              obscureText: obscure,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontFamily: 'ShareTechMono',
                decoration: TextDecoration.none,
              ),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(
                  color: Colors.white.withOpacity(0.2),
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.only(bottom: 12),
              ),
            ),
          ),
          if (suffix != null) ...[
            const SizedBox(width: 4),
            Padding(
              padding: const EdgeInsets.only(right: 14),
              child: suffix,
            ),
          ] else
            const SizedBox(width: 16),
        ],
      ),
    );
  }
}
