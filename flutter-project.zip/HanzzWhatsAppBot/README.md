# Hanzz WhatsApp Bot
Proyek APK Android berupa panel demo bot WhatsApp.

## Build di Termux
pkg update -y && pkg upgrade -y
pkg install -y openjdk-17 gradle
cd HanzzWhatsAppBot
gradle assembleDebug

APK:
app/build/outputs/apk/debug/app-debug.apk

Catatan:
APK ini adalah panel demo. Bot Baileys yang benar-benar terhubung ke WhatsApp sebaiknya berjalan sebagai service Node.js di Termux/server. Jangan gunakan untuk spam, crash, atau mengganggu akun orang lain.
