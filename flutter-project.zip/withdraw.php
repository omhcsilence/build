<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$my_id = $_SESSION['user_id'];
$users = json_decode(file_get_contents('data/users.json'), true);
$user_data = $users[$my_id] ?? null;

if (!$user_data || $user_data['saldo'] < 210000 || !$user_data['joined_group']) {
    die("Akses ditolak. Anda belum memenuhi syarat penarikan dana.");
}

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim(htmlspecialchars($_POST['nama']));
    $nomor = trim(htmlspecialchars($_POST['nomor']));
    $nominal = intval($_POST['nominal']);

    if (empty($nama) || empty($nomor) || $nominal <= 0) {
        $error = "Semua field formulir wajib diisi dengan benar.";
    } elseif ($nominal < 210000) {
        $error = "Minimal penarikan dana adalah Rp 210.000.";
    } elseif ($nominal > $user_data['saldo']) {
        $error = "Saldo Anda saat ini tidak mencukupi.";
    } else {
        // Ambil Data Withdraw Eksis
        $withdraws = json_decode(file_get_contents('data/withdraw.json'), true);
        
        $wd_id = 'WD' . rand(10000, 99999);
        $withdraws[$wd_id] = [
            'id' => $wd_id,
            'user_id' => $my_id,
            'nama' => $nama,
            'nomor' => $nomor,
            'nominal' => $nominal,
            'status' => 'PENDING',
            'date' => date('Y-m-d H:i:s')
        ];
        
        // Potong Saldo User Langsung
        $users[$my_id]['saldo'] -= $nominal;
        
        // Simpan Kedua Perubahan Data ke File JSON
        file_put_contents('data/withdraw.json', json_encode($withdraws, JSON_PRETTY_PRINT));
        file_put_contents('data/users.json', json_encode($users, JSON_PRETTY_PRINT));
        
        $success = "Pengajuan penarikan dana diproses! Mohon tunggu konfirmasi admin.";
        $user_data['saldo'] -= $nominal; // Sinkronisasi tampilan lokal
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tarik Saldo</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Roboto, sans-serif; }
        body { background: #f4f7fe; padding: 20px; display: flex; justify-content: center; }
        .container { width: 100%; max-width: 450px; }
        .card { background: white; border-radius: 24px; padding: 30px 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.03); }
        h2 { font-size: 22px; color: #1a237e; margin-bottom: 20px; text-align: center; }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-size: 14px; font-weight: 600; color: #495057; margin-bottom: 8px; }
        input { width: 100%; padding: 16px; border: 1px solid #ced4da; border-radius: 12px; font-size: 16px; outline: none; transition: border 0.2s; }
        input:focus { border-color: #2979ff; }
        .btn-submit { display: block; width: 100%; background: linear-gradient(135deg, #2979ff, #1565c0); color: white; border: none; padding: 18px; border-radius: 16px; font-size: 16px; font-weight: 600; cursor: pointer; margin-top: 25px; }
        .alert { padding: 15px; border-radius: 12px; font-size: 14px; font-weight: 500; margin-bottom: 20px; text-align: center; }
        .alert-error { background: #ffebee; color: #c62828; }
        .alert-success { background: #e8f5e9; color: #2e7d32; }
        .btn-back { display: block; text-align: center; margin-top: 20px; color: #666; text-decoration: none; font-size: 14px; }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <h2>Form Penarikan Dana</h2>
        
        <?php if(!empty($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if(!empty($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Nama Sesuai Rekening / E-Wallet</label>
                <input type="text" name="nama" placeholder="Contoh: Budi Santoso" required>
            </div>
            <div class="form-group">
                <label>Nomor Rekening / HP Dana/OVO</label>
                <input type="number" name="nomor" placeholder="Contoh: 08123456789" required>
            </div>
            <div class="form-group">
                <label>Nominal Penarikan (Maks: Rp <?php echo number_format($user_data['saldo'], 0,',','.'); ?>)</label>
                <input type="number" name="nominal" min="210000" max="<?php echo $user_data['saldo']; ?>" value="<?php echo $user_data['saldo']; ?>" required>
            </div>
            <button type="submit" class="btn-submit">Kirim Pengajuan</button>
        </form>
        
        <a href="dashboard.php" class="btn-back">← Kembali ke Dashboard</a>
    </div>
</div>

</body>
</html>
