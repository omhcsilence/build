module.exports = {

  TELEGRAM_BOT_TOKEN: "tokenbotlu", // token bot tele lu
  OWNER_TELEGRAM_ID: 6143435003, // ada di database.json juga jangan lupa diganti yakk
  DEFAULT_OWNER_USERNAME: "panness", // username owner buat login web
  DEFAULT_OWNER_PASSWORD: "123", // password owner buat login web (bisa diubah di sini)

  // URL Base dashboard website untuk menghasilkan tautan akses akun
  DASHBOARD_URL: "http://localhost:3000", // ganti pake link panel + port 

  // WhatsApp API Server configuration
  WA_SERVER_PORT: 3000, // port panel
  WA_SERVER_URL: "http://localhost:3000", // ini juga

  CREDITS: ["Vanness Wangsaff", "Baileys"] // ngehapus nama gw = error, ga percaya coba aja :v
};
