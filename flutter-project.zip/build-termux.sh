#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "== Simple APK build =="
if [ ! -d "$HOME/.gradle" ]; then
  echo "Gradle cache belum ada. Pastikan Gradle tersedia."
fi
if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug
else
  echo "Gradle tidak ditemukan."
  echo "Install Gradle/Android build environment terlebih dahulu."
  exit 1
fi
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
