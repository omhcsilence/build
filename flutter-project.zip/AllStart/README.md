# AllStart

A Flutter application with a **black & white liquid glass** UI theme, crafted by **Developer OmhcSilence**.

## Theme

- Black background with floating white "liquid" blobs (animated)
- Frosted glass cards with `BackdropFilter` blur
- White-on-black typography with the `Made` font
- Animated "Developer OmhcSilence" credit (typewriter + shimmer effects)
- Tidy 2x2 quick-actions grid on the dashboard
- Floating glass bottom navigation bar

## Build

This is a standard Flutter project. To build the APK:

```bash
flutter pub get
flutter run               # debug on a connected device / emulator
flutter build apk --release   # release APK at build/app/outputs/flutter-apk/
```

> **Note:** Requires Flutter SDK `^3.8.1` and Android SDK with `compileSdk = 36`, `minSdk = 21`.

## Server / API Endpoint

The app talks to a backend exposed through a **Cloudflare Tunnel**:

- **HTTP API:** `https://omhc-host-premium.yakuza.biz.id`
- **WebSocket:** `wss://omhc-host-premium.yakuza.biz.id`

Both HTTP and WS go through the same tunnel host. To run the tunnel locally:

```bash
cloudflared tunnel run --protocol http2 \
  --url http://localhost:5024 \
  --token <your-token>
```

The tunnel routes `https://omhc-host-premium.yakuza.biz.id` → `http://localhost:5024`,
so make sure your backend server listens on port `5024` (or change the `--url` target
to match whatever port your server actually uses).

The endpoint URLs are defined in each `lib/*.dart` file as `const String _baseUrl`
(or `_kBase` / `baseUrl`). To switch domains later, just do a project-wide find/replace
of `omhc-host-premium.yakuza.biz.id`.

## Project Structure

```
lib/
├── main.dart              # App entry + routing
├── theme.dart             # Shared theme: AppColors, LiquidCard, LiquidBackground,
│                          #   TypewriterText, ShimmerText, MarqueeText, PulseDot
├── landing.dart           # Landing onboarding + Sign In / Buy Access
├── splash.dart            # Video splash + AllStart logo + Developer OmhcSilence
├── login_page.dart        # Liquid glass login form
├── dashboard_page.dart    # Main dashboard with quick actions, video banner, etc.
├── chat.dart              # Chat page (themed)
├── owner_page.dart        # Owner admin page (themed)
├── tqto.dart              # Thanks-to page (themed)
├── device_permission.dart # Device permission manager (themed)
├── control_panel.dart     # Remote control panel (themed)
└── device_dashboard.dart  # Device dashboard (themed)
```

## Credits

- **Developer:** OmhcSilence
- **Brand:** AllStart
- **Originally supported by:** Motion Team
