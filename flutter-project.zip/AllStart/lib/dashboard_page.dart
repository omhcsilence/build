import 'dart:async';
import 'dart:convert';
import 'dart:math' as dart_math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

import 'owner_page.dart';
import 'login_page.dart';
import 'device_dashboard.dart' hide ShadowUtils;
import 'tqto.dart';
import 'chat.dart';
import 'theme.dart';

// ─── GLASS CARD ──────────────────────────────────────────────────
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double radius;
  final Color? borderColor;
  final Color? bgColor;
  final List<Color>? gradient;
  final bool hasShadow;
  final VoidCallback? onTap;

  const _GlassCard({
    required this.child,
    this.padding,
    this.radius = 24,
    this.borderColor,
    this.bgColor,
    this.gradient,
    this.hasShadow = true,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final container = Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: gradient != null
            ? LinearGradient(
                colors: gradient!,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : LinearGradient(
                colors: [
                  (bgColor ?? const Color(0x1AFFFFFF)),
                  (bgColor ?? const Color(0x0DFFFFFF)).withOpacity(0.04),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        border: Border.all(
          color: borderColor ?? const Color(0x33FFFFFF),
          width: 0.6,
        ),
        boxShadow: hasShadow ? ShadowUtils.card : null,
      ),
      child: child,
    );

    final layered = ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: container,
      ),
    );

    if (onTap != null) {
      return _AnimatedCard(onTap: onTap!, child: layered);
    }
    return layered;
  }
}

class _AnimatedCard extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;

  const _AnimatedCard({required this.child, required this.onTap});

  @override
  State<_AnimatedCard> createState() => _AnimatedCardState();
}

class _AnimatedCardState extends State<_AnimatedCard> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.98 : 1.0,
        child: widget.child,
      ),
    );
  }
}

// ─── LIQUID HEX/GRID BACKGROUND (monochrome) ───────────────────────────
class _HexBackground extends StatelessWidget {
  final Widget child;
  const _HexBackground({required this.child});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _HexPainter(),
      child: child,
    );
  }
}

class _HexPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // White radial blobs (very subtle)
    final glowPaint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 80)
      ..shader = RadialGradient(
        colors: [
          Colors.white.withOpacity(0.12),
          Colors.white.withOpacity(0.04),
          Colors.transparent
        ],
      ).createShader(
          Rect.fromCircle(center: Offset.zero, radius: size.width * 0.6));
    canvas.drawCircle(Offset.zero, size.width * 0.6, glowPaint);

    final glowPaint2 = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 80)
      ..shader = RadialGradient(
        colors: [Colors.white.withOpacity(0.10), Colors.transparent],
      ).createShader(Rect.fromCircle(
          center: Offset(size.width, size.height),
          radius: size.width * 0.5));
    canvas.drawCircle(
        Offset(size.width, size.height), size.width * 0.5, glowPaint2);

    // Hex grid (white hairline)
    final hexWidth = 60.0;
    final hexHeight = hexWidth * dart_math.sqrt(3) / 2;
    final cols = (size.width / hexWidth).ceil() + 2;
    final rows = (size.height / hexHeight).ceil() + 2;

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5
      ..color = Colors.white.withOpacity(0.04);

    for (int row = -1; row < rows; row++) {
      for (int col = -1; col < cols; col++) {
        final x = col * hexWidth + (row % 2) * hexWidth / 2;
        final y = row * hexHeight * 0.75;

        final path = Path();
        for (int i = 0; i < 6; i++) {
          final angle = i * dart_math.pi * 2 / 6;
          final px = x + hexWidth / 2 + dart_math.cos(angle) * hexWidth / 2;
          final py = y + hexHeight / 2 + dart_math.sin(angle) * hexHeight / 2;
          if (i == 0)
            path.moveTo(px, py);
          else
            path.lineTo(px, py);
        }
        path.close();
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ─── PULSE DOT ────────────────────────────────────────────────────
class _PulseDot extends StatefulWidget {
  final Color color;
  const _PulseDot({required this.color});
  @override
  State<_PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<_PulseDot> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _a,
        builder: (_, __) => Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color.withOpacity(_a.value),
            boxShadow: [
              BoxShadow(color: widget.color.withOpacity(0.5), blurRadius: 6)
            ],
          ),
        ),
      );
}

// ─── TYPEWRITER TEXT ───────────────────────────────────────────────
class _TypewriterText extends StatefulWidget {
  final String text;
  final TextStyle style;
  const _TypewriterText({required this.text, required this.style});
  @override
  State<_TypewriterText> createState() => _TypewriterTextState();
}

class _TypewriterTextState extends State<_TypewriterText>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<int> _charAnim;
  late Timer _restartTimer;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this,
        duration: Duration(milliseconds: widget.text.length * 70));
    _charAnim = IntTween(begin: 0, end: widget.text.length)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _ctrl.forward();
    _restartTimer = Timer.periodic(const Duration(seconds: 8), (_) {
      if (mounted) {
        _ctrl.reset();
        _ctrl.forward();
      }
    });
  }
  @override
  void dispose() {
    _ctrl.dispose();
    _restartTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _charAnim,
      builder: (_, __) {
        final displayed = widget.text.substring(0, _charAnim.value);
        return Row(mainAxisSize: MainAxisSize.min, children: [
          Text(displayed, style: widget.style),
          if (_charAnim.value < widget.text.length)
            Text('|', style: widget.style.copyWith(color: Colors.white)),
        ]);
      },
    );
  }
}

// ─── SHIMMER TEXT (for Developer OmhcSilence) ─────────────────────
class _ShimmerText extends StatefulWidget {
  final String text;
  final TextStyle baseStyle;
  final Duration duration;

  const _ShimmerText({
    required this.text,
    required this.baseStyle,
    this.duration = const Duration(milliseconds: 2500),
  });

  @override
  State<_ShimmerText> createState() => _ShimmerTextState();
}

class _ShimmerTextState extends State<_ShimmerText>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration)..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        return ShaderMask(
          shaderCallback: (bounds) {
            final sweep = _c.value * 2 - 0.5;
            return LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: const [
                Color(0xFF5A5A5A),
                Color(0xFFBDBDBD),
                Color(0xFFFFFFFF),
                Color(0xFFBDBDBD),
                Color(0xFF5A5A5A),
              ],
              stops: [
                (sweep - 0.4).clamp(0.0, 1.0),
                (sweep - 0.15).clamp(0.0, 1.0),
                (sweep).clamp(0.0, 1.0),
                (sweep + 0.15).clamp(0.0, 1.0),
                (sweep + 0.4).clamp(0.0, 1.0),
              ],
            ).createShader(bounds);
          },
          child: Text(
            widget.text,
            style: widget.baseStyle.copyWith(color: Colors.white),
          ),
        );
      },
    );
  }
}

// ─── BANNER CAROUSEL ──────────────────────────────────────────────
class _BannerCarousel extends StatefulWidget {
  final List<Map<String, dynamic>> banners;
  const _BannerCarousel({required this.banners});

  @override
  State<_BannerCarousel> createState() => _BannerCarouselState();
}

class _BannerCarouselState extends State<_BannerCarousel> {
  late PageController _pageCtrl;
  int _current = 0;
  Timer? _autoTimer;

  @override
  void initState() {
    super.initState();
    _pageCtrl = PageController();
    if (widget.banners.isNotEmpty) {
      _autoTimer = Timer.periodic(const Duration(seconds: 5), (_) {
        if (!mounted) return;
        final next = (_current + 1) % widget.banners.length;
        _pageCtrl.animateToPage(next,
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeInOut);
      });
    }
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    _autoTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.banners.isEmpty) return const SizedBox();
    return Column(
      children: [
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _pageCtrl,
            itemCount: widget.banners.length,
            onPageChanged: (i) => setState(() => _current = i),
            itemBuilder: (_, i) {
              final banner = widget.banners[i];
              final imagePath = banner['image'] ?? '';
              final text = banner['text'] ?? '';
              final subtext = banner['subtext'] ?? '';
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.25),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.10),
                      blurRadius: 20,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.asset(
                        imagePath,
                        fit: BoxFit.cover,
                        color: Colors.black.withOpacity(0.35),
                        colorBlendMode: BlendMode.darken,
                        errorBuilder: (_, __, ___) => Container(
                          color: AppColors.surface2,
                          child: const Icon(Icons.image_rounded,
                              color: Colors.white54),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.75)
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 16,
                        bottom: 16,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              text,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                                shadows: [
                                  Shadow(
                                      color: Colors.black87, blurRadius: 4),
                                ],
                              ),
                            ),
                            if (subtext.isNotEmpty)
                              Text(
                                subtext,
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                  shadows: [
                                    Shadow(
                                        color: Colors.black87,
                                        blurRadius: 4),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            widget.banners.length,
            (di) => AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: di == _current ? 24 : 6,
              height: 4,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2),
                color: di == _current
                    ? Colors.white
                    : Colors.white.withOpacity(0.25),
                boxShadow: di == _current
                    ? [
                        BoxShadow(
                            color: Colors.white.withOpacity(0.5),
                            blurRadius: 4)
                      ]
                    : null,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ─── VIDEO BANNER WIDGET ──────────────────────────────────────────
class _VideoBanner extends StatefulWidget {
  final String videoPath;
  const _VideoBanner({required this.videoPath});

  @override
  State<_VideoBanner> createState() => _VideoBannerState();
}

class _VideoBannerState extends State<_VideoBanner> {
  late VideoPlayerController _controller;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset(widget.videoPath)
      ..initialize().then((_) {
        setState(() {
          _isInitialized = true;
        });
        _controller.setLooping(true);
        _controller.play();
      }).catchError((error) {
        debugPrint('Error loading video: $error');
        setState(() {
          _isInitialized = true;
        });
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withOpacity(0.25),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.white.withOpacity(0.10),
            blurRadius: 25,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.06),
            blurRadius: 15,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: AspectRatio(
          aspectRatio: 16 / 9,
          child: _isInitialized && _controller.value.isInitialized
              ? Stack(
                  alignment: Alignment.center,
                  children: [
                    VideoPlayer(_controller),
                    // Dark overlay for cohesion
                    Container(
                      color: Colors.black.withOpacity(0.15),
                    ),
                    Positioned(
                      bottom: 12,
                      right: 12,
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _controller.value.isPlaying
                                ? _controller.pause()
                                : _controller.play();
                          });
                        },
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: BackdropFilter(
                            filter: ImageFilter.blur(
                                sigmaX: 10, sigmaY: 10),
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.18),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.35),
                                  width: 1,
                                ),
                              ),
                              child: Icon(
                                _controller.value.isPlaying
                                    ? Icons.pause
                                    : Icons.play_arrow,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                        height: 3,
                        color: Colors.black.withOpacity(0.3),
                        child: FractionallySizedBox(
                          widthFactor: _controller.value.isInitialized
                              ? _controller.value.position.inMilliseconds /
                                  _controller.value.duration.inMilliseconds
                              : 0,
                          child: Container(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                )
              : Container(
                  color: AppColors.surface2,
                  child: const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(color: Colors.white),
                        SizedBox(height: 12),
                        Text(
                          'Loading video...',
                          style: TextStyle(
                            color: Colors.white54,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        ),
      ),
    );
  }
}

// ─── ENHANCED THANKS TO WIDGET ─────────────────────────────────────
class _ThanksToWidget extends StatelessWidget {
  const _ThanksToWidget();

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      radius: 20,
      borderColor: Colors.white.withOpacity(0.25),
      onTap: () => Navigator.push(
          context, _createRoute(const ThanksToPage())),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Colors.white, Colors.white70]),
              borderRadius: BorderRadius.circular(14),
              boxShadow: ShadowUtils.soft,
              border:
                  Border.all(color: Colors.white.withOpacity(0.4), width: 0.5),
            ),
            child: const Icon(Icons.favorite_rounded,
                color: Colors.black, size: 18),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Thanks To',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14)),
                Text('Orang orang yang berkontribusi',
                    style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios_rounded,
              color: Colors.white, size: 14),
        ],
      ),
    );
  }
}

// ─── SELECT DEVICES WIDGET ─────────────────────────────────────
class _SelectDevicesWidget extends StatefulWidget {
  final String sessionKey;
  const _SelectDevicesWidget({required this.sessionKey});

  @override
  State<_SelectDevicesWidget> createState() => _SelectDevicesWidgetState();
}

class _SelectDevicesWidgetState extends State<_SelectDevicesWidget> {
  List<dynamic> _devices = [];
  bool _loading = true;
  static const String _kBase = 'https://api-service.yakuza.biz.id';

  @override
  void initState() {
    super.initState();
    _loadDevices();
  }

  Future<void> _loadDevices() async {
    try {
      final response = await http.get(
        Uri.parse('$_kBase/rat/my-devices?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        if (body['valid'] == true) {
          setState(() {
            _devices = body['devices'] ?? [];
            _loading = false;
          });
        }
      }
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      radius: 20,
      borderColor: Colors.white.withOpacity(0.2),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Colors.white, Colors.white70]),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.devices_rounded,
                    color: Colors.black, size: 16),
              ),
              const SizedBox(width: 10),
              const Text(
                'SELECT DEVICES',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              Text(
                '${_devices.length} devices',
                style: const TextStyle(color: Colors.white54, fontSize: 11),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_loading)
            const Center(child: CircularProgressIndicator(color: Colors.white))
          else if (_devices.isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  'Belum ada device terhubung',
                  style: TextStyle(color: Colors.white54, fontSize: 12),
                ),
              ),
            )
          else
            SizedBox(
              height: 60,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _devices.length,
                itemBuilder: (ctx, i) {
                  final d = _devices[i];
                  final isOnline = d['online'] == true;
                  return Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: isOnline
                          ? Colors.white.withOpacity(0.15)
                          : Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isOnline
                            ? Colors.white.withOpacity(0.4)
                            : Colors.white.withOpacity(0.1),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.phone_android_rounded,
                          color: isOnline ? Colors.white : Colors.white38,
                          size: 16,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          d['model']?.toString() ?? 'Unknown',
                          style: TextStyle(
                            color: isOnline ? Colors.white : Colors.white54,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: isOnline ? Colors.white : Colors.white38,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}

// ─── TELEGRAM COMMUNITY WIDGET ────────────────────────────────────
class _TelegramCommunityWidget extends StatelessWidget {
  const _TelegramCommunityWidget();

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      radius: 20,
      borderColor: Colors.white.withOpacity(0.25),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Colors.white, Colors.white70]),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: ShadowUtils.soft,
                  border: Border.all(
                      color: Colors.white.withOpacity(0.4), width: 0.5),
                ),
                child: const Icon(FontAwesomeIcons.telegram,
                    color: Colors.black, size: 18),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Telegram Community',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 15),
                    ),
                    Text(
                      'Gabung ke grup telegram kami untuk mendapatkan berita terbaru, bantuan support dari admin, serta berdiskusi bersama anggota lainnya secara langsung.',
                      style: TextStyle(
                          color: Colors.white70, fontSize: 11),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () async {
              final uri = Uri.parse('https://t.me/+byTclDlpfUc1MTJl');
              if (await canLaunchUrl(uri)) await launchUrl(uri);
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [Colors.white, Colors.white70]),
                borderRadius: BorderRadius.circular(12),
                boxShadow: ShadowUtils.soft,
                border: Border.all(
                    color: Colors.white.withOpacity(0.4), width: 0.5),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(FontAwesomeIcons.telegram,
                      color: Colors.black, size: 16),
                  SizedBox(width: 8),
                  Text(
                    'Join Community',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── DEVELOPER OMHCSILENCE STRIP (animated credit) ───────────────
class _DeveloperCreditStrip extends StatelessWidget {
  const _DeveloperCreditStrip();

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      radius: 18,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      borderColor: Colors.white.withOpacity(0.22),
      child: Row(
        children: [
          // Pulsing dot
          const _PulseDot(color: Colors.white),
          const SizedBox(width: 12),
          const Icon(Icons.code_rounded, color: Colors.white, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'CRAFTED BY',
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                  ),
                ),
                _ShimmerText(
                  text: 'Developer OmhcSilence',
                  baseStyle: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                    fontFamily: 'Made',
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.auto_awesome_rounded,
              color: Colors.white70, size: 16),
        ],
      ),
    );
  }
}

// ─── MAIN DASHBOARD PAGE ───────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

const String _kBase = 'https://api-service.yakuza.biz.id';

Route _createRoute(Widget page) {
  return PageRouteBuilder(
    transitionDuration: const Duration(milliseconds: 400),
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const curve = Curves.easeOutCubic;
      var tween = Tween(begin: const Offset(0.03, 0.0), end: Offset.zero)
          .chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);
      var fadeTween = Tween(begin: 0.0, end: 1.0)
          .chain(CurveTween(curve: curve));
      var fadeAnimation = animation.drive(fadeTween);
      return FadeTransition(
        opacity: fadeAnimation,
        child: SlideTransition(
          position: offsetAnimation,
          child: child,
        ),
      );
    },
  );
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late WebSocketChannel channel;
  late String sessionKey, username, role, expiredDate;
  String androidId = "unknown";
  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    role = widget.role;
    expiredDate = widget.expiredDate;

    _fadeCtrl = AnimationController(
        duration: const Duration(milliseconds: 500), vsync: this);
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic);
    _fadeCtrl.forward();

    _selectedPage = _buildDashboardHome();
    _initAndroidIdAndConnect();
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectWebSocket();
  }

  void _connectWebSocket() {
    channel = WebSocketChannel.connect(
        Uri.parse('wss://ws:api-service.yakuza.biz.id:4000'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId
    }));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false)
        _showSessionExpired();
    });
  }

  void _showSessionExpired() async {
    await SharedPreferences.getInstance().then((p) => p.clear());
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          radius: 24,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Colors.white, Colors.white70]),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: Colors.black, size: 24),
              ),
              const SizedBox(height: 12),
              const Text("Session Expired",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16)),
              const SizedBox(height: 8),
              const Text("Silakan login kembali",
                  style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 16),
              _AnimatedDialogButton(
                text: "OK",
                onTap: () => Navigator.pushAndRemoveUntil(
                    context,
                    _createRoute(const LoginPage()),
                    (r) => false),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onNavTapped(int index) {
    HapticFeedback.lightImpact();
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildDashboardHome();
      } else if (index == 1) {
        _selectedPage = ChatPage(
          username: username,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = DeviceDashboardPage(
            username: username, role: role, sessionKey: sessionKey);
      }
    });
  }

  void _navigateToOwner() => Navigator.push(context,
      _createRoute(OwnerPage(sessionKey: sessionKey, username: username)));
  void _showAccountSheet() => showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _AccountSheet(
          username: username,
          role: role,
          expiredDate: expiredDate,
          onLogout: _showLogoutDialog));

  Widget _buildDashboardHome() {
    return _HexBackground(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // === Hero header card: AllStart brand + animated dev credit ===
            _HeroHeader(
              username: username,
              role: role,
              expiredDate: expiredDate,
            ),
            const SizedBox(height: 16),

            // === Quick Actions grid (tidy button layout) ===
            const _QuickActionsGrid(),
            const SizedBox(height: 16),

            // === Main Banner Video ===
            const _VideoBanner(
              videoPath: 'assets/videos/flux.mp4',
            ),
            const SizedBox(height: 16),

            // === Animated Developer Credit (always visible) ===
            const _DeveloperCreditStrip(),
            const SizedBox(height: 16),

            const _ThanksToWidget(),
            const SizedBox(height: 16),

            // === Banner Carousel ===
            _BannerCarousel(banners: const [
              {'image': 'assets/images/p.jpg', 'text': 'AllStart'},
              {'image': 'assets/images/l.jpg', 'text': 'AllStart Founder'},
            ]),
            const SizedBox(height: 16),

            _SelectDevicesWidget(sessionKey: sessionKey),
            const SizedBox(height: 16),

            const _TelegramCommunityWidget(),

            const SizedBox(height: 24),
            // === Footer credit (shimmer) ===
            Center(
              child: _ShimmerText(
                text: 'DEVELOPER OMHCSILENCE • ALLSTART',
                baseStyle: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 4,
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Center(
              child: Text(
                '© 2026 AllStart',
                style: TextStyle(color: Colors.white38, fontSize: 10),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── FLOATING PILL BOTTOM NAVIGATION ────────────────────────────────────
  Widget _buildBottomNav() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              height: 68,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.0,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.white.withOpacity(0.08),
                    blurRadius: 24,
                    spreadRadius: 2,
                    offset: const Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    blurRadius: 16,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                children: [
                  _FloatingNavItem(
                    icon: Icons.grid_view_rounded,
                    label: 'Home',
                    isActive: _bottomNavIndex == 0,
                    onTap: () => _onNavTapped(0),
                  ),
                  _FloatingNavItem(
                    icon: Icons.chat_bubble_outline_rounded,
                    activeIcon: Icons.chat_bubble_rounded,
                    label: 'Chat',
                    isActive: _bottomNavIndex == 1,
                    onTap: () => _onNavTapped(1),
                  ),
                  _FloatingNavItem(
                    icon: Icons.devices_outlined,
                    activeIcon: Icons.devices_rounded,
                    label: 'Device',
                    isActive: _bottomNavIndex == 2,
                    onTap: () => _onNavTapped(2),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      toolbarHeight: 60,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu_rounded, color: Colors.white),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
      ),
      title: Row(
        children: [
          // Logo mark
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Colors.white, Colors.white70],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.white.withOpacity(0.35),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
              border: Border.all(
                  color: Colors.white.withOpacity(0.5), width: 1),
            ),
            child: Center(
              child: ShaderMask(
                shaderCallback: (b) => const LinearGradient(
                  colors: [Colors.black87, Colors.black54],
                ).createShader(b),
                child: const Text(
                  "A",
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    fontFamily: 'Made',
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          const _TypewriterText(
            text: 'AllStart',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              letterSpacing: 3,
              color: Colors.white,
              fontFamily: 'Made',
            ),
          ),
        ],
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: _ProfileAvatar(onTap: _showAccountSheet),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.transparent,
                Colors.white.withOpacity(0.5),
                Colors.transparent
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return ClipRRect(
      borderRadius: const BorderRadius.horizontal(right: Radius.circular(28)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
        child: Container(
          color: Colors.black.withOpacity(0.55),
          width: MediaQuery.of(context).size.width * 0.8,
          child: Column(
            children: [
              Container(
                height: 220,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.white.withOpacity(0.15),
                      Colors.white.withOpacity(0.05),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border(
                    bottom: BorderSide(
                        color: Colors.white.withOpacity(0.2)),
                  ),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TweenAnimationBuilder(
                        duration: const Duration(milliseconds: 500),
                        tween: Tween<double>(begin: 0.8, end: 1.0),
                        curve: Curves.easeOutBack,
                        builder: (context, value, child) =>
                            Transform.scale(scale: value, child: child),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: ShadowUtils.heavy,
                          ),
                          child: const CircleAvatar(
                            radius: 40,
                            backgroundColor: Colors.transparent,
                            child: Icon(Icons.person_outline,
                                color: Colors.white, size: 40),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(username,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: Colors.white.withOpacity(0.3)),
                        ),
                        child: Text(role.toUpperCase(),
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 9,
                                fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(height: 10),
                      _ShimmerText(
                        text: 'Developer OmhcSilence',
                        baseStyle: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (role.toLowerCase() == 'owner')
                      _DrawerItem(
                          icon: Icons.storefront_rounded,
                          title: 'Owner Page',
                          onTap: () {
                            Navigator.pop(context);
                            _navigateToOwner();
                          }),
                    const SizedBox(height: 8),
                    Divider(color: Colors.white.withOpacity(0.1)),
                    const SizedBox(height: 8),
                    _DrawerItem(
                        icon: Icons.logout_rounded,
                        title: 'Logout',
                        color: Colors.white,
                        onTap: () {
                          Navigator.pop(context);
                          _showLogoutDialog();
                        }),
                    const SizedBox(height: 20),
                    Center(
                        child: Text("ALLSTART • OMHCSILENCE",
                            style: TextStyle(
                                color: Colors.white.withOpacity(0.4),
                                fontSize: 9,
                                letterSpacing: 2))),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          radius: 24,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Colors.white, Colors.white70]),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.logout_rounded,
                    color: Colors.black, size: 24),
              ),
              const SizedBox(height: 12),
              const Text("Konfirmasi Logout",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16)),
              const SizedBox(height: 8),
              const Text("Yakin ingin logout?",
                  style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("Batal",
                          style: TextStyle(color: Colors.white54))),
                  const SizedBox(width: 8),
                  _AnimatedDialogButton(
                    text: "Logout",
                    onTap: () async {
                      Navigator.pop(context);
                      await SharedPreferences.getInstance()
                          .then((p) => p.clear());
                      if (mounted)
                        Navigator.pushAndRemoveUntil(
                            context,
                            _createRoute(const LoginPage()),
                            (r) => false);
                    },
                    isError: true,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      drawer: _buildDrawer(),
      appBar: _buildAppBar(),
      extendBody: true,
      body: FadeTransition(opacity: _fadeAnim, child: _selectedPage),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    super.dispose();
  }
}

// ─── HERO HEADER (top of dashboard) ───────────────────────────────
class _HeroHeader extends StatelessWidget {
  final String username, role, expiredDate;
  const _HeroHeader({
    required this.username,
    required this.role,
    required this.expiredDate,
  });

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      radius: 24,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
      borderColor: Colors.white.withOpacity(0.28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Colors.white, Colors.white70],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.3),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Center(
                  child: ShaderMask(
                    shaderCallback: (b) => const LinearGradient(
                      colors: [Colors.black87, Colors.black54],
                    ).createShader(b),
                    child: const Text(
                      "A",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        fontFamily: 'Made',
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Welcome back",
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.white.withOpacity(0.3)),
                ),
                child: Text(
                  role.toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Animated dev credit (typewriter + pulse)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.white.withOpacity(0.15)),
            ),
            child: Row(
              children: [
                const _PulseDot(color: Colors.white),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'CRAFTED BY',
                        style: TextStyle(
                          color: Colors.white54,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                        ),
                      ),
                      _TypewriterText(
                        text: 'Developer OmhcSilence',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                          fontFamily: 'Made',
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.auto_awesome_rounded,
                    color: Colors.white70, size: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── QUICK ACTIONS GRID ───────────────────────────────────────────
/// A tidy 2x2 grid of action buttons replacing scattered widgets.
class _QuickActionsGrid extends StatelessWidget {
  const _QuickActionsGrid();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _QuickActionTile(
            icon: Icons.devices_rounded,
            label: 'Devices',
            sub: 'Manage',
            onTap: () {
              HapticFeedback.lightImpact();
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _QuickActionTile(
            icon: Icons.chat_rounded,
            label: 'Chat',
            sub: 'Community',
            onTap: () {
              HapticFeedback.lightImpact();
              Navigator.push(
                context,
                _createRoute(ChatPage(
                  username: '',
                  sessionKey: '',
                )),
              );
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _QuickActionTile(
            icon: Icons.favorite_rounded,
            label: 'Thanks',
            sub: 'Credits',
            onTap: () {
              HapticFeedback.lightImpact();
              Navigator.push(
                context,
                _createRoute(const ThanksToPage()),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _QuickActionTile extends StatefulWidget {
  final IconData icon;
  final String label;
  final String sub;
  final VoidCallback onTap;

  const _QuickActionTile({
    required this.icon,
    required this.label,
    required this.sub,
    required this.onTap,
  });

  @override
  State<_QuickActionTile> createState() => _QuickActionTileState();
}

class _QuickActionTileState extends State<_QuickActionTile> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _isPressed ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
              decoration: BoxDecoration(
                color: _isPressed
                    ? Colors.white.withOpacity(0.18)
                    : Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: _isPressed
                      ? Colors.white.withOpacity(0.5)
                      : Colors.white.withOpacity(0.2),
                ),
              ),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                          colors: [Colors.white, Colors.white70]),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.2),
                          blurRadius: 8,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Icon(widget.icon, color: Colors.black, size: 18),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    widget.label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    widget.sub,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 9,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── FLOATING NAV ITEM ──────────────────────────────────────────────
class _FloatingNavItem extends StatefulWidget {
  final IconData icon;
  final IconData? activeIcon;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _FloatingNavItem({
    required this.icon,
    this.activeIcon,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  State<_FloatingNavItem> createState() => _FloatingNavItemState();
}

class _FloatingNavItemState extends State<_FloatingNavItem> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTapDown: (_) => setState(() => _isPressed = true),
        onTapUp: (_) => setState(() => _isPressed = false),
        onTapCancel: () => setState(() => _isPressed = false),
        onTap: () {
          HapticFeedback.lightImpact();
          widget.onTap();
        },
        child: AnimatedScale(
          duration: const Duration(milliseconds: 120),
          scale: _isPressed ? 0.94 : 1.0,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              decoration: widget.isActive
                  ? BoxDecoration(
                      color: Colors.white.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.55),
                        width: 1.0,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.18),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                    ),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                child: Row(
                  mainAxisAlignment: widget.isActive
                      ? MainAxisAlignment.start
                      : MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 200),
                      child: Icon(
                        widget.isActive
                            ? (widget.activeIcon ?? widget.icon)
                            : widget.icon,
                        key: ValueKey(widget.isActive),
                        color: widget.isActive
                            ? Colors.white
                            : Colors.white54,
                        size: 20,
                      ),
                    ),
                    if (widget.isActive) ...[
                      const SizedBox(width: 8),
                      AnimatedOpacity(
                        duration: const Duration(milliseconds: 200),
                        opacity: widget.isActive ? 1.0 : 0.0,
                        child: Text(
                          widget.label,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ProfileAvatar extends StatefulWidget {
  final VoidCallback onTap;

  const _ProfileAvatar({required this.onTap});

  @override
  State<_ProfileAvatar> createState() => _ProfileAvatarState();
}

class _ProfileAvatarState extends State<_ProfileAvatar> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.92 : 1.0,
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
                colors: [Colors.white, Colors.white70]),
            boxShadow: ShadowUtils.soft,
            border: Border.all(color: Colors.white.withOpacity(0.4), width: 1),
          ),
          child: const CircleAvatar(
            radius: 16,
            backgroundColor: Colors.transparent,
            child: Icon(Icons.person_outline, color: Colors.black, size: 16),
          ),
        ),
      ),
    );
  }
}

// ─── DRAWER ITEM ────────────────────────────────────────────────────
class _DrawerItem extends StatefulWidget {
  final IconData icon;
  final String title;
  final Color? color;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.title,
    this.color,
    required this.onTap,
  });

  @override
  State<_DrawerItem> createState() => _DrawerItemState();
}

class _DrawerItemState extends State<_DrawerItem> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.98 : 1.0,
        child: ListTile(
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white.withOpacity(0.2)),
            ),
            child: Icon(widget.icon,
                color: widget.color ?? Colors.white, size: 18),
          ),
          title: Text(widget.title,
              style: TextStyle(
                  color: widget.color ?? Colors.white,
                  fontWeight: FontWeight.w500)),
        ),
      ),
    );
  }
}

// ─── ANIMATED DIALOG BUTTON ─────────────────────────────────────────
class _AnimatedDialogButton extends StatefulWidget {
  final String text;
  final VoidCallback onTap;
  final bool isError;

  const _AnimatedDialogButton({
    required this.text,
    required this.onTap,
    this.isError = false,
  });

  @override
  State<_AnimatedDialogButton> createState() => _AnimatedDialogButtonState();
}

class _AnimatedDialogButtonState extends State<_AnimatedDialogButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.95 : 1.0,
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
                colors: [Colors.white, Colors.white70]),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.4)),
          ),
          child: Text(
            widget.text,
            style: const TextStyle(
                color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}

// ─── ACCOUNT BOTTOM SHEET ───────────────────────────────────────────
class _AccountSheet extends StatelessWidget {
  final String username, role, expiredDate;
  final VoidCallback onLogout;
  const _AccountSheet({
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius:
          const BorderRadius.vertical(top: Radius.circular(24)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.55),
            borderRadius:
                const BorderRadius.vertical(top: Radius.circular(24)),
            boxShadow: ShadowUtils.heavy,
            border: Border(
                top: BorderSide(color: Colors.white.withOpacity(0.2))),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Colors.white, Colors.white70]),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              TweenAnimationBuilder(
                duration: const Duration(milliseconds: 400),
                tween: Tween<double>(begin: 0.8, end: 1.0),
                curve: Curves.easeOutBack,
                builder: (context, value, child) =>
                    Transform.scale(scale: value, child: child),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                        colors: [Colors.white, Colors.white70]),
                    boxShadow: ShadowUtils.medium,
                    border: Border.all(
                        color: Colors.white.withOpacity(0.4), width: 2),
                  ),
                  child: const CircleAvatar(
                    radius: 35,
                    backgroundColor: Colors.transparent,
                    child: Icon(Icons.person_outline,
                        color: Colors.black, size: 35),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(username,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white.withOpacity(0.3)),
                ),
                child: Text(role.toUpperCase(),
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                      child: TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("Tutup",
                              style:
                                  TextStyle(color: Colors.white54)))),
                  Expanded(
                    child: _AnimatedSheetButton(
                      text: "Logout",
                      onTap: () {
                        Navigator.pop(context);
                        onLogout();
                      },
                      isError: true,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AnimatedSheetButton extends StatefulWidget {
  final String text;
  final VoidCallback onTap;
  final bool isError;

  const _AnimatedSheetButton({
    required this.text,
    required this.onTap,
    this.isError = false,
  });

  @override
  State<_AnimatedSheetButton> createState() => _AnimatedSheetButtonState();
}

class _AnimatedSheetButtonState extends State<_AnimatedSheetButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.97 : 1.0,
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
                colors: [Colors.white, Colors.white70]),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.white.withOpacity(0.4)),
          ),
          child: TextButton(
            onPressed: null,
            child: Text(
              widget.text,
              style: const TextStyle(
                  color: Colors.black, fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
    );
  }
}
