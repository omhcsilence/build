import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'login_page.dart';
import 'splash.dart';
import 'theme.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  int _currentPage = 0;
  late AnimationController _indicatorAnimController;
  late Animation<double> _indicatorAnimation;
  final PageController _pageController = PageController();
  bool _isCheckingAuth = true;

  static const String _baseUrl = 'https://omhc-host-premium.yakuza.biz.id';

  @override
  void initState() {
    super.initState();
    _checkAutoLogin();

    _indicatorAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);

    _indicatorAnimation = Tween<double>(begin: 6.0, end: 18.0).animate(
      CurvedAnimation(parent: _indicatorAnimController, curve: Curves.easeInOut),
    );
  }

  Future<void> _checkAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser == null || savedPass == null || savedKey == null) {
      setState(() => _isCheckingAuth = false);
      return;
    }

    try {
      final deviceInfo = DeviceInfoPlugin();
      final android = await deviceInfo.androidInfo;
      final androidId = android.id ?? "unknown_device";

      final uri = Uri.parse(
          "$_baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");
      final res = await http.get(uri);
      final data = jsonDecode(res.body);

      if (data['valid'] == true) {
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => SplashScreen(
              username: savedUser,
              password: savedPass,
              role: data['role']?.toString() ?? '',
              expiredDate: data['expiredDate']?.toString() ?? '',
              sessionKey: data['key']?.toString() ?? savedKey,
              listBug: (data['listBug'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              listDoos: (data['listDDoS'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              news: (data['news'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
            ),
          ),
        );
      } else {
        setState(() => _isCheckingAuth = false);
      }
    } catch (e) {
      setState(() => _isCheckingAuth = false);
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    _indicatorAnimController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isCheckingAuth) {
      return Scaffold(
        backgroundColor: AppColors.bg,
        body: LiquidBackground(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                CircularProgressIndicator(color: Colors.white),
                SizedBox(height: 16),
                Text(
                  "AllStart",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 4,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: LiquidBackground(
        child: Stack(
          children: [
            PageView(
              scrollDirection: Axis.vertical,
              controller: _pageController,
              onPageChanged: (int page) {
                setState(() => _currentPage = page);
              },
              children: [
                // PAGE 1: WELCOME
                Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ShaderMask(
                        shaderCallback: (b) => const LinearGradient(
                          colors: [Colors.white, Colors.white54],
                        ).createShader(b),
                        child: const Text(
                          ".WELCOME.",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 44,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 3,
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      TypewriterText(
                        text: 'Developer OmhcSilence',
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 2,
                        ),
                        cursorColor: Colors.white,
                      ),
                    ],
                  ),
                ),

                // PAGE 2: DESCRIPTION
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        "Selamat Datang",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 20),
                      Text(
                        "Selamat datang di komunitas AllStart! Kami sangat berterima kasih atas kehadiran Anda. Di sini, Anda dapat menikmati kenyamanan sambil memanfaatkan teknologi terbaru dan berbagai alat yang berguna. Jika Anda memiliki pertanyaan atau kendala, jangan ragu untuk menghubungi tim dukungan kami. Selamat menikmati pengalaman Anda!",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 15,
                          height: 1.6,
                        ),
                      ),
                    ],
                  ),
                ),

                // PAGE 3: LANDING ASLI (LOGIN + BUY)
                SafeArea(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 40),

                        // Logo AllStart (glass card with "A" mark)
                        Container(
                          width: 320,
                          height: 320,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(40),
                                child: BackdropFilter(
                                  filter: ImageFilter.blur(
                                      sigmaX: 24, sigmaY: 24),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.06),
                                      borderRadius: BorderRadius.circular(40),
                                      border: Border.all(
                                        color: Colors.white.withOpacity(0.25),
                                        width: 1.5,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    width: 110,
                                    height: 110,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: LinearGradient(
                                        colors: [
                                          Colors.white,
                                          Colors.white.withOpacity(0.7),
                                        ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.white.withOpacity(0.4),
                                          blurRadius: 35,
                                          spreadRadius: 4,
                                        ),
                                      ],
                                      border: Border.all(
                                        color: Colors.white.withOpacity(0.6),
                                        width: 1.5,
                                      ),
                                    ),
                                    child: Center(
                                      child: ShaderMask(
                                        shaderCallback: (b) =>
                                            const LinearGradient(
                                          colors: [
                                            Colors.black87,
                                            Colors.black54
                                          ],
                                        ).createShader(b),
                                        child: const Text(
                                          "A",
                                          style: TextStyle(
                                            fontSize: 58,
                                            fontWeight: FontWeight.w900,
                                            color: Colors.white,
                                            fontFamily: 'Made',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 24),
                                  const Text(
                                    "AllStart",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 32,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 5,
                                      fontFamily: 'Made',
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    "Silakan Login atau Beli Akses",
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.65),
                                      fontSize: 12,
                                      letterSpacing: 1,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 40),

                        // SIGN IN button (solid white glass)
                        _LiquidActionButton(
                          label: "Sign In",
                          icon: Icons.login,
                          onPressed: () {
                            HapticFeedback.lightImpact();
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const LoginPage()),
                            );
                          },
                          primary: true,
                        ),

                        const SizedBox(height: 16),

                        // BUY ACCESS button (outline glass)
                        _LiquidActionButton(
                          label: "Beli Akses ke Owner",
                          icon: Icons.shopping_bag,
                          onPressed: () {
                            HapticFeedback.lightImpact();
                            _openUrl("https://t.me/snakereals17");
                          },
                          primary: false,
                        ),

                        const SizedBox(height: 30),

                        // Telegram channel
                        Row(
                          children: [
                            Expanded(
                              child: _buildContactButton(
                                icon: FontAwesomeIcons.telegram,
                                label: "Telegram Channel",
                                url: "https://t.me/imgnteam",
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 30),
                        ShimmerText(
                          text: "DEVELOPER OMHCSILENCE",
                          baseStyle: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 4,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          "© 2026 AllStart",
                          style: TextStyle(
                              color: Colors.white38, fontSize: 11),
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // HEADER
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    SizedBox(height: 20),
                    Text(
                      "AllStart",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                        letterSpacing: 3,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "Version 2.0",
                      style:
                          TextStyle(color: Colors.white54, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),

            // FOOTER SWIPE
            Positioned(
              bottom: 30,
              left: 0,
              right: 0,
              child: Center(
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 300),
                  opacity: _currentPage == 2 ? 0.0 : 1.0,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 22,
                        height: 45,
                        decoration: BoxDecoration(
                          border:
                              Border.all(color: Colors.white54, width: 2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        alignment: Alignment.topCenter,
                        child: AnimatedBuilder(
                          animation: _indicatorAnimation,
                          builder: (context, child) => Padding(
                            padding:
                                EdgeInsets.only(top: _indicatorAnimation.value),
                            child: Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                color: Colors.white54,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        "Geser ke atas untuk melanjutkan",
                        style:
                            TextStyle(color: Colors.white70, fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required IconData icon,
    required String label,
    required String url,
  }) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              border: Border.all(color: Colors.white.withOpacity(0.18)),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FaIcon(icon, color: Colors.white, size: 20),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── LIQUID ACTION BUTTON ───────────────────────────────────────────
class _LiquidActionButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final VoidCallback onPressed;
  final bool primary;

  const _LiquidActionButton({
    required this.label,
    required this.icon,
    required this.onPressed,
    required this.primary,
  });

  @override
  State<_LiquidActionButton> createState() => _LiquidActionButtonState();
}

class _LiquidActionButtonState extends State<_LiquidActionButton>
    with SingleTickerProviderStateMixin {
  bool _isPressed = false;
  late AnimationController _glow;
  late Animation<double> _glowAnim;

  @override
  void initState() {
    super.initState();
    _glow = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.25, end: 0.7).animate(
      CurvedAnimation(parent: _glow, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _glow.dispose();
    super.dispose();
  }

  void _tap() {
    HapticFeedback.lightImpact();
    setState(() => _isPressed = true);
    Future.delayed(const Duration(milliseconds: 120), () {
      if (mounted) setState(() => _isPressed = false);
      widget.onPressed();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (_, __) => GestureDetector(
        onTap: _tap,
        child: AnimatedScale(
          scale: _isPressed ? 0.97 : 1.0,
          duration: const Duration(milliseconds: 120),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: double.infinity,
            height: 55,
            decoration: BoxDecoration(
              gradient: widget.primary
                  ? LinearGradient(
                      colors: [
                        Colors.white,
                        Colors.white.withOpacity(0.85),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : LinearGradient(
                      colors: [
                        Colors.white.withOpacity(0.10),
                        Colors.white.withOpacity(0.04),
                      ],
                    ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: widget.primary
                    ? Colors.white
                    : Colors.white.withOpacity(0.4),
                width: widget.primary ? 1.5 : 1.2,
              ),
              boxShadow: widget.primary
                  ? [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.35 * _glowAnim.value),
                        blurRadius: 25,
                        spreadRadius: 2,
                        offset: const Offset(0, 5),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  widget.icon,
                  color: widget.primary ? Colors.black : Colors.white,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Text(
                  widget.label,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: widget.primary ? Colors.black : Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
