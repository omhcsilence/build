import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─── ALLSTART • BLACK & WHITE LIQUID GLASS THEME ────────────────────
class AppColors {
  // Base backgrounds (deep black gradient)
  static const bg            = Color(0xFF000000);
  static const bgSoft        = Color(0xFF050505);
  static const surface       = Color(0xFF0E0E0E);
  static const surfaceLight  = Color(0xFF161616);
  static const surface2      = Color(0xFF1C1C1C);
  static const cardDark      = Color(0xFF080808);

  // Liquid glass tints (white transparency)
  static const glass1        = Color(0x14FFFFFF); // 8%
  static const glass2        = Color(0x1FFFFFFF); // 12%
  static const glass3        = Color(0x33FFFFFF); // 20%
  static const glassBorder   = Color(0x55FFFFFF); // 33%
  static const glassHighlight= Color(0xCCFFFFFF); // 80%

  // Liquid accent whites
  static const liquid1       = Color(0xFFFFFFFF);
  static const liquid2       = Color(0xFFEDEDED);
  static const liquid3       = Color(0xFFBDBDBD);
  static const liquid4       = Color(0xFF7A7A7A);

  // Mono accents
  static const accent1       = Colors.white;
  static const accent2       = Color(0xFFDADADA);
  static const accent3       = Color(0xFF8E8E8E);

  static const success       = Color(0xFFE0E0E0);
  static const warning       = Color(0xFFBDBDBD);
  static const error         = Color(0xFFEDEDED);

  // Text
  static const textPrimary   = Color(0xFFFFFFFF);
  static const textSec       = Color(0xFFCCCCCC);
  static const textMuted     = Color(0xFF6E6E6E);

  // Shadows
  static const shadow        = Color(0x33000000);
  static const shadowHeavy   = Color(0x66000000);
  static const glow          = Color(0x33FFFFFF);
}

// ─── SHADOW UTILITIES ─────────────────────────────────────────────
class ShadowUtils {
  static List<BoxShadow> get soft => const [
    BoxShadow(color: AppColors.shadow, blurRadius: 8, offset: Offset(0, 2)),
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 2, offset: Offset(0, 1)),
  ];

  static List<BoxShadow> get medium => const [
    BoxShadow(color: AppColors.shadow, blurRadius: 16, offset: Offset(0, 4)),
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 4, offset: Offset(0, 2)),
  ];

  static List<BoxShadow> get heavy => const [
    BoxShadow(color: AppColors.shadow, blurRadius: 24, offset: Offset(0, 8)),
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 8, offset: Offset(0, 4)),
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 2, offset: Offset(0, 1)),
  ];

  static List<BoxShadow> get card => const [
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 20, offset: Offset(0, 10)),
    BoxShadow(color: AppColors.shadow, blurRadius: 6, offset: Offset(0, 2)),
  ];

  static List<BoxShadow> get glow => const [
    BoxShadow(color: AppColors.glow, blurRadius: 30, spreadRadius: 2),
  ];
}

// ─── LIQUID GLASS CARD ──────────────────────────────────────────────
/// A frosted-glass card with backdrop blur, white hairline border,
/// and a subtle inner highlight. Used everywhere in AllStart UI.
class LiquidCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double radius;
  final Color? borderColor;
  final Color? bgColor;
  final List<Color>? gradient;
  final bool hasShadow;
  final bool blur;
  final double blurSigma;
  final VoidCallback? onTap;

  const LiquidCard({
    super.key,
    required this.child,
    this.padding,
    this.radius = 24,
    this.borderColor,
    this.bgColor,
    this.gradient,
    this.hasShadow = true,
    this.blur = true,
    this.blurSigma = 18,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final Container container = Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: gradient != null
            ? LinearGradient(colors: gradient!, begin: Alignment.topLeft, end: Alignment.bottomRight)
            : LinearGradient(
                colors: [
                  bgColor ?? const Color(0x1AFFFFFF),
                  (bgColor ?? const Color(0x0DFFFFFF)).withOpacity(0.04),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        border: Border.all(
          color: borderColor ?? const Color(0x33FFFFFF),
          width: 0.6,
        ),
        boxShadow: hasShadow ? ShadowUtils.card : null,
      ),
      child: child,
    );

    Widget layered = blur
        ? ClipRRect(
            borderRadius: BorderRadius.circular(radius),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma),
              child: container,
            ),
          )
        : container;

    if (onTap != null) {
      return AnimatedLiquidTap(onTap: onTap!, child: layered);
    }
    return layered;
  }
}

class AnimatedLiquidTap extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const AnimatedLiquidTap({super.key, required this.child, required this.onTap});

  @override
  State<AnimatedLiquidTap> createState() => _AnimatedLiquidTapState();
}

class _AnimatedLiquidTapState extends State<AnimatedLiquidTap> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.98 : 1.0,
        child: widget.child,
      ),
    );
  }
}

// ─── ANIMATED LIQUID BACKGROUND ───────────────────────────────────
/// Two large soft white "blobs" that drift slowly across the canvas,
/// giving the impression of liquid glass moving behind the UI.
class LiquidBackground extends StatefulWidget {
  final Widget child;
  const LiquidBackground({super.key, required this.child});

  @override
  State<LiquidBackground> createState() => _LiquidBackgroundState();
}

class _LiquidBackgroundState extends State<LiquidBackground>
    with TickerProviderStateMixin {
  late AnimationController _c1;
  late AnimationController _c2;
  late AnimationController _c3;

  @override
  void initState() {
    super.initState();
    _c1 = AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();
    _c2 = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat();
    _c3 = AnimationController(vsync: this, duration: const Duration(seconds: 22))..repeat();
  }

  @override
  void dispose() {
    _c1.dispose();
    _c2.dispose();
    _c3.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Base black
        Container(color: AppColors.bg),
        // Drifting blobs
        Positioned.fill(
          child: AnimatedBuilder(
            animation: Listenable.merge([_c1, _c2, _c3]),
            builder: (context, _) {
              return CustomPaint(
                painter: _LiquidBlobPainter(
                  t1: _c1.value,
                  t2: _c2.value,
                  t3: _c3.value,
                ),
                size: Size.infinite,
              );
            },
          ),
        ),
        // Subtle vignette
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                colors: [Colors.transparent, Colors.black.withOpacity(0.65)],
                center: Alignment.center,
                radius: 0.95,
              ),
            ),
          ),
        ),
        // Foreground content
        Positioned.fill(child: widget.child),
      ],
    );
  }
}

class _LiquidBlobPainter extends CustomPainter {
  final double t1, t2, t3;
  _LiquidBlobPainter({required this.t1, required this.t2, required this.t3});

  @override
  void paint(Canvas canvas, Size size) {
    // Blob 1 - top-left
    final p1 = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 80)
      ..shader = RadialGradient(
        colors: [Colors.white.withOpacity(0.18), Colors.white.withOpacity(0.0)],
      ).createShader(Rect.fromCircle(
        center: Offset(
          size.width * (0.2 + 0.15 * _sin(t1, 0)),
          size.height * (0.15 + 0.10 * _sin(t1, 1.5)),
        ),
        radius: size.width * 0.55,
      ));
    canvas.drawCircle(
      Offset(
        size.width * (0.2 + 0.15 * _sin(t1, 0)),
        size.height * (0.15 + 0.10 * _sin(t1, 1.5)),
      ),
      size.width * 0.55,
      p1,
    );

    // Blob 2 - bottom-right
    final p2 = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 90)
      ..shader = RadialGradient(
        colors: [Colors.white.withOpacity(0.14), Colors.white.withOpacity(0.0)],
      ).createShader(Rect.fromCircle(
        center: Offset(
          size.width * (0.85 - 0.18 * _sin(t2, 1.0)),
          size.height * (0.85 - 0.12 * _sin(t2, 0.5)),
        ),
        radius: size.width * 0.6,
      ));
    canvas.drawCircle(
      Offset(
        size.width * (0.85 - 0.18 * _sin(t2, 1.0)),
        size.height * (0.85 - 0.12 * _sin(t2, 0.5)),
      ),
      size.width * 0.6,
      p2,
    );

    // Blob 3 - center small
    final p3 = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 70)
      ..shader = RadialGradient(
        colors: [Colors.white.withOpacity(0.10), Colors.white.withOpacity(0.0)],
      ).createShader(Rect.fromCircle(
        center: Offset(
          size.width * (0.5 + 0.25 * _sin(t3, 2.0)),
          size.height * (0.5 + 0.20 * _sin(t3, 0.8)),
        ),
        radius: size.width * 0.4,
      ));
    canvas.drawCircle(
      Offset(
        size.width * (0.5 + 0.25 * _sin(t3, 2.0)),
        size.height * (0.5 + 0.20 * _sin(t3, 0.8)),
      ),
      size.width * 0.4,
      p3,
    );
  }

  double _sin(double t, double phase) {
    final v = (t * 2 * 3.14159265 + phase) % (2 * 3.14159265);
    return (1 - (v - 3.14159265).abs() / 3.14159265).clamp(0.0, 1.0) * 2 - 1;
  }

  @override
  bool shouldRepaint(covariant _LiquidBlobPainter old) =>
      old.t1 != t1 || old.t2 != t2 || old.t3 != t3;
}

// ─── PULSE DOT ────────────────────────────────────────────────────
class PulseDot extends StatefulWidget {
  final Color color;
  const PulseDot({super.key, required this.color});
  @override State<PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<PulseDot> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(
    animation: _a,
    builder: (_, __) => Container(
      width: 8, height: 8,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: widget.color.withOpacity(_a.value),
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.5), blurRadius: 6)],
      ),
    ),
  );
}

// ─── TYPEWRITER TEXT (Reusable) ───────────────────────────────────
class TypewriterText extends StatefulWidget {
  final String text;
  final TextStyle style;
  final Color? cursorColor;
  final Duration speed;
  final Duration restartPause;

  const TypewriterText({
    super.key,
    required this.text,
    required this.style,
    this.cursorColor,
    this.speed = const Duration(milliseconds: 70),
    this.restartPause = const Duration(seconds: 4),
  });

  @override
  State<TypewriterText> createState() => _TypewriterTextState();
}

class _TypewriterTextState extends State<TypewriterText>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<int> _charAnim;
  Timer? _restartTimer;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: widget.speed * widget.text.length,
    );
    _charAnim = IntTween(begin: 0, end: widget.text.length)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _ctrl.forward();
    _restartTimer = Timer.periodic(
      widget.speed * widget.text.length + widget.restartPause,
      (_) {
        if (mounted) {
          _ctrl.reset();
          _ctrl.forward();
        }
      },
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _restartTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _charAnim,
      builder: (_, __) {
        final displayed = widget.text.substring(0, _charAnim.value);
        return Row(mainAxisSize: MainAxisSize.min, children: [
          Text(displayed, style: widget.style),
          if (_charAnim.value < widget.text.length)
            _BlinkingCursor(color: widget.cursorColor ?? Colors.white),
        ]);
      },
    );
  }
}

class _BlinkingCursor extends StatefulWidget {
  final Color color;
  const _BlinkingCursor({required this.color});
  @override State<_BlinkingCursor> createState() => _BlinkingCursorState();
}

class _BlinkingCursorState extends State<_BlinkingCursor>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 500))
      ..repeat();
  }
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        // Triangle wave: blink 0..1..0..1
        final v = _c.value;
        final opacity = (v < 0.5) ? (v * 2) : ((1 - v) * 2);
        return Opacity(
          opacity: opacity,
          child: Padding(
            padding: const EdgeInsets.only(left: 2),
            child: Text('|', style: TextStyle(color: widget.color)),
          ),
        );
      },
    );
  }
}

// ─── SHIMMER TEXT (gradient sweep) ────────────────────────────────
/// A text whose fill animates as a moving white-on-grey gradient sweep.
/// Used for the "Developer OmhcSilence" credit line.
class ShimmerText extends StatefulWidget {
  final String text;
  final TextStyle baseStyle;
  final Duration duration;

  const ShimmerText({
    super.key,
    required this.text,
    required this.baseStyle,
    this.duration = const Duration(milliseconds: 2500),
  });

  @override
  State<ShimmerText> createState() => _ShimmerTextState();
}

class _ShimmerTextState extends State<ShimmerText>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration)..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        return ShaderMask(
          shaderCallback: (bounds) {
            final sweep = _c.value * 2 - 0.5; // -0.5 .. 1.5
            return LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: const [
                Color(0xFF5A5A5A),
                Color(0xFFBDBDBD),
                Color(0xFFFFFFFF),
                Color(0xFFBDBDBD),
                Color(0xFF5A5A5A),
              ],
              stops: [
                (sweep - 0.4).clamp(0.0, 1.0),
                (sweep - 0.15).clamp(0.0, 1.0),
                (sweep).clamp(0.0, 1.0),
                (sweep + 0.15).clamp(0.0, 1.0),
                (sweep + 0.4).clamp(0.0, 1.0),
              ],
            ).createShader(bounds);
          },
          child: Text(
            widget.text,
            style: widget.baseStyle.copyWith(color: Colors.white),
          ),
        );
      },
    );
  }
}

// ─── MARQUEE TEXT (horizontal scroll, looping) ────────────────────
class MarqueeText extends StatefulWidget {
  final String text;
  final TextStyle style;
  final Duration duration;
  final double gap;

  const MarqueeText({
    super.key,
    required this.text,
    required this.style,
    this.duration = const Duration(seconds: 12),
    this.gap = 60,
  });

  @override
  State<MarqueeText> createState() => _MarqueeTextState();
}

class _MarqueeTextState extends State<MarqueeText>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late double _textWidth = 0;
  final GlobalKey _textKey = GlobalKey();
  final ScrollController _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration)..repeat();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _textKey.currentContext;
      if (ctx != null) {
        final box = ctx.findRenderObject() as RenderBox?;
        if (box != null && mounted) {
          setState(() => _textWidth = box.size.width);
        }
      }
    });
  }

  @override
  void dispose() {
    _c.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: OverflowBox(
        maxWidth: double.infinity,
        alignment: Alignment.centerLeft,
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) {
            return Transform.translate(
              offset: Offset(-(_c.value * (_textWidth + widget.gap)), 0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(widget.text, key: _textKey, style: widget.style),
                  SizedBox(width: widget.gap),
                  Text(widget.text, style: widget.style),
                  SizedBox(width: widget.gap),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

// ─── END OF THEME ─────────────────────────────────────────────────
