plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.motion.team"
    // 35 is widely available in CI/build environments; 36 may force a
    // long SDK download on first build. Bump only when actually needed.
    compileSdk = 35
    // Let Flutter pick its bundled NDK — don't pin a specific (1.5 GB) version.
    // ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    tasks.withType<JavaCompile>().configureEach {
        options.compilerArgs.addAll(listOf(
            "-Xlint:-deprecation",
            "-Xlint:-unchecked",
            "-Xlint:none",
            "-nowarn"
        ))
        options.isWarnings = false
    }

    kotlinOptions {
        jvmTarget = "11"
        freeCompilerArgs = listOf("-Xno-source-debug-extension")
    }

    defaultConfig {
        applicationId = "com.motion.team"
        minSdk = 21
        targetSdk = 35
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    lint {
        disable += "Deprecation"
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

flutter {
    source = "../.."
}
