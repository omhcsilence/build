#!/bin/bash
# ============================================================
# YakuzaXsilence Flutter APK Build Script v14
# Compatible with GitHub Actions workflow auto-fix logic
# Auto-setup: JDK 17, Android SDK, Flutter SDK, NDK
# Debug signing -- no keystore needed
# v14: Full auto-fix pipeline (pubspec, code, FA v11), RAM detection, retry + fallback
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

echo -e "${CYAN}${BOLD}+============================================+${NC}"
echo -e "${CYAN}${BOLD}|  YakuzaXsilence Build v14 (Auto-Fix+Retry) |${NC}"
echo -e "${CYAN}${BOLD}+============================================+${NC}"
echo ""

# ──────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────
FLUTTER_VERSION="3.44.0"
ANDROID_SDK_DIR="$HOME/android-sdk"
FLUTTER_DIR="$HOME/flutter"
REQUIRED_NDK="28.2.13676358"
REQUIRED_COMPILE_SDK=36
REQUIRED_TARGET_SDK=36

# cmdline-tools versions to try (newest first)
CMDLINE_VERSIONS=("9123335" "8512546")

# Build retry config
MAX_RETRIES=6
RETRY_COUNT=0
SUCCESS=false

# Fallback Flutter versions (same as workflow)
FALLBACK_VERSIONS=("3.35.2" "3.32.0" "3.27.0" "3.24.0" "3.22.0" "3.19.0")
FALLBACK_IDX=0

# ──────────────────────────────────────────────
# Step 0: Pre-flight
# ──────────────────────────────────────────────
echo -e "${CYAN}[0/9] Pre-flight checks...${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -f "pubspec.yaml" ]; then
    echo -e "${RED}ERROR: pubspec.yaml not found in ${SCRIPT_DIR}${NC}"
    exit 1
fi

echo -e "  Project: ${GREEN}$(grep '^name:' pubspec.yaml | head -1)${NC}"
echo -e "  Version: ${GREEN}$(grep '^version:' pubspec.yaml | head -1)${NC}"
echo -e "  SDK:     ${GREEN}$(grep 'sdk:' pubspec.yaml | head -1)${NC}"

# Fix git safe.directory for root user (common on VPS)
if [ "$(id -u)" -eq 0 ]; then
    echo -e "  ${YELLOW}Running as root — adding git safe.directory exceptions${NC}"
    git config --global --add safe.directory "$FLUTTER_DIR" 2>/dev/null || true
    git config --global --add safe.directory "$SCRIPT_DIR" 2>/dev/null || true
    git config --global --add safe.directory "*" 2>/dev/null || true
fi

echo ""

# ──────────────────────────────────────────────
# Step 1: RAM detection & swap
# ──────────────────────────────────────────────
echo -e "${CYAN}[1/9] Checking system memory...${NC}"

TOTAL_RAM_MB=$(grep MemTotal /proc/meminfo | awk '{print int($2/1024)}')
echo -e "  Total RAM: ${GREEN}${TOTAL_RAM_MB} MB${NC}"

if [ "$TOTAL_RAM_MB" -ge 16000 ]; then
    GRADLE_HEAP="8G"; GRADLE_META="2G"
    echo -e "  ${GREEN}Plenty of RAM — Gradle heap: 8G${NC}"
elif [ "$TOTAL_RAM_MB" -ge 8000 ]; then
    GRADLE_HEAP="4G"; GRADLE_META="1G"
    echo -e "  ${GREEN}8GB+ RAM — Gradle heap: 4G${NC}"
elif [ "$TOTAL_RAM_MB" -ge 4000 ]; then
    GRADLE_HEAP="2G"; GRADLE_META="512m"
    echo -e "  ${YELLOW}4GB+ RAM — Gradle heap: 2G (may be slow)${NC}"
else
    GRADLE_HEAP="1G"; GRADLE_META="256m"
    echo -e "  ${YELLOW}Low RAM — Gradle heap: 1G (will be slow)${NC}"
fi

CURRENT_SWAP_MB=$(grep SwapTotal /proc/meminfo | awk '{print int($2/1024)}')
echo -e "  Current swap: ${GREEN}${CURRENT_SWAP_MB} MB${NC}"

NEED_SWAP=false
TOTAL_VIRTUAL=$((TOTAL_RAM_MB + CURRENT_SWAP_MB))

if [ "$TOTAL_VIRTUAL" -lt 4096 ]; then
    NEED_SWAP=true
    SWAP_SIZE_MB=$((4096 - TOTAL_VIRTUAL + 1024))
elif [ "$TOTAL_RAM_MB" -lt 40192 ] && [ "$CURRENT_SWAP_MB" -lt 2048 ]; then
    NEED_SWAP=true
    SWAP_SIZE_MB=2048
fi

if [ "$NEED_SWAP" = true ]; then
    echo -e "  ${YELLOW}Creating ${SWAP_SIZE_MB}MB swap file...${NC}"
    SWAP_FILE="/swapfile_build"
    if [ ! -f "$SWAP_FILE" ]; then
        dd if=/dev/zero of="$SWAP_FILE" bs=1M count="$SWAP_SIZE_MB" status=progress 2>&1 || true
        chmod 600 "$SWAP_FILE"
        mkswap "$SWAP_FILE" 2>/dev/null || true
        swapon "$SWAP_FILE" 2>/dev/null || true
        echo -e "  ${GREEN}Swap created and activated${NC}"
    else
        if ! swapon --show | grep -q "$SWAP_FILE"; then
            swapon "$SWAP_FILE" 2>/dev/null || true
        fi
        echo -e "  ${GREEN}Swap file already exists${NC}"
    fi
fi

GRADLE_PROPS_PATH="android/gradle.properties"
echo -e "  ${YELLOW}Writing gradle.properties with Gradle heap: ${GRADLE_HEAP}${NC}"
cat > "$GRADLE_PROPS_PATH" << GRADLE_EOF
org.gradle.jvmargs=-Xmx${GRADLE_HEAP} -XX:MaxMetaspaceSize=${GRADLE_META} -XX:ReservedCodeCacheSize=256m
org.gradle.daemon=true
org.gradle.parallel=true
org.gradle.caching=true
android.useAndroidX=true
android.enableJetifier=true
GRADLE_EOF

echo -e "  ${GREEN}gradle.properties tuned for this server${NC}"
echo ""

# ──────────────────────────────────────────────
# Step 2: Install JDK 17
# ──────────────────────────────────────────────
echo -e "${CYAN}[2/9] Checking JDK 17...${NC}"

if java -version 2>&1 | grep -q "17"; then
    echo -e "  ${GREEN}JDK 17 already installed${NC}"
else
    echo -e "  ${YELLOW}JDK 17 not found, installing...${NC}"
    if command -v apt-get &> /dev/null; then
        apt-get update -qq 2>/dev/null || true
        apt-get install -y -qq openjdk-17-jdk-headless 2>/dev/null || true
    elif command -v yum &> /dev/null; then
        yum install -y java-17-openjdk-devel 2>/dev/null || true
    fi

    if java -version 2>&1 | grep -q "17"; then
        echo -e "  ${GREEN}JDK 17 installed via package manager${NC}"
    else
        echo -e "  ${YELLOW}Package manager failed, downloading Adoptium JDK...${NC}"
        TMP_JDK="/tmp/jdk17install"
        rm -rf "$TMP_JDK"
        mkdir -p "$TMP_JDK"
        curl -fSL "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse" -o "$TMP_JDK/jdk17.tar.gz"
        tar -xzf "$TMP_JDK/jdk17.tar.gz" -C "$TMP_JDK"
        JDK_EXTRACTED=$(find "$TMP_JDK" -maxdepth 1 -type d -name "jdk-*" | head -1)
        if [ -n "$JDK_EXTRACTED" ]; then
            rm -rf /opt/jdk-17
            mv "$JDK_EXTRACTED" /opt/jdk-17
            export JAVA_HOME=/opt/jdk-17
            export PATH="/opt/jdk-17/bin:$PATH"
            if ! grep -q "jdk-17" "$HOME/.bashrc" 2>/dev/null; then
                echo 'export JAVA_HOME=/opt/jdk-17' >> "$HOME/.bashrc"
                echo 'export PATH=$JAVA_HOME/bin:$PATH' >> "$HOME/.bashrc"
            fi
            echo -e "  ${GREEN}JDK 17 installed at /opt/jdk-17${NC}"
        else
            echo -e "${RED}ERROR: Failed to install JDK 17${NC}"
            exit 1
        fi
        rm -rf "$TMP_JDK"
    fi
fi

if [ -z "$JAVA_HOME" ]; then
    JAVA_BIN_PATH=$(readlink -f "$(which java)" 2>/dev/null || echo "")
    if [ -n "$JAVA_BIN_PATH" ]; then
        JAVA_BIN_DIR=$(dirname "$JAVA_BIN_PATH")
        export JAVA_HOME=$(dirname "$JAVA_BIN_DIR")
    fi
fi
echo -e "  JAVA_HOME = ${GREEN}${JAVA_HOME}${NC}"
echo ""

# ──────────────────────────────────────────────
# Step 3: Install Android SDK command-line tools
# ──────────────────────────────────────────────
echo -e "${CYAN}[3/9] Checking Android SDK...${NC}"

export ANDROID_HOME="$ANDROID_SDK_DIR"
export ANDROID_SDK_ROOT="$ANDROID_SDK_DIR"

if [ -f "$ANDROID_SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
    echo -e "  ${GREEN}Android SDK cmdline-tools found${NC}"
else
    echo -e "  ${YELLOW}Android SDK not found, installing...${NC}"
    mkdir -p "$ANDROID_SDK_DIR/cmdline-tools"

    CMDLINE_DOWNLOADED=false
    for VER in "${CMDLINE_VERSIONS[@]}"; do
        CMDLINE_URL="https://dl.google.com/android/repository/commandlinetools-linux-${VER}_latest.zip"
        echo -e "  ${YELLOW}Trying cmdline-tools v${VER}...${NC}"
        HTTP_CODE=$(curl -sIo /dev/null -w "%{http_code}" "$CMDLINE_URL" 2>/dev/null || echo "000")
        if [ "$HTTP_CODE" = "200" ]; then
            CMDLINE_ZIP="/tmp/commandlinetools.zip"
            curl -fSL "$CMDLINE_URL" -o "$CMDLINE_ZIP"
            TMP_EXTRACT="/tmp/cmdline-tools-tmp"
            rm -rf "$TMP_EXTRACT"
            mkdir -p "$TMP_EXTRACT"
            unzip -q "$CMDLINE_ZIP" -d "$TMP_EXTRACT"
            if [ -d "$TMP_EXTRACT/cmdline-tools" ]; then
                mv "$TMP_EXTRACT/cmdline-tools" "$ANDROID_SDK_DIR/cmdline-tools/latest"
                CMDLINE_DOWNLOADED=true
            fi
            rm -rf "$TMP_EXTRACT" "$CMDLINE_ZIP"
            break
        else
            echo -e "  ${YELLOW}v${VER} returned HTTP ${HTTP_CODE}, trying next...${NC}"
        fi
    done

    if [ "$CMDLINE_DOWNLOADED" = true ] && [ -f "$ANDROID_SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
        echo -e "  ${GREEN}Android cmdline-tools installed${NC}"
    else
        echo -e "${RED}ERROR: Could not download Android cmdline-tools${NC}"
        exit 1
    fi
fi

export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

if ! grep -q "ANDROID_HOME" "$HOME/.bashrc" 2>/dev/null; then
    echo "export ANDROID_HOME=$ANDROID_SDK_DIR" >> "$HOME/.bashrc"
    echo "export ANDROID_SDK_ROOT=$ANDROID_SDK_DIR" >> "$HOME/.bashrc"
fi

echo ""

# ──────────────────────────────────────────────
# Step 4: Install Android SDK components
# ──────────────────────────────────────────────
echo -e "${CYAN}[4/9] Installing SDK components...${NC}"

SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKMANAGER" --licenses > /dev/null 2>&1 || true

echo -e "  Installing platforms;android-${REQUIRED_COMPILE_SDK}..."
yes | "$SDKMANAGER" --install "platforms;android-${REQUIRED_COMPILE_SDK}" > /dev/null 2>&1 || true

echo -e "  Installing build-tools;${REQUIRED_COMPILE_SDK}.0..."
yes | "$SDKMANAGER" --install "build-tools;${REQUIRED_COMPILE_SDK}.0" > /dev/null 2>&1 || true

echo -e "  Installing platform-tools..."
yes | "$SDKMANAGER" --install "platform-tools" > /dev/null 2>&1 || true

echo -e "  Installing ndk;${REQUIRED_NDK}..."
yes | "$SDKMANAGER" --install "ndk;${REQUIRED_NDK}" > /dev/null 2>&1 || true

echo -e "  ${GREEN}SDK components ready${NC}"
echo ""

# ──────────────────────────────────────────────
# Step 5: Install Flutter SDK
# ──────────────────────────────────────────────
echo -e "${CYAN}[5/9] Checking Flutter SDK...${NC}"

# Resolve FLUTTER_BIN — find existing or install
resolve_flutter() {
    local TARGET_VER="$1"
    local TARGET_DIR="$HOME/flutter"

    # If specific version requested and different from default location
    if [ -n "$TARGET_VER" ] && [ "$TARGET_VER" != "$FLUTTER_VERSION" ]; then
        TARGET_DIR="$HOME/flutter-$TARGET_VER"
    fi

    # Check if already installed at target dir
    if [ -f "$TARGET_DIR/bin/flutter" ]; then
        echo -e "  ${GREEN}Flutter found at $TARGET_DIR${NC}"
        FLUTTER_BIN="$TARGET_DIR/bin/flutter"
        # Verify version matches
        local INSTALLED_VER
        INSTALLED_VER=$("$FLUTTER_BIN" --version 2>/dev/null | head -1 | awk '{print $2}' || echo "")
        if [ -n "$INSTALLED_VER" ] && [ "$INSTALLED_VER" = "$TARGET_VER" ]; then
            return 0
        fi
    fi

    # Check system PATH
    if command -v flutter &> /dev/null; then
        local SYS_FLUTTER
        SYS_FLUTTER="$(command -v flutter)"
        local INSTALLED_VER
        INSTALLED_VER=$("$SYS_FLUTTER" --version 2>/dev/null | head -1 | awk '{print $2}' || echo "")
        if [ "$INSTALLED_VER" = "$TARGET_VER" ]; then
            FLUTTER_BIN="$SYS_FLUTTER"
            echo -e "  ${GREEN}Flutter $TARGET_VER found in PATH${NC}"
            return 0
        fi
    fi

    # Download and install
    echo -e "  ${YELLOW}Flutter $TARGET_VER not found, installing...${NC}"

    if command -v apt-get &> /dev/null; then
        apt-get update -qq 2>/dev/null || true
        apt-get install -y -qq git curl unzip xz-utils zip clang cmake ninja-build pkg-config libgtk-3-dev 2>/dev/null || true
    elif command -v yum &> /dev/null; then
        yum install -y git curl unzip xz zip 2>/dev/null || true
    fi

    FLUTTER_URL="https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_${TARGET_VER}-stable.tar.xz"
    echo -e "  ${YELLOW}Downloading Flutter ${TARGET_VER}...${NC}"
    
    if curl -fSL "$FLUTTER_URL" -o "/tmp/flutter.tar.xz" 2>/dev/null; then
        echo -e "  ${YELLOW}Extracting to ${TARGET_DIR}...${NC}"
        rm -rf "$TARGET_DIR"
        mkdir -p "$TARGET_DIR"
        tar -xf "/tmp/flutter.tar.xz" -C "$TARGET_DIR" --strip-components=1
        rm -f "/tmp/flutter.tar.xz"
    else
        echo -e "  ${YELLOW}Direct download failed, trying git clone...${NC}"
        rm -rf "$TARGET_DIR"
        git clone --depth 1 --branch "$TARGET_VER" https://github.com/flutter/flutter.git "$TARGET_DIR" 2>/dev/null || {
            echo -e "${RED}ERROR: Failed to install Flutter $TARGET_VER${NC}"
            return 1
        }
    fi

    FLUTTER_BIN="$TARGET_DIR/bin/flutter"
    git config --global --add safe.directory "$TARGET_DIR" 2>/dev/null || true
    git config --global --add safe.directory "*" 2>/dev/null || true

    if ! grep -q "flutter/bin" "$HOME/.bashrc" 2>/dev/null; then
        echo "export PATH=$TARGET_DIR/bin:\$PATH" >> "$HOME/.bashrc"
    fi

    echo -e "  ${GREEN}Flutter ${TARGET_VER} installed at ${TARGET_DIR}${NC}"
}

# Install the primary Flutter version
resolve_flutter "$FLUTTER_VERSION"
CURRENT_FLUTTER="$FLUTTER_VERSION"

export PATH="$(dirname "$FLUTTER_BIN"):$PATH"

echo -e "  ${YELLOW}Running flutter doctor...${NC}"
"$FLUTTER_BIN" doctor 2>&1 | head -25 || true
echo ""

# ──────────────────────────────────────────────
# Step 6: Auto-fix build.gradle.kts
# ──────────────────────────────────────────────
echo -e "${CYAN}[6/9] Validating build.gradle.kts...${NC}"

GRADLE_FILE="android/app/build.gradle.kts"
if [ ! -f "$GRADLE_FILE" ]; then
    echo -e "${RED}ERROR: ${GRADLE_FILE} not found!${NC}"
    exit 1
fi

CS=$(grep -oP 'compileSdk\s*=\s*\K\d+' "$GRADLE_FILE" 2>/dev/null || echo "")
if [ "$CS" = "$REQUIRED_COMPILE_SDK" ]; then
    echo -e "  ${GREEN}compileSdk = ${REQUIRED_COMPILE_SDK} OK${NC}"
else
    echo -e "  ${YELLOW}Fixing compileSdk -> ${REQUIRED_COMPILE_SDK}${NC}"
    sed -i "s/compileSdk\s*=\s*[0-9]\+/compileSdk = ${REQUIRED_COMPILE_SDK}/" "$GRADLE_FILE"
fi

TS=$(grep -oP 'targetSdk\s*=\s*\K\d+' "$GRADLE_FILE" 2>/dev/null || echo "")
if [ "$TS" = "$REQUIRED_TARGET_SDK" ]; then
    echo -e "  ${GREEN}targetSdk = ${REQUIRED_TARGET_SDK} OK${NC}"
else
    echo -e "  ${YELLOW}Fixing targetSdk -> ${REQUIRED_TARGET_SDK}${NC}"
    sed -i "s/targetSdk\s*=\s*[0-9]\+/targetSdk = ${REQUIRED_TARGET_SDK}/" "$GRADLE_FILE"
fi

if grep -q 'ndkVersion' "$GRADLE_FILE"; then
    NK=$(grep -oP 'ndkVersion\s*=\s*"\K[^"]+' "$GRADLE_FILE" 2>/dev/null || echo "")
    if [ "$NK" = "$REQUIRED_NDK" ]; then
        echo -e "  ${GREEN}ndkVersion = ${REQUIRED_NDK} OK${NC}"
    else
        echo -e "  ${YELLOW}Fixing ndkVersion -> ${REQUIRED_NDK}${NC}"
        sed -i "s/ndkVersion\s*=\s*\"[^\"]*\"/ndkVersion = \"${REQUIRED_NDK}\"/" "$GRADLE_FILE"
    fi
else
    echo -e "  ${YELLOW}Adding ndkVersion${NC}"
    sed -i "/compileSdk = ${REQUIRED_COMPILE_SDK}/a\\    ndkVersion = \"${REQUIRED_NDK}\"" "$GRADLE_FILE"
fi

if grep -q 'storeFile' "$GRADLE_FILE"; then
    echo -e "  ${YELLOW}Switching to debug signing (no keystore)${NC}"
    sed -i '/signingConfigs {/,/^    }/d' "$GRADLE_FILE"
    sed -i 's/signingConfigs.getByName("release")/signingConfigs.getByName("debug")/' "$GRADLE_FILE"
fi

echo -e "  ${GREEN}build.gradle.kts OK${NC}"
echo ""

# ──────────────────────────────────────────────
# Step 7: Write local.properties
# ──────────────────────────────────────────────
echo -e "${CYAN}[7/9] Writing local.properties...${NC}"

FLUTTER_SDK_ROOT=$(dirname "$(dirname "$FLUTTER_BIN")")
printf 'sdk.dir=%s\nflutter.sdk=%s\n' "$ANDROID_HOME" "$FLUTTER_SDK_ROOT" > android/local.properties

echo -e "  ${GREEN}local.properties written${NC}"
echo -e "  sdk.dir     = ${GREEN}${ANDROID_HOME}${NC}"
echo -e "  flutter.sdk = ${GREEN}${FLUTTER_SDK_ROOT}${NC}"
echo ""

# ════════════════════════════════════════════════════════
# AUTO-FIX FUNCTIONS (matching workflow logic)
# ════════════════════════════════════════════════════════

PUB_LOG="/tmp/pubget.log"
BUILD_LOG="/tmp/build.log"

# ── Function: Fix code issues (pre-build) ──
fix_code_issues() {
    echo -e "  ${CYAN}=== Auto-fixing code issues ===${NC}"
    local CHANGED=0

    # 1. Add http dependency if missing
    if ! grep -q "^  http:" pubspec.yaml; then
        echo -e "  ${YELLOW}Adding http dependency${NC}"
        sed -i '/dependencies:/a \ \ http: ^1.2.0' pubspec.yaml
        CHANGED=1
    fi

    # 2. Add http import to files that use http.XXX but lack import
    grep -rl "http\.[a-zA-Z]" lib/ --include="*.dart" 2>/dev/null | while IFS= read -r FILE; do
        if [ -f "$FILE" ] && ! grep -q "import.*http" "$FILE"; then
            echo -e "  ${YELLOW}Adding http import to $FILE${NC}"
            sed -i '1i import '"'"'package:http/http.dart'"'"' as http;' "$FILE"
            CHANGED=1
        fi
    done

    # 3. font_awesome_flutter v11: Remove .data from FontAwesomeIcons.xxx.data
    #    (v11 removed the .data getter, icons are already FaIconData)
    local FA_DATA_COUNT
    FA_DATA_COUNT=$(grep -rl "FontAwesomeIcons\.\w\+\.data" lib/ --include="*.dart" 2>/dev/null | wc -l || echo "0")
    if [ "$FA_DATA_COUNT" -gt 0 ]; then
        echo -e "  ${YELLOW}Removing .data from FontAwesomeIcons (v11 compat)${NC}"
        find lib/ -name "*.dart" -exec sed -i -E 's/(FontAwesomeIcons\.[a-zA-Z_0-9]+)\.data/\1/g' {} \; 2>/dev/null || true
        CHANGED=1
    fi

    # 4. font_awesome_flutter v11: Ensure version ^11.0.0 in pubspec
    if grep -q "font_awesome_flutter:" pubspec.yaml; then
        if ! grep -Eq "font_awesome_flutter:[[:space:]]*\^11\." pubspec.yaml; then
            echo -e "  ${YELLOW}Upgrading font_awesome_flutter to ^11.0.0 (v11 compat)${NC}"
            sed -i -E "s/font_awesome_flutter:[[:space:]]*['\"]?[^'\"]+['\"]?/font_awesome_flutter: ^11.0.0/g" pubspec.yaml
            CHANGED=1
        fi
    fi

    # 5. qr_flutter: Ensure ^4.1.0 for null safety
    if grep -q "qr_flutter:" pubspec.yaml; then
        if ! grep -Eq "qr_flutter:[[:space:]]*\^4\." pubspec.yaml; then
            echo -e "  ${YELLOW}Upgrading qr_flutter to ^4.1.0 (null safety)${NC}"
            sed -i -E "s/qr_flutter:[[:space:]]*['\"]?[^'\"]+['\"]?/qr_flutter: ^4.1.0/g" pubspec.yaml
            CHANGED=1
        fi
    fi

    # 6. Replace .withValues(alpha: X) → .withOpacity(X) (Flutter 3.27+ deprecation)
    local WV_COUNT
    WV_COUNT=$(grep -rl "\.withValues(" lib/ --include="*.dart" 2>/dev/null | wc -l || echo "0")
    if [ "$WV_COUNT" -gt 0 ]; then
        echo -e "  ${YELLOW}Replacing .withValues(alpha:) → .withOpacity()${NC}"
        find lib/ -name "*.dart" -exec sed -i -E "s/\.withValues\(alpha: ([^)]+)\)/.withOpacity(\1)/g" {} \; 2>/dev/null || true
        CHANGED=1
    fi

    # 7. Add dart:async import for StreamSubscription
    grep -rl "StreamSubscription" lib/ --include="*.dart" 2>/dev/null | while IFS= read -r FILE; do
        if [ -f "$FILE" ] && ! grep -q "import 'dart:async'" "$FILE"; then
            echo -e "  ${YELLOW}Adding dart:async import to $FILE${NC}"
            sed -i "1i import 'dart:async';" "$FILE"
            CHANGED=1
        fi
    done

    echo "$CHANGED" > /tmp/changed_flag
}

# ── Function: Auto-fix pubspec.yaml (dependency version fixes) ──
auto_fix_pubspec() {
    local FIXED=false
    echo -e "  ${CYAN}=== Auto-fixing pubspec.yaml ===${NC}"

    # Fix SDK constraint — use Python for safe YAML handling (avoid sed corruption)
    if grep -q "requires SDK version" "$PUB_LOG" 2>/dev/null || grep -q "requires Dart SDK version" "$PUB_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: Tightening SDK constraint to >=3.6.0 <4.0.0${NC}"
        # Use Python to safely replace the SDK line (avoids sed quote corruption)
        python3 -c "
import re
with open('pubspec.yaml', 'r') as f:
    content = f.read()
# Replace the sdk line under environment:
content = re.sub(r\"(sdk:\\s*)['\\\"]?[\^>=]*3\\.[0-9]+(\\.[0-9]+)?['\\\"]?(\\s*<4\\.0\\.0)?['\\\"]?\", r'\\1\">=3.6.0 <4.0.0\"', content, count=1)
with open('pubspec.yaml', 'w') as f:
    f.write(content)
" 2>/dev/null || true
        FIXED=true
    fi

    if grep -q "version solving failed" "$PUB_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: Broad SDK constraint for version solving${NC}"
        python3 -c "
import re
with open('pubspec.yaml', 'r') as f:
    content = f.read()
content = re.sub(r\"(sdk:\\s*)['\\\"]?[\^>=]*3\\.[0-9]+(\\.[0-9]+)?['\\\"]?(\\s*<4\\.0\\.0)?['\\\"]?\", r'\\1\">=3.0.0 <4.0.0\"', content, count=1)
with open('pubspec.yaml', 'w') as f:
    f.write(content)
" 2>/dev/null || true
        FIXED=true
    fi

    # Package-specific downgrades (same as workflow)
    if grep -q "webview_flutter" "$PUB_LOG" 2>/dev/null && (grep -q "requires SDK version" "$PUB_LOG" 2>/dev/null || grep -q "version solving failed" "$PUB_LOG" 2>/dev/null); then
        echo -e "  ${YELLOW}Fix: Downgrading webview_flutter to ^4.13.0${NC}"
        sed -i -E "s/webview_flutter:[[:space:]]*['\"]?[^'\"]+['\"]?/webview_flutter: ^4.13.0/g" pubspec.yaml || true
        FIXED=true
    fi

    if grep -q "flutter_sound" "$PUB_LOG" 2>/dev/null && (grep -q "requires SDK version" "$PUB_LOG" 2>/dev/null || grep -q "version solving failed" "$PUB_LOG" 2>/dev/null); then
        echo -e "  ${YELLOW}Fix: Downgrading flutter_sound to ^9.2.13${NC}"
        sed -i -E "s/flutter_sound:[[:space:]]*['\"]?[^'\"]+['\"]?/flutter_sound: ^9.2.13/g" pubspec.yaml || true
        FIXED=true
    fi

    if grep -q "permission_handler" "$PUB_LOG" 2>/dev/null && (grep -q "requires SDK version" "$PUB_LOG" 2>/dev/null || grep -q "version solving failed" "$PUB_LOG" 2>/dev/null); then
        echo -e "  ${YELLOW}Fix: Downgrading permission_handler to ^11.3.1${NC}"
        sed -i -E "s/permission_handler:[[:space:]]*['\"]?[^'\"]+['\"]?/permission_handler: ^11.3.1/g" pubspec.yaml || true
        FIXED=true
    fi

    if grep -q "audioplayers" "$PUB_LOG" 2>/dev/null && grep -q "version solving failed" "$PUB_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: Downgrading audioplayers to ^5.2.1${NC}"
        sed -i -E "s/audioplayers:[[:space:]]*['\"]?[^'\"]+['\"]?/audioplayers: ^5.2.1/g" pubspec.yaml || true
        FIXED=true
    fi

    if grep -q "font_awesome_flutter" "$PUB_LOG" 2>/dev/null && (grep -q "extends.*IconData" "$PUB_LOG" 2>/dev/null || grep -q "final class" "$PUB_LOG" 2>/dev/null); then
        echo -e "  ${YELLOW}Fix: font_awesome_flutter v10 extends final IconData — upgrading to ^11.0.0${NC}"
        sed -i -E "s/font_awesome_flutter:[[:space:]]*['\"]?[^'\"]+['\"]?/font_awesome_flutter: ^11.0.0/g" pubspec.yaml || true
        FIXED=true
    fi

    # Remove dependency_overrides if causing issues
    if grep -q "overrides" "$PUB_LOG" 2>/dev/null || grep -q "dependency_overrides" "$PUB_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: Removing dependency_overrides${NC}"
        sed -i '/^dependency_overrides:/,/^[^ ]/d' pubspec.yaml || true
        FIXED=true
    fi

    # Validate YAML syntax after fixes
    if ! python3 -c "import yaml; yaml.safe_load(open('pubspec.yaml'))" 2>/dev/null; then
        echo -e "  ${RED}WARNING: pubspec.yaml may be corrupted, attempting recovery...${NC}"
        # Try to fix common corruption: unbalanced quotes in sdk line
        python3 -c "
import re
with open('pubspec.yaml', 'r') as f:
    lines = f.readlines()
fixed = []
for line in lines:
    stripped = line.strip()
    if stripped.startswith('sdk:'):
        # Reconstruct the sdk line cleanly
        fixed.append(\"  sdk: '>=3.6.0 <4.0.0'\n\")
    else:
        fixed.append(line)
with open('pubspec.yaml', 'w') as f:
    f.writelines(fixed)
" 2>/dev/null || true
        FIXED=true
    fi

    if [ "$FIXED" = true ]; then
        echo -e "  ${GREEN}Pubspec has been fixed${NC}"
        rm -f pubspec.lock
    else
        echo -e "  ${GREEN}No pubspec fixes needed${NC}"
    fi
}

# ── Function: Auto-fix code errors from build log ──
auto_fix_code_errors() {
    local FIXED=false
    echo -e "  ${CYAN}=== Auto-fixing code errors from build log ===${NC}"

    # PlayerState.connecting removed in newer flutter_sound
    if grep -q "Member not found: 'connecting'" "$BUILD_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: Removing PlayerState.connecting${NC}"
        find lib/ -name "*.dart" -exec sed -i "s/s == PlayerState.connecting || s == PlayerState.buffering/s == PlayerState.buffering/g" {} \; 2>/dev/null || true
        find lib/ -name "*.dart" -exec sed -i "s/|| s == PlayerState.connecting//g" {} \; 2>/dev/null || true
        FIXED=true
    fi

    # Icons.whatsapp_rounded removed
    if grep -q "Member not found: 'whatsapp_rounded'" "$BUILD_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: Replacing Icons.whatsapp_rounded → Icons.chat_rounded${NC}"
        find lib/ -name "*.dart" -exec sed -i "s/Icons\.whatsapp_rounded/Icons.chat_rounded/g" {} \; 2>/dev/null || true
        FIXED=true
    fi

    # .withValues → .withOpacity
    if grep -q "withValues" "$BUILD_LOG" 2>/dev/null || grep -q "is not a constant expression" "$BUILD_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: Replacing .withValues(alpha:) → .withOpacity()${NC}"
        find lib/ -name "*.dart" -exec sed -i -E "s/\.withValues\(alpha: ([^)]+)\)/.withOpacity(\1)/g" {} \; 2>/dev/null || true
        FIXED=true
    fi

    # StreamSubscription missing import
    if grep -q "Type 'StreamSubscription' not found" "$BUILD_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: Adding dart:async import${NC}"
        grep -rl "StreamSubscription" lib/ --include="*.dart" 2>/dev/null | while IFS= read -r FILE; do
            if [ -f "$FILE" ] && ! grep -q "import 'dart:async'" "$FILE"; then
                sed -i "1i import 'dart:async';" "$FILE"
            fi
        done
        FIXED=true
    fi

    # FontAwesomeIcons .data getter removed (v11)
    if grep -q "\.data" "$BUILD_LOG" 2>/dev/null && grep -q "FontAwesomeIcons" "$BUILD_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: Removing .data from FontAwesomeIcons (v11)${NC}"
        find lib/ -name "*.dart" -exec sed -i -E 's/(FontAwesomeIcons\.[a-zA-Z_0-9]+)\.data/\1/g' {} \; 2>/dev/null || true
        FIXED=true
    fi

    # font_awesome_flutter v10 extends final class IconData
    if grep -q "extends.*IconData" "$BUILD_LOG" 2>/dev/null && grep -q "font_awesome" "$BUILD_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: font_awesome_flutter v10 incompatible — upgrading to ^11.0.0${NC}"
        sed -i -E "s/font_awesome_flutter:[[:space:]]*['\"]?[^'\"]+['\"]?/font_awesome_flutter: ^11.0.0/g" pubspec.yaml || true
        # Also remove all .data references
        find lib/ -name "*.dart" -exec sed -i -E 's/(FontAwesomeIcons\.[a-zA-Z_0-9]+)\.data/\1/g' {} \; 2>/dev/null || true
        FIXED=true
    fi

    # _kBase scope error (top-level constant needed)
    if grep -q "_kBase" "$BUILD_LOG" 2>/dev/null && grep -q "not defined" "$BUILD_LOG" 2>/dev/null; then
        echo -e "  ${YELLOW}Fix: _kBase scope issue — check control_panel.dart top-level _kBaseUrl${NC}"
        FIXED=true
    fi

    if [ "$FIXED" = true ]; then
        echo -e "  ${GREEN}Code errors have been fixed${NC}"
    else
        echo -e "  ${GREEN}No auto-fixable code errors found${NC}"
    fi
}

# ── Function: Switch Flutter version ──
switch_flutter_version() {
    local TARGET_VERSION="$1"
    if [ -z "$TARGET_VERSION" ] || [ "$TARGET_VERSION" = "$CURRENT_FLUTTER" ]; then
        return 0
    fi
    echo -e "  ${YELLOW}=== Switching Flutter from $CURRENT_FLUTTER → $TARGET_VERSION ===${NC}"

    resolve_flutter "$TARGET_VERSION"
    if [ -n "$FLUTTER_BIN" ] && [ -f "$FLUTTER_BIN" ]; then
        export PATH="$(dirname "$FLUTTER_BIN"):$PATH"
        "$FLUTTER_BIN" --version 2>&1 | head -3
        CURRENT_FLUTTER="$TARGET_VERSION"
    else
        echo -e "  ${RED}Flutter $TARGET_VERSION failed to install, staying at $CURRENT_FLUTTER${NC}"
    fi
}

# ── Function: try_pub_get ──
try_pub_get() {
    "$FLUTTER_BIN" pub get 2>&1 | tee "$PUB_LOG"
    return ${PIPESTATUS[0]}
}

# ════════════════════════════════════════════════════════
# Step 8: Pre-build auto-fix pass
# ════════════════════════════════════════════════════════
echo -e "${CYAN}[8/9] Pre-build auto-fix pass...${NC}"

set +e
fix_code_issues
set -e

if [ -f /tmp/changed_flag ]; then
    CHANGED=$(cat /tmp/changed_flag)
    rm -f /tmp/changed_flag
else
    CHANGED=0
fi

if [ "$CHANGED" = "1" ]; then
    echo -e "  ${YELLOW}Code was fixed, running flutter pub get...${NC}"
    "$FLUTTER_BIN" pub get || true
fi

echo ""

# ════════════════════════════════════════════════════════
# Step 9: Build APK with retry + auto-fix + fallback
# ════════════════════════════════════════════════════════
echo -e "${CYAN}[9/9] Building APK (with auto-fix retry)...${NC}"
echo -e "  ${YELLOW}Gradle heap: ${GRADLE_HEAP} | Flutter: ${CURRENT_FLUTTER}${NC}"
echo -e "  ${YELLOW}Max retries: ${MAX_RETRIES} | Fallback versions: ${FALLBACK_VERSIONS[*]}${NC}"
echo ""

while [ $RETRY_COUNT -lt $MAX_RETRIES ] && [ "$SUCCESS" = false ]; do
    RETRY_COUNT=$((RETRY_COUNT + 1))
    echo ""
    echo -e "${BOLD}============================================${NC}"
    echo -e "${BOLD}  Attempt $RETRY_COUNT of $MAX_RETRIES (Flutter $CURRENT_FLUTTER)${NC}"
    echo -e "${BOLD}============================================${NC}"

    # ── Try flutter pub get ──
    if try_pub_get; then
        echo -e "  ${GREEN}flutter pub get succeeded${NC}"

        # Kill stale Gradle daemons
        cd android
        ./gradlew --stop 2>/dev/null || true
        cd "$SCRIPT_DIR"

        # ── Run build ──
        BUILD_START=$(date +%s)
        BUILD_CMD="$FLUTTER_BIN build apk --release"

        echo -e "  ${YELLOW}Running: $BUILD_CMD${NC}"
        if $BUILD_CMD 2>&1 | tee "$BUILD_LOG"; then
            BUILD_END=$(date +%s)
            DUR=$((BUILD_END - BUILD_START))
            SUCCESS=true
            echo ""
            echo -e "${GREEN}+============================================+${NC}"
            echo -e "${GREEN}|         BUILD SUCCESSFUL!                  |${NC}"
            echo -e "${GREEN}+============================================+${NC}"

            APK_PATH="build/app/outputs/flutter-apk/app-release.apk"
            if [ -f "$APK_PATH" ]; then
                APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
                echo -e "  ${GREEN}APK:${NC}    ${APK_PATH}"
                echo -e "  ${GREEN}Size:${NC}   ${APK_SIZE}"
                echo -e "  ${GREEN}Time:${NC}   $((DUR/60))m $((DUR%60))s"
            fi
            break
        else
            BUILD_END=$(date +%s)
            DURF=$((BUILD_END - BUILD_START))
            echo ""
            echo -e "${RED}Build failed after $((DURF/60))m $((DURF%60))s${NC}"

            # ── Auto-fix and retry ──
            set +e
            auto_fix_code_errors
            set -e
            auto_fix_pubspec

            # Check if SDK version issue — try fallback Flutter
            if grep -q "requires SDK version" "$BUILD_LOG" 2>/dev/null || grep -q "requires Dart SDK version" "$BUILD_LOG" 2>/dev/null; then
                if [ $FALLBACK_IDX -lt ${#FALLBACK_VERSIONS[@]} ]; then
                    NEXT_VERSION="${FALLBACK_VERSIONS[$FALLBACK_IDX]}"
                    FALLBACK_IDX=$((FALLBACK_IDX + 1))
                    echo -e "  ${YELLOW}SDK version mismatch — switching to Flutter $NEXT_VERSION...${NC}"
                    switch_flutter_version "$NEXT_VERSION"
                    rm -rf build .dart_tool
                    continue
                fi
            fi

            # Generic fallback after 3 failures
            if [ "$SUCCESS" = false ] && [ $RETRY_COUNT -ge 3 ] && [ $FALLBACK_IDX -lt ${#FALLBACK_VERSIONS[@]} ]; then
                NEXT_VERSION="${FALLBACK_VERSIONS[$FALLBACK_IDX]}"
                FALLBACK_IDX=$((FALLBACK_IDX + 1))
                echo -e "  ${YELLOW}Trying fallback Flutter $NEXT_VERSION...${NC}"
                switch_flutter_version "$NEXT_VERSION"
                rm -rf build .dart_tool
                continue
            fi

            rm -rf build .dart_tool
        fi
    else
        echo -e "  ${RED}flutter pub get failed, attempting to fix pubspec...${NC}"
        auto_fix_pubspec
        rm -f pubspec.lock

        # Fallback Flutter version after 3 failed pub gets
        if [ $RETRY_COUNT -ge 3 ] && [ $FALLBACK_IDX -lt ${#FALLBACK_VERSIONS[@]} ]; then
            NEXT_VERSION="${FALLBACK_VERSIONS[$FALLBACK_IDX]}"
            FALLBACK_IDX=$((FALLBACK_IDX + 1))
            echo -e "  ${YELLOW}Trying fallback Flutter $NEXT_VERSION for pub get...${NC}"
            switch_flutter_version "$NEXT_VERSION"
            rm -f pubspec.lock
        fi
    fi
done

# ════════════════════════════════════════════════════════
# Final result
# ════════════════════════════════════════════════════════
if [ "$SUCCESS" = false ]; then
    echo ""
    echo -e "${RED}+============================================+${NC}"
    echo -e "${RED}|         BUILD FAILED!                      |${NC}"
    echo -e "${RED}+============================================+${NC}"
    echo -e "  ${RED}Tried $MAX_RETRIES attempts with Flutter versions: $CURRENT_FLUTTER${NC}"
    echo ""
    echo -e "  ${YELLOW}Last pub get output:${NC}"
    cat "$PUB_LOG" 2>/dev/null | tail -30 || true
    echo ""
    echo -e "  ${YELLOW}Last build output (last 60 lines):${NC}"
    tail -60 "$BUILD_LOG" 2>/dev/null || true
    echo ""
    echo -e "  ${YELLOW}Tips:${NC}"
    echo -e "    - Check OOM: dmesg | grep -i 'oom kill'"
    echo -e "    - Free memory: free -h"
    echo -e "    - Debug build: $FLUTTER_BIN build apk --release --verbose"
    echo -e "    - Check pubspec: cat pubspec.yaml"
    exit 1
fi

echo ""
echo -e "${CYAN}=== Build Script Complete ===${NC}"
echo -e "  Flutter version used: ${CURRENT_FLUTTER}"
echo -e "  Total attempts: ${RETRY_COUNT}"
