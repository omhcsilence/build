package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.app.ActivityManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class AppBlockMonitorService extends Service {
    private static final String CHANNEL_ID = "app_block_monitor";
    private static final String TAG = "CRPT.AppBlock";
    private Handler handler;
    private Runnable monitorRunnable;
    private boolean isRunning = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(9999, createNotification());

        handler = new Handler(Looper.getMainLooper());
        isRunning = true;

        monitorRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;

                try {
                    checkAndKillBlockedApps();
                } catch (Exception e) {
                    Log.w(TAG, "checkAndKillBlockedApps error: " + e.getMessage());
                }

                if (isRunning) {
                    handler.postDelayed(this, 500);
                }
            }
        };
        handler.post(monitorRunnable);
    }

    private void forceStopPackage(ActivityManager am, String packageName) {
        try {
            try {
                Method method = am.getClass().getMethod("forceStopPackage", String.class);
                method.setAccessible(true);
                method.invoke(am, packageName);
                return;
            } catch (Exception e1) {
                Log.w(TAG, "Reflection failed: " + e1.getMessage());
            }

            try {
                Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "am force-stop " + packageName});
                boolean finished = process.waitFor(2, TimeUnit.SECONDS);
                if (finished) {
                    return;
                }
            } catch (Exception e2) {
                Log.w(TAG, "Shell failed: " + e2.getMessage());
            }
        } catch (Exception e) {
            Log.e(TAG, "forceStopPackage error: " + e.getMessage());
        }
    }

    private void checkAndKillBlockedApps() {
        try {
            SharedPreferences prefs = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
            Set<String> blockedSet = new HashSet<>(prefs.getStringSet("blocked_apps", new HashSet<>()));

            if (blockedSet.isEmpty()) return;

            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return;
            
            for (String packageName : blockedSet) {
                try {
                    forceStopPackage(am, packageName);
                } catch (Exception e) {
                    Log.w(TAG, "Failed to kill " + packageName + ": " + e.getMessage());
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "checkAndKillBlockedApps error: " + e.getMessage());
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        if (handler != null && monitorRunnable != null) {
            handler.removeCallbacks(monitorRunnable);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "App Block Monitor",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Monitoring blocked applications");
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("App Block Active")
            .setContentText("Monitoring blocked apps...")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }
}
