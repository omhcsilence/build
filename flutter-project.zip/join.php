<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$my_id = $_SESSION['user_id'];
$settings = json_decode(file_get_contents('data/settings.json'), true);
$users = json_decode(file_get_contents('data/users.json'), true);

if (isset($users[$my_id])) {
    $users[$my_id]['joined_group'] = true;
    file_put_contents('data/users.json', json_encode($users, JSON_PRETTY_PRINT));
}

// Redirect ke Link WhatsApp dari Admin Settings
$target_url = !empty($settings['group_link']) ? $settings['group_link'] : 'https://chat.whatsapp.com/';
header("Location: " . $target_url);
exit();
