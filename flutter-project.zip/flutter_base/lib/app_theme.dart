import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

/// Shared video background URL used across the entire app.
const String kAppBgVideoUrl = 'assets/videos/bg_video.mp4';

/// A reusable widget that provides the consistent app theme:
/// - Video background (same as login/dashboard)
/// - Dark overlay
/// - Scaffold with transparent background
///
/// Usage:
/// ```dart
/// @override
/// Widget build(BuildContext context) {
///   return AppThemeScaffold(
///     appBar: AppBar(...),
///     child: YourContent(),
///   );
/// }
/// ```
class AppThemeScaffold extends StatefulWidget {
  final Widget child;
  final PreferredSizeWidget? appBar;

  AppThemeScaffold({
    super.key,
    required this.child,
    this.appBar,
  });

  @override
  State<AppThemeScaffold> createState() => _AppThemeScaffoldState();
}

class _AppThemeScaffoldState extends State<AppThemeScaffold> {
  late VideoPlayerController _videoController;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.asset(kAppBgVideoUrl)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _ready = true);
          _videoController.play();
          _videoController.setLooping(true);
          _videoController.setVolume(0.0);
        }
      }).catchError((_) {});
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: widget.appBar,
      body: Stack(
        children: [
          // Video background
          if (_ready && _videoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
                ),
              ),
            ),

          // Dark overlay
          Container(color: Colors.black.withOpacity(0.6)),

          // Content
          widget.child,
        ],
      ),
    );
  }
}

/// A pre-built transparent AppBar that matches the app theme.
/// Usage: `appBar: appThemeAppBar('Title', onBack: () => Navigator.pop(context))`
PreferredSizeWidget appThemeAppBar(String title, {VoidCallback? onBack, List<Widget>? actions}) {
  return AppBar(
    backgroundColor: Colors.black.withOpacity(0.3),
    elevation: 0,
    leading: onBack != null
        ? IconButton(icon: Icon(Icons.arrow_back_ios_new, color: Colors.white70, size: 18), onPressed: onBack)
        : null,
    title: Text(
      title,
      style: TextStyle(
        color: Colors.white,
        fontFamily: 'MADEEvolveSansEVO',
        fontSize: 16,
        fontWeight: FontWeight.bold,
        letterSpacing: 1,
      ),
    ),
    centerTitle: true,
    flexibleSpace: ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(color: Colors.transparent),
      ),
    ),
    actions: actions,
    iconTheme: IconThemeData(color: Colors.white70),
  );
}

/// A themed card container with glassmorphism effect.
Widget appThemeCard({required Widget child, EdgeInsetsGeometry? padding}) {
  return Container(
    width: double.infinity,
    padding: padding ?? const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.06),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: Colors.white.withOpacity(0.07), width: 0.5),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.25),
          blurRadius: 16,
          offset: Offset(0, 6),
        ),
      ],
    ),
    child: child,
  );
}

/// A themed text field input (iOS-style transparent).
Widget appThemeInput({
  required TextEditingController controller,
  required IconData icon,
  required String hint,
  bool obscure = false,
  Widget? suffix,
}) {
  return Container(
    height: 48,
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.05),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.white.withOpacity(0.06), width: 0.5),
    ),
    child: Row(
      children: [
        SizedBox(width: 14),
        Icon(icon, color: Colors.white.withOpacity(0.25), size: 15),
        SizedBox(width: 10),
        Expanded(
          child: TextField(
            controller: controller,
            obscureText: obscure,
            style: TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontFamily: 'ShareTechMono',
              decoration: TextDecoration.none,
            ),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                color: Colors.white.withOpacity(0.2),
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.only(bottom: 12),
            ),
          ),
        ),
        if (suffix != null) ...[
          SizedBox(width: 4),
          Padding(padding: const EdgeInsets.only(right: 12), child: suffix),
        ] else
          SizedBox(width: 14),
      ],
    ),
  );
}

/// A themed primary button.
Widget appThemeButton({
  required String text,
  required VoidCallback onTap,
  bool isLoading = false,
  double? width,
}) {
  return GestureDetector(
    onTap: isLoading ? null : onTap,
    child: AnimatedContainer(
      duration: Duration(milliseconds: 250),
      height: 48,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isLoading
              ? [Color(0xFF222222), Color(0xFF222222)]
              : [Color(0xFF111111), Color(0xFF222222)],
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF111111).withOpacity(isLoading ? 0.1 : 0.3),
            blurRadius: 14,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Center(
        child: isLoading
            ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : Text(
                text,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'MADEEvolveSansEVO',
                  letterSpacing: 2,
                ),
              ),
      ),
    ),
  );
}