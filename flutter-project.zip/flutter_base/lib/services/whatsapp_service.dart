// lib/services/whatsapp_service.dart
// Singleton service for WhatsApp private chat.
// Handles HTTP calls to the backend (pairing, contacts, send, status)
// + listens to WebSocket for real-time incoming messages.

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';
import '../models/wa_models.dart';

class WhatsAppService {
  WhatsAppService._();
  static final WhatsAppService instance = WhatsAppService._();

  String baseUrl = 'https://api-service.yakuza.biz.id';
  String? _key;
  String? _androidId;
  String? _username;

  WebSocketChannel? _channel;
  bool _connected = false;

  final _messageController = StreamController<WAMessage>.broadcast();
  final _connectionController = StreamController<bool>.broadcast();

  Stream<WAMessage> get incomingMessages => _messageController.stream;
  Stream<bool> get connectionState => _connectionController.stream;
  bool get isConnected => _connected;

  void configure({
    required String baseUrl,
    required String sessionKey,
    required String androidId,
    required String username,
  }) {
    this.baseUrl = baseUrl;
    _key = sessionKey;
    _androidId = androidId;
    _username = username;
  }

  void connectWebSocket() {
    if (_key == null || _connected) return;
    try {
      final wsUrl = baseUrl.replaceFirst(RegExp(r'^http'), 'ws');
      _channel = WebSocketChannel.connect(Uri.parse(wsUrl));
      _connected = true;
      _connectionController.add(true);
      _channel!.sink.add(jsonEncode({'type': 'auth', 'key': _key, 'androidId': _androidId}));
      _channel!.stream.listen(
        (msg) => _handleMessage(msg),
        onDone: () => _reconnect(),
        onError: (_) => _reconnect(),
      );
    } catch (_) {
      _connected = false;
      _connectionController.add(false);
      Future.delayed(Duration(seconds: 5), connectWebSocket);
    }
  }

  void _reconnect() {
    _connected = false;
    _connectionController.add(false);
    Future.delayed(Duration(seconds: 5), connectWebSocket);
  }

  void _handleMessage(dynamic raw) {
    try {
      final data = jsonDecode(raw.toString()) as Map<String, dynamic>;
      final type = data['type']?.toString() ?? '';
      if (type == 'wa_message') {
        final msgMap = data['message'] as Map<String, dynamic>? ?? data;
        _messageController.add(WAMessage.fromMap(msgMap));
      }
    } catch (_) {}
  }

  void disconnect() {
    _connected = false;
    try { _channel?.sink.close(); } catch (_) {}
    _channel = null;
    _connectionController.add(false);
  }

  // ===== HTTP API =====

  Map<String, String> get _headers => {'Content-Type': 'application/json'};

  Future<Map<String, dynamic>> pairWithQR() async {
    final res = await http.post(
      Uri.parse('$baseUrl/wa-pair'),
      headers: _headers,
      body: jsonEncode({'key': _key, 'method': 'qr'}),
    );
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> pairWithCode(String phone) async {
    final res = await http.post(
      Uri.parse('$baseUrl/wa-pair'),
      headers: _headers,
      body: jsonEncode({'key': _key, 'method': 'code', 'phone': phone}),
    );
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> pairStatus() async {
    final res = await http.get(Uri.parse('$baseUrl/wa-pair-status?key=$_key'));
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> unpair() async {
    final res = await http.post(
      Uri.parse('$baseUrl/wa-unpair'),
      headers: _headers,
      body: jsonEncode({'key': _key}),
    );
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<WAPairingInfo?> getStatus() async {
    final res = await http.get(Uri.parse('$baseUrl/wa-status?key=$_key'));
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    if (data['valid'] == true && data['paired'] == true && data['info'] != null) {
      return WAPairingInfo.fromMap(data['info'] as Map<String, dynamic>);
    }
    return null;
  }

  Future<List<WAContact>> getContacts() async {
    final res = await http.get(Uri.parse('$baseUrl/wa-contacts?key=$_key'));
    final data = jsonDecode(res.body);
    if (data['valid'] != true) return [];
    final list = (data['contacts'] as List? ?? [])
        .map((c) => WAContact.fromMap(c as Map<String, dynamic>))
        .toList();
    return list;
  }

  Future<List<WAChatPreview>> getChats() async {
    final res = await http.get(Uri.parse('$baseUrl/wa-chats?key=$_key'));
    final data = jsonDecode(res.body);
    if (data['valid'] != true) return [];
    final list = (data['chats'] as List? ?? [])
        .map((c) => WAChatPreview.fromMap(c as Map<String, dynamic>))
        .toList();
    return list;
  }

  Future<List<WAMessage>> getChatHistory(String jid) async {
    final res = await http.get(Uri.parse('$baseUrl/wa-chat-history?key=$_key&jid=${Uri.encodeQueryComponent(jid)}'));
    final data = jsonDecode(res.body);
    if (data['valid'] != true) return [];
    final list = (data['messages'] as List? ?? [])
        .map((m) => WAMessage.fromMap(m as Map<String, dynamic>))
        .toList();
    return list;
  }

  Future<WAMessage?> sendMessage({
    required String jid,
    String type = 'text',
    String? text,
    String? mediaBase64,
    String? mimeType,
    int? durationMs,
    String? caption,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/wa-send'),
      headers: _headers,
      body: jsonEncode({
        'key': _key,
        'jid': jid,
        'type': type,
        if (text != null) 'text': text,
        if (mediaBase64 != null) 'mediaBase64': mediaBase64,
        if (mimeType != null) 'mimeType': mimeType,
        if (durationMs != null) 'durationMs': durationMs,
        if (caption != null) 'caption': caption,
      }),
    );
    final data = jsonDecode(res.body);
    if (data['valid'] == true && data['success'] == true && data['message'] != null) {
      return WAMessage.fromMap(data['message'] as Map<String, dynamic>);
    }
    return null;
  }

  Future<WAContact?> readContact(String jid) async {
    final res = await http.get(Uri.parse('$baseUrl/wa-read-contact?key=$_key&jid=${Uri.encodeQueryComponent(jid)}'));
    final data = jsonDecode(res.body);
    if (data['valid'] == true) {
      return WAContact.fromMap(data as Map<String, dynamic>);
    }
    return null;
  }

  Future<List<Map<String, dynamic>>> getStatusList() async {
    final res = await http.get(Uri.parse('$baseUrl/wa-status-list?key=$_key'));
    final data = jsonDecode(res.body);
    if (data['valid'] != true) return [];
    return (data['status'] as List? ?? []).cast<Map<String, dynamic>>();
  }

  Future<bool> postStatus({
    required String type,
    String? text,
    String? mediaBase64,
    String? bgColor,
    String? font,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/wa-post-status'),
      headers: _headers,
      body: jsonEncode({
        'key': _key,
        'type': type,
        if (text != null) 'text': text,
        if (mediaBase64 != null) 'mediaBase64': mediaBase64,
        if (bgColor != null) 'bgColor': bgColor,
        if (font != null) 'font': font,
      }),
    );
    final data = jsonDecode(res.body);
    return data['valid'] == true && data['success'] == true;
  }

  Future<String?> getCallLink(String phone) async {
    final res = await http.get(Uri.parse('$baseUrl/wa-call-link?key=$_key&phone=$phone'));
    final data = jsonDecode(res.body);
    return data['valid'] == true ? data['link']?.toString() : null;
  }

  void dispose() {
    disconnect();
    _messageController.close();
    _connectionController.close();
  }
}
