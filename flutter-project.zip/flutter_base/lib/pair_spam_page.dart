// pair_spam_page.dart — Spam Pairing Code via Baileys
//
// Fitur: Kirim request pairing code ke nomor target berkali-kali
// menggunakan sesi Baileys yang aktif di server API.
//
// Cara kerja:
// 1. User input nomor target + jumlah spam
// 2. App kirim request ke API /spamPairing
// 3. API pakai sock.requestPairingCode() berkali-kali
// 4. Target akan dapet popup pairing code berkali-kali

import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class _PC {
  static const bg       = Color(0xFF000000);
  static const bg2       = Color(0xFF0a0a0a);
  static const surface   = Color(0xFF111111);
  static const card      = Color(0xFF111111);
  static const accent    = Color(0xFFFF3B30);
  static const accent2   = Color(0xFFFF6B6B);
  static const accent3   = Color(0xFFCC2E25);
  static const gold      = Color(0xFF333333);
  static const success   = Color(0xFFFF3B30);
  static const text      = Color(0xFFE0E7FF);
  static const muted     = Color(0x73E0E7FF);
  static const muted2    = Color(0x38E0E7FF);
  static const border    = Color(0x1AFF3B30);
  static const border2   = Color(0x0FFFFFFF);
  static const String baseUrl = "https://api-service.yakuza.biz.id";
}

class PairSpamPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  PairSpamPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<PairSpamPage> createState() => _PairSpamPageState();
}

class _PairSpamPageState extends State<PairSpamPage>
    with TickerProviderStateMixin {
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  final _targetController = TextEditingController();
  final _amountController = TextEditingController(text: '10');
  final _logController = TextEditingController();
  final ScrollController _logScroll = ScrollController();

  bool _isAttacking = false;
  int _successCount = 0;
  int _failCount = 0;
  List<String> _logs = [];

  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _initBgVideo();
    _pulseController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _bgVideoController.dispose();
    _targetController.dispose();
    _amountController.dispose();
    _logController.dispose();
    _logScroll.dispose();
    super.dispose();
  }

  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ── API ──
  Future<void> _executeSpam() async {
    if (_isAttacking) {
      setState(() => _isAttacking = false);
      return;
    }

    final target = _targetController.text.trim();
    final amountStr = _amountController.text.trim();

    if (target.isEmpty) {
      _showSnack('Nomor target wajib diisi', isError: true);
      return;
    }

    final amount = int.tryParse(amountStr) ?? 10;
    if (amount < 1 || amount > 500) {
      _showSnack('Jumlah 1-500', isError: true);
      return;
    }

    setState(() {
      _isAttacking = true;
      _successCount = 0;
      _failCount = 0;
      _logs.clear();
    });

    _addLog('[SYSTEM] Initializing Pair Spam Protocol...');
    _addLog('[TARGET] $target');
    _addLog('[AMOUNT] $amount pairing requests');

    for (int i = 0; i < amount; i++) {
      if (!_isAttacking) {
        _addLog('[SYSTEM] Spam aborted by user.');
        break;
      }

      try {
        final res = await http.get(
          Uri.parse("${_PC.baseUrl}/spamPairing?key=${widget.sessionKey}&target=$target&pairingCode=OMHCMBUD"),
        ).timeout(Duration(seconds: 15));

        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['valid'] == true) {
            setState(() => _successCount++);
            _addLog('[${i + 1}/$amount] ✅ Pairing code sent to $target');
          } else if (data['cooldown'] == true) {
            setState(() => _failCount++);
            _addLog('[${i + 1}/$amount] ⏳ Cooldown ${data['wait'] ?? ''}s');
            await Future.delayed(Duration(milliseconds: 500));
          } else {
            setState(() => _failCount++);
            _addLog('[${i + 1}/$amount] ❌ ${data['message'] ?? 'Failed'}');
          }
        } else {
          setState(() => _failCount++);
          _addLog('[${i + 1}/$amount] ❌ HTTP ${res.statusCode}');
        }
      } catch (e) {
        setState(() => _failCount++);
        _addLog('[${i + 1}/$amount] ❌ Error: $e');
      }

      await Future.delayed(Duration(milliseconds: 300));
    }

    setState(() => _isAttacking = false);
    _addLog('[SYSTEM] Mission Ended. Success: $_successCount, Fail: $_failCount');
  }

  void _addLog(String log) {
    if (!mounted) return;
    setState(() {
      _logs.add(log);
    });
    Future.delayed(Duration(milliseconds: 100), () {
      if (_logScroll.hasClients) {
        _logScroll.animateTo(
          _logScroll.position.maxScrollExtent,
          duration: Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor: isError ? _PC.accent.withOpacity(0.92) : _PC.success.withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  String? _formatNumber(String input) {
    final c = input.replaceAll(RegExp(r'[^\d]'), '');
    if (c.startsWith('0') || c.length < 8) return null;
    return c;
  }

  Future<void> _pasteTarget() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) {
      _targetController.text = data!.text!.replaceAll(RegExp(r'[^\d]'), '');
    }
  }

  // ── BUILD ──
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.65)),
        Scaffold(
          backgroundColor: Colors.transparent,
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: _PC.card.withOpacity(0.5), shape: BoxShape.circle),
              child: IconButton(
                icon: Icon(Icons.arrow_back_ios_new, color: _PC.accent, size: 18),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(FontAwesomeIcons.link.data, color: _PC.accent, size: 16),
                SizedBox(width: 8),
                Text("PAIR SPAM",
                    style: TextStyle(
                        color: _PC.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        fontSize: 15)),
              ],
            ),
            centerTitle: true,
            flexibleSpace: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(color: _PC.bg.withOpacity(0.4)),
              ),
            ),
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.4,
                colors: [_PC.accent.withOpacity(0.06), _PC.bg.withOpacity(0.0)],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Column(
                  children: [
                    // ── User Card ──
                    _buildUserCard(),
                    SizedBox(height: 20),

                    // ── Target + Amount ──
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: _buildInputField(
                            controller: _targetController,
                            label: 'Target (628xx)',
                            icon: FontAwesomeIcons.whatsapp.data,
                            isNumber: true,
                            onPaste: _pasteTarget,
                          ),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                          flex: 1,
                          child: _buildInputField(
                            controller: _amountController,
                            label: 'Amount',
                            icon: FontAwesomeIcons.hashtag.data,
                            isNumber: true,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),

                    // ── Launch Button ──
                    _buildActionButton(),
                    SizedBox(height: 20),

                    // ── Terminal Logs ──
                    Expanded(child: _buildTerminalLogs()),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildUserCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _PC.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _PC.accent.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: _PC.accent.withOpacity(0.1), blurRadius: 10)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: _PC.accent.withOpacity(0.2),
                child: Icon(FontAwesomeIcons.userAstronaut.data, color: _PC.accent, size: 20),
              ),
              SizedBox(width: 15),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.username.toUpperCase(),
                      style: TextStyle(
                          color: _PC.text,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'MADEEvolveSansEVO')),
                  Text("PAIR SPAMMER",
                      style: TextStyle(color: _PC.accent, fontSize: 10, letterSpacing: 1)),
                ],
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: _isAttacking ? _PC.accent : _PC.muted2),
            ),
            child: Row(
              children: [
                Icon(Icons.circle, color: _isAttacking ? _PC.accent : _PC.muted2, size: 8),
                SizedBox(width: 6),
                Text(
                  _isAttacking ? 'ACTIVE' : 'IDLE',
                  style: TextStyle(
                      color: _isAttacking ? _PC.accent : _PC.muted,
                      fontSize: 10,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isNumber = false,
    VoidCallback? onPaste,
  }) {
    return TextField(
      controller: controller,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      style: TextStyle(color: _PC.text),
      cursorColor: _PC.accent,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: _PC.muted),
        prefixIcon: Icon(icon, color: _PC.accent2, size: 20),
        suffixIcon: onPaste != null
            ? GestureDetector(onTap: onPaste, child: Icon(Icons.paste, color: _PC.muted2, size: 18))
            : null,
        filled: true,
        fillColor: _PC.card,
        contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: _PC.accent.withOpacity(0.2)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: _PC.accent),
        ),
      ),
    );
  }

  Widget _buildActionButton() {
    return GestureDetector(
      onTap: _executeSpam,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: _isAttacking
                ? [Color(0xFFCC2E25), Colors.red]
                : [_PC.accent, Color(0xFF991133)],
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: (_isAttacking ? Colors.red : _PC.accent).withOpacity(0.4),
              blurRadius: 15,
              offset: Offset(0, 5),
            )
          ],
        ),
        child: Center(
          child: _isAttacking
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                        width: 20, height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                    SizedBox(width: 16),
                    Text('STOP SPAM',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'MADEEvolveSansEVO',
                            letterSpacing: 2)),
                  ],
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(FontAwesomeIcons.rocket.data, color: Colors.white, size: 18),
                    SizedBox(width: 14),
                    Text('LAUNCH PAIR SPAM',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'MADEEvolveSansEVO',
                            letterSpacing: 2)),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildTerminalLogs() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: _PC.accent.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('> SYSTEM LOGS',
                  style: TextStyle(
                      color: _PC.accent,
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.bold)),
              if (_isAttacking)
                SizedBox(
                    height: 10, width: 10,
                    child: CircularProgressIndicator(strokeWidth: 2, color: _PC.accent)),
            ],
          ),
          Divider(color: Colors.white12, height: 20),
          Expanded(
            child: ListView.builder(
              controller: _logScroll,
              itemCount: _logs.length,
              itemBuilder: (context, index) {
                final log = _logs[index];
                Color logColor = _PC.muted;
                if (log.contains('✅')) logColor = _PC.accent;
                if (log.contains('❌') || log.contains('Error')) logColor = Color(0xFFFF6B6B);
                if (log.contains('⏳')) logColor = Color(0xFFFFA500);
                if (log.contains('[SYSTEM]')) logColor = _PC.text;

                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                    log,
                    style: TextStyle(color: logColor, fontSize: 11, fontFamily: 'monospace'),
                  ),
                );
              },
            ),
          ),
          if (_logs.isNotEmpty) ...[
            Divider(color: Colors.white12, height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('✅ ${_successCount}',
                    style: TextStyle(color: _PC.accent, fontSize: 11, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                Text('❌ ${_failCount}',
                    style: TextStyle(color: Color(0xFFFF6B6B), fontSize: 11, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
