// ignore_for_file: use_build_context_synchronously
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';

const String _baseUrl = "https://omhc-host-premium.yakuza.biz.id";
const String _bgVideoUrl = 'assets/videos/bg_video.mp4';

class RegisterPage extends StatefulWidget {
  RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final confirmController = TextEditingController();
  bool _isObscure = true;
  bool _isLoading = false;
  String? _errorMsg;
  String? _successMsg;

  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 1200),
    );
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);

    _slideController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 800),
    );
    _slideAnimation = Tween<Offset>(
      begin: Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));

    _initBgVideo();
    Future.delayed(Duration(milliseconds: 300), () {
      if (mounted) _fadeController.forward();
      if (mounted) _slideController.forward();
    });
  }

  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset(_bgVideoUrl)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  @override
  void dispose() {
    _bgVideoController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    userController.dispose();
    passController.dispose();
    confirmController.dispose();
    super.dispose();
  }

  // ── Register ────────────────────────────────────────────────────
  Future<void> _handleRegister() async {
    final username = userController.text.trim();
    final password = passController.text.trim();
    final confirm = confirmController.text.trim();

    if (username.isEmpty || password.isEmpty || confirm.isEmpty) {
      setState(() => _errorMsg = 'Semua field harus diisi');
      return;
    }
    if (username.length < 3) {
      setState(() => _errorMsg = 'Username minimal 3 karakter');
      return;
    }
    if (password.length < 4) {
      setState(() => _errorMsg = 'Password minimal 4 karakter');
      return;
    }
    if (password != confirm) {
      setState(() => _errorMsg = 'Password tidak cocok');
      return;
    }

    setState(() { _isLoading = true; _errorMsg = null; _successMsg = null; });

    try {
      final response = await http.post(
        Uri.parse("$_baseUrl/api/auth/register"),
        body: {
          "username": username,
          "password": password,
        },
      );
      final data = jsonDecode(response.body);

      if (data['valid'] == true && data['created'] == true) {
        setState(() {
          _isLoading = false;
          _successMsg = data['message'] ?? 'Akun berhasil dibuat!';
        });
        // Auto redirect to login after 2 seconds
        Future.delayed(Duration(seconds: 2), () {
          if (mounted) {
            Navigator.pop(context, {
              'username': username,
              'password': password,
            });
          }
        });
      } else {
        setState(() {
          _isLoading = false;
          _errorMsg = data['message'] ?? 'Gagal membuat akun';
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMsg = 'Gagal terhubung ke server. Coba lagi nanti.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final sw = mq.size.width;

    return Scaffold(
      body: Stack(
        children: [
          // Background
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF0A0E1A), Color(0xFF0D0D1A)],
              ),
            ),
          ),
          // Video background
          if (_bgVideoReady)
            Positioned.fill(
              child: Opacity(
                opacity: 0.15,
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _bgVideoController.value.size.width,
                    height: _bgVideoController.value.size.height,
                    child: VideoPlayer(_bgVideoController),
                  ),
                ),
              ),
            ),
          // Content
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: SingleChildScrollView(
                  padding: EdgeInsets.symmetric(horizontal: sw * 0.08),
                  child: Column(
                    children: [
                      SizedBox(height: mq.size.height * 0.06),

                      // Back button + Title
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              width: 40, height: 40,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.05),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.white.withOpacity(0.06), width: 0.5),
                              ),
                              child: Icon(Icons.arrow_back, color: Colors.white54, size: 18),
                            ),
                          ),
                          Spacer(),
                          Text(
                            'CREATE ACCOUNT',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.3),
                              fontSize: 10,
                              fontFamily: 'ShareTechMono',
                              letterSpacing: 4,
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: mq.size.height * 0.05),

                      // Logo
                      Container(
                        width: 72, height: 72,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFFFF3B30), Color(0xFFCC2E25)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFFFF3B30).withOpacity(0.3),
                              blurRadius: 24,
                              offset: Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Icon(FontAwesomeIcons.userPlus, color: Colors.white, size: 28),
                      ),

                      SizedBox(height: 20),

                      Text(
                        'REGISTER',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'MADEEvolveSansEVO',
                          letterSpacing: 4,
                        ),
                      ),

                      SizedBox(height: 6),

                      Text(
                        'Buat akun gratis (7 hari trial)',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.4),
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),

                      SizedBox(height: mq.size.height * 0.04),

                      // Form Card
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.03),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white.withOpacity(0.06), width: 0.5),
                        ),
                        child: Column(
                          children: [
                            _buildInputField(
                              controller: userController,
                              icon: Icons.person_outline,
                              hint: 'Username (min 3 chars)',
                              obscure: false,
                            ),
                            SizedBox(height: 14),
                            _buildInputField(
                              controller: passController,
                              icon: Icons.lock_outline,
                              hint: 'Password (min 4 chars)',
                              obscure: _isObscure,
                              suffix: GestureDetector(
                                onTap: () => setState(() => _isObscure = !_isObscure),
                                child: Icon(
                                  _isObscure ? Icons.visibility_off : Icons.visibility,
                                  color: Colors.white.withOpacity(0.2),
                                  size: 16,
                                ),
                              ),
                            ),
                            SizedBox(height: 14),
                            _buildInputField(
                              controller: confirmController,
                              icon: Icons.lock_outline,
                              hint: 'Confirm Password',
                              obscure: _isObscure,
                            ),

                            if (_errorMsg != null) ...[
                              SizedBox(height: 14),
                              Row(
                                children: [
                                  Icon(Icons.error_outline_rounded, color: Color(0xFFFF6B8A), size: 16),
                                  SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      _errorMsg!,
                                      style: TextStyle(color: Color(0xFFFF6B8A), fontSize: 12, fontFamily: 'ShareTechMono'),
                                    ),
                                  ),
                                ],
                              ),
                            ],

                            if (_successMsg != null) ...[
                              SizedBox(height: 14),
                              Row(
                                children: [
                                  Icon(Icons.check_circle, color: Color(0xFFFF3B30), size: 16),
                                  SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      _successMsg!,
                                      style: TextStyle(color: Color(0xFFFF3B30), fontSize: 12, fontFamily: 'ShareTechMono'),
                                    ),
                                  ),
                                ],
                              ),
                            ],

                            SizedBox(height: 24),
                            _buildRegisterButton(),
                          ],
                        ),
                      ),

                      SizedBox(height: 20),

                      // Already have account?
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Text(
                          'Sudah punya akun? Login di sini',
                          style: TextStyle(
                            color: Color(0xFFFF3B30).withOpacity(0.7),
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ),

                      SizedBox(height: 32),

                      Text(
                        'v4.1.0 · ENCRYPTED',
                        style: TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize: 8,
                          letterSpacing: 3,
                          color: Colors.white.withOpacity(0.1),
                        ),
                      ),
                      SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required IconData icon,
    required String hint,
    required bool obscure,
    Widget? suffix,
  }) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06), width: 0.5),
      ),
      child: Row(
        children: [
          SizedBox(width: 16),
          Icon(icon, color: Colors.white.withOpacity(0.25), size: 16),
          SizedBox(width: 12),
          Expanded(
            child: TextField(
              controller: controller,
              obscureText: obscure,
              style: TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'ShareTechMono', decoration: TextDecoration.none),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontSize: 13, fontFamily: 'ShareTechMono'),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.only(bottom: 12),
              ),
            ),
          ),
          if (suffix != null) ...[
            SizedBox(width: 4),
            Padding(padding: const EdgeInsets.only(right: 14), child: suffix),
          ] else
            SizedBox(width: 16),
        ],
      ),
    );
  }

  Widget _buildRegisterButton() {
    return GestureDetector(
      onTap: _isLoading ? null : _handleRegister,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        height: 52,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: _isLoading
                ? [Color(0xFF222222), Color(0xFF222222)]
                : [Color(0xFFFF3B30), Color(0xFF30D158)],
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0xFFFF3B30).withOpacity(_isLoading ? 0.1 : 0.35),
              blurRadius: 16,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: _isLoading
              ? SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : Text(
                  'CREATE ACCOUNT',
                  style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700, fontFamily: 'MADEEvolveSansEVO', letterSpacing: 3),
                ),
        ),
      ),
    );
  }
}
