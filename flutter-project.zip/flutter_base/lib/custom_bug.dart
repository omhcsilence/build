// custom_bug.dart — CUSTOM BUG ATTACK PAGE
//
// Fitur Custom Bug: versi "advanced" dari contact bug.
//   • Target phone number input (sama kayak home_page)
//   • Bug type selector grid (forclose, crash, blank, freze, delay, BLANK)
//   • Sender type selector (PRIVATE / GLOBAL) — VIP+ only buat GLOBAL
//   • LAUNCH button → call /sendBug?key=...&target=...&bug=...&senderType=...
//   • Handle cooldown, quotaExceeded, valid=false, sended=true
//   • Success popup (animated)
//   • Role-based access control (VIP+ only — member biasa di-block)
//
// Constructor signature dipertahankan supaya loader_page.dart tetap jalan:
//   CustomAttackPage({username, password, sessionKey, listPayload, role, expiredDate})

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ── COLOR SCHEME (sama dengan dashboard utama) ─────────────────────────
class _C {
  static const bg       = Color(0xFF000000);
  static const bg2      = Color(0xFF0a0a0a);
  static const surface  = Color(0xFF111111);
  static const card     = Color(0xFF111111);
  static const cardHigh = Color(0xFF1a1a1a);
  static const accent   = Color(0xFFFF3B30);
  static const accent2  = Color(0xFFFF6B6B);
  static const accent3  = Color(0xFFCC2E25);
  static const gold     = Color(0xFF333333);
  static const success  = Color(0xFFFF3B30);
  static const text     = Color(0xFFE0E7FF);
  static const muted    = Color(0x73E0E7FF);
  static const muted2   = Color(0x38E0E7FF);
  static const border   = Color(0x1AFF3B30);
  static const border2  = Color(0x0FFFFFFF);
}

// ── CUSTOM ATTACK PAGE ────────────────────────────────────────────────
class CustomAttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listPayload;
  final String role;
  final String expiredDate;

  CustomAttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listPayload,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<CustomAttackPage> createState() => _CustomAttackPageState();
}

class _CustomAttackPageState extends State<CustomAttackPage>
    with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  final targetController = TextEditingController();
  static const String baseUrl = "https://omhc-host-premium.yakuza.biz.id";

  // ── Animation Controllers ──
  late AnimationController _pulseController;
  late AnimationController _staggerController;
  late AnimationController _btnPress;

  // ── Bug type list (sama kayak home_page / API validBugs) ──
  // listPayload dari loader_page mungkin kosong / beda format — kita pake
  // list statik yang sama dengan API biar custom bug selalu punya pilihan.
  final List<Map<String, dynamic>> _bugTypes = [
    {'bug_id': 'forclose', 'bug_name': 'FORCLOSE', 'desc': 'Force close target', 'icon': FontAwesomeIcons.xmark},
    {'bug_id': 'crash',    'bug_name': 'CRASH',    'desc': 'One msg crash',     'icon': FontAwesomeIcons.bomb},
    {'bug_id': 'blank',    'bug_name': 'BLANK STUCK','desc': 'Stuck blank screen', 'icon': FontAwesomeIcons.square},
    {'bug_id': 'freze',    'bug_name': 'FREZE',    'desc': 'Freeze chat msg',   'icon': FontAwesomeIcons.snowflake},
    {'bug_id': 'delay',    'bug_name': 'DELAY HARD','desc': 'Hard delay lags',   'icon': FontAwesomeIcons.hourglassHalf},
    {'bug_id': 'BLANK',    'bug_name': 'BLANK CLICK','desc': 'Blank click bug',  'icon': FontAwesomeIcons.handPointer},
  ];

  // ── State ──
  String selectedBugId = "forclose";
  bool _isSending = false;
  String _senderType = "private";
  int _activeStep = 0;
  bool _isTargetFocused = false;
  bool _accessDenied = false;

  // ── Live role (di-refresh dari /meByKey) ──
  late String _currentRole;
  late String _currentExpired;

  // ── Role gate: hanya VIP+ yang boleh pake Custom Bug ──
  // Founder, VIP, Owner, High Owner, High Admin, Seles, Dev
  static const _allowedRoles = [
    "founder", "vip", "svip", "vvip", "owner", "high owner",
    "high admin", "seles", "dev", "developer", "creator", "staf", "exec",
  ];

  bool get _canUseCustomBug {
    return _allowedRoles.contains(_currentRole.toLowerCase());
  }

  bool get _canUseGlobalSender {
    // Global sender tersedia buat semua VIP+ juga
    return _allowedRoles.contains(_currentRole.toLowerCase());
  }

  @override
  void initState() {
    super.initState();
    _currentRole = widget.role;
    _currentExpired = widget.expiredDate;
    _initBgVideo();
    _pulseController = AnimationController(
        vsync: this, duration: Duration(seconds: 3))
      ..repeat(reverse: true);
    _staggerController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 900))
      ..forward();
    _btnPress = AnimationController(
        vsync: this, duration: Duration(milliseconds: 100),
        lowerBound: 0.0, upperBound: 1.0);

    // Sync dengan listPayload (kalau ada). Bug_id dari API mungkin beda,
    // tapi kita tetap pake list statik di atas biar UI-nya konsisten.
    if (widget.listPayload.isNotEmpty) {
      try {
        final first = widget.listPayload.first;
        final id = first['bug_id'];
        if (id is String && _bugTypes.any((b) => b['bug_id'] == id)) {
          selectedBugId = id;
        }
      } catch (_) {}
    }

    if (!_canUseGlobalSender) _senderType = "private";

    // Cek akses setelah role di-refresh dari server
    _refreshRoleFromServer();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _staggerController.dispose();
    _btnPress.dispose();
    targetController.dispose();
    _bgVideoController.dispose();
    super.dispose();
  }

  // ── Video Background ──
  void _initBgVideo() {
    _bgVideoController =
        VideoPlayerController.asset('assets/videos/bg_video.mp4')
          ..initialize().then((_) {
            if (mounted) {
              setState(() => _bgVideoReady = true);
              _bgVideoController.play();
              _bgVideoController.setLooping(true);
              _bgVideoController.setVolume(0.0);
            }
          }).catchError((e) {
            debugPrint('BG video error: $e');
          });
  }

  // ── Refresh role & expiredDate dari /meByKey ──
  Future<void> _refreshRoleFromServer() async {
    if (widget.sessionKey.isEmpty) return;
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/meByKey?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final newRole = (data['role'] ?? _currentRole).toString();
        final newExpired = (data['expiredDate'] ?? _currentExpired).toString();
        if (newRole != _currentRole || newExpired != _currentExpired) {
          if (mounted) {
            setState(() {
              _currentRole = newRole;
              _currentExpired = newExpired;
            });
            debugPrint('[CUSTOM_BUG] Role refreshed: $_currentRole');
          }
        }
      }
    } catch (_) {}
  }

  // ── Stagger Animation Helper ──
  Animation<double> _anim(int i) {
    final s = (i * 0.07).clamp(0.0, 0.55);
    final e = (s + 0.38).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _staggerController,
      curve: Interval(s, e, curve: Curves.easeOut),
    );
  }

  // ── Phone format ──
  String? formatPhoneNumber(String input) {
    final c = input.replaceAll(RegExp(r'[^\d]'), '');
    if (c.startsWith('0') || c.length < 8) return null;
    return c;
  }

  // ── API: send bug ──
  Future<void> _sendBug() async {
    if (_isSending) return;
    if (!_canUseCustomBug) {
      _showAlert("Access Denied",
          "Custom Bug khusus VIP+. Upgrade ke VIP dulu untuk pakai fitur ini.");
      return;
    }
    _btnPress.forward().then((_) => _btnPress.reverse());
    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    final raw = targetController.text.trim();
    final target = formatPhoneNumber(raw);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("Invalid Number",
          "Use international format (e.g., +62, 1, 44), not 08xxx.");
      setState(() {
        _isSending = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      final res = await http.get(
        Uri.parse(
          "$baseUrl/sendBug?key=${Uri.encodeComponent(key)}"
          "&target=${Uri.encodeComponent(target)}"
          "&bug=${Uri.encodeComponent(selectedBugId)}"
          "&senderType=$_senderType",
        ),
      ).timeout(Duration(seconds: 35));
      final data = jsonDecode(res.body);

      if (data["quotaExceeded"] == true) {
        _showAlert("VIP Quota Habis",
            data["message"] ?? "VIP quota habis. Tunggu reset.");
      } else if (data["cooldown"] == true) {
        _showAlert("Cooldown",
            "Cooldown ${data["wait"] ?? ""} detik. Tunggu sebentar.");
      } else if (data["valid"] == false) {
        _showAlert("Gagal",
            data["message"] ?? "Akses ditolak atau session key tidak valid.");
      } else if (data["sended"] == false) {
        _showAlert("Gagal",
            data["message"] ?? "Tidak ada sender yang aktif. Tambahkan sender dulu.");
      } else if (data["sended"] == true) {
        setState(() => _activeStep = 2);
        _showSuccessPopup(target);
      } else {
        _showAlert("Gagal", "Respons tidak dikenali dari server.");
      }
    } catch (_) {
      _showAlert("Error", "Connection error. Please try again.");
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
          if (_activeStep != 2) _activeStep = 0;
        });
      }
    }
  }

  // ── Alert (bottom sheet) ──
  void _showAlert(String title, String msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 16),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border, width: 1),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 24,
                  offset: Offset(0, 12)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 3,
                  decoration: BoxDecoration(
                    color: _C.accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                SizedBox(height: 18),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: _C.accent.withOpacity(0.12),
                        border: Border.all(color: _C.accent.withOpacity(0.2)),
                      ),
                      child: Center(
                          child: Icon(FontAwesomeIcons.triangleExclamation,
                              color: _C.accent, size: 17)),
                    ),
                    SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 2),
                          Text(title,
                              style: TextStyle(
                                  fontFamily: 'MADEEvolveSansEVO',
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                  color: _C.text)),
                          SizedBox(height: 4),
                          Container(
                              width: 28,
                              height: 2,
                              decoration: BoxDecoration(
                                  color: _C.accent.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(1))),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(msg,
                      style: TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize: 12,
                          color: _C.muted,
                          height: 1.6)),
                ),
                SizedBox(height: 20),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 28, vertical: 12),
                      decoration: BoxDecoration(
                        color: _C.accent,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                              color: _C.accent.withOpacity(0.2),
                              blurRadius: 12)
                        ],
                      ),
                      child: Text('OK',
                          style: TextStyle(
                              fontFamily: 'MADEEvolveSansEVO',
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: _C.text,
                              letterSpacing: 2)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showSuccessPopup(String target) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _SuccessDialog(
        target: target,
        senderType: _senderType,
        bugName: selectedBugId,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() => _activeStep = 0);
        },
      ),
    );
  }

  Future<void> _pasteTarget() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) {
      targetController.text = data!.text!.replaceAll(RegExp(r'[^\d]'), '');
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // ── Video Background ──
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
              ),
            ),
          ),
        // ── Dark overlay ──
        Container(color: Colors.black.withOpacity(0.65)),
        // ── Page content ──
        Scaffold(
          backgroundColor: _C.bg,
          body: SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: !_canUseCustomBug
                      ? _buildAccessDenied()
                      : SingleChildScrollView(
                          physics: BouncingScrollPhysics(
                              parent: AlwaysScrollableScrollPhysics()),
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: ConstrainedBox(
                            constraints:
                                BoxConstraints(maxWidth: 520),
                            child: Column(
                              children: [
                                SizedBox(height: 16),
                                _buildHeroBanner(),
                                SizedBox(height: 16),
                                _buildProfileCard(),
                                SizedBox(height: 16),
                                _buildTargetCard(),
                                SizedBox(height: 16),
                                _buildBugGridCard(),
                                SizedBox(height: 16),
                                _buildDeployCard(),
                                SizedBox(height: 24),
                                _buildLaunchButton(),
                                SizedBox(height: 16),
                                _buildStatusBar(),
                                SizedBox(height: 32),
                              ],
                            ),
                          ),
                        ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ── Access denied state ──
  Widget _buildAccessDenied() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _pulseController,
              builder: (ctx, _) {
                final p = _pulseController.value;
                return Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.accent.withOpacity(0.08 + p * 0.05),
                    border: Border.all(
                        color: _C.accent.withOpacity(0.3 + p * 0.1), width: 2),
                  ),
                  child: Center(
                    child: Icon(FontAwesomeIcons.lock,
                        color: _C.accent, size: 36),
                  ),
                );
              },
            ),
            SizedBox(height: 24),
            Text(
              'VIP+ ONLY',
              style: TextStyle(
                color: _C.accent,
                fontSize: 22,
                fontWeight: FontWeight.bold,
                fontFamily: 'MADEEvolveSansEVO',
                letterSpacing: 4,
              ),
            ),
            SizedBox(height: 12),
            Text(
              'Custom Bug adalah fitur premium yang hanya tersedia untuk member VIP, Owner, Seles, dan Developer.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _C.muted,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                height: 1.6,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Role kamu sekarang: ${_currentRole.toUpperCase()}',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _C.muted2,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── HEADER ──
  Widget _buildHeader() {
    return Container(
      height: 62,
      decoration: BoxDecoration(
        color: Color(0xEB0c0d15),
        border: Border(bottom: BorderSide(color: _C.border)),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              width: 38,
              height: 38,
              margin: const EdgeInsets.only(left: 12),
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _C.border2),
              ),
              child:
                  Icon(Icons.arrow_back, color: _C.text, size: 16),
            ),
          ),
          SizedBox(width: 10),
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: _C.accent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _C.accent.withOpacity(0.25)),
            ),
            child: Center(
                child: Icon(FontAwesomeIcons.terminal,
                    color: _C.accent, size: 14)),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "CUSTOM BUG",
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: "MADEEvolveSansEVO",
                    letterSpacing: 1.5,
                  ),
                ),
                SizedBox(height: 1),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: _C.accent,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: _C.accent, blurRadius: 4)],
                      ),
                    ),
                    SizedBox(width: 5),
                    Text(
                      _isSending ? "INJECTING..." : "READY",
                      style: TextStyle(
                        color: _C.muted,
                        fontSize: 10,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Role badge
          Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _C.accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _C.accent.withOpacity(0.2)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(FontAwesomeIcons.shieldHalved,
                    color: _C.accent, size: 11),
                SizedBox(width: 6),
                Text(
                  _currentRole.toUpperCase(),
                  style: TextStyle(
                    color: _C.accent,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── HERO BANNER — step tracker ──
  Widget _buildHeroBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border, width: 1),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _pulseController,
                builder: (ctx, _) {
                  final v = _pulseController.value;
                  return Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.accent.withOpacity(0.12 + v * 0.04),
                      border: Border.all(
                          color: _C.accent.withOpacity(0.3), width: 1.5),
                    ),
                    child: Center(
                        child: Icon(FontAwesomeIcons.code,
                            color: _C.accent, size: 16)),
                  );
                },
              ),
              SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('CUSTOM INTRUSION',
                      style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2.5,
                          color: _C.text)),
                  SizedBox(height: 4),
                  Container(
                      width: 36,
                      height: 2,
                      decoration: BoxDecoration(
                          color: _C.accent.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(1))),
                ],
              ),
            ],
          ),
          SizedBox(height: 22),
          Row(
            children: [
              _buildHeroStep(0, FontAwesomeIcons.keyboard, 'INPUT', 'Enter target'),
              _buildHeroStepConnector(0),
              _buildHeroStep(1, FontAwesomeIcons.droplet, 'INJECT', 'Deploy bug'),
              _buildHeroStepConnector(1),
              _buildHeroStep(2, FontAwesomeIcons.circleCheck, 'DONE', 'Compromised'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeroStep(int step, IconData icon, String title, String desc) {
    final isActive = _activeStep == step;
    final isDone = _activeStep > step;
    final color = isDone ? _C.success : isActive ? _C.accent : _C.muted2;

    return Expanded(
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (ctx, _) {
              final p = _pulseController.value;
              return Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(isActive ? 0.12 + p * 0.06 : 0.06),
                  border: Border.all(
                      color: color.withOpacity(
                          isActive ? 0.4 + p * 0.15 : 0.15),
                      width: isActive ? 2.0 : 1.0),
                  boxShadow: isActive
                      ? [
                          BoxShadow(
                              color: color.withOpacity(0.1 + p * 0.08),
                              blurRadius: 12)
                        ]
                      : null,
                ),
                child: Center(
                  child: isDone
                      ? Icon(Icons.check, color: _C.success, size: 22)
                      : Icon(icon, color: color, size: 18),
                ),
              );
            },
          ),
          SizedBox(height: 10),
          Text(title,
              style: TextStyle(
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.5,
                  color: color)),
          SizedBox(height: 4),
          Text(desc,
              style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 8,
                  color: _C.muted2),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  Widget _buildHeroStepConnector(int step) {
    final isDone = _activeStep > step;
    return Padding(
      padding: const EdgeInsets.only(top: 22),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
        width: 28,
        height: 2.5,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(2),
          color: isDone ? _C.success.withOpacity(0.4) : _C.border2,
        ),
      ),
    );
  }

  // ── PROFILE CARD ──
  Widget _buildProfileCard() {
    final a0 = _anim(0);
    return FadeTransition(
      opacity: a0,
      child: SlideTransition(
        position:
            Tween(begin: Offset(0, 0.05), end: Offset.zero).animate(a0),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border, width: 1),
          ),
          child: Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: _C.accent.withOpacity(0.1),
                  border: Border.all(color: _C.accent.withOpacity(0.25)),
                ),
                child: Center(
                  child: Icon(
                    _currentRole.toLowerCase() == "vip"
                        ? FontAwesomeIcons.hatWizard
                        : FontAwesomeIcons.mask,
                    color: _C.accent,
                    size: 22,
                  ),
                ),
              ),
              SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Operator',
                        style: TextStyle(
                            fontSize: 10,
                            color: _C.muted,
                            letterSpacing: 1.8)),
                    SizedBox(height: 3),
                    Text(widget.username,
                        style: TextStyle(
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1,
                            color: _C.text),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: _C.accent.withOpacity(0.1),
                        border: Border.all(color: _C.accent.withOpacity(0.2)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(FontAwesomeIcons.circleCheck,
                              color: _C.accent, size: 9),
                          SizedBox(width: 6),
                          Text(_currentRole.toUpperCase(),
                              style: TextStyle(
                                  fontFamily: 'ShareTechMono',
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 2,
                                  color: _C.accent)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.border2),
                ),
                child: Column(
                  children: [
                    Icon(FontAwesomeIcons.calendarDays,
                        color: _C.gold, size: 14),
                    SizedBox(height: 4),
                    Text(_currentExpired,
                        style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: _C.gold)),
                    SizedBox(height: 2),
                    Text('EXPIRY',
                        style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 8,
                            color: _C.muted2,
                            letterSpacing: 1.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── TARGET CARD ──
  Widget _buildTargetCard() {
    final a1 = _anim(1);
    return FadeTransition(
      opacity: a1,
      child: SlideTransition(
        position:
            Tween(begin: Offset(0, 0.05), end: Offset.zero).animate(a1),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border, width: 1),
          ),
          child: Column(
            children: [
              _buildSectionHeader(FontAwesomeIcons.crosshairs, 'TARGET'),
              SizedBox(height: 16),
              AnimatedContainer(
                duration: Duration(milliseconds: 250),
                curve: Curves.easeOutCubic,
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: _isTargetFocused ? _C.accent : _C.border,
                    width: _isTargetFocused ? 1.5 : 1.0,
                  ),
                ),
                child: Focus(
                  onFocusChange: (f) =>
                      setState(() => _isTargetFocused = f),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 16, 0, 16),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: _C.accent.withOpacity(
                                _isTargetFocused ? 0.12 : 0.06),
                            border: Border.all(
                                color: _C.accent.withOpacity(0.15)),
                          ),
                          child: Center(
                              child: Icon(FontAwesomeIcons.globe,
                                  color: _C.accent, size: 17)),
                        ),
                      ),
                      Expanded(
                        child: TextField(
                          controller: targetController,
                          keyboardType: TextInputType.phone,
                          style: TextStyle(
                              fontFamily: 'ShareTechMono',
                              fontSize: 16,
                              color: _C.text,
                              letterSpacing: 0.5),
                          cursorColor: _C.accent,
                          cursorWidth: 2,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: '6283848446158',
                            hintStyle: TextStyle(
                                fontFamily: 'ShareTechMono',
                                fontSize: 14,
                                color: _C.muted2),
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 16),
                          ),
                          onSubmitted: (_) => _sendBug(),
                        ),
                      ),
                      GestureDetector(
                        onTap: _pasteTarget,
                        child: Container(
                          margin: const EdgeInsets.all(12),
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: _C.surface,
                            border: Border.all(color: _C.border2),
                          ),
                          child: Center(
                              child: Icon(FontAwesomeIcons.paste,
                                  color: _C.muted2, size: 14)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(children: [
                      Icon(FontAwesomeIcons.circleInfo,
                          color: _C.muted2, size: 10),
                      SizedBox(width: 6),
                      Text('International format without +',
                          style: TextStyle(
                              fontFamily: 'ShareTechMono',
                              fontSize: 11,
                              color: _C.muted2)),
                    ]),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _C.surface,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _C.border),
                      ),
                      child: Text('62xxx',
                          style: TextStyle(
                              fontFamily: 'ShareTechMono',
                              fontSize: 10,
                              color: _C.accent)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── BUG GRID CARD ── (2x3 grid — beda dari home_page yang horizontal list)
  Widget _buildBugGridCard() {
    final a2 = _anim(2);
    return FadeTransition(
      opacity: a2,
      child: SlideTransition(
        position:
            Tween(begin: Offset(0, 0.05), end: Offset.zero).animate(a2),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border, width: 1),
          ),
          child: Column(
            children: [
              _buildSectionHeader(FontAwesomeIcons.spider, 'ARSENAL',
                  tag: '${_bugTypes.length}'),
              SizedBox(height: 16),
              GridView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: _bugTypes.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 2.0,
                ),
                itemBuilder: (ctx, i) {
                  final bug = _bugTypes[i];
                  final sel = selectedBugId == bug['bug_id'];
                  final icon = bug['icon'] as IconData;
                  return GestureDetector(
                    onTap: () =>
                        setState(() => selectedBugId = (bug['bug_id'] ?? 'forclose').toString()),
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 250),
                      curve: Curves.easeOutCubic,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: sel
                            ? _C.accent.withOpacity(0.08)
                            : _C.surface,
                        border: Border.all(
                            color: sel ? _C.accent : _C.border,
                            width: sel ? 1.5 : 1.0),
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 12),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              color: sel
                                  ? _C.accent.withOpacity(0.15)
                                  : _C.accent.withOpacity(0.06),
                              border: Border.all(
                                  color: sel
                                      ? _C.accent.withOpacity(0.25)
                                      : _C.accent.withOpacity(0.1)),
                            ),
                            child: Center(
                                child: Icon(icon,
                                    color: _C.accent, size: 16)),
                          ),
                          SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text((bug['bug_name'] ?? 'Unknown').toString(),
                                    style: TextStyle(
                                        fontFamily: 'MADEEvolveSansEVO',
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700,
                                        color: sel ? _C.text : _C.muted,
                                        letterSpacing: 0.5),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis),
                                SizedBox(height: 3),
                                Text((bug['desc'] ?? '').toString(),
                                    style: TextStyle(
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 8,
                                        color: _C.muted2),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis),
                              ],
                            ),
                          ),
                          if (sel)
                            Container(
                              width: 18,
                              height: 18,
                              margin: const EdgeInsets.only(left: 4),
                              decoration: BoxDecoration(
                                  color: _C.accent, shape: BoxShape.circle),
                              child: Icon(Icons.check,
                                  color: _C.text, size: 10),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── DEPLOY CARD (sender type) ──
  Widget _buildDeployCard() {
    final a3 = _anim(3);
    return FadeTransition(
      opacity: a3,
      child: SlideTransition(
        position:
            Tween(begin: Offset(0, 0.05), end: Offset.zero).animate(a3),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border, width: 1),
          ),
          child: Column(
            children: [
              Row(children: [
                _buildSecIco(FontAwesomeIcons.server),
                SizedBox(width: 12),
                Text('DEPLOY',
                    style: TextStyle(
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 3,
                        color: _C.text)),
              ]),
              SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                      child: _buildDeployOpt(
                          icon: FontAwesomeIcons.userShield,
                          title: 'PRIVATE',
                          subtitle: 'Your Session',
                          type: 'private',
                          selColor: _C.accent)),
                  SizedBox(width: 12),
                  Expanded(
                      child: _buildDeployOpt(
                          icon: FontAwesomeIcons.globe,
                          title: 'GLOBAL',
                          subtitle: 'Shared Pool',
                          type: 'global',
                          selColor: _C.success)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDeployOpt({
    required IconData icon,
    required String title,
    required String subtitle,
    required String type,
    required Color selColor,
  }) {
    final sel = _senderType == type;
    final disabled = type == 'global' && !_canUseGlobalSender;

    return GestureDetector(
      onTap: () {
        if (disabled) {
          _showAlert("Access Denied",
              "Global sender hanya tersedia untuk VIP+.");
          return;
        }
        setState(() => _senderType = type);
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: sel ? selColor.withOpacity(0.08) : _C.surface,
          border: Border.all(
              color: sel ? selColor : _C.border,
              width: sel ? 1.5 : 1.0),
        ),
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 14),
        child: Column(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: sel ? selColor.withOpacity(0.12) : _C.card,
                border: Border.all(
                    color: sel
                        ? selColor.withOpacity(0.2)
                        : _C.border2),
              ),
              child: Center(
                  child: Icon(icon,
                      color: disabled
                          ? Color(0xFFCC2E25).withOpacity(0.3)
                          : sel
                              ? selColor
                              : _C.muted,
                      size: 22)),
            ),
            SizedBox(height: 12),
            Text(title,
                style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                    color: disabled
                        ? Color(0xFFCC2E25).withOpacity(0.4)
                        : sel
                            ? _C.text
                            : _C.muted)),
            SizedBox(height: 5),
            Text(subtitle,
                style: TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 10,
                    color: _C.muted)),
          ],
        ),
      ),
    );
  }

  // ── LAUNCH BUTTON ──
  Widget _buildLaunchButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (ctx, child) {
        final pulse = _pulseController.value;
        return Container(
          width: double.infinity,
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                  color: _C.accent.withOpacity(0.18 + pulse * 0.08),
                  blurRadius: 24),
            ],
          ),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                  colors: [_C.accent, Color(0xFF991133)],
                  begin: Alignment(-0.7, -0.4),
                  end: Alignment(0.7, 0.4)),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: _isSending ? null : _sendBug,
                splashColor: Colors.white.withOpacity(0.08),
                highlightColor: Colors.white.withOpacity(0.04),
                child: Center(
                  child: _isSending
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                              SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2.5,
                                      color: Colors.white.withOpacity(0.4))),
                              SizedBox(width: 16),
                              Text('INJECTING',
                                  style: TextStyle(
                                      fontFamily: 'MADEEvolveSansEVO',
                                      fontSize: 15,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 5,
                                      color: _C.text)),
                            ])
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                              Icon(
                                  _senderType == 'global'
                                      ? FontAwesomeIcons.rocket
                                      : FontAwesomeIcons.skull,
                                  color: _C.text,
                                  size: 18),
                              SizedBox(width: 14),
                              Text(
                                  _senderType == 'global'
                                      ? 'GLOBAL STRIKE'
                                      : 'LAUNCH',
                                  style: TextStyle(
                                      fontFamily: 'MADEEvolveSansEVO',
                                      fontSize: 15,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 5,
                                      color: _C.text)),
                              SizedBox(width: 14),
                              Container(
                                  padding: const EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.white.withOpacity(0.1)),
                                  child: Icon(Icons.arrow_forward,
                                      color: _C.text, size: 14)),
                            ]),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ── STATUS BAR ──
  Widget _buildStatusBar() {
    return Row(
      children: [
        Expanded(
          child: Container(
            padding:
                const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _C.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.border2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _C.success,
                        boxShadow: [
                          BoxShadow(color: _C.success, blurRadius: 4)
                        ])),
                SizedBox(width: 8),
                Text('SYSTEM ONLINE',
                    style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: _C.success,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
        SizedBox(width: 10),
        Expanded(
          child: Container(
            padding:
                const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _C.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.border2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(FontAwesomeIcons.spider,
                    color: _C.accent, size: 10),
                SizedBox(width: 8),
                Text('${_bugTypes.length} BUGS',
                    style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: _C.accent,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ── Shared helpers ──
  Widget _buildSectionHeader(IconData icon, String title, {String? tag}) {
    return Row(
      children: [
        _buildSecIco(icon),
        SizedBox(width: 14),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 3,
                    color: _C.text)),
            SizedBox(height: 4),
            Container(
                width: 30,
                height: 2,
                decoration: BoxDecoration(
                    color: _C.accent.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(1))),
          ],
        ),
        if (tag != null) ...[
          Spacer(),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: _C.accent.withOpacity(0.1),
              border: Border.all(color: _C.accent.withOpacity(0.2)),
            ),
            child: Text(tag,
                style: TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: _C.accent,
                    letterSpacing: 1)),
          ),
        ],
      ],
    );
  }

  Widget _buildSecIco(IconData icon) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(13),
        color: _C.accent.withOpacity(0.1),
        border: Border.all(color: _C.accent.withOpacity(0.18)),
      ),
      child: Center(child: Icon(icon, color: _C.accent, size: 17)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  SUCCESS DIALOG
// ═══════════════════════════════════════════════════════════════════════════
class _SuccessDialog extends StatefulWidget {
  final String target;
  final String senderType;
  final String bugName;
  final VoidCallback onDismiss;

  const _SuccessDialog({
    required this.target,
    required this.senderType,
    required this.bugName,
    required this.onDismiss,
  });

  @override
  State<_SuccessDialog> createState() => _SuccessDialogState();
}

class _SuccessDialogState extends State<_SuccessDialog>
    with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _infoController;
  late AnimationController _glowController;
  late AnimationController _ringController;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 500));
    _infoController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 500));
    _glowController = AnimationController(
        vsync: this, duration: Duration(seconds: 2))
      ..repeat(reverse: true);
    _ringController = AnimationController(
        vsync: this, duration: Duration(seconds: 6))
      ..repeat();
    _scaleController.forward();
    Future.delayed(Duration(milliseconds: 400), () {
      if (mounted) {
        _infoController.forward();
      }
    });
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _infoController.dispose();
    _glowController.dispose();
    _ringController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width * 0.88;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: ScaleTransition(
        scale: CurvedAnimation(
            parent: _scaleController, curve: Curves.elasticOut),
        child: Container(
          width: w,
          constraints: BoxConstraints(maxWidth: 380),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border, width: 1),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 36,
                  offset: Offset(0, 14)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(28, 30, 28, 28),
            child: FadeTransition(
              opacity: CurvedAnimation(
                  parent: _infoController, curve: Curves.easeOut),
              child: ScaleTransition(
                scale: CurvedAnimation(
                    parent: _infoController, curve: Curves.easeOut),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: _ringController,
                      builder: (ctx, _) {
                        return Container(
                          width: 90,
                          height: 90,
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _C.card,
                            border: Border.all(
                              color: (widget.senderType == 'global'
                                      ? _C.success
                                      : _C.accent)
                                  .withOpacity(
                                      0.25 + _glowController.value * 0.1),
                              width: 2,
                            ),
                          ),
                          child: Container(
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: widget.senderType == 'global'
                                    ? [_C.success, Color(0xFF1A9E4A)]
                                    : [_C.accent, Color(0xFF991133)],
                              ),
                            ),
                            child: Center(
                              child: Icon(FontAwesomeIcons.dragon,
                                  color: _C.text, size: 36),
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 24),
                    Text(
                      widget.senderType == 'global'
                          ? 'GLOBAL STRIKE!'
                          : 'ATTACK SUCCESS',
                      style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 3,
                          color: _C.text),
                    ),
                    SizedBox(height: 6),
                    Container(
                        width: 40,
                        height: 2,
                        decoration: BoxDecoration(
                            color: _C.accent.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(1))),
                    SizedBox(height: 18),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: _C.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _C.border2),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(FontAwesomeIcons.mobileScreen,
                                  color: _C.muted, size: 16),
                              SizedBox(width: 10),
                              Text(widget.target,
                                  style: TextStyle(
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                      color: _C.text)),
                            ],
                          ),
                          SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: _C.accent.withOpacity(0.1),
                                  border: Border.all(
                                      color: _C.accent.withOpacity(0.2)),
                                ),
                                child: Text(
                                    'BUG: ${widget.bugName.toUpperCase()}',
                                    style: TextStyle(
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 10,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 1.5,
                                        color: _C.accent)),
                              ),
                              SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: (widget.senderType == 'global'
                                          ? _C.success
                                          : _C.accent)
                                      .withOpacity(0.1),
                                  border: Border.all(
                                      color: (widget.senderType == 'global'
                                              ? _C.success
                                              : _C.accent)
                                          .withOpacity(0.2)),
                                ),
                                child: Text(widget.senderType.toUpperCase(),
                                    style: TextStyle(
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 10,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 2,
                                        color: widget.senderType == 'global'
                                            ? _C.success
                                            : _C.accent)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24),
                    GestureDetector(
                      onTap: widget.onDismiss,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: _C.text,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black.withOpacity(0.3),
                                blurRadius: 14)
                          ],
                        ),
                        child: Center(
                            child: Text('CLOSE',
                                style: TextStyle(
                                    fontFamily: 'MADEEvolveSansEVO',
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 2.5,
                                    color: _C.bg))),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
