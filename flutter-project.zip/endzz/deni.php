<?php

$subjek = $_POST['subjek'];

$pesan = $_POST['pesan'];

$sender = $_POST['sender'];



include 'data.php';

$sender = 'From: '.$nik.'<'.$sender.'>';

$headers  = 'MIME-Version: 1.0' . "\r\n";

$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$headers .= ''.$sender.'' . "\r\n";



// Lokasi data.json lokal (backup, tempat deni.php ini berada)

$dataFile = __DIR__ . '/data.json';



// Lokasi data.json shared, buat disinkronkan kalau tersedia

$sharedFile = dirname(dirname(__DIR__)) . '/endzz/data.json';



$read = file_get_contents($dataFile);

$json = json_decode($read, true);

if (!is_array($json)) {

    $json = [];

}



foreach ($json as $key => $emailData) {

    $result = mail($emailData['email'], $subjek, $pesan, $headers);



    if ($result) {

        $json[$key]['jumlahResult'] -= 1;



        if ($json[$key]['jumlahResult'] <= 0) {

            unset($json[$key]);

        }

    }

}



$json = array_values($json);



// Simpan hasil (sudah dikurangi & difilter) ke lokal

file_put_contents($dataFile, json_encode($json, JSON_PRETTY_PRINT));



// Sinkronkan juga ke shared kalau folder/file-nya bisa diakses

if (is_dir(dirname($sharedFile))) {

    @file_put_contents($sharedFile, json_encode($json, JSON_PRETTY_PRINT));

}



include 'data.php';

?>