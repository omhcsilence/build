<?php
header('Content-Type: application/json');

$nick = trim($_GET['nick'] ?? '');
$sender = trim($_GET['sender'] ?? '');

if ($nick === '' || $sender === '') {
    echo json_encode(['success' => false, 'message' => 'Nama dan sender wajib diisi.']);
    exit;
}

$pertama = "<?php \n";
$terakhir = "?>";

$put = fopen(__DIR__ . '/ser.php', 'w');
if (!$put) {
    echo json_encode(['success' => false, 'message' => 'Gagal menulis ser.php (cek permission file).']);
    exit;
}
fwrite($put, $pertama);
fwrite($put, '$nik = "' . addslashes($nick) . '";');
fwrite($put, "\n");
fwrite($put, '$sender = "' . addslashes($sender) . '";');
fwrite($put, "\n");
fwrite($put, $terakhir);
fclose($put);

echo json_encode(['success' => true, 'message' => 'Nama berhasil diganti.']);
