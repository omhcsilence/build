<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$dataFile = 'data.json';

if (file_exists($dataFile)) {
    $data = json_decode(file_get_contents($dataFile), true);
    
    if (!is_array($data)) {
        $data = [];
    }
    
    // Filter: hapus email yang jumlahResult <= 0
    foreach ($data as $key => $emailData) {
        if (isset($emailData['jumlahResult']) && (int)$emailData['jumlahResult'] <= 0) {
            unset($data[$key]);
        }
    }
    
    $data = array_values($data);
    
    // Simpan hasil filter
    file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT));
    
    echo json_encode($data, JSON_PRETTY_PRINT);
} else {
    echo json_encode([]);
}
?>