<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// ... rest of code (sama seperti sebelumnya) ...
header('Content-Type: application/json');

// Lokasi 1: data.json satu folder dengan add.php ini
// (/public_html/$namapanel/endzz/data.json)
$dataFile1 = __DIR__ . '/data.json';

// Lokasi 2: data.json di /public_html/endzz/data.json
// add.php ada di /public_html/$namapanel/endzz/
// jadi naik 2 folder (lewati endzzxyudzz & $namapanel) lalu masuk lagi ke endzz
$dataFile2 = dirname(dirname(__DIR__)) . '/endzz/data.json';

$email = trim($_POST['email'] ?? '');
$jumlahResult = trim($_POST['jumlahResult'] ?? '');

if ($email === '' || $jumlahResult === '') {
    echo json_encode(['success' => false, 'message' => 'Email dan jumlah result wajib diisi.']);
    exit;
}

function simpanKeFile($dataFile, $email, $jumlahResult) {
    $read = file_exists($dataFile) ? file_get_contents($dataFile) : '';
    $json = json_decode($read, true);
    if (!is_array($json)) {
        $json = [];
    }

    // Cegah email duplikat
    foreach ($json as $row) {
        if (isset($row['email']) && $row['email'] === $email) {
            return ['success' => false, 'message' => 'Email sudah terdaftar.', 'file' => $dataFile];
        }
    }

    $add = [
        'email' => $email,
        'jumlahResult' => $jumlahResult,
    ];

    array_unshift($json, $add);

    // Pastikan folder tujuan ada
    $dir = dirname($dataFile);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }

    $put = @fopen($dataFile, 'w');
    if (!$put) {
        return ['success' => false, 'message' => 'Gagal menulis ' . $dataFile . ' (cek permission/path).', 'file' => $dataFile];
    }
    fwrite($put, json_encode($json, JSON_PRETTY_PRINT));
    fclose($put);

    return ['success' => true, 'message' => 'Berhasil disimpan.', 'file' => $dataFile];
}

$result1 = simpanKeFile($dataFile1, $email, $jumlahResult);
$result2 = simpanKeFile($dataFile2, $email, $jumlahResult);

if ($result1['success'] && $result2['success']) {
    echo json_encode(['success' => true, 'message' => 'Email berhasil ditambahkan.']);
} elseif (!$result1['success'] && !$result2['success']) {
    echo json_encode(['success' => false, 'message' => 'Gagal di kedua lokasi: ' . $result1['message'] . ' | ' . $result2['message']]);
} else {
    // Salah satu berhasil, salah satu gagal
    $gagal = !$result1['success'] ? $result1 : $result2;
    echo json_encode(['success' => false, 'message' => 'Sebagian gagal: ' . $gagal['message']]);
}
