<?php
// panel.php
// Pastikan file ini diletakkan di server yang benar dan file include (ser.php, config.php, expiration_config.php) tersedia.
include 'ser.php';
$config = include 'config.php';
$expiration_config = include 'expiration_config.php';

if ($expiration_config && isset($expiration_config['expiration_datetime'])) {
    $expiration_date_str = $expiration_config['expiration_datetime'];
    if (!empty($expiration_date_str)) {
        try {
            $expiration_datetime = new DateTime($expiration_date_str);
            $current_time = new DateTime();
            if ($current_time > $expiration_datetime) {
                header('Location: exp.php');
                exit;
            }
        } catch (Exception $e) {
            // Jika format salah, biarkan panel tetap tampil
        }
    }
}

// Pastikan $nik dan $sender tersedia dari include atau set default
$nik = $nik ?? '';
$sender = $sender ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ENDZZ • PANEL JASTEB PREMIUM</title>
    
    <!-- Fonts Premium -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    
    <!-- Particles.js -->
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    
    <!-- GSAP -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #4e73df;
            --primary-dark: #224abe;
            --primary-light: #6b8aff;
            --secondary: #1cc88a;
            --success: #1cc88a;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --dark: #0a0f1e;
            --darker: #050814;
            --glass: rgba(255, 255, 255, 0.03);
            --glass-hover: rgba(255, 255, 255, 0.05);
            --border: rgba(255, 255, 255, 0.05);
            --border-hover: rgba(78, 115, 223, 0.3);
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--darker);
            color: #fff;
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        /* Particle Background */
        #particles-js {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }

        /* Gradient Overlay */
        .gradient-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 50% 50%, rgba(78, 115, 223, 0.1) 0%, transparent 70%);
            z-index: 1;
            pointer-events: none;
        }

        /* Main Content */
        .content-wrapper {
            position: relative;
            z-index: 2;
            max-width: 100%;
            margin: 0 auto;
            padding: 24px 40px;
        }

        /* Glass Card */
        .glass-card {
            background: rgba(8, 12, 28, 0.75);
            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);
            border: 1px solid rgba(78, 115, 223, 0.12);
            border-radius: 20px;
            padding: 28px 32px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .glass-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(78, 115, 223, 0.5), rgba(28, 200, 138, 0.4), transparent);
            pointer-events: none;
        }

        .glass-card:hover {
            transform: translateY(-4px);
            border-color: rgba(78, 115, 223, 0.25);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(78, 115, 223, 0.15);
        }

        /* Header Profile */
        .profile-section {
            display: flex;
            align-items: center;
            gap: 25px;
            flex-wrap: wrap;
        }

        .profile-image {
            position: relative;
            width: 100px;
            height: 100px;
        }

        .profile-image img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(78, 115, 223, 0.5);
            box-shadow: 0 0 30px rgba(78, 115, 223, 0.3);
            transition: all 0.3s;
        }

        .profile-image:hover img {
            transform: scale(1.05);
            border-color: var(--primary);
            box-shadow: 0 0 40px rgba(78, 115, 223, 0.5);
        }

        .profile-ring {
            position: absolute;
            top: -5px;
            left: -5px;
            right: -5px;
            bottom: -5px;
            border-radius: 50%;
            border: 2px solid transparent;
            border-top-color: var(--primary);
            border-right-color: var(--secondary);
            border-bottom-color: var(--warning);
            border-left-color: var(--primary);
            animation: spin 4s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .profile-title {
            flex: 1;
        }

        .profile-title h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.2rem;
            font-weight: 900;
            background: linear-gradient(135deg, #fff, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            line-height: 1.2;
        }

        .profile-badges {
            display: flex;
            gap: 15px;
            margin-top: 10px;
            flex-wrap: wrap;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 18px;
            border-radius: 60px;
            font-size: 0.85rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(255, 255, 255, 0.02);
            backdrop-filter: blur(5px);
        }

        .badge i {
            font-size: 0.7rem;
            color: var(--success);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .badge.primary {
            border-color: rgba(78, 115, 223, 0.3);
            background: rgba(78, 115, 223, 0.1);
        }

        /* Stats Cards */
        .stats-grid {
            display: flex;
            gap: 16px;
            margin-left: auto;
        }

        .stat-card {
            background: rgba(78, 115, 223, 0.06);
            border: 1px solid rgba(78, 115, 223, 0.18);
            border-radius: 16px;
            padding: 18px 24px;
            min-width: 150px;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 2px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 2px 2px 0 0;
        }

        .stat-card:hover {
            border-color: rgba(78, 115, 223, 0.4);
            background: rgba(78, 115, 223, 0.1);
            transform: translateY(-3px);
            box-shadow: 0 8px 24px rgba(78, 115, 223, 0.15);
        }

        .stat-icon {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 10px;
        }

        .stat-value {
            font-size: 2.2rem;
            font-weight: 800;
            line-height: 1;
            background: linear-gradient(135deg, #fff, var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .stat-label {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.5);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Social Links */
        .social-links {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }

        .social-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 0.85rem;
            border: 1px solid rgba(255, 255, 255, 0.08);
            background: rgba(255, 255, 255, 0.03);
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.25s;
        }

        .social-btn:hover {
            transform: translateY(-2px);
        }

        .social-btn i {
            font-size: 1rem;
        }

        .social-btn.instagram:hover { background: rgba(225, 48, 108, 0.15); border-color: rgba(225, 48, 108, 0.4); color: #e1306c; }
        .social-btn.tiktok:hover { background: rgba(0, 242, 234, 0.1); border-color: rgba(0, 242, 234, 0.4); color: #00f2ea; }
        .social-btn.telegram:hover { background: rgba(0, 136, 204, 0.15); border-color: rgba(0, 136, 204, 0.4); color: #0088cc; }
        .social-btn.whatsapp:hover { background: rgba(37, 211, 102, 0.15); border-color: rgba(37, 211, 102, 0.4); color: #25d366; }

        /* Section Title */
        .section-title {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid rgba(78, 115, 223, 0.1);
        }

        .section-icon {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            background: linear-gradient(135deg, rgba(78, 115, 223, 0.2), rgba(28, 200, 138, 0.1));
            border: 1px solid rgba(78, 115, 223, 0.25);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.15rem;
            color: var(--primary);
            flex-shrink: 0;
        }

        .section-title h2 {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.25rem;
            font-weight: 700;
            letter-spacing: 1.5px;
            background: linear-gradient(135deg, #fff 40%, var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 10px;
            font-size: 0.88rem;
            font-weight: 600;
            color: rgba(255, 255, 255, 0.6);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-label i {
            color: var(--primary);
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.25);
            transition: all 0.3s;
            z-index: 2;
            font-size: 0.9rem;
        }

        .form-control {
            width: 100%;
            padding: 14px 18px 14px 44px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 12px;
            color: white;
            font-size: 0.95rem;
            transition: all 0.25s;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .form-control:focus {
            outline: none;
            border-color: rgba(78, 115, 223, 0.5);
            background: rgba(78, 115, 223, 0.05);
            box-shadow: 0 0 0 3px rgba(78, 115, 223, 0.12);
        }

        .form-control:focus ~ .input-icon {
            color: var(--primary);
        }

        .form-control[readonly] {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(255, 255, 255, 0.03);
            color: rgba(255, 255, 255, 0.35);
            cursor: not-allowed;
        }

        /* Progress Bar */
        .progress-container {
            margin-top: 10px;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 10px;
            transition: width 0.3s ease;
            position: relative;
        }

        .progress-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            animation: shimmer 1.5s infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .progress-text {
            text-align: right;
            font-size: 0.8rem;
            color: rgba(255, 255, 255, 0.3);
            margin-top: 5px;
        }

        /* Button Premium */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 13px 24px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 0.88rem;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            cursor: pointer;
            transition: all 0.25s;
            width: 100%;
            background: linear-gradient(135deg, rgba(78, 115, 223, 0.2), rgba(28, 200, 138, 0.1));
            border: 1px solid rgba(78, 115, 223, 0.35);
            color: white;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .btn:hover {
            transform: translateY(-2px);
            background: linear-gradient(135deg, rgba(78, 115, 223, 0.35), rgba(28, 200, 138, 0.2));
            border-color: rgba(78, 115, 223, 0.6);
            box-shadow: 0 8px 20px rgba(78, 115, 223, 0.25), 0 0 0 1px rgba(78, 115, 223, 0.2);
        }

        .btn:active {
            transform: translateY(0);
        }

        .btn i {
            font-size: 1.1rem;
            transition: transform 0.3s;
        }

        .btn:hover i {
            transform: rotate(360deg) scale(1.1);
        }

        /* Search Box */
        .search-box {
            position: relative;
            width: 300px;
        }

        .search-box i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.3);
            z-index: 2;
        }

        .search-box input {
            padding-left: 48px !important;
        }

        /* Table Premium */
        .table-responsive {
            overflow-x: auto;
            margin-top: 16px;
            border-radius: 12px;
            border: 1px solid rgba(78, 115, 223, 0.1);
        }

        .premium-table {
            width: 100%;
            border-collapse: collapse;
        }

        .premium-table th {
            padding: 14px 18px;
            background: rgba(78, 115, 223, 0.08);
            font-weight: 700;
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: rgba(255, 255, 255, 0.6);
            border: none;
            border-bottom: 1px solid rgba(78, 115, 223, 0.12);
            white-space: nowrap;
        }

        .premium-table td {
            padding: 14px 18px;
            background: transparent;
            border: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            color: rgba(255, 255, 255, 0.85);
            font-size: 0.9rem;
            transition: background 0.2s;
            white-space: nowrap;
        }

        .premium-table tr:last-child td {
            border-bottom: none;
        }

        .premium-table tbody tr:hover td {
            background: rgba(78, 115, 223, 0.06);
        }

        /* Status Badge */
        .result-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 16px;
            border-radius: 60px;
            font-size: 0.75rem;
            font-weight: 600;
            background: rgba(28, 200, 138, 0.1);
            border: 1px solid rgba(28, 200, 138, 0.2);
            color: var(--success);
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .action-btn {
            width: 36px;
            height: 36px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(255, 255, 255, 0.02);
            color: white;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 0.9rem;
        }

        .action-btn:hover {
            transform: translateY(-3px);
        }

        .action-btn.edit:hover {
            background: rgba(78, 115, 223, 0.2);
            border-color: var(--primary);
            color: var(--primary);
        }

        .action-btn.delete:hover {
            background: rgba(231, 74, 59, 0.2);
            border-color: var(--danger);
            color: var(--danger);
        }

        /* Pagination */
        .pagination {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 8px;
            margin-top: 20px;
        }

        .page-btn {
            padding: 8px 14px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.08);
            color: white;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 0.85rem;
            min-width: 38px;
        }

        .page-btn:hover:not(:disabled) {
            background: rgba(78, 115, 223, 0.15);
            border-color: rgba(78, 115, 223, 0.4);
        }

        .page-btn:disabled {
            opacity: 0.25;
            cursor: not-allowed;
        }

        .page-info {
            padding: 8px 18px;
            background: rgba(78, 115, 223, 0.1);
            border: 1px solid rgba(78, 115, 223, 0.2);
            border-radius: 10px;
            font-weight: 600;
            font-size: 0.85rem;
        }

        /* Audio Player */
        .audio-player {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 100;
        }

        .audio-btn {
            width: 65px;
            height: 65px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border: none;
            color: white;
            font-size: 1.8rem;
            cursor: pointer;
            box-shadow: 0 15px 30px rgba(78, 115, 223, 0.4);
            transition: all 0.3s;
            position: relative;
            animation: pulse-ring 2.5s infinite;
        }

        .audio-btn::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            opacity: 0.3;
            z-index: -1;
            animation: ring-pulse 2.5s infinite;
        }

        @keyframes ring-pulse {
            0% { transform: scale(1); opacity: 0.3; }
            100% { transform: scale(1.5); opacity: 0; }
        }

        @keyframes pulse-ring {
            0% { box-shadow: 0 0 0 0 rgba(78, 115, 223, 0.4); }
            70% { box-shadow: 0 0 0 20px rgba(78, 115, 223, 0); }
            100% { box-shadow: 0 0 0 0 rgba(78, 115, 223, 0); }
        }

        .audio-btn:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .audio-btn.playing {
            background: linear-gradient(135deg, var(--secondary), #0f9b6e);
        }

        /* Debug Panel */
        .debug-panel {
            position: fixed;
            bottom: 120px;
            right: 30px;
            background: rgba(0, 0, 0, 0.9);
            backdrop-filter: blur(20px);
            border: 1px solid var(--primary);
            border-radius: 20px;
            padding: 20px;
            max-width: 350px;
            display: none;
            z-index: 1000;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }

        .debug-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            color: var(--primary);
            font-weight: 700;
        }

        .debug-content {
            font-family: monospace;
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.8);
            white-space: pre-wrap;
        }

        .debug-close {
            cursor: pointer;
            color: rgba(255, 255, 255, 0.5);
            transition: color 0.3s;
        }

        .debug-close:hover {
            color: white;
        }

        /* Loading Animation */
        .loading-spinner {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 3px solid rgba(78, 115, 223, 0.1);
            border-top-color: var(--primary);
            border-right-color: var(--secondary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        /* Grid System */
        .grid-2 {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 28px;
            margin: 28px 0;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .profile-section {
                flex-direction: column;
                text-align: center;
            }
            
            .stats-grid {
                margin-left: 0;
                width: 100%;
                justify-content: center;
            }
            
            .profile-title h1 {
                font-size: 2.2rem;
            }
        }

        @media (max-width: 768px) {
            .content-wrapper {
                padding: 15px;
            }
            
            .glass-card {
                padding: 20px;
                border-radius: 30px;
            }
            
            .grid-2 {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .stat-card {
                min-width: 120px;
                padding: 15px 20px;
            }
            
            .stat-value {
                font-size: 1.8rem;
            }
            
            .section-title h2 {
                font-size: 1.4rem;
            }
            
            .search-box {
                width: 100%;
                margin-top: 15px;
            }
            
            .pagination {
                justify-content: center;
            }
            
            .audio-btn {
                width: 55px;
                height: 55px;
                font-size: 1.5rem;
            }
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 12px;
            height: 12px;
        }

        ::-webkit-scrollbar-track {
            background: var(--darker);
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(var(--primary), var(--secondary));
            border-radius: 10px;
            border: 3px solid var(--darker);
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(var(--primary-light), var(--success));
        }
    </style>
</head>
<body>

    <!-- Particles Background -->
    <div id="particles-js"></div>
    <div class="gradient-overlay"></div>

    <!-- Debug Panel -->
    <div id="debugPanel" class="debug-panel">
        <div class="debug-header">
            <span><i class="fas fa-bug me-2"></i>DEBUG INFO</span>
            <span class="debug-close" onclick="$('#debugPanel').fadeOut()"><i class="fas fa-times"></i></span>
        </div>
        <div class="debug-content" id="debugContent"></div>
    </div>

    <div class="content-wrapper">
        
        <!-- Header Card -->
        <div class="glass-card animate__animated animate__fadeInDown">
            <div class="profile-section">
                <div class="profile-image">
                    <img src="https://endzznyx-s.xo.je/uploads/prod_6a670b5b7aa1d_1785138054.jpeg" alt="ENDZZ NOT DEV">
                    <div class="profile-ring"></div>
                </div>
                
                <div class="profile-title">
                    <h1>ENDZZ</h1>
                    <div class="profile-badges">
                        <span class="badge primary">
                            <i class="fas fa-circle"></i>
                            SYSTEM ACTIVE
                        </span>
                        <span class="badge">
                            <i class="far fa-clock"></i>
                            <span id="liveClock"></span>
                        </span>
                    </div>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-envelope"></i></div>
                        <div class="stat-value" id="totalEmails">0</div>
                        <div class="stat-label">Total Emails</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-list-ol"></i></div>
                        <div class="stat-value" id="totalResults">0</div>
                        <div class="stat-label">Results</div>
                    </div>
                </div>
            </div>
            
            <!-- Social Links -->
            <div class="social-links">
                <a href="https://wa.me/6285872080250" target="_blank" class="social-btn whatsapp">
                    <i class="fab fa-whatsapp"></i>
                    <span>Whatsapp</span>
                </a>
                <a href="https://tiktok.com/@endzzhost" target="_blank" class="social-btn tiktok">
                    <i class="fab fa-tiktok"></i>
                    <span>TikTok</span>
                </a>
                <a href="https://t.me/Endzzhost" target="_blank" class="social-btn telegram">
                    <i class="fab fa-telegram"></i>
                    <span>Telegram</span>
                </a>                
            </div>
        </div>

        <!-- Main Grid -->
        <div class="grid-2">
            
            <!-- Panel Settings -->
            <div class="glass-card">
                <div class="section-title">
                    <div class="section-icon">
                        <i class="fas fa-cog"></i>
                    </div>
                    <h2>PANEL SETTINGS</h2>
                </div>
                
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-user"></i>
                        Nama Result
                    </label>
                    <div class="input-wrapper">
                        <i class="fas fa-pen input-icon"></i>
                        <input type="text" id="namaResult" class="form-control" 
                               value="<?= htmlspecialchars($nik); ?>" 
                               placeholder="Masukkan nama result">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-server"></i>
                        Nick Sender
                    </label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="text" id="panelMurni" class="form-control" 
                               value="<?= htmlspecialchars($sender); ?>" 
                               readonly>
                    </div>
                    <small style="color: rgba(255,255,255,0.3); font-size: 0.75rem; margin-top: 5px; display: block;">
                        <i class="fas fa-info-circle me-1"></i> Field tidak dapat diubah
                    </small>
                </div>
                
                <button id="gantiButton" class="btn">
                    <i class="fas fa-sync-alt"></i>
                    <span>UPDATE PANEL</span>
                </button>
            </div>
            
            <!-- Add Email -->
            <div class="glass-card">
                <div class="section-title">
                    <div class="section-icon">
                        <i class="fas fa-plus-circle"></i>
                    </div>
                    <h2>ADD EMAIL</h2>
                </div>
                
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-envelope"></i>
                        Email Address
                    </label>
                    <div class="input-wrapper">
                        <i class="fas fa-at input-icon"></i>
                        <input type="email" id="email" class="form-control" 
                               placeholder="user@example.com">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-hashtag"></i>
                        Jumlah Result
                    </label>
                    <div class="input-wrapper">
                        <i class="fas fa-layer-group input-icon"></i>
                        <input type="number" id="jumlahResult" class="form-control" 
                               value="1" min="1" max="100">
                    </div>
                    
                    <div class="progress-container">
                        <div class="progress-bar">
                            <div class="progress-fill" id="resultProgress" style="width: 1%"></div>
                        </div>
                        <div class="progress-text">
                            <span id="progressValue">1</span> / 100
                        </div>
                    </div>
                </div>
                
                <button id="addEmailButton" class="btn">
                    <i class="fas fa-plus-circle"></i>
                    <span>TAMBAH EMAIL</span>
                </button>
            </div>
        </div>
        
        <!-- Email Management Table -->
        <div class="glass-card" style="margin-top: 25px;">
            <div class="flex" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; margin-bottom: 25px;">
                <div class="section-title" style="margin-bottom: 0;">
                    <div class="section-icon">
                        <i class="fas fa-database"></i>
                    </div>
                    <h2>EMAIL MANAGEMENT</h2>
                </div>
                
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchEmail" class="form-control" 
                           placeholder="Cari email...">
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="premium-table">
                    <thead>
                        <tr>
                            <th><i class="fas fa-envelope me-2"></i>EMAIL</th>
                            <th><i class="fas fa-list-ol me-2"></i>RESULTS</th>
                            <th><i class="fas fa-calendar me-2"></i>TANGGAL</th>
                            <th><i class="fas fa-cogs me-2"></i>AKSI</th>
                        </tr>
                    </thead>
                    <tbody id="emailData">
                        <tr>
                            <td colspan="4">
                                <div class="loading-spinner">
                                    <div class="spinner"></div>
                                    <p style="margin-top: 15px; color: rgba(255,255,255,0.5);">Memuat data...</p>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="pagination">
                <div style="color: rgba(255,255,255,0.5); font-size: 0.9rem; margin-right: auto;">
                    Menampilkan <span id="startEntry">1</span> - <span id="endEntry">10</span> dari <span id="totalEntries">0</span>
                </div>
                <button class="page-btn" id="prevPage" disabled>
                    <i class="fas fa-chevron-left"></i>
                </button>
                <span class="page-info" id="pageInfo">1</span>
                <button class="page-btn" id="nextPage">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Audio Player -->
    <div class="audio-player">
        <button id="playAudioBtn" class="audio-btn">
            <i class="fas fa-music"></i>
        </button>
    </div>
    
    <audio id="bgAudio" loop>
        <source src="sound.mp3" type="audio/mpeg">
    </audio>

    <script>
        $(document).ready(function() {
            // Initialize particles
            particlesJS('particles-js', {
                particles: {
                    number: { value: 100, density: { enable: true, value_area: 800 } },
                    color: { value: "#4e73df" },
                    shape: { type: "circle" },
                    opacity: { value: 0.3, random: true },
                    size: { value: 3, random: true },
                    line_linked: {
                        enable: true,
                        distance: 150,
                        color: "#4e73df",
                        opacity: 0.2,
                        width: 1
                    },
                    move: {
                        enable: true,
                        speed: 2,
                        direction: "none",
                        random: true,
                        straight: false,
                        out_mode: "out"
                    }
                },
                interactivity: {
                    detect_on: "canvas",
                    events: {
                        onhover: { enable: true, mode: "repulse" },
                        onclick: { enable: true, mode: "push" },
                        resize: true
                    }
                },
                retina_detect: true
            });
            
            // Live clock
            function updateClock() {
                const now = new Date();
                const options = { 
                    hour: '2-digit', 
                    minute: '2-digit', 
                    second: '2-digit',
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric'
                };
                $('#liveClock').text(now.toLocaleString('id-ID', options));
            }
            setInterval(updateClock, 1000);
            updateClock();
            
            // Progress bar
            $('#jumlahResult').on('input', function() {
                let val = parseInt($(this).val()) || 0;
                val = Math.min(100, Math.max(1, val));
                let percent = (val / 100) * 100;
                $('#resultProgress').css('width', percent + '%');
                $('#progressValue').text(val);
            });
            
            // Load data
            let allEmails = [];
            let currentPage = 1;
            const itemsPerPage = 10;
            
            function fetchEmails() {
                $.ajax({
                    url: 'data.php',
                    method: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        console.log('Data received:', data);
                        
                        // Handle different data structures
                        if (Array.isArray(data)) {
                            allEmails = data;
                        } else if (data && typeof data === 'object') {
                            if (data.data && Array.isArray(data.data)) {
                                allEmails = data.data;
                            } else if (data.emails && Array.isArray(data.emails)) {
                                allEmails = data.emails;
                            } else if (data.email || data.id) {
                                allEmails = [data];
                            } else {
                                allEmails = [];
                            }
                        } else {
                            allEmails = [];
                        }
                        
                        $('#totalEntries').text(allEmails.length);
                        updateStats();
                        displayEmails();
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                        $('#emailData').html(`
                            <tr>
                                <td colspan="4" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-exclamation-triangle" style="font-size: 2rem; color: var(--danger);"></i>
                                    <p style="margin-top: 10px; color: rgba(255,255,255,0.5);">Gagal memuat data</p>
                                    <small style="color: rgba(255,255,255,0.3);">${error}</small>
                                </td>
                            </tr>
                        `);
                    }
                });
            }
            
            function updateStats() {
                $('#totalEmails').text(allEmails.length);
                
                let totalResults = 0;
                allEmails.forEach(item => {
                    let jumlah = item.jumlahResult || item.jumlah || item.result || item.count || 0;
                    totalResults += parseInt(jumlah) || 0;
                });
                $('#totalResults').text(totalResults);
            }
            
            function displayEmails() {
                let filtered = allEmails;
                let searchTerm = $('#searchEmail').val().toLowerCase();
                
                if (searchTerm) {
                    filtered = allEmails.filter(item => {
                        let email = item.email || item.Email || item.mail || item.address || '';
                        return String(email).toLowerCase().includes(searchTerm);
                    });
                }
                
                let start = (currentPage - 1) * itemsPerPage;
                let end = Math.min(start + itemsPerPage, filtered.length);
                let paginated = filtered.slice(start, end);
                
                $('#startEntry').text(filtered.length ? start + 1 : 0);
                $('#endEntry').text(end);
                $('#totalEntries').text(filtered.length);
                
                if (paginated.length === 0) {
                    $('#emailData').html(`
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px;">
                                <i class="fas fa-inbox" style="font-size: 3rem; color: rgba(255,255,255,0.1);"></i>
                                <p style="margin-top: 10px; color: rgba(255,255,255,0.3);">Tidak ada data</p>
                                <small style="color: rgba(255,255,255,0.2);">Tekan 'T' untuk debug</small>
                            </td>
                        </tr>
                    `);
                    return;
                }
                
                let html = '';
                paginated.forEach(item => {
                    let email = item.email || item.Email || item.mail || item.address || '-';
                    let jumlah = item.jumlahResult || item.jumlah || item.result || item.count || 0;
                    let date = item.added_at || item.created_at || item.date || item.tanggal || new Date().toISOString();
                    
                    try {
                        date = new Date(date).toLocaleString('id-ID');
                    } catch (e) {
                        date = date;
                    }
                    
                    html += `
                        <tr>
                            <td>
                                <i class="fas fa-envelope" style="color: var(--primary); margin-right: 10px;"></i>
                                ${email}
                            </td>
                            <td>
                                <span class="result-badge">
                                    <i class="fas fa-check-circle"></i>
                                    ${jumlah} Result
                                </span>
                            </td>
                            <td>
                                <i class="far fa-calendar-alt" style="color: rgba(255,255,255,0.3); margin-right: 8px;"></i>
                                ${date}
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button class="action-btn edit" onclick="editEmail('${email}')" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="action-btn delete" onclick="deleteEmail('${email}')" title="Hapus">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `;
                });
                
                $('#emailData').html(html);
                
                // Update pagination
                let totalPages = Math.ceil(filtered.length / itemsPerPage);
                $('#pageInfo').text(`${currentPage} / ${totalPages || 1}`);
                $('#prevPage').prop('disabled', currentPage === 1);
                $('#nextPage').prop('disabled', currentPage === totalPages || totalPages === 0);
            }
            
            // Search with debounce
            let searchTimeout;
            $('#searchEmail').on('keyup', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    currentPage = 1;
                    displayEmails();
                }, 300);
            });
            
            // Pagination
            $('#prevPage').click(function() {
                if (currentPage > 1) {
                    currentPage--;
                    displayEmails();
                }
            });
            
            $('#nextPage').click(function() {
                let totalPages = Math.ceil(allEmails.length / itemsPerPage);
                if (currentPage < totalPages) {
                    currentPage++;
                    displayEmails();
                }
            });
            
            // Update config
            $('#gantiButton').click(function() {
                const namaResult = $('#namaResult').val().trim();
                const panelMurni = $('#panelMurni').val().trim();

                if (!namaResult || !panelMurni) {
                    Swal.fire({
                        title: 'Error!',
                        text: 'Nama Result tidak boleh kosong',
                        icon: 'error',
                        background: '#0a0f1e',
                        color: 'white',
                        confirmButtonColor: '#4e73df'
                    });
                    return;
                }

                $(this).html('<i class="fas fa-spinner fa-spin"></i> UPDATING...');
                
                $.ajax({
                    url: `ganti.php?nick=${encodeURIComponent(namaResult)}&sender=${encodeURIComponent(panelMurni)}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        if (data.success) {
                            Swal.fire({
                                title: 'Sukses!',
                                text: data.message,
                                icon: 'success',
                                background: '#0a0f1e',
                                color: 'white',
                                confirmButtonColor: '#4e73df',
                                timer: 2000
                            }).then(() => location.reload());
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: data.message,
                                icon: 'error',
                                background: '#0a0f1e',
                                color: 'white',
                                confirmButtonColor: '#4e73df'
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            title: 'Error!',
                            text: 'Gagal update data',
                            icon: 'error',
                            background: '#0a0f1e',
                            color: 'white',
                            confirmButtonColor: '#4e73df'
                        });
                    },
                    complete: function() {
                        $('#gantiButton').html('<i class="fas fa-sync-alt"></i><span>UPDATE PANEL</span>');
                    }
                });
            });
            
            // Add email
            $('#addEmailButton').click(function() {
                const email = $('#email').val().trim();
                const jumlahResult = $('#jumlahResult').val();

                if (!email || !jumlahResult) {
                    Swal.fire({
                        title: 'Error!',
                        text: 'Email dan Jumlah Result harus diisi',
                        icon: 'error',
                        background: '#0a0f1e',
                        color: 'white',
                        confirmButtonColor: '#4e73df'
                    });
                    return;
                }

                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    Swal.fire({
                        title: 'Error!',
                        text: 'Format email tidak valid',
                        icon: 'error',
                        background: '#0a0f1e',
                        color: 'white',
                        confirmButtonColor: '#4e73df'
                    });
                    return;
                }

                $(this).html('<i class="fas fa-spinner fa-spin"></i> ADDING...');
                
                $.ajax({
                    url: 'add.php',
                    method: 'POST',
                    data: { email: email, jumlahResult: jumlahResult },
                    dataType: 'json',
                    success: function(data) {
                        if (data.success) {
                            Swal.fire({
                                title: 'Sukses!',
                                text: data.message,
                                icon: 'success',
                                background: '#0a0f1e',
                                color: 'white',
                                confirmButtonColor: '#4e73df',
                                timer: 1500
                            });
                            
                            $('#email').val('');
                            $('#jumlahResult').val('1');
                            $('#resultProgress').css('width', '1%');
                            $('#progressValue').text('1');
                            fetchEmails();
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: data.message,
                                icon: 'error',
                                background: '#0a0f1e',
                                color: 'white',
                                confirmButtonColor: '#4e73df'
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            title: 'Error!',
                            text: 'Gagal menambah email',
                            icon: 'error',
                            background: '#0a0f1e',
                            color: 'white',
                            confirmButtonColor: '#4e73df'
                        });
                    },
                    complete: function() {
                        $('#addEmailButton').html('<i class="fas fa-plus-circle"></i><span>TAMBAH EMAIL</span>');
                    }
                });
            });
            
            // Audio player
            const audio = document.getElementById('bgAudio');
            const audioBtn = document.getElementById('playAudioBtn');
            let isPlaying = false;
            
            audio.volume = 0.3;
            
            audioBtn.addEventListener('click', function() {
                if (!isPlaying) {
                    audio.play().then(() => {
                        isPlaying = true;
                        audioBtn.classList.add('playing');
                        audioBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
                        Swal.fire({
                            title: '🎵 Musik',
                            text: 'Musik dinyalakan',
                            icon: 'success',
                            background: '#0a0f1e',
                            color: 'white',
                            confirmButtonColor: '#4e73df',
                            timer: 1500,
                            showConfirmButton: false
                        });
                    }).catch(() => {
                        audioBtn.innerHTML = '<i class="fas fa-volume-mute"></i>';
                    });
                } else {
                    audio.pause();
                    isPlaying = false;
                    audioBtn.classList.remove('playing');
                    audioBtn.innerHTML = '<i class="fas fa-music"></i>';
                }
            });
            
            // Debug (tekan T)
            $(document).on('keydown', function(e) {
                if (e.key === 't' || e.key === 'T') {
                    $.ajax({
                        url: 'data.php',
                        method: 'GET',
                        dataType: 'json',
                        success: function(data) {
                            let debugInfo = 'Data Type: ' + typeof data + '\n';
                            debugInfo += 'Is Array: ' + Array.isArray(data) + '\n';
                            debugInfo += 'Length: ' + (data ? (Array.isArray(data) ? data.length : 'not array') : 'null') + '\n';
                            
                            if (Array.isArray(data) && data.length > 0) {
                                debugInfo += '\nFirst Item:\n';
                                let first = data[0];
                                for (let prop in first) {
                                    debugInfo += `- ${prop}: ${first[prop]} (${typeof first[prop]})\n`;
                                }
                            }
                            
                            $('#debugContent').text(debugInfo);
                            $('#debugPanel').fadeIn();
                            
                            setTimeout(() => $('#debugPanel').fadeOut(), 10000);
                        }
                    });
                }
            });
            
            // Initial load
            fetchEmails();
            
            // Auto refresh every 30 seconds
            setInterval(fetchEmails, 30000);
        });
        
        // Global functions
        function editEmail(email) {
            $.ajax({
                url: 'data.php',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    let items = Array.isArray(data) ? data : (data.data || data.emails || []);
                    let item = items.find(i => 
                        i.email === email || i.Email === email || i.mail === email
                    );
                    
                    let currentJumlah = item ? (item.jumlahResult || item.jumlah || item.result || item.count || 1) : 1;
                    
                    Swal.fire({
                        title: 'Edit Email',
                        input: 'number',
                        inputLabel: 'Jumlah Result',
                        inputValue: currentJumlah,
                        inputAttributes: { min: 1, max: 100, step: 1 },
                        showCancelButton: true,
                        confirmButtonText: 'Update',
                        cancelButtonText: 'Batal',
                        background: '#0a0f1e',
                        color: 'white',
                        confirmButtonColor: '#4e73df'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'update.php',
                                method: 'POST',
                                data: { email: email, jumlahResult: result.value },
                                dataType: 'json',
                                success: function(data) {
                                    if (data.success) {
                                        Swal.fire({
                                            title: 'Sukses!',
                                            text: data.message,
                                            icon: 'success',
                                            background: '#0a0f1e',
                                            color: 'white',
                                            confirmButtonColor: '#4e73df',
                                            timer: 1500
                                        });
                                        location.reload();
                                    } else {
                                        Swal.fire({
                                            title: 'Error!',
                                            text: data.message,
                                            icon: 'error',
                                            background: '#0a0f1e',
                                            color: 'white',
                                            confirmButtonColor: '#4e73df'
                                        });
                                    }
                                }
                            });
                        }
                    });
                }
            });
        }
        
        function deleteEmail(email) {
            Swal.fire({
                title: 'Konfirmasi Hapus',
                text: `Yakin ingin menghapus ${email}?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#1cc88a',
                cancelButtonColor: '#e74a3b',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal',
                background: '#0a0f1e',
                color: 'white'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'delete.php',
                        method: 'POST',
                        data: { email: email },
                        dataType: 'json',
                        success: function(data) {
                            if (data.success) {
                                Swal.fire({
                                    title: 'Terhapus!',
                                    text: data.message,
                                    icon: 'success',
                                    background: '#0a0f1e',
                                    color: 'white',
                                    confirmButtonColor: '#4e73df',
                                    timer: 1500
                                });
                                location.reload();
                            } else {
                                Swal.fire({
                                    title: 'Error!',
                                    text: data.message,
                                    icon: 'error',
                                    background: '#0a0f1e',
                                    color: 'white',
                                    confirmButtonColor: '#4e73df'
                                });
                            }
                        }
                    });
                }
            });
        }
    </script>
</body>
</html>