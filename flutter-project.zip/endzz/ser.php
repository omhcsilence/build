<?php 
$nik = "RESS 2026 | BY ENDZZ🌊";
$sender = "admin@nyx";
?>