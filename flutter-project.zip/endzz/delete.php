<?php
// ========== DELETE EMAIL + KURANGI JUMLAH RESULT ==========
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// ========== KONFIGURASI PATH ==========
$root_dir = $_SERVER['DOCUMENT_ROOT'];
$current_dir = __DIR__;
$panel_folder = dirname($current_dir);
$panel_name = basename($panel_folder);

$dataFile1 = $current_dir . '/data.json';
$dataFile2 = $root_dir . '/endzz/data.json';

$email = trim($_POST['email'] ?? '');
$result = trim($_POST['result'] ?? '');

if ($email === '' && $result === '') {
    echo json_encode(['success' => false, 'message' => 'Email atau Result tidak boleh kosong.']);
    exit;
}

// ========== FUNGSI KURANGI / HAPUS ==========
function processFile($filePath, $email, $result) {
    if (!file_exists($filePath)) {
        return ['success' => false, 'message' => "File tidak ditemukan: $filePath"];
    }

    $read = file_get_contents($filePath);
    $json = json_decode($read, true);
    if (!is_array($json)) {
        $json = [];
    }

    $found = false;
    $new = [];
    $updated = false;
    
    foreach ($json as $row) {
        $match = false;
        $isEmailMatch = false;
        
        // Cek berdasarkan email
        if ($email !== '' && isset($row['email']) && $row['email'] === $email) {
            $match = true;
            $isEmailMatch = true;
        }
        
        // Cek berdasarkan result/pass
        if ($result !== '') {
            if (isset($row['result']) && $row['result'] === $result) $match = true;
            if (isset($row['pass']) && $row['pass'] === $result) $match = true;
            if (isset($row['password']) && $row['password'] === $result) $match = true;
        }

        if ($match) {
            $found = true;
            
            // KALAU MATCH EMAIL, KURANGI jumlahResult
            if ($isEmailMatch && isset($row['jumlahResult'])) {
                $row['jumlahResult'] = (int)$row['jumlahResult'] - 1;
                
                // KALO jumlahResult > 0, tetap simpan (update)
                if ($row['jumlahResult'] > 0) {
                    $new[] = $row;
                    $updated = true;
                }
                // KALO <= 0, HAPUS (skip)
                continue;
            }
            
            // KALAU MATCH RESULT, HAPUS BARIS ITU
            continue;
        }
        
        $new[] = $row;
    }

    if (!$found) {
        return ['success' => false, 'message' => 'Data tidak ditemukan.'];
    }

    // KALO GA ADA PERUBAHAN (jumlahResult udah 0)
    if (!$updated && $found && $email !== '') {
        // Cek apakah email masih ada di data baru (berarti jumlahResult > 0)
        $emailStillExists = false;
        foreach ($new as $row) {
            if (isset($row['email']) && $row['email'] === $email) {
                $emailStillExists = true;
                break;
            }
        }
        if (!$emailStillExists) {
            return ['success' => true, 'message' => 'Email berhasil dihapus (jumlahResult habis).'];
        }
    }

    $put = fopen($filePath, 'w');
    if (!$put) {
        return ['success' => false, 'message' => 'Gagal menulis file (cek permission).'];
    }
    fwrite($put, json_encode(array_values($new), JSON_PRETTY_PRINT));
    fclose($put);

    return ['success' => true, 'message' => 'Data berhasil diproses.'];
}

// ========== PROSES 2 FILE ==========
$result1 = processFile($dataFile1, $email, $result);
$result2 = processFile($dataFile2, $email, $result);

// ========== LOG ==========
$log_file = $current_dir . '/delete_log.txt';
$log = "[" . date('Y-m-d H:i:s') . "] Panel: $panel_name | Email: $email | Result: $result\n";
$log .= "File 1: " . ($result1['success'] ? '✅' : '❌') . " " . $result1['message'] . "\n";
$log .= "File 2: " . ($result2['success'] ? '✅' : '❌') . " " . $result2['message'] . "\n";
$log .= "----------------------------------------\n";
file_put_contents($log_file, $log, FILE_APPEND);

// ========== RESPONSE ==========
$success = $result1['success'] || $result2['success'];
$messages = [];
if ($result1['success']) $messages[] = "File 1: " . $result1['message'];
if ($result2['success']) $messages[] = "File 2: " . $result2['message'];
if (!$result1['success'] && !$result2['success']) {
    $messages[] = $result1['message'];
}

echo json_encode([
    'success' => $success,
    'message' => implode(' | ', $messages),
    'file1' => $result1,
    'file2' => $result2
], JSON_PRETTY_PRINT);
?>