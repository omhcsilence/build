CARA BUILD DI TERMUX

1. Install Termux dari sumber resmi tepercaya.
2. Jalankan:
   pkg update
   pkg install git wget unzip openjdk-17

3. Salin folder proyek ini ke Termux, lalu masuk ke folder:
   cd apk-termux-sederhana

4. Jika memakai Gradle Wrapper, jalankan:
   chmod +x gradlew
   ./gradlew assembleDebug

5. APK akan berada di:
   app/build/outputs/apk/debug/app-debug.apk

CATATAN:
Proyek ini menggunakan Android Gradle Plugin 8.6.1 dan compileSdk 35.
Jika build environment Termux belum memiliki Android SDK/platform yang diperlukan,
pasang Android SDK command-line tools/platform-tools dan platform Android yang sesuai,
atau build proyek ini di Android Studio.
