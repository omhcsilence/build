Flutter Project
================
Project ini adalah template Flutter minimal untuk proses build.

File wajib:
- pubspec.yaml
- lib/main.dart

Jalankan:
flutter pub get
flutter build apk --release
