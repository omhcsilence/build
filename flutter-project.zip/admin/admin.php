<?php
session_start();

// GANTI PASSWORD LOGIN ADMIN DI SINI
$admin_user = "anony";
$admin_pass = "password123";

// Handle Login Form
if (isset($_POST['login'])) {
    if ($_POST['username'] === $admin_user && $_POST['password'] === $admin_pass) {
        $_SESSION['is_admin'] = true;
    } else {
        $login_err = "Username atau password salah.";
    }
}

// Cek Proteksi Login Admin
$is_logged_in = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;

if ($is_logged_in) {
    $settings = json_decode(file_get_contents('../data/settings.json'), true);
    $users = json_decode(file_get_contents('../data/users.json'), true);
    $withdraws = json_decode(file_get_contents('../data/withdraw.json'), true);
    $stats = json_decode(file_get_contents('../data/stats.json'), true);

    // Action: Update Settings
    if (isset($_POST['update_settings'])) {
        $settings['web_status'] = $_POST['web_status'];
        $settings['offline_message'] = htmlspecialchars($_POST['offline_message']);
        $settings['group_link'] = htmlspecialchars($_POST['group_link']);
        file_put_contents('../data/settings.json', json_encode($settings, JSON_PRETTY_PRINT));
        header("Location: admin.php");
        exit();
    }

    // Action: Approve / Reject Withdraw
    if (isset($_GET['action']) && isset($_GET['wd_id'])) {
        $wd_id = $_GET['wd_id'];
        $action = $_GET['action'];
        
        if (isset($withdraws[$wd_id]) && $withdraws[$wd_id]['status'] === 'PENDING') {
            if ($action === 'approve') {
                $withdraws[$wd_id]['status'] = 'APPROVED';
            } elseif ($action === 'reject') {
                $withdraws[$wd_id]['status'] = 'REJECTED';
                // Kembalikan dana ke user jika ditolak admin
                $u_id = $withdraws[$wd_id]['user_id'];
                if (isset($users[$u_id])) {
                    $users[$u_id]['saldo'] += $withdraws[$wd_id]['nominal'];
                }
            }
            file_put_contents('../data/withdraw.json', json_encode($withdraws, JSON_PRETTY_PRINT));
            file_put_contents('../data/users.json', json_encode($users, JSON_PRETTY_PRINT));
        }
        header("Location: admin.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Kontrol Admin</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: sans-serif; }
        body { background: #f0f2f5; padding: 20px; color: #333; }
        .wrapper { max-width: 900px; margin: 0 auto; }
        .card { background: white; padding: 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        h2, h3 { margin-bottom: 15px; color: #1a237e; }
        .form-control { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; font-size: 14px; }
        input[type="text"], input[type="password"], textarea, select { width: 100%; padding: 12px; border: 1px solid #ccc; border-radius: 6px; font-size: 14px; }
        .btn { display: inline-block; background: #1a237e; color: white; border: none; padding: 12px 20px; border-radius: 6px; cursor: pointer; text-decoration: none; font-weight: bold; font-size: 14px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 12px; text-align: left; font-size: 14px; }
        th { background: #f8f9fa; }
        .status { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
        .status-PENDING { background: #fff3cd; color: #856404; }
        .status-APPROVED { background: #d4edda; color: #155724; }
        .status-REJECTED { background: #f8d7da; color: #721c24; }
        .btn-action { padding: 5px 10px; font-size: 12px; border-radius: 4px; color: white; text-decoration: none; margin-right: 5px; }
        .btn-approve { background: #28a745; }
        .btn-reject { background: #dc3545; }
    </style>
</head>
<body>

<div class="wrapper">
    <?php if (!$is_logged_in): ?>
        <div class="card" style="max-width: 400px; margin: 100px auto;">
            <h2>Login Admin</h2>
            <?php if(isset($login_err)): ?>
                <p style="color:red; margin-bottom:10px;"><?php echo $login_err; ?></p>
            <?php endif; ?>
            <form method="POST">
                <div class="form-control">
                    <label>Username</label>
                    <input type="text" name="username" required>
                </div>
                <div class="form-control">
                    <label>Password</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" name="login" class="btn" style="width:100%;">Masuk</button>
            </form>
        </div>
    <?php else: ?>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2>Panel Kontrol Utama Admin</h2>
            <p>Total Kunjungan Web: <strong><?php echo $stats['visits'] ?? 0; ?></strong></p>
        </div>

        <div class="card">
            <h3>⚙️ Pengaturan Website</h3>
            <form method="POST">
                <div class="form-control">
                    <label>Status Sistem Web</label>
                    <select name="web_status">
                        <option value="ON" <?php if($settings['web_status']=='ON') echo 'selected'; ?>>ON (Aktif Terbuka)</option>
                        <option value="OFF" <?php if($settings['web_status']=='OFF') echo 'selected'; ?>>OFF (Mode Perbaikan / Offline)</option>
                    </select>
                </div>
                <div class="form-control">
                    <label>Pesan Pemeliharaan (Jika Web Di-OFF-kan)</label>
                    <textarea name="offline_message" rows="3"><?php echo $settings['offline_message']; ?></textarea>
                </div>
                <div class="form-control">
                    <label>Tautan Tautan Grup WhatsApp Resmi</label>
                    <input type="text" name="group_link" value="<?php echo $settings['group_link']; ?>">
                </div>
                <button type="submit" name="update_settings" class="btn">Simpan Konfigurasi</button>
            </form>
        </div>

        <div class="card" style="overflow-x:auto;">
            <h3>💸 Daftar Pengajuan Penarikan Saldo</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID WD</th>
                        <th>ID User</th>
                        <th>Detail Penerima</th>
                        <th>Nominal</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($withdraws)): ?><tr><td colspan="6" style="text-align:center;">Belum ada data pengajuan.</td></tr><?php endif; ?>
                    <?php foreach(array_reverse($withdraws) as $wd): ?>
                    <tr>
                        <td><?php echo $wd['id']; ?></td>
                        <td><?php echo $wd['user_id']; ?></td>
                        <td>
                            <strong><?php echo $wd['nama']; ?></strong><br>
                            <span style="color:#666; font-size:12px;"><?php echo $wd['nomor']; ?></span>
                        </td>
                        <td>Rp <?php echo number_format($wd['nominal'], 0, ',', '.'); ?></td>
                        <td><span class="status status-<?php echo $wd['status']; ?>"><?php echo $wd['status']; ?></span></td>
                        <td>
                            <?php if($wd['status'] === 'PENDING'): ?>
                                <a href="admin.php?action=approve&wd_id=<?php echo $wd['id']; ?>" class="btn-action btn-approve" onclick="return confirm('Setujui transaksi ini?')">Approve</a>
                                <a href="admin.php?action=reject&wd_id=<?php echo $wd['id']; ?>" class="btn-action btn-reject" onclick="return confirm('Tolak transaksi dan kembalikan saldo user?')">Reject</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="card" style="overflow-x:auto;">
            <h3>👥 Daftar Pengguna Terdaftar</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID Pengguna</th>
                        <th>Saldo Saat Ini</th>
                        <th>Total Referral</th>
                        <th>Grup WA?</th>
                        <th>Diundang Oleh</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($users)): ?><tr><td colspan="5" style="text-align:center;">Belum ada user mendaftar.</td></tr><?php endif; ?>
                    <?php foreach($users as $u): ?>
                    <tr>
                        <td><strong><?php echo $u['id']; ?></strong></td>
                        <td>Rp <?php echo number_format($u['saldo'], 0, ',', '.'); ?></td>
                        <td><?php echo $u['referral']; ?> Orang</td>
                        <td><?php echo $u['joined_group'] ? '✅ Sudah' : '❌ Belum'; ?></td>
                        <td><?php echo $u['from_ref'] ? $u['from_ref'] : '-'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <p style="text-align: center;"><a href="?logout" style="color: #666; font-size:14px;" onclick="<?php if(isset($_GET['logout'])) { session_destroy(); header('Location: admin.php'); } ?>">Log Out Panel Admin</a></p>
    <?php endif; ?>
</div>

</body>
</html>
