// store_page.dart — Toko Mbud (Store Page)
// Alur:
// 1. Tab PANEL: grid panel produk → pilih → bayar QRIS + upload bukti → submit → pending → owner approve → popup credentials
// 2. Tab NOMOR: saldo display + top up button → service list → country list (with pricelist)
//    → operator list → order → OTP polling → cancel order (with 5-min wait + refund)
// 3. History order di bawah (panel + nokos + topup)
// 4. Testimoni otomatis ke @kiuchan12 channel via canvas thumbnail (server-side)

// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

// ── COLOR SCHEME (Dark + Red accent — matches app theme) ──────────────────
class _SC {
  static const bg        = Color(0xFF000000);
  static const bg2        = Color(0xFF0a0a0a);
  static const surface    = Color(0xFF111111);
  static const card      = Color(0xFF111111);
  static const cardHigh  = Color(0xFF222222);
  static const accent    = Color(0xFFFF3B30);
  static const accent2   = Color(0xFFFF6B6B);
  static const accentDim = Color(0x1AFF3B30);
  static const text      = Color(0xFFE5E7EB);
  static const textSub   = Color(0xFF9CA3AF);
  static const muted     = Color(0x99E5E7EB);
  static const muted2    = Color(0x55E5E7EB);
  static const border    = Color(0x1AFFFFFF);
  static const border2   = Color(0x0FFFFFFF);
  static const danger    = Color(0xFFFF3B30);
  static const success   = Color(0xFF22C55E);
  static const warning   = Color(0xFFFBBF24);
}

class StorePage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const StorePage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<StorePage> createState() => _StorePageState();
}

class _StorePageState extends State<StorePage>
    with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  static const String _baseUrl = "https://omhc-host-premium.yakuza.biz.id";

  // ── Tab controller ──
  late TabController _tabController;

  // ── Panel products ──
  List<Map<String, dynamic>> _panels = [];
  bool _loadingPanels = false;

  // ── Nokos services ──
  List<dynamic> _nokosServices = [];
  bool _loadingServices = false;

  // ── My orders ──
  List<Map<String, dynamic>> _myOrders = [];
  bool _loadingOrders = false;
  Timer? _pollTimer;
  final Set<String> _shownApproved = {};

  // ── Active nokos order (OTP polling) ──
  Map<String, dynamic>? _activeNokos;
  Timer? _otpPollTimer;
  final ValueNotifier<String> _otpStatusNotifier = ValueNotifier<String>('Menunggu OTP...');
  final ValueNotifier<String?> _otpCodeNotifier = ValueNotifier<String?>(null);

  // ── Submit states ──
  bool _isSubmittingPanel = false;
  bool _isOrderingNokos = false;

  // ── Saldo ──
  int _saldo = 0;
  Map<String, dynamic>? _pendingTopup;
  bool _loadingSaldo = false;
  Timer? _saldoPollTimer;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _initBgVideo();
    _fetchPanels();
    _fetchNokosServices();
    _fetchMyOrders(initial: true);
    _fetchSaldo();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _otpPollTimer?.cancel();
    _saldoPollTimer?.cancel();
    _tabController.dispose();
    _bgVideoController.dispose();
    _otpStatusNotifier.dispose();
    _otpCodeNotifier.dispose();
    super.dispose();
  }

  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ── Helpers ──
  String _formatRupiah(num n) {
    return 'Rp ${n.toInt().toString().replaceAll(RegExp(r'\B(?=(\d{3})+(?!\d))'), '.')}';
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: isError ? _SC.danger : _SC.surface,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        content: Row(
          children: [
            Icon(isError ? Icons.error_outline : Icons.check_circle_outline,
                color: isError ? Colors.white : _SC.accent, size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(msg,
                  style: TextStyle(
                    color: isError ? Colors.white : _SC.text,
                    fontFamily: 'ShareTechMono',
                    fontSize: 12,
                  )),
            ),
          ],
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ── API calls ────────────────────────────────────────────────────────────

  Future<void> _fetchPanels() async {
    setState(() => _loadingPanels = true);
    try {
      final res = await http
          .get(Uri.parse("$_baseUrl/store/panels?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['panels'] is List) {
          setState(() {
            _panels = List<Map<String, dynamic>>.from(
                (data['panels'] as List).map((e) => Map<String, dynamic>.from(e)));
          });
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingPanels = false);
  }

  Future<void> _fetchNokosServices() async {
    setState(() => _loadingServices = true);
    try {
      final res = await http
          .get(Uri.parse("$_baseUrl/store/nokos/services?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['services'] is List) {
          setState(() => _nokosServices = data['services'] as List);
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingServices = false);
  }

  Future<void> _fetchMyOrders({bool initial = false}) async {
    setState(() => _loadingOrders = true);
    try {
      final res = await http
          .get(Uri.parse("$_baseUrl/store/myOrders?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['orders'] is List) {
          final orders = List<Map<String, dynamic>>.from(
              (data['orders'] as List).map((e) => Map<String, dynamic>.from(e)));
          orders.sort((a, b) {
            final ta = a['createdAt'] ?? '';
            final tb = b['createdAt'] ?? '';
            return tb.compareTo(ta);
          });
          setState(() => _myOrders = orders);

          // Check for newly approved panel orders → show popup
          for (final o in orders) {
            if (o['type'] == 'panel' &&
                o['status'] == 'approved' &&
                !_shownApproved.contains(o['id'])) {
              _shownApproved.add(o['id']);
              if (!initial) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  _showPanelApprovedPopup(o);
                });
              }
            }
          }

          // Start polling if any panel order is still pending
          final hasPending = orders.any((o) =>
              o['type'] == 'panel' && o['status'] == 'pending');
          if (hasPending) {
            _startPolling();
          } else {
            _pollTimer?.cancel();
          }
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingOrders = false);
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) _fetchMyOrders();
    });
  }

  // ── Saldo ──
  Future<void> _fetchSaldo({bool initial = false}) async {
    setState(() => _loadingSaldo = true);
    try {
      final res = await http
          .get(Uri.parse("$_baseUrl/store/saldo?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final newSaldo = (data['saldo'] ?? 0) as num;
          final prev = _saldo;
          setState(() {
            _saldo = newSaldo.toInt();
            _pendingTopup = data['pendingTopup'] as Map<String, dynamic>?;
          });
          if (!initial && newSaldo.toInt() > prev && _pendingTopup == null) {
            _showSnack('✅ Top up disetujui! Saldo: ${_formatRupiah(_saldo)}');
          }
          if (_pendingTopup != null) {
            _startSaldoPolling();
          } else {
            _saldoPollTimer?.cancel();
          }
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingSaldo = false);
  }

  void _startSaldoPolling() {
    _saldoPollTimer?.cancel();
    _saldoPollTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) _fetchSaldo();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.68)),
        Scaffold(
          backgroundColor: Colors.transparent,
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _SC.card.withOpacity(0.5),
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new,
                    color: _SC.accent, size: 18),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(FontAwesomeIcons.store, color: _SC.accent, size: 16),
                const SizedBox(width: 8),
                Text("TOKO MBUD",
                    style: TextStyle(
                        color: _SC.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        fontSize: 15)),
              ],
            ),
            centerTitle: true,
            flexibleSpace: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(color: _SC.bg.withOpacity(0.4)),
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(56),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: _SC.card.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _SC.border2),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    gradient: LinearGradient(colors: [_SC.accent, _SC.accent2]),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  dividerColor: Colors.transparent,
                  indicatorSize: TabBarIndicatorSize.tab,
                  labelColor: Colors.white,
                  unselectedLabelColor: _SC.textSub,
                  labelStyle: const TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                  unselectedLabelStyle: const TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    letterSpacing: 1,
                  ),
                  tabs: const [
                    Tab(text: 'PANEL'),
                    Tab(text: 'NOMOR'),
                  ],
                ),
              ),
            ),
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.4,
                colors: [_SC.accent.withOpacity(0.08), _SC.bg.withOpacity(0.0)],
              ),
            ),
            child: SafeArea(
              child: TabBarView(
                controller: _tabController,
                children: [
                  // ── PANEL tab ──
                  RefreshIndicator(
                    color: _SC.accent,
                    onRefresh: () => _fetchPanels(),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 32),
                      children: [
                        _buildPanelHero(),
                        const SizedBox(height: 18),
                        _buildPanelGrid(),
                        const SizedBox(height: 24),
                        _buildOrdersSection(filterType: 'panel'),
                        const SizedBox(height: 32),
                      ],
                    ),
                  ),
                  // ── NOMOR tab ──
                  RefreshIndicator(
                    color: _SC.accent,
                    onRefresh: () async {
                      await Future.wait([_fetchNokosServices(), _fetchSaldo()]);
                    },
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 32),
                      children: [
                        _buildNokosHero(),
                        const SizedBox(height: 18),
                        if (_activeNokos != null) ...[
                          _buildActiveNokosCard(),
                          const SizedBox(height: 18),
                        ],
                        _buildNokosServicesList(),
                        const SizedBox(height: 24),
                        _buildOrdersSection(filterType: 'nokos'),
                        const SizedBox(height: 32),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Hero: PANEL ──
  Widget _buildPanelHero() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_SC.accent.withOpacity(0.18), _SC.card],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _SC.accent.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: _SC.accent.withOpacity(0.12), blurRadius: 24)],
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [_SC.accent, _SC.accent2]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(FontAwesomeIcons.server, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('PANEL PTERODACTYL',
                    style: TextStyle(
                      color: _SC.text,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    )),
                const SizedBox(height: 4),
                Text('Manual approval: bayar QRIS + upload bukti, tunggu owner approve',
                    style: TextStyle(
                      color: _SC.textSub,
                      fontFamily: 'ShareTechMono',
                      fontSize: 10,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Hero: NOMOR + SALDO + TOP UP ──
  Widget _buildNokosHero() {
    final hasPending = _pendingTopup != null;
    final pendingNominal = hasPending ? (_pendingTopup!['nominal'] ?? 0) as num : 0;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_SC.accent.withOpacity(0.18), _SC.card],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _SC.accent.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: _SC.accent.withOpacity(0.12), blurRadius: 24)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [_SC.accent, _SC.accent2]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(FontAwesomeIcons.mobileScreenButton,
                    color: Colors.white, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('OMHC NOKOS',
                        style: TextStyle(
                          color: _SC.text,
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        )),
                    const SizedBox(height: 4),
                    Text('Saldo dipakai buat beli nomor virtual',
                        style: TextStyle(
                          color: _SC.textSub,
                          fontFamily: 'ShareTechMono',
                          fontSize: 10,
                        )),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _SC.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _SC.accent.withOpacity(0.25)),
            ),
            child: Row(
              children: [
                Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(
                    color: _SC.accent.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(FontAwesomeIcons.wallet, color: _SC.accent, size: 16),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('SALDO',
                          style: TextStyle(
                            color: _SC.textSub,
                            fontFamily: 'ShareTechMono',
                            fontSize: 10,
                            letterSpacing: 1,
                          )),
                      const SizedBox(height: 2),
                      _loadingSaldo
                          ? const SizedBox(
                              width: 18, height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: _SC.accent),
                            )
                          : Text(_formatRupiah(_saldo),
                              style: const TextStyle(
                                color: _SC.accent,
                                fontFamily: 'ShareTechMono',
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              )),
                    ],
                  ),
                ),
                if (hasPending)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _SC.warning.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _SC.warning.withOpacity(0.4)),
                    ),
                    child: Text('PENDING',
                        style: TextStyle(
                          color: _SC.warning,
                          fontFamily: 'ShareTechMono',
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        )),
                  ),
              ],
            ),
          ),
          if (hasPending) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: _SC.warning.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _SC.warning.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  Icon(Icons.hourglass_top, color: _SC.warning, size: 14),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Top up ${_formatRupiah(pendingNominal)} menunggu konfirmasi owner...',
                      style: const TextStyle(
                        color: _SC.warning,
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: ElevatedButton.icon(
              onPressed: hasPending ? null : _openTopupDialog,
              icon: const Icon(FontAwesomeIcons.plus, size: 14),
              label: const Text('TOP UP SALDO',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  )),
              style: ElevatedButton.styleFrom(
                backgroundColor: _SC.accent,
                foregroundColor: Colors.white,
                disabledBackgroundColor: _SC.cardHigh,
                disabledForegroundColor: _SC.textSub,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Panel grid ──
  Widget _buildPanelGrid() {
    if (_loadingPanels && _panels.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(40),
        child: const Center(
          child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2),
        ),
      );
    }
    if (_panels.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(40),
        child: Center(
          child: Text('Gagal memuat panel. Tarik untuk refresh.',
              style: TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 11)),
        ),
      );
    }
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _panels.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.92,
      ),
      itemBuilder: (ctx, i) {
        final p = _panels[i];
        return _buildPanelCard(p);
      },
    );
  }

  Widget _buildPanelCard(Map<String, dynamic> p) {
    return GestureDetector(
      onTap: () => _openPanelOrderDialog(p),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_SC.card, _SC.cardHigh],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _SC.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: _SC.accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _SC.accent.withOpacity(0.3)),
              ),
              child: const Icon(FontAwesomeIcons.server, color: _SC.accent, size: 14),
            ),
            const Spacer(),
            Text(p['name'] ?? 'Panel',
                style: const TextStyle(
                  color: _SC.text,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                )),
            const SizedBox(height: 4),
            Text(p['desc'] ?? '',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: _SC.textSub,
                  fontFamily: 'ShareTechMono',
                  fontSize: 9,
                  height: 1.3,
                )),
            const Spacer(),
            Row(
              children: [
                Text(_formatRupiah((p['price'] ?? 0) as num),
                    style: const TextStyle(
                      color: _SC.accent,
                      fontFamily: 'ShareTechMono',
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    )),
                const Spacer(),
                const Icon(Icons.arrow_forward_ios_rounded, color: _SC.accent, size: 12),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Nokos services list ──
  Widget _buildNokosServicesList() {
    if (_loadingServices && _nokosServices.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(40),
        child: const Center(
          child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2),
        ),
      );
    }
    if (_nokosServices.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(40),
        child: Center(
          child: Text('Gagal memuat layanan. Tarik untuk refresh.',
              style: TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 11)),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('PILIH LAYANAN',
            style: TextStyle(
              color: _SC.textSub,
              fontFamily: 'ShareTechMono',
              fontSize: 11,
              letterSpacing: 2,
            )),
        const SizedBox(height: 12),
        ..._nokosServices.map((svc) => _buildServiceCard(svc)),
      ],
    );
  }

  Widget _buildServiceCard(dynamic svcRaw) {
    final svc = Map<String, dynamic>.from(svcRaw as Map);
    final name = (svc['service_name'] ?? svc['name'] ?? 'Service').toString();
    final code = (svc['service_code'] ?? svc['id'] ?? '').toString();
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_SC.card, _SC.cardHigh],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _SC.border),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => _openCountryListDialog(code, name),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: _SC.accent.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _SC.accent.withOpacity(0.3)),
                  ),
                  child: const Icon(FontAwesomeIcons.mobileScreenButton,
                      color: _SC.accent, size: 16),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name,
                          style: const TextStyle(
                            color: _SC.text,
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                          )),
                      const SizedBox(height: 2),
                      Text('Code: $code',
                          style: const TextStyle(
                            color: _SC.textSub,
                            fontFamily: 'ShareTechMono',
                            fontSize: 9,
                          )),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: _SC.textSub, size: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Active Nokos Card (shows active order + OTP) ──
  Widget _buildActiveNokosCard() {
    final a = _activeNokos!;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_SC.accent.withOpacity(0.18), _SC.card],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _SC.accent.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.sim_card_rounded, color: _SC.accent, size: 16),
              const SizedBox(width: 8),
              const Text('NOMOR AKTIF',
                  style: TextStyle(
                    color: _SC.text,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  )),
              const Spacer(),
              GestureDetector(
                onTap: _cancelNokosOrder,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: _SC.danger.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _SC.danger.withOpacity(0.4)),
                  ),
                  child: const Text('BATAL',
                      style: TextStyle(
                        color: _SC.danger,
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(a['phone'] ?? '-',
              style: const TextStyle(
                color: _SC.text,
                fontFamily: 'ShareTechMono',
                fontSize: 18,
                fontWeight: FontWeight.bold,
              )),
          const SizedBox(height: 4),
          Text('${a['service'] ?? '-'} • ${a['country'] ?? ''}',
              style: const TextStyle(
                color: _SC.textSub,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
              )),
          const SizedBox(height: 12),
          ValueListenableBuilder<String>(
            valueListenable: _otpStatusNotifier,
            builder: (_, status, __) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: _SC.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _SC.border2),
              ),
              child: Row(
                children: [
                  Icon(status.contains('diterima') ? Icons.check_circle : Icons.hourglass_top,
                      color: status.contains('diterima') ? _SC.success : _SC.warning, size: 14),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(status,
                        style: TextStyle(
                          color: status.contains('diterima') ? _SC.success : _SC.warning,
                          fontFamily: 'ShareTechMono',
                          fontSize: 11,
                        )),
                  ),
                ],
              ),
            ),
          ),
          ValueListenableBuilder<String?>(
            valueListenable: _otpCodeNotifier,
            builder: (_, code, __) {
              if (code == null || code.isEmpty) return const SizedBox.shrink();
              return Container(
                margin: const EdgeInsets.only(top: 8),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _SC.success.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _SC.success.withOpacity(0.4)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.message, color: _SC.success, size: 16),
                    const SizedBox(width: 10),
                    const Text('OTP:',
                        style: TextStyle(
                          color: _SC.textSub,
                          fontFamily: 'ShareTechMono',
                          fontSize: 11,
                        )),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(code,
                          style: const TextStyle(
                            color: _SC.success,
                            fontFamily: 'ShareTechMono',
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          )),
                    ),
                    GestureDetector(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: code));
                        _showSnack('OTP disalin');
                      },
                      child: const Icon(Icons.copy, color: _SC.success, size: 14),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // ── Orders section ──
  Widget _buildOrdersSection({required String filterType}) {
    final orders = _myOrders.where((o) => o['type'] == filterType).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(filterType == 'panel' ? FontAwesomeIcons.server : FontAwesomeIcons.mobileScreenButton,
                color: _SC.accent, size: 14),
            const SizedBox(width: 8),
            Text(filterType == 'panel' ? 'ORDER PANEL' : 'ORDER NOMOR',
                style: const TextStyle(
                  color: _SC.text,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
            const Spacer(),
            Text('${orders.length}',
                style: const TextStyle(
                  color: _SC.textSub,
                  fontFamily: 'ShareTechMono',
                  fontSize: 11,
                )),
          ],
        ),
        const SizedBox(height: 12),
        if (_loadingOrders && orders.isEmpty)
          const Center(child: Padding(
            padding: EdgeInsets.all(20),
            child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2),
          ))
        else if (orders.isEmpty)
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _SC.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _SC.border2),
            ),
            child: Center(
              child: Text(
                filterType == 'panel' ? 'Belum ada order panel' : 'Belum ada order nomor',
                style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 11),
              ),
            ),
          )
        else
          ...orders.map((o) => filterType == 'panel'
              ? _buildPanelOrderCard(o)
              : _buildNokosOrderCard(o)),
      ],
    );
  }

  Widget _buildPanelOrderCard(Map<String, dynamic> o) {
    final status = (o['status'] ?? '').toString();
    Color statusColor = _SC.warning;
    if (status == 'approved') statusColor = _SC.success;
    if (status == 'rejected') statusColor = _SC.danger;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _SC.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _SC.border2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(FontAwesomeIcons.server, color: _SC.accent, size: 14),
              const SizedBox(width: 8),
              Expanded(
                child: Text(o['panelName'] ?? 'Panel',
                    style: const TextStyle(
                      color: _SC.text,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    )),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: statusColor.withOpacity(0.4)),
                ),
                child: Text(status.toUpperCase(),
                    style: TextStyle(
                      color: statusColor,
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    )),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(_formatRupiah((o['price'] ?? 0) as num),
                  style: const TextStyle(color: _SC.accent, fontFamily: 'ShareTechMono', fontSize: 11)),
              const SizedBox(width: 12),
              if (o['createdAt'] != null)
                Expanded(
                  child: Text(o['createdAt'].toString().substring(0, 16),
                      textAlign: TextAlign.right,
                      style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 9)),
                ),
            ],
          ),
          if (status == 'approved' && o['panelData'] != null) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _SC.success.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _SC.success.withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Username: ${o['panelData']['username'] ?? '-'}',
                      style: const TextStyle(color: _SC.text, fontFamily: 'ShareTechMono', fontSize: 10)),
                  Text('Password: ${o['panelData']['password'] ?? '-'}',
                      style: const TextStyle(color: _SC.text, fontFamily: 'ShareTechMono', fontSize: 10)),
                  Text('Login: ${o['panelData']['login'] ?? '-'}',
                      style: const TextStyle(color: _SC.text, fontFamily: 'ShareTechMono', fontSize: 10)),
                ],
              ),
            ),
          ],
          if (status == 'rejected' && o['rejectReason'] != null) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _SC.danger.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _SC.danger.withOpacity(0.3)),
              ),
              child: Text('Alasan: ${o['rejectReason']}',
                  style: const TextStyle(color: _SC.danger, fontFamily: 'ShareTechMono', fontSize: 10)),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildNokosOrderCard(Map<String, dynamic> o) {
    final status = (o['status'] ?? '').toString();
    Color statusColor = _SC.warning;
    if (status == 'active' || status == 'completed') statusColor = _SC.success;
    if (status == 'cancelled') statusColor = _SC.danger;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _SC.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _SC.border2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(FontAwesomeIcons.mobileScreenButton, color: _SC.accent, size: 14),
              const SizedBox(width: 8),
              Expanded(
                child: Text(o['phoneNumber'] ?? '-',
                    style: const TextStyle(
                      color: _SC.text,
                      fontFamily: 'ShareTechMono',
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    )),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: statusColor.withOpacity(0.4)),
                ),
                child: Text(status.toUpperCase(),
                    style: TextStyle(
                      color: statusColor,
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    )),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text('${o['service'] ?? '-'} • ${o['country'] ?? ''}',
              style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 10)),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(_formatRupiah((o['price'] ?? 0) as num),
                  style: const TextStyle(color: _SC.accent, fontFamily: 'ShareTechMono', fontSize: 11)),
              const SizedBox(width: 12),
              if (o['createdAt'] != null)
                Expanded(
                  child: Text(o['createdAt'].toString().substring(0, 16),
                      textAlign: TextAlign.right,
                      style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 9)),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // ── DIALOGS ───────────────────────────────────────────────────────────────

  // Panel order dialog: show QRIS, upload proof, submit
  Future<void> _openPanelOrderDialog(Map<String, dynamic> panel) async {
    File? proofFile;
    String? proofBase64;
    bool submitting = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogCtx) {
        return StatefulBuilder(
          builder: (ctx, setDialogState) {
            return Dialog(
              backgroundColor: Colors.transparent,
              insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Container(
                constraints: const BoxConstraints(maxHeight: 620),
                decoration: BoxDecoration(
                  color: _SC.card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _SC.accentDim, width: 1.5),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [_SC.accent.withOpacity(0.18), Colors.transparent]),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(20), topRight: Radius.circular(20),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 36, height: 36,
                            decoration: BoxDecoration(
                              color: _SC.accent.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _SC.accent.withOpacity(0.4)),
                            ),
                            child: const Icon(FontAwesomeIcons.server, color: _SC.accent, size: 16),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(panel['name'] ?? 'Panel',
                                    style: const TextStyle(
                                      color: _SC.text,
                                      fontFamily: 'MADEEvolveSansEVO',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    )),
                                Text(_formatRupiah((panel['price'] ?? 0) as num),
                                    style: const TextStyle(
                                      color: _SC.accent,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 11,
                                    )),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, color: _SC.textSub, size: 18),
                            onPressed: () => Navigator.pop(ctx),
                          ),
                        ],
                      ),
                    ),
                    Flexible(
                      child: ListView(
                        shrinkWrap: true,
                        padding: const EdgeInsets.all(16),
                        children: [
                          Center(
                            child: Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _SC.text,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  'assets/images/qris.jpg',
                                  width: 200, height: 200, fit: BoxFit.cover,
                                  errorBuilder: (c, e, _) => Container(
                                    width: 200, height: 200,
                                    color: _SC.text,
                                    child: Icon(Icons.broken_image, color: _SC.muted2, size: 40),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                            decoration: BoxDecoration(
                              color: _SC.surface,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _SC.border2),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.info_outline_rounded, color: _SC.accent.withOpacity(0.7), size: 14),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    'Bayar ${_formatRupiah((panel['price'] ?? 0) as num)} via QRIS, lalu upload screenshot bukti pembayaran di bawah.',
                                    style: const TextStyle(
                                      color: _SC.muted,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 10,
                                      height: 1.5,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          GestureDetector(
                            onTap: () async {
                              try {
                                final picker = ImagePicker();
                                final xfile = await picker.pickImage(
                                  source: ImageSource.gallery,
                                  imageQuality: 70,
                                  maxWidth: 1280,
                                );
                                if (xfile == null) return;
                                final bytes = await xfile.readAsBytes();
                                final b64 = base64Encode(bytes);
                                final mime = xfile.mimeType ?? 'image/jpeg';
                                proofFile = File(xfile.path);
                                proofBase64 = 'data:$mime;base64,$b64';
                                setDialogState(() {});
                              } catch (e) {
                                _showSnack('Gagal memilih gambar: $e', isError: true);
                              }
                            },
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: _SC.surface,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: proofFile != null
                                      ? _SC.accent.withOpacity(0.5)
                                      : _SC.border2,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 36, height: 36,
                                    decoration: BoxDecoration(
                                      color: _SC.accent.withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(
                                      proofFile != null ? Icons.check_rounded : Icons.upload_file,
                                      color: _SC.accent, size: 18,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      proofFile != null
                                          ? 'Bukti terpilih (tap untuk ganti)'
                                          : 'Upload Bukti Pembayaran',
                                      style: TextStyle(
                                        color: proofFile != null ? _SC.text : _SC.textSub,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 11,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            width: double.infinity,
                            height: 46,
                            child: ElevatedButton(
                              onPressed: submitting
                                  ? null
                                  : () async {
                                      if (proofBase64 == null || proofBase64!.length < 100) {
                                        _showSnack('Upload bukti dulu', isError: true);
                                        return;
                                      }
                                      setDialogState(() => submitting = true);
                                      final ok = await _submitPanelOrder(
                                          panel['id'], proofBase64!);
                                      setDialogState(() => submitting = false);
                                      if (ok) {
                                        Navigator.pop(ctx, true);
                                      }
                                    },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _SC.accent,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12)),
                                elevation: 0,
                              ),
                              child: submitting
                                  ? const SizedBox(
                                      width: 18, height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                      ),
                                    )
                                  : const Text('BAYAR & KIRIM',
                                      style: TextStyle(
                                        fontFamily: 'MADEEvolveSansEVO',
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 2,
                                      )),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<bool> _submitPanelOrder(String panelId, String proofBase64) async {
    try {
      final res = await http
          .post(
            Uri.parse("$_baseUrl/store/orderPanel"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'panelId': panelId,
              'proofBase64': proofBase64,
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (res.statusCode != 200) {
        _showSnack('Server error (${res.statusCode})', isError: true);
        return false;
      }

      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showSnack('Order terkirim! Tunggu owner approve.');
        await _fetchMyOrders();
        return true;
      } else {
        _showSnack(data['message'] ?? 'Gagal order panel', isError: true);
        return false;
      }
    } catch (e) {
      _showSnack('Connection error: $e', isError: true);
      return false;
    }
  }

  // Country list dialog (with pricelist)
  Future<void> _openCountryListDialog(String serviceCode, String serviceName) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Dialog(
        backgroundColor: Colors.transparent,
        child: Center(child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2)),
      ),
    );

    try {
      final res = await http
          .get(Uri.parse(
              "$_baseUrl/store/nokos/countries?key=${widget.sessionKey}&serviceId=${Uri.encodeComponent(serviceCode)}"))
          .timeout(const Duration(seconds: 15));
      Navigator.pop(context); // close loading
      if (res.statusCode != 200) {
        _showSnack('Server error (${res.statusCode})', isError: true);
        return;
      }
      final data = jsonDecode(res.body);
      if (data['valid'] != true) {
        _showSnack(data['message'] ?? 'Gagal memuat negara', isError: true);
        return;
      }
      final countries = (data['countries'] as List?) ?? [];
      if (countries.isEmpty) {
        _showSnack('Tidak ada negara tersedia', isError: true);
        return;
      }
      _showCountryPicker(serviceCode, serviceName, countries);
    } catch (e) {
      Navigator.pop(context); // close loading
      _showSnack('Connection error: $e', isError: true);
    }
  }

  void _showCountryPicker(String serviceCode, String serviceName, List<dynamic> countries) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        height: MediaQuery.of(context).size.height * 0.85,
        decoration: const BoxDecoration(
          color: _SC.bg2,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20), topRight: Radius.circular(20),
          ),
          border: Border(top: BorderSide(color: _SC.accentDim, width: 1.5)),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_SC.accent.withOpacity(0.18), Colors.transparent]),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20), topRight: Radius.circular(20),
                ),
              ),
              child: Row(
                children: [
                  const Icon(FontAwesomeIcons.earthAsia, color: _SC.accent, size: 16),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(serviceName,
                            style: const TextStyle(
                              color: _SC.text,
                              fontFamily: 'MADEEvolveSansEVO',
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            )),
                        Text('${countries.length} negara tersedia',
                            style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 10)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: _SC.textSub, size: 18),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: countries.length,
                itemBuilder: (c, i) {
                  final country = Map<String, dynamic>.from(countries[i] as Map);
                  final name = (country['name'] ?? 'Unknown').toString();
                  final stock = country['stock_total'] ?? country['stock'] ?? 0;
                  final pricelist = (country['pricelist'] as List?) ?? [];
                  final available = pricelist.where((p) {
                    final pm = Map<String, dynamic>.from(p as Map);
                    return pm['available'] == true;
                  }).length;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: _SC.card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _SC.border2),
                    ),
                    child: Material(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () {
                          Navigator.pop(ctx);
                          _showPricelistPicker(serviceName, name, country);
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Container(
                                width: 38, height: 38,
                                decoration: BoxDecoration(
                                  color: _SC.accent.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Icon(FontAwesomeIcons.earthAsia, color: _SC.accent, size: 14),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(name,
                                        style: const TextStyle(
                                          color: _SC.text,
                                          fontFamily: 'MADEEvolveSansEVO',
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                        )),
                                    const SizedBox(height: 2),
                                    Text('Stok: $stock • $available provider',
                                        style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 10)),
                                  ],
                                ),
                              ),
                              const Icon(Icons.chevron_right_rounded, color: _SC.textSub, size: 16),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showPricelistPicker(String serviceName, String countryName, Map<String, dynamic> country) {
    final pricelistRaw = (country['pricelist'] as List?) ?? [];
    final pricelist = pricelistRaw
        .map((p) => Map<String, dynamic>.from(p as Map))
        .where((p) => p['available'] == true)
        .toList();
    pricelist.sort((a, b) {
      final pa = int.tryParse(a['price']?.toString() ?? '0') ?? 0;
      final pb = int.tryParse(b['price']?.toString() ?? '0') ?? 0;
      return pa.compareTo(pb);
    });

    if (pricelist.isEmpty) {
      _showSnack('Tidak ada provider tersedia untuk negara ini', isError: true);
      return;
    }

    final numberId = country['number_id']?.toString() ?? '';

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        height: MediaQuery.of(context).size.height * 0.85,
        decoration: const BoxDecoration(
          color: _SC.bg2,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20), topRight: Radius.circular(20),
          ),
          border: Border(top: BorderSide(color: _SC.accentDim, width: 1.5)),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_SC.accent.withOpacity(0.18), Colors.transparent]),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20), topRight: Radius.circular(20),
                ),
              ),
              child: Row(
                children: [
                  const Icon(FontAwesomeIcons.tags, color: _SC.accent, size: 16),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('$countryName • $serviceName',
                            style: const TextStyle(
                              color: _SC.text,
                              fontFamily: 'MADEEvolveSansEVO',
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            )),
                        Text('Pilih harga (sudah termasuk markup Rp 800)',
                            style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 10)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: _SC.textSub, size: 18),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: pricelist.length,
                itemBuilder: (c, i) {
                  final p = pricelist[i];
                  final basePrice = int.tryParse(p['price']?.toString() ?? '0') ?? 0;
                  final finalPrice = basePrice + 800;
                  final stock = p['stock'] ?? 0;
                  final providerId = p['provider_id']?.toString() ?? '';
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: _SC.card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _SC.border2),
                    ),
                    child: Material(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () {
                          Navigator.pop(ctx);
                          _openOperatorDialog(
                            serviceName: serviceName,
                            countryName: countryName,
                            numberId: numberId,
                            providerId: providerId,
                            finalPrice: finalPrice,
                          );
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Container(
                                width: 38, height: 38,
                                decoration: BoxDecoration(
                                  color: _SC.accent.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Icon(FontAwesomeIcons.tags, color: _SC.accent, size: 14),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(_formatRupiah(finalPrice),
                                        style: const TextStyle(
                                          color: _SC.accent,
                                          fontFamily: 'ShareTechMono',
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                        )),
                                    const SizedBox(height: 2),
                                    Text('Provider: $providerId • Stok: $stock',
                                        style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 10)),
                                  ],
                                ),
                              ),
                              const Icon(Icons.chevron_right_rounded, color: _SC.textSub, size: 16),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Operator picker (optional — can use 'any')
  Future<void> _openOperatorDialog({
    required String serviceName,
    required String countryName,
    required String numberId,
    required String providerId,
    required int finalPrice,
  }) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Dialog(
        backgroundColor: Colors.transparent,
        child: Center(child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2)),
      ),
    );

    try {
      final res = await http
          .get(Uri.parse(
              "$_baseUrl/store/nokos/operators?key=${widget.sessionKey}&countryName=${Uri.encodeComponent(countryName)}&providerId=${Uri.encodeComponent(providerId)}"))
          .timeout(const Duration(seconds: 10));
      Navigator.pop(context); // close loading

      final data = jsonDecode(res.body);
      final operators = (data['operators'] as List?) ?? [];

      _showOperatorPicker(
        serviceName: serviceName,
        countryName: countryName,
        numberId: numberId,
        providerId: providerId,
        finalPrice: finalPrice,
        operators: operators,
      );
    } catch (e) {
      Navigator.pop(context); // close loading
      // Fallback: skip operator selection, just order with 'any'
      _confirmOrder(
        serviceName: serviceName,
        countryName: countryName,
        numberId: numberId,
        providerId: providerId,
        operatorId: 'any',
        finalPrice: finalPrice,
      );
    }
  }

  void _showOperatorPicker({
    required String serviceName,
    required String countryName,
    required String numberId,
    required String providerId,
    required int finalPrice,
    required List<dynamic> operators,
  }) {
    if (operators.isEmpty) {
      _confirmOrder(
        serviceName: serviceName,
        countryName: countryName,
        numberId: numberId,
        providerId: providerId,
        operatorId: 'any',
        finalPrice: finalPrice,
      );
      return;
    }
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: _SC.bg2,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20), topRight: Radius.circular(20),
          ),
          border: Border(top: BorderSide(color: _SC.accentDim, width: 1.5)),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [_SC.accent.withOpacity(0.18), Colors.transparent]),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20), topRight: Radius.circular(20),
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(FontAwesomeIcons.towerBroadcast, color: _SC.accent, size: 16),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text('PILIH OPERATOR',
                          style: TextStyle(
                            color: _SC.text,
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                          )),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: _SC.textSub, size: 18),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
              ),
              // Any option
              ListTile(
                leading: const Icon(Icons.shuffle, color: _SC.accent, size: 18),
                title: const Text('Random / Any',
                    style: TextStyle(color: _SC.text, fontFamily: 'ShareTechMono', fontSize: 12)),
                trailing: const Icon(Icons.chevron_right, color: _SC.textSub, size: 18),
                onTap: () {
                  Navigator.pop(ctx);
                  _confirmOrder(
                    serviceName: serviceName,
                    countryName: countryName,
                    numberId: numberId,
                    providerId: providerId,
                    operatorId: 'any',
                    finalPrice: finalPrice,
                  );
                },
              ),
              const Divider(color: _SC.border2, height: 1),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.5),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: operators.length,
                  itemBuilder: (c, i) {
                    final op = Map<String, dynamic>.from(operators[i] as Map);
                    final name = (op['name'] ?? 'Operator').toString();
                    final id = (op['id'] ?? '').toString();
                    return ListTile(
                      leading: const Icon(FontAwesomeIcons.towerBroadcast, color: _SC.textSub, size: 16),
                      title: Text(name,
                          style: const TextStyle(color: _SC.text, fontFamily: 'ShareTechMono', fontSize: 12)),
                      subtitle: Text('ID: $id',
                          style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 10)),
                      trailing: const Icon(Icons.chevron_right, color: _SC.textSub, size: 18),
                      onTap: () {
                        Navigator.pop(ctx);
                        _confirmOrder(
                          serviceName: serviceName,
                          countryName: countryName,
                          numberId: numberId,
                          providerId: providerId,
                          operatorId: id,
                          finalPrice: finalPrice,
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmOrder({
    required String serviceName,
    required String countryName,
    required String numberId,
    required String providerId,
    required String operatorId,
    required int finalPrice,
  }) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _SC.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.shopping_cart_checkout, color: _SC.accent, size: 18),
            const SizedBox(width: 8),
            const Text('Konfirmasi Order',
                style: TextStyle(
                  color: _SC.text,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                )),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Layanan: $serviceName',
                style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 11)),
            const SizedBox(height: 4),
            Text('Negara: $countryName',
                style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 11)),
            const SizedBox(height: 4),
            Text('Operator: $operatorId',
                style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 11)),
            const SizedBox(height: 8),
            Text('Harga: ${_formatRupiah(finalPrice)}',
                style: const TextStyle(color: _SC.accent, fontFamily: 'ShareTechMono', fontSize: 13, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Saldo setelah order: ${_formatRupiah(_saldo - finalPrice)}',
                style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 11)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal',
                style: TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 12)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _orderNokos(
                serviceName: serviceName,
                countryName: countryName,
                numberId: numberId,
                providerId: providerId,
                operatorId: operatorId,
                finalPrice: finalPrice,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _SC.accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('ORDER',
                style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
          ),
        ],
      ),
    );
  }

  Future<void> _orderNokos({
    required String serviceName,
    required String countryName,
    required String numberId,
    required String providerId,
    required String operatorId,
    required int finalPrice,
  }) async {
    if (_isOrderingNokos) return;

    if (_saldo < finalPrice) {
      _showInsufficientSaldoDialog(finalPrice);
      return;
    }

    setState(() => _isOrderingNokos = true);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Dialog(
        backgroundColor: Colors.transparent,
        child: Center(child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2)),
      ),
    );

    try {
      final res = await http
          .post(
            Uri.parse("$_baseUrl/store/orderNokos"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'numberId': numberId,
              'providerId': providerId,
              'operatorId': operatorId,
              'price': finalPrice,
              'serviceName': serviceName,
              'countryName': countryName,
            }),
          )
          .timeout(const Duration(seconds: 60));

      Navigator.pop(context); // close loading

      if (res.statusCode != 200) {
        _showSnack('Server error (${res.statusCode})', isError: true);
        return;
      }

      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final order = data['order'] as Map<String, dynamic>?;
        setState(() {
          _activeNokos = {
            'phone': order?['phone_number'] ?? '-',
            'orderId': order?['order_id']?.toString() ?? '-',
            'service': serviceName,
            'country': countryName,
            'price': finalPrice,
          };
        });
        _fetchSaldo();
        _otpStatusNotifier.value = 'Menunggu OTP...';
        _otpCodeNotifier.value = null;
        _showSnack('Nomor berhasil dipesan!');
        await _fetchMyOrders();
        _startOtpPolling();
      } else {
        if (data['insufficientSaldo'] == true) {
          final need = (data['need'] ?? finalPrice) as num;
          _showInsufficientSaldoDialog(need.toInt());
        } else {
          _showSnack(data['message'] ?? 'Gagal order nomor', isError: true);
        }
      }
    } catch (e) {
      Navigator.pop(context); // close loading
      _showSnack('Connection error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isOrderingNokos = false);
    }
  }

  void _showInsufficientSaldoDialog(int need) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _SC.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(FontAwesomeIcons.wallet, color: _SC.warning, size: 18),
            const SizedBox(width: 8),
            const Text('Saldo Tidak Cukup',
                style: TextStyle(
                  color: _SC.text,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                )),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Saldo kamu: ${_formatRupiah(_saldo)}',
                style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 12)),
            const SizedBox(height: 4),
            Text('Butuh: ${_formatRupiah(need)}',
                style: const TextStyle(color: _SC.warning, fontFamily: 'ShareTechMono', fontSize: 12)),
            const SizedBox(height: 8),
            const Text('Top up dulu buat lanjut order nomor virtual.',
                style: TextStyle(color: _SC.textSub, fontSize: 12)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal',
                style: TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 12)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _openTopupDialog();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _SC.accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('TOP UP',
                style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
          ),
        ],
      ),
    );
  }

  void _startOtpPolling() {
    _otpPollTimer?.cancel();
    final orderId = _activeNokos?['orderId']?.toString();
    if (orderId == null || orderId == '-') return;
    _otpPollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted) {
        _otpPollTimer?.cancel();
        return;
      }
      try {
        final res = await http
            .get(Uri.parse(
              "$_baseUrl/store/nokos/status?key=${widget.sessionKey}&orderId=${Uri.encodeComponent(orderId)}",
            ))
            .timeout(const Duration(seconds: 10));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['valid'] == true) {
            final st = data['status'];
            String statusText = 'Menunggu OTP...';
            String? otp;
            if (st is Map) {
              final statusStr = (st['status'] ?? '').toString().toLowerCase();
              otp = st['otp_code']?.toString() ?? st['otp']?.toString() ?? st['code']?.toString();
              if (otp != null && otp.isNotEmpty && otp != 'null' && otp != '-') {
                statusText = 'OTP diterima!';
                _otpCodeNotifier.value = otp;
                _otpStatusNotifier.value = statusText;
                _otpPollTimer?.cancel();
                // Update order status in store
                await _fetchMyOrders();
                return;
              }
              if (statusStr.contains('completed') || statusStr.contains('success')) {
                statusText = 'OTP diterima!';
              } else if (statusStr.contains('cancelled') || statusStr.contains('cancel')) {
                statusText = 'Order dibatalkan';
                _otpPollTimer?.cancel();
                _otpStatusNotifier.value = statusText;
                await _fetchMyOrders();
                return;
              } else if (statusStr.contains('processing') || statusStr.contains('waiting') || statusStr.contains('pending')) {
                statusText = 'Menunggu OTP...';
              }
            }
            _otpStatusNotifier.value = statusText;
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _cancelNokosOrder() async {
    final orderId = _activeNokos?['orderId']?.toString();
    if (orderId == null || orderId == '-') return;

    // Confirm dialog
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _SC.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Batalkan Order?',
            style: TextStyle(
              color: _SC.text,
              fontFamily: 'MADEEvolveSansEVO',
              fontSize: 14,
              fontWeight: FontWeight.bold,
            )),
        content: const Text('Order bisa dibatalkan setelah 5 menit. Saldo akan dikembalikan.',
            style: TextStyle(color: _SC.textSub, fontSize: 12)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal',
                style: TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 12)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: _SC.danger,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('BATALKAN',
                style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Dialog(
        backgroundColor: Colors.transparent,
        child: Center(child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2)),
      ),
    );

    try {
      final res = await http
          .post(
            Uri.parse("$_baseUrl/store/nokos/cancel"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'orderId': orderId,
            }),
          )
          .timeout(const Duration(seconds: 15));

      Navigator.pop(context); // close loading

      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showSnack('Order dibatalkan. Saldo: ${_formatRupiah((data['newSaldo'] ?? 0) as num)}');
        _otpPollTimer?.cancel();
        setState(() => _activeNokos = null);
        _otpCodeNotifier.value = null;
        _otpStatusNotifier.value = 'Menunggu OTP...';
        await _fetchSaldo();
        await _fetchMyOrders();
      } else {
        // Show wait time if still in 5-min window
        final waitMin = data['waitMinutes'];
        final waitSec = data['waitSeconds'];
        if (waitMin != null && waitSec != null) {
          _showSnack('Belum bisa dibatal. Tunggu ${waitMin}m ${waitSec}s lagi.', isError: true);
        } else {
          _showSnack(data['message'] ?? 'Gagal membatalkan order', isError: true);
        }
      }
    } catch (e) {
      Navigator.pop(context); // close loading
      _showSnack('Connection error: $e', isError: true);
    }
  }

  // Top up saldo dialog
  Future<void> _openTopupDialog() async {
    if (_pendingTopup != null) {
      _showSnack('Top up Rp ${_formatRupiah((_pendingTopup!['nominal'] ?? 0) as num)} masih menunggu konfirmasi owner.');
      return;
    }

    final List<Map<String, dynamic>> presets = [
      {'nominal': 5000,  'label': 'Rp 5.000'},
      {'nominal': 10000, 'label': 'Rp 10.000'},
      {'nominal': 25000, 'label': 'Rp 25.000'},
      {'nominal': 50000, 'label': 'Rp 50.000'},
    ];

    int? selectedNominal;
    File? proofFile;
    String? proofBase64;
    bool submitting = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogCtx) {
        return StatefulBuilder(
          builder: (ctx, setDialogState) {
            return Dialog(
              backgroundColor: Colors.transparent,
              insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Container(
                constraints: const BoxConstraints(maxHeight: 620),
                decoration: BoxDecoration(
                  color: _SC.card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _SC.accentDim, width: 1.5),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [_SC.accent.withOpacity(0.18), Colors.transparent]),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(20), topRight: Radius.circular(20),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 36, height: 36,
                            decoration: BoxDecoration(
                              color: _SC.accent.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _SC.accent.withOpacity(0.4)),
                            ),
                            child: const Icon(FontAwesomeIcons.wallet, color: _SC.accent, size: 16),
                          ),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Text('TOP UP SALDO',
                                style: TextStyle(
                                  color: _SC.text,
                                  fontFamily: 'MADEEvolveSansEVO',
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13,
                                  letterSpacing: 2,
                                )),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, color: _SC.textSub, size: 18),
                            onPressed: () => Navigator.pop(ctx),
                          ),
                        ],
                      ),
                    ),
                    Flexible(
                      child: ListView(
                        shrinkWrap: true,
                        padding: const EdgeInsets.all(16),
                        children: [
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: _SC.surface,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: _SC.border2),
                            ),
                            child: Row(
                              children: [
                                const Icon(FontAwesomeIcons.wallet, color: _SC.accent, size: 16),
                                const SizedBox(width: 10),
                                const Expanded(
                                  child: Text('Saldo saat ini',
                                      style: TextStyle(
                                        color: _SC.textSub,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 11,
                                      )),
                                ),
                                Text(_formatRupiah(_saldo),
                                    style: const TextStyle(
                                      color: _SC.accent,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    )),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          const Text('Pilih Nominal',
                              style: TextStyle(
                                color: _SC.textSub,
                                fontFamily: 'ShareTechMono',
                                fontSize: 11,
                                letterSpacing: 1,
                              )),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: presets.map((p) {
                              final sel = selectedNominal == p['nominal'];
                              return GestureDetector(
                                onTap: () => setDialogState(() => selectedNominal = p['nominal'] as int),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                  decoration: BoxDecoration(
                                    color: sel ? _SC.accent : _SC.surface,
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: sel ? _SC.accent : _SC.border2,
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Text(p['label'] as String,
                                      style: TextStyle(
                                        color: sel ? Colors.white : _SC.text,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      )),
                                ),
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 16),
                          if (selectedNominal != null) ...[
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _SC.text,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  'assets/images/qris.jpg',
                                  width: 180, height: 180, fit: BoxFit.cover,
                                  errorBuilder: (c, e, _) => Container(
                                    width: 180, height: 180,
                                    color: _SC.text,
                                    child: Icon(Icons.broken_image, color: _SC.muted2, size: 40),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                              decoration: BoxDecoration(
                                color: _SC.surface,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: _SC.border2),
                              ),
                              child: Row(
                                children: [
                                  Icon(Icons.info_outline_rounded, color: _SC.accent.withOpacity(0.7), size: 14),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      'Bayar ${_formatRupiah(selectedNominal!)} via QRIS, lalu upload bukti pembayaran.',
                                      style: const TextStyle(
                                        color: _SC.muted,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 10,
                                        height: 1.5,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 12),
                          ],
                          GestureDetector(
                            onTap: () async {
                              try {
                                final picker = ImagePicker();
                                final xfile = await picker.pickImage(
                                  source: ImageSource.gallery,
                                  imageQuality: 70,
                                  maxWidth: 1280,
                                );
                                if (xfile == null) return;
                                final bytes = await xfile.readAsBytes();
                                final b64 = base64Encode(bytes);
                                final mime = xfile.mimeType ?? 'image/jpeg';
                                proofFile = File(xfile.path);
                                proofBase64 = 'data:$mime;base64,$b64';
                                setDialogState(() {});
                              } catch (e) {
                                _showSnack('Gagal memilih gambar: $e', isError: true);
                              }
                            },
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: _SC.surface,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: proofFile != null
                                      ? _SC.accent.withOpacity(0.5)
                                      : _SC.border2,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 36, height: 36,
                                    decoration: BoxDecoration(
                                      color: _SC.accent.withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(
                                      proofFile != null ? Icons.check_rounded : Icons.upload_file,
                                      color: _SC.accent, size: 18,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      proofFile != null
                                          ? 'Bukti terpilih (tap untuk ganti)'
                                          : 'Upload Bukti Pembayaran',
                                      style: TextStyle(
                                        color: proofFile != null ? _SC.text : _SC.textSub,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 11,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            width: double.infinity,
                            height: 46,
                            child: ElevatedButton(
                              onPressed: submitting
                                  ? null
                                  : () async {
                                      if (selectedNominal == null) {
                                        _showSnack('Pilih nominal dulu', isError: true);
                                        return;
                                      }
                                      if (proofBase64 == null || proofBase64!.length < 100) {
                                        _showSnack('Upload bukti dulu', isError: true);
                                        return;
                                      }
                                      setDialogState(() => submitting = true);
                                      final ok = await _submitTopupRequest(
                                        selectedNominal!,
                                        proofBase64!,
                                      );
                                      setDialogState(() => submitting = false);
                                      if (ok) {
                                        Navigator.pop(ctx, true);
                                      }
                                    },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _SC.accent,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12)),
                                elevation: 0,
                              ),
                              child: submitting
                                  ? const SizedBox(
                                      width: 18, height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                      ),
                                    )
                                  : const Text('BAYAR & KIRIM',
                                      style: TextStyle(
                                        fontFamily: 'MADEEvolveSansEVO',
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 2,
                                      )),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<bool> _submitTopupRequest(int nominal, String proofBase64) async {
    try {
      final res = await http
          .post(
            Uri.parse("$_baseUrl/store/topupRequest"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'nominal': nominal,
              'proofBase64': proofBase64,
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (res.statusCode != 200) {
        _showSnack('Server error (${res.statusCode})', isError: true);
        return false;
      }

      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showSnack('Top up request terkirim! Tunggu owner approve.');
        await _fetchSaldo();
        return true;
      } else {
        _showSnack(data['message'] ?? 'Gagal top up', isError: true);
        return false;
      }
    } catch (e) {
      _showSnack('Connection error: $e', isError: true);
      return false;
    }
  }

  // ── Panel approved popup ──
  void _showPanelApprovedPopup(Map<String, dynamic> order) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: _SC.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _SC.success.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _SC.success.withOpacity(0.4)),
              ),
              child: const Icon(Icons.check_circle, color: _SC.success, size: 20),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Text('PANEL DIAPPROVE!',
                  style: TextStyle(
                    color: _SC.text,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  )),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${order['panelName']} • ${_formatRupiah((order['price'] ?? 0) as num)}',
                style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 11)),
            const SizedBox(height: 12),
            if (order['panelData'] != null) ...[
              const Text('CREDENTIALS:',
                  style: TextStyle(
                    color: _SC.textSub,
                    fontFamily: 'ShareTechMono',
                    fontSize: 10,
                    letterSpacing: 1,
                  )),
              const SizedBox(height: 6),
              _credRow('Username', order['panelData']['username']?.toString() ?? '-'),
              const SizedBox(height: 4),
              _credRow('Password', order['panelData']['password']?.toString() ?? '-'),
              const SizedBox(height: 4),
              _credRow('Login URL', order['panelData']['login']?.toString() ?? '-'),
            ],
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            style: ElevatedButton.styleFrom(
              backgroundColor: _SC.accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('OK',
                style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
          ),
        ],
      ),
    );
  }

  Widget _credRow(String label, String value) {
    return Row(
      children: [
        SizedBox(
          width: 80,
          child: Text('$label:',
              style: const TextStyle(color: _SC.textSub, fontFamily: 'ShareTechMono', fontSize: 11)),
        ),
        Expanded(
          child: SelectableText(value,
              style: const TextStyle(color: _SC.text, fontFamily: 'ShareTechMono', fontSize: 11)),
        ),
      ],
    );
  }
}

