// store_page.dart — Toko Mbud (Store Page)
//
// Alur:
// 1. Dua tab: PANEL & NOMOR
// 2. PANEL → grid panel produk → pilih → bayar QRIS → upload bukti → submit
//    → status pending approval (polling /store/myOrders). Kalau approved,
//    popup premium nunjukin login credentials panel.
// 3. NOMOR → list service RumahOTP → tap → pilih negara → order → dapat
//    nomer + order ID → auto-poll OTP status.
// 4. History order di bawah (gabungan panel + nokos).

// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

// ── COLOR SCHEME (Dark + Red accent — matches app theme) ──────────────────
class _SC {
  static const bg        = Color(0xFF000000);
  static const bg2        = Color(0xFF0a0a0a);
  static const surface    = Color(0xFF111111);
  static const card      = Color(0xFF111111);
  static const cardHigh  = Color(0xFF222222);
  static const accent    = Color(0xFFFF3B30);
  static const accent2   = Color(0xFFFF6B6B);
  static const accentDim = Color(0x1AFF3B30);
  static const text      = Color(0xFFE5E7EB);
  static const textSub   = Color(0xFF9CA3AF);
  static const muted     = Color(0x99E5E7EB);
  static const muted2    = Color(0x55E5E7EB);
  static const border    = Color(0x1AFFFFFF);
  static const border2   = Color(0x0FFFFFFF);
  static const danger    = Color(0xFFFF3B30);
  static const success   = Color(0xFF22C55E);
  static const warning   = Color(0xFFFBBF24);
}

class StorePage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const StorePage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<StorePage> createState() => _StorePageState();
}

class _StorePageState extends State<StorePage>
    with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  static const String _baseUrl = "https://omhc-host-premium.yakuza.biz.id";

  // ── Tab controller ──
  late TabController _tabController;

  // ── Panel products (mirror of API) ──
  List<Map<String, dynamic>> _panels = [];
  bool _loadingPanels = false;

  // ── Nokos services + countries ──
  List<dynamic> _nokosServices = [];
  bool _loadingServices = false;
  Map<String, List<dynamic>> _cachedCountries = {}; // by serviceId

  // ── My orders (panel + nokos combined) ──
  List<Map<String, dynamic>> _myOrders = [];
  bool _loadingOrders = false;
  Timer? _pollTimer;
  // Track which approved panel orders we've already shown popup for
  final Set<String> _shownApproved = {};

  // ── Active nokos order (for OTP polling) ──
  Map<String, dynamic>? _activeNokos;
  Timer? _otpPollTimer;
  // ValueNotifiers so the result dialog auto-updates on OTP arrival
  final ValueNotifier<String> _otpStatusNotifier = ValueNotifier<String>('Menunggu OTP...');
  final ValueNotifier<String?> _otpCodeNotifier = ValueNotifier<String?>(null);

  // ── Submit states ──
  bool _isSubmittingPanel = false;
  bool _isOrderingNokos = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _initBgVideo();
    _fetchPanels();
    _fetchNokosServices();
    _fetchMyOrders(initial: true);
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _otpPollTimer?.cancel();
    _tabController.dispose();
    _bgVideoController.dispose();
    _otpStatusNotifier.dispose();
    _otpCodeNotifier.dispose();
    super.dispose();
  }

  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ── API calls ────────────────────────────────────────────────────────────

  Future<void> _fetchPanels() async {
    setState(() => _loadingPanels = true);
    try {
      final res = await http
          .get(Uri.parse("$_baseUrl/store/panels?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['panels'] is List) {
          setState(() {
            _panels = List<Map<String, dynamic>>.from(
                (data['panels'] as List).map((e) => Map<String, dynamic>.from(e)));
          });
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingPanels = false);
  }

  Future<void> _fetchNokosServices() async {
    setState(() => _loadingServices = true);
    try {
      final res = await http
          .get(Uri.parse("$_baseUrl/store/nokos/services?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          // API may return {data: [...]} or [...]
          final svc = data['services'];
          List list;
          if (svc is List) {
            list = svc;
          } else if (svc is Map && svc['data'] is List) {
            list = svc['data'] as List;
          } else if (svc is Map && svc['services'] is List) {
            list = svc['services'] as List;
          } else {
            list = [];
          }
          setState(() => _nokosServices = list);
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingServices = false);
  }

  Future<List<dynamic>> _fetchCountries(String serviceId) async {
    if (_cachedCountries.containsKey(serviceId)) {
      return _cachedCountries[serviceId]!;
    }
    try {
      final res = await http
          .get(Uri.parse("$_baseUrl/store/nokos/countries?key=${widget.sessionKey}&serviceId=${Uri.encodeComponent(serviceId)}"))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final c = data['countries'];
          List list;
          if (c is List) {
            list = c;
          } else if (c is Map && c['data'] is List) {
            list = c['data'] as List;
          } else {
            list = [];
          }
          _cachedCountries[serviceId] = list;
          return list;
        }
      }
    } catch (_) {}
    return [];
  }

  Future<void> _fetchMyOrders({bool initial = false}) async {
    setState(() => _loadingOrders = true);
    try {
      final res = await http
          .get(Uri.parse("$_baseUrl/store/myOrders?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['orders'] is List) {
          final orders = List<Map<String, dynamic>>.from(
              (data['orders'] as List).map((e) => Map<String, dynamic>.from(e)));
          orders.sort((a, b) {
            final ta = a['createdAt'] ?? '';
            final tb = b['createdAt'] ?? '';
            return tb.compareTo(ta);
          });
          setState(() => _myOrders = orders);

          // Check for newly approved panel orders → show popup
          for (final o in orders) {
            if (o['type'] == 'panel' &&
                o['status'] == 'approved' &&
                !_shownApproved.contains(o['id'])) {
              _shownApproved.add(o['id']);
              if (!initial) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  _showPanelApprovedPopup(o);
                });
              }
            }
          }

          // Start polling if any panel order is still pending
          final hasPending = orders.any((o) =>
              o['type'] == 'panel' && o['status'] == 'pending');
          if (hasPending) {
            _startPolling();
          } else {
            _pollTimer?.cancel();
          }
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingOrders = false);
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) _fetchMyOrders();
    });
  }

  Future<void> _pickProofAndSubmitPanel(Map<String, dynamic> panel) async {
    File? proofFile;
    String? proofBase64;

    // Show dialog: QRIS + upload + submit
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogCtx) {
        return StatefulBuilder(
          builder: (ctx, setDialogState) {
            return Dialog(
              backgroundColor: Colors.transparent,
              insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Container(
                constraints: const BoxConstraints(maxHeight: 600),
                decoration: BoxDecoration(
                  color: _SC.card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _SC.accentDim, width: 1.5),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Header
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [_SC.accent.withOpacity(0.18), Colors.transparent],
                        ),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 36, height: 36,
                            decoration: BoxDecoration(
                              color: _SC.accent.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _SC.accent.withOpacity(0.4)),
                            ),
                            child: const Icon(FontAwesomeIcons.server, color: _SC.accent, size: 16),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(panel['name'] ?? 'Panel',
                                    style: const TextStyle(
                                      color: _SC.text,
                                      fontFamily: 'MADEEvolveSansEVO',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    )),
                                Text(_formatRupiah((panel['price'] ?? 0) as num),
                                    style: const TextStyle(
                                      color: _SC.accent,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 11,
                                    )),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, color: _SC.textSub, size: 18),
                            onPressed: () => Navigator.pop(ctx),
                          ),
                        ],
                      ),
                    ),
                    // Body
                    Flexible(
                      child: ListView(
                        shrinkWrap: true,
                        padding: const EdgeInsets.all(16),
                        children: [
                          // QRIS
                          Center(
                            child: Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _SC.text,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  'assets/images/qris.jpg',
                                  width: 200, height: 200, fit: BoxFit.cover,
                                  errorBuilder: (c, e, _) => Container(
                                    width: 200, height: 200,
                                    color: _SC.text,
                                    child: Icon(Icons.broken_image, color: _SC.muted2, size: 40),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                            decoration: BoxDecoration(
                              color: _SC.surface,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _SC.border2),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.info_outline_rounded,
                                    color: _SC.accent.withOpacity(0.7), size: 14),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    'Bayar ${_formatRupiah((panel['price'] ?? 0) as num)} via QRIS, lalu upload screenshot bukti pembayaran di bawah.',
                                    style: const TextStyle(
                                      color: _SC.muted,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 10,
                                      height: 1.5,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          // Proof picker
                          GestureDetector(
                            onTap: () async {
                              try {
                                final picker = ImagePicker();
                                final xfile = await picker.pickImage(
                                  source: ImageSource.gallery,
                                  imageQuality: 70,
                                  maxWidth: 1280,
                                );
                                if (xfile == null) return;
                                final bytes = await xfile.readAsBytes();
                                final b64 = base64Encode(bytes);
                                final mime = xfile.mimeType ?? 'image/jpeg';
                                proofFile = File(xfile.path);
                                proofBase64 = 'data:$mime;base64,$b64';
                                setDialogState(() {});
                              } catch (e) {
                                _showSnack('Gagal memilih gambar: $e', isError: true);
                              }
                            },
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: _SC.surface,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: proofFile != null
                                      ? _SC.accent.withOpacity(0.5)
                                      : _SC.border2,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 36, height: 36,
                                    decoration: BoxDecoration(
                                      color: _SC.accent.withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(
                                      proofFile != null ? Icons.check_rounded : Icons.upload_file,
                                      color: _SC.accent, size: 18,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      proofFile != null
                                          ? 'Bukti terpilih (tap untuk ganti)'
                                          : 'Upload Bukti Pembayaran',
                                      style: TextStyle(
                                        color: proofFile != null ? _SC.text : _SC.textSub,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 11,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          // Submit button
                          SizedBox(
                            width: double.infinity,
                            height: 46,
                            child: ElevatedButton(
                              onPressed: _isSubmittingPanel
                                  ? null
                                  : () async {
                                      if (proofBase64 == null ||
                                          proofBase64!.length < 100) {
                                        _showSnack('Upload bukti dulu',
                                            isError: true);
                                        return;
                                      }
                                      setDialogState(() => _isSubmittingPanel = true);
                                      final ok = await _submitPanelOrder(
                                          panel['id'], proofBase64!);
                                      setDialogState(() => _isSubmittingPanel = false);
                                      if (ok) {
                                        Navigator.pop(ctx, true);
                                      }
                                    },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _SC.accent,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12)),
                                elevation: 0,
                              ),
                              child: _isSubmittingPanel
                                  ? const SizedBox(
                                      width: 18, height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(Colors.white),
                                      ),
                                    )
                                  : const Text('BAYAR & KIRIM',
                                      style: TextStyle(
                                        fontFamily: 'MADEEvolveSansEVO',
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 2,
                                      )),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<bool> _submitPanelOrder(String panelId, String proofBase64) async {
    try {
      final res = await http
          .post(
            Uri.parse("$_baseUrl/store/orderPanel"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'panelId': panelId,
              'paymentProof': proofBase64,
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (res.statusCode != 200) {
        _showSnack('Server error (${res.statusCode})', isError: true);
        return false;
      }

      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showSnack('Order terkirim! Tunggu owner approve.');
        await _fetchMyOrders();
        return true;
      } else {
        _showSnack(data['message'] ?? 'Gagal order panel', isError: true);
        return false;
      }
    } catch (e) {
      _showSnack('Connection error: $e', isError: true);
      return false;
    }
  }

  // ── Nokos flow: pick service → pick country → order ──
  Future<void> _openNokosFlow(Map<String, dynamic> service) async {
    final serviceId = (service['id'] ?? service['service_id'] ?? '').toString();
    final serviceName = (service['name'] ?? service['service'] ?? 'Service').toString();
    final servicePrice = service['price'] ?? service['base_price'] ?? 800;

    // Load countries
    List<dynamic> countries = [];
    bool loadingCountries = true;
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (sCtx, setDialogState) {
            if (loadingCountries) {
              loadingCountries = false;
              _fetchCountries(serviceId).then((list) {
                setDialogState(() {});
              });
            }
            return Dialog(
              backgroundColor: Colors.transparent,
              insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Container(
                constraints: const BoxConstraints(maxHeight: 540),
                decoration: BoxDecoration(
                  color: _SC.card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _SC.accentDim, width: 1.5),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Header
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [_SC.accent.withOpacity(0.18), Colors.transparent],
                        ),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 36, height: 36,
                            decoration: BoxDecoration(
                              color: _SC.accent.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _SC.accent.withOpacity(0.4)),
                            ),
                            child: const Icon(FontAwesomeIcons.mobileScreen,
                                color: _SC.accent, size: 16),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(serviceName,
                                    style: const TextStyle(
                                      color: _SC.text,
                                      fontFamily: 'MADEEvolveSansEVO',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    )),
                                Text('Pilih Negara',
                                    style: const TextStyle(
                                      color: _SC.textSub,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 10,
                                    )),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, color: _SC.textSub, size: 18),
                            onPressed: () => Navigator.pop(ctx),
                          ),
                        ],
                      ),
                    ),
                    // Body
                    Flexible(
                      child: countries.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const CircularProgressIndicator(
                                    color: _SC.accent,
                                    strokeWidth: 2,
                                  ),
                                  const SizedBox(height: 12),
                                  Text('Memuat negara...',
                                      style: TextStyle(
                                        color: _SC.muted,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 11,
                                      )),
                                ],
                              ),
                            )
                          : ListView.separated(
                              shrinkWrap: true,
                              padding: const EdgeInsets.all(12),
                              itemCount: countries.length,
                              separatorBuilder: (_, __) => const SizedBox(height: 8),
                              itemBuilder: (_, i) {
                                final c = countries[i] as Map;
                                final cId = (c['id'] ?? c['country_id'] ?? '').toString();
                                final cName = (c['name'] ?? c['country'] ?? cId).toString();
                                final cPrice = c['price'] ?? servicePrice;
                                return _countryRow(
                                  cName,
                                  _formatRupiah((cPrice is num ? cPrice : 800) as num),
                                  _SC.accent,
                                  () async {
                                    Navigator.pop(ctx);
                                    await _orderNokos(
                                      serviceId: serviceId,
                                      serviceName: serviceName,
                                      country: cId,
                                      countryName: cName,
                                      price: (cPrice is num ? cPrice : 800).toInt(),
                                    );
                                  },
                                );
                              },
                            ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _orderNokos({
    required String serviceId,
    required String serviceName,
    required String country,
    required String countryName,
    required int price,
  }) async {
    if (_isOrderingNokos) return;
    setState(() => _isOrderingNokos = true);

    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Dialog(
        backgroundColor: Colors.transparent,
        child: Center(
          child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2),
        ),
      ),
    );

    try {
      final res = await http
          .post(
            Uri.parse("$_baseUrl/store/orderNokos"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'serviceId': serviceId,
              'country': country,
              'operatorId': 'any',
              'price': price,
            }),
          )
          .timeout(const Duration(seconds: 20));

      Navigator.pop(context); // close loading

      if (res.statusCode != 200) {
        _showSnack('Server error (${res.statusCode})', isError: true);
        return;
      }

      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final order = data['order'] as Map<String, dynamic>?;
        final paid = data['price'] ?? price;
        setState(() {
          _activeNokos = {
            'phone': order?['phone_number'] ?? '-',
            'orderId': order?['order_id']?.toString() ?? '-',
            'service': serviceName,
            'country': countryName,
            'price': paid,
          };
        });
        _otpStatusNotifier.value = 'Menunggu OTP...';
        _otpCodeNotifier.value = null;
        _showSnack('Nomor berhasil dipesan!');
        await _fetchMyOrders();
        _startOtpPolling();
        _showNokosResultDialog();
      } else {
        _showSnack(data['message'] ?? 'Gagal order nomor', isError: true);
      }
    } catch (e) {
      Navigator.pop(context); // close loading
      _showSnack('Connection error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isOrderingNokos = false);
    }
  }

  void _startOtpPolling() {
    _otpPollTimer?.cancel();
    final orderId = _activeNokos?['orderId']?.toString();
    if (orderId == null || orderId == '-') return;
    _otpPollTimer = Timer.periodic(const Duration(seconds: 4), (_) async {
      if (!mounted) {
        _otpPollTimer?.cancel();
        return;
      }
      try {
        final res = await http
            .get(Uri.parse(
              "$_baseUrl/store/nokos/status?key=${widget.sessionKey}&orderId=${Uri.encodeComponent(orderId)}",
            ))
            .timeout(const Duration(seconds: 10));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['valid'] == true) {
            final st = data['status'];
            // Try multiple response shapes
            String statusText = '';
            String? otp;
            if (st is Map) {
              statusText = (st['status'] ?? st['message'] ?? '').toString();
              otp = st['otp']?.toString() ?? st['code']?.toString();
            } else if (st is String) {
              statusText = st;
            }
            if (otp != null && otp.isNotEmpty && otp != 'null') {
              _otpCodeNotifier.value = otp;
              _otpStatusNotifier.value = 'OTP diterima!';
              _otpPollTimer?.cancel();
              // Also refresh UI for the "Nomor Aktif" card
              if (mounted) setState(() {});
            } else {
              _otpStatusNotifier.value = statusText.isEmpty
                  ? 'Menunggu OTP...'
                  : 'Status: $statusText';
              if (mounted) setState(() {});
            }
          }
        }
      } catch (_) {}
    });
  }

  void _showNokosResultDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _NokosResultDialog(
        active: _activeNokos!,
        statusNotifier: _otpStatusNotifier,
        otpNotifier: _otpCodeNotifier,
        onClose: () {
          Navigator.pop(context);
          _otpPollTimer?.cancel();
        },
      ),
    );
  }

  // ── Premium popup when panel approved ──
  void _showPanelApprovedPopup(Map<String, dynamic> order) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _PanelApprovedDialog(
        order: order,
        onDismiss: () => Navigator.of(context).pop(),
      ),
    );
  }

  // ── Helpers ──
  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(
              color: _SC.text, fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor:
          isError ? _SC.danger.withOpacity(0.92) : _SC.success.withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  String _formatRupiah(num n) {
    final s = n.toInt().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp $buf';
  }

  String _fmtDate(String? iso) {
    if (iso == null || iso.isEmpty) return '-';
    try {
      final dt = DateTime.parse(iso).toLocal();
      return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }

  Color _statusColor(String? status) {
    switch (status) {
      case 'approved':
      case 'active':
        return _SC.success;
      case 'pending':
      case 'waiting':
        return _SC.warning;
      case 'rejected':
      case 'expired':
      case 'failed':
        return _SC.danger;
      default:
        return _SC.textSub;
    }
  }

  String _statusLabel(String? status) {
    switch (status) {
      case 'approved':
        return 'APPROVED';
      case 'pending':
        return 'PENDING';
      case 'active':
        return 'ACTIVE';
      case 'rejected':
        return 'REJECTED';
      case 'expired':
        return 'EXPIRED';
      case 'failed':
        return 'FAILED';
      case 'waiting':
        return 'WAITING';
      default:
        return (status ?? 'UNKNOWN').toUpperCase();
    }
  }

  // ── BUILD ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Video BG
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.68)),
        Scaffold(
          backgroundColor: Colors.transparent,
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _SC.card.withOpacity(0.5),
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new,
                    color: _SC.accent, size: 18),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(FontAwesomeIcons.store, color: _SC.accent, size: 16),
                const SizedBox(width: 8),
                Text("TOKO MBUD",
                    style: TextStyle(
                        color: _SC.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        fontSize: 15)),
              ],
            ),
            centerTitle: true,
            flexibleSpace: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(color: _SC.bg.withOpacity(0.4)),
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(56),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: _SC.card.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _SC.border2),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_SC.accent, _SC.accent2],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  dividerColor: Colors.transparent,
                  indicatorSize: TabBarIndicatorSize.tab,
                  labelColor: Colors.white,
                  unselectedLabelColor: _SC.textSub,
                  labelStyle: const TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                  unselectedLabelStyle: const TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    letterSpacing: 1,
                  ),
                  tabs: const [
                    Tab(text: 'PANEL'),
                    Tab(text: 'NOMOR'),
                  ],
                ),
              ),
            ),
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.4,
                colors: [
                  _SC.accent.withOpacity(0.08),
                  _SC.bg.withOpacity(0.0),
                ],
              ),
            ),
            child: SafeArea(
              child: TabBarView(
                controller: _tabController,
                children: [
                  // ── PANEL tab ──
                  RefreshIndicator(
                    color: _SC.accent,
                    onRefresh: () => _fetchPanels(),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 32),
                      children: [
                        _buildPanelHero(),
                        const SizedBox(height: 18),
                        _buildPanelGrid(),
                        const SizedBox(height: 24),
                        _buildOrdersSection(filterType: 'panel'),
                        const SizedBox(height: 32),
                      ],
                    ),
                  ),
                  // ── NOMOR tab ──
                  RefreshIndicator(
                    color: _SC.accent,
                    onRefresh: () => _fetchNokosServices(),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 32),
                      children: [
                        _buildNokosHero(),
                        const SizedBox(height: 18),
                        if (_activeNokos != null) ...[
                          _buildActiveNokosCard(),
                          const SizedBox(height: 18),
                        ],
                        _buildNokosServicesList(),
                        const SizedBox(height: 24),
                        _buildOrdersSection(filterType: 'nokos'),
                        const SizedBox(height: 32),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Hero: PANEL ──
  Widget _buildPanelHero() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_SC.accent.withOpacity(0.18), _SC.card],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _SC.accent.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: _SC.accent.withOpacity(0.12), blurRadius: 24)],
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [_SC.accent, _SC.accent2]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(FontAwesomeIcons.server,
                color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('PANEL PTERODACTYL',
                    style: TextStyle(
                      color: _SC.text,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    )),
                const SizedBox(height: 4),
                Text('Panel premium, manual approval oleh owner',
                    style: TextStyle(
                      color: _SC.textSub,
                      fontFamily: 'ShareTechMono',
                      fontSize: 10,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Hero: NOMOR ──
  Widget _buildNokosHero() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_SC.accent.withOpacity(0.18), _SC.card],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _SC.accent.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: _SC.accent.withOpacity(0.12), blurRadius: 24)],
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [_SC.accent, _SC.accent2]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(FontAwesomeIcons.mobileScreenButton,
                color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('NOMOR VIRTUAL (OTP)',
                    style: TextStyle(
                      color: _SC.text,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    )),
                const SizedBox(height: 4),
                Text('Otomatis via RumahOTP, langsung dapat nomer',
                    style: TextStyle(
                      color: _SC.textSub,
                      fontFamily: 'ShareTechMono',
                      fontSize: 10,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Panel grid ──
  Widget _buildPanelGrid() {
    if (_loadingPanels && _panels.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(40),
        child: const Center(
          child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2),
        ),
      );
    }
    if (_panels.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          color: _SC.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _SC.border2),
        ),
        child: Column(
          children: [
            Icon(Icons.cloud_off_rounded, color: _SC.muted2, size: 32),
            const SizedBox(height: 12),
            Text('Gak ada panel tersedia',
                style: TextStyle(
                  color: _SC.textSub,
                  fontFamily: 'ShareTechMono',
                  fontSize: 11,
                )),
          ],
        ),
      );
    }
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _panels.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.88,
      ),
      itemBuilder: (ctx, i) {
        final p = _panels[i];
        final isUnlimited = (p['ram'] ?? 0) == 0;
        return GestureDetector(
          onTap: () => _pickProofAndSubmitPanel(p),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isUnlimited
                    ? [_SC.accent.withOpacity(0.18), _SC.card]
                    : [_SC.card, _SC.surface],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: isUnlimited
                    ? _SC.accent.withOpacity(0.5)
                    : _SC.border2,
                width: isUnlimited ? 1.5 : 1,
              ),
              boxShadow: isUnlimited
                  ? [BoxShadow(color: _SC.accent.withOpacity(0.18), blurRadius: 16)]
                  : null,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 28, height: 28,
                      decoration: BoxDecoration(
                        color: _SC.accent.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _SC.accent.withOpacity(0.4)),
                      ),
                      child: Icon(
                        isUnlimited ? FontAwesomeIcons.infinity : FontAwesomeIcons.server,
                        color: _SC.accent, size: 12,
                      ),
                    ),
                    const Spacer(),
                    if (isUnlimited)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: _SC.accent,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: const Text('HOT',
                            style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'MADEEvolveSansEVO',
                              fontSize: 8,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            )),
                      ),
                  ],
                ),
                const Spacer(),
                Text(p['name'] ?? 'Panel',
                    style: const TextStyle(
                      color: _SC.text,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    )),
                const SizedBox(height: 4),
                Text(p['desc'] ?? '',
                    style: const TextStyle(
                      color: _SC.textSub,
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                      height: 1.4,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
                const Spacer(),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 7),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [_SC.accent, _SC.accent2]),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _formatRupiah((p['price'] ?? 0) as num),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ── Active nokos card (live OTP status) ──
  Widget _buildActiveNokosCard() {
    final a = _activeNokos!;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_SC.accent.withOpacity(0.22), _SC.card],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _SC.accent.withOpacity(0.5), width: 1.5),
        boxShadow: [BoxShadow(color: _SC.accent.withOpacity(0.18), blurRadius: 20)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30, height: 30,
                decoration: BoxDecoration(
                  color: _SC.accent.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _SC.accent.withOpacity(0.4)),
                ),
                child: const Icon(Icons.phone_iphone_rounded,
                    color: _SC.accent, size: 14),
              ),
              const SizedBox(width: 10),
              const Text('NOMOR AKTIF',
                  style: TextStyle(
                    color: _SC.accent,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  )),
              const Spacer(),
              const SizedBox(
                width: 14, height: 14,
                child: CircularProgressIndicator(
                  color: _SC.accent, strokeWidth: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _infoRow('No. Telepon', a['phone'] ?? '-', valueColor: _SC.accent),
          const SizedBox(height: 8),
          _infoRow('Order ID', a['orderId'] ?? '-'),
          const SizedBox(height: 8),
          _infoRow('Service', a['service'] ?? '-'),
          const SizedBox(height: 8),
          _infoRow('Negara', a['country'] ?? '-'),
          const SizedBox(height: 8),
          _infoRow('Harga', _formatRupiah((a['price'] ?? 0) as num)),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              color: _SC.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: _otpCodeNotifier.value != null
                    ? _SC.success.withOpacity(0.5)
                    : _SC.border2,
              ),
            ),
            child: ValueListenableBuilder<String?> (
              valueListenable: _otpCodeNotifier,
              builder: (ctx, otpCode, _) {
                return Row(
                  children: [
                    Icon(
                      otpCode != null
                          ? Icons.check_circle_rounded
                          : Icons.hourglass_top_rounded,
                      color: otpCode != null ? _SC.success : _SC.warning,
                      size: 16,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ValueListenableBuilder<String>(
                            valueListenable: _otpStatusNotifier,
                            builder: (sCtx, statusText, _) {
                              return Text(otpCode != null ? 'OTP DITERIMA' : statusText,
                                  style: TextStyle(
                                    color: otpCode != null ? _SC.success : _SC.warning,
                                    fontFamily: 'MADEEvolveSansEVO',
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ));
                            },
                          ),
                          if (otpCode != null) ...[
                            const SizedBox(height: 4),
                            GestureDetector(
                              onTap: () {
                                Clipboard.setData(ClipboardData(text: otpCode));
                                _showSnack('OTP disalin!');
                              },
                              child: Text(otpCode,
                                  style: const TextStyle(
                                    color: _SC.text,
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  )),
                            ),
                          ],
                        ],
                      ),
                    ),
                    if (otpCode != null)
                      IconButton(
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: otpCode));
                          _showSnack('OTP disalin!');
                        },
                        icon: const Icon(Icons.copy_rounded, color: _SC.accent, size: 16),
                        visualDensity: VisualDensity.compact,
                      ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value, {Color? valueColor}) {
    return Row(
      children: [
        SizedBox(
          width: 90,
          child: Text('[$label]',
              style: const TextStyle(
                color: _SC.muted,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
              )),
        ),
        Expanded(
          child: Text(value,
              style: TextStyle(
                color: valueColor ?? _SC.text,
                fontFamily: 'ShareTechMono',
                fontSize: 11,
              )),
        ),
      ],
    );
  }

  // ── Nokos services list ──
  Widget _buildNokosServicesList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(width: 3, height: 16, color: _SC.accent),
            const SizedBox(width: 8),
            Text('PILIH SERVICE',
                style: TextStyle(
                  color: _SC.accent,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
          ],
        ),
        const SizedBox(height: 12),
        if (_loadingServices && _nokosServices.isEmpty)
          Container(
            padding: const EdgeInsets.all(40),
            decoration: BoxDecoration(
              color: _SC.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _SC.border2),
            ),
            child: const Center(
              child: CircularProgressIndicator(color: _SC.accent, strokeWidth: 2),
            ),
          )
        else if (_nokosServices.isEmpty)
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: _SC.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _SC.border2),
            ),
            child: Column(
              children: [
                Icon(Icons.cloud_off_rounded, color: _SC.muted2, size: 32),
                const SizedBox(height: 12),
                Text('Service nomor virtual tidak tersedia',
                    style: TextStyle(
                      color: _SC.textSub,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                    )),
                const SizedBox(height: 8),
                Text('Coba refresh / hubungi admin',
                    style: TextStyle(
                      color: _SC.muted2,
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                    )),
              ],
            ),
          )
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _nokosServices.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (ctx, i) {
              final svc = _nokosServices[i] as Map;
              final name = (svc['name'] ?? svc['service'] ?? svc['service_name'] ?? 'Service').toString();
              final desc = (svc['description'] ?? svc['desc'] ?? '').toString();
              final price = svc['price'] ?? svc['base_price'] ?? 800;
              final icon = _serviceIcon(name);
              return GestureDetector(
                onTap: _isOrderingNokos
                    ? null
                    : () => _openNokosFlow(Map<String, dynamic>.from(svc)),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _SC.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _SC.border2),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 40, height: 40,
                        decoration: BoxDecoration(
                          color: _SC.accent.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _SC.accent.withOpacity(0.3)),
                        ),
                        child: Icon(icon, color: _SC.accent, size: 16),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(name,
                                style: const TextStyle(
                                  color: _SC.text,
                                  fontFamily: 'MADEEvolveSansEVO',
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                )),
                            if (desc.isNotEmpty) ...[
                              const SizedBox(height: 2),
                              Text(desc,
                                  style: const TextStyle(
                                    color: _SC.textSub,
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 9,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis),
                            ],
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: _SC.accent,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          _formatRupiah((price is num ? price : 800) as num),
                          style: const TextStyle(
                            color: Colors.white,
                            fontFamily: 'ShareTechMono',
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Icon(Icons.chevron_right_rounded,
                          color: _SC.textSub, size: 20),
                    ],
                  ),
                ),
              );
            },
          ),
      ],
    );
  }

  IconData _serviceIcon(String name) {
    final n = name.toLowerCase();
    if (n.contains('wa') || n.contains('whats')) return FontAwesomeIcons.whatsapp;
    if (n.contains('tele')) return FontAwesomeIcons.telegram;
    if (n.contains('google') || n.contains('gmail')) return FontAwesomeIcons.google;
    if (n.contains('insta')) return FontAwesomeIcons.instagram;
    if (n.contains('face')) return FontAwesomeIcons.facebook;
    if (n.contains('discord')) return FontAwesomeIcons.discord;
    if (n.contains('tiktok')) return FontAwesomeIcons.tiktok;
    if (n.contains('twit')) return FontAwesomeIcons.twitter;
    if (n.contains('gmail')) return Icons.mail_outline_rounded;
    return FontAwesomeIcons.mobileScreen;
  }

  Widget _countryRow(String name, String price, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _SC.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _SC.border2),
        ),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(Icons.public_rounded, color: color, size: 14),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(name,
                  style: const TextStyle(
                    color: _SC.text,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  )),
            ),
            Text(price,
                style: const TextStyle(
                  color: _SC.accent,
                  fontFamily: 'ShareTechMono',
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                )),
            const SizedBox(width: 6),
            const Icon(Icons.chevron_right_rounded,
                color: _SC.textSub, size: 20),
          ],
        ),
      ),
    );
  }

  // ── Orders history section ──
  Widget _buildOrdersSection({required String filterType}) {
    final orders = _myOrders.where((o) => o['type'] == filterType).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(width: 3, height: 16, color: _SC.accent),
            const SizedBox(width: 8),
            Text(filterType == 'panel' ? 'ORDER PANEL' : 'ORDER NOMOR',
                style: TextStyle(
                  color: _SC.accent,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
            const Spacer(),
            if (_loadingOrders)
              const SizedBox(
                width: 12, height: 12,
                child: CircularProgressIndicator(
                  color: _SC.accent, strokeWidth: 1.5,
                ),
              ),
            IconButton(
              onPressed: () => _fetchMyOrders(),
              icon: const Icon(Icons.refresh_rounded, color: _SC.textSub, size: 16),
              visualDensity: VisualDensity.compact,
              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
              padding: EdgeInsets.zero,
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (orders.isEmpty)
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _SC.card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _SC.border2),
            ),
            child: Center(
              child: Text(
                filterType == 'panel'
                    ? 'Belum ada order panel'
                    : 'Belum ada order nomor',
                style: TextStyle(
                  color: _SC.textSub,
                  fontFamily: 'ShareTechMono',
                  fontSize: 11,
                ),
              ),
            ),
          )
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: orders.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (ctx, i) {
              final o = orders[i];
              if (filterType == 'panel') {
                return _buildPanelOrderCard(o);
              } else {
                return _buildNokosOrderCard(o);
              }
            },
          ),
      ],
    );
  }

  Widget _buildPanelOrderCard(Map<String, dynamic> o) {
    final status = o['status']?.toString();
    final sColor = _statusColor(status);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _SC.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: sColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: sColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: sColor.withOpacity(0.3)),
            ),
            child: Icon(FontAwesomeIcons.server, color: sColor, size: 14),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(o['panelName'] ?? 'Panel',
                    style: const TextStyle(
                      color: _SC.text,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    )),
                const SizedBox(height: 2),
                Text(
                  '${_formatRupiah((o['price'] ?? 0) as num)} · ${_fmtDate(o['createdAt'])}',
                  style: const TextStyle(
                    color: _SC.textSub,
                    fontFamily: 'ShareTechMono',
                    fontSize: 9,
                  ),
                ),
                if (status == 'approved' && o['panelData'] != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    'Login: ${(o['panelData'] as Map)['login'] ?? '-'}',
                    style: const TextStyle(
                      color: _SC.success,
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: sColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: sColor.withOpacity(0.3)),
            ),
            child: Text(
              _statusLabel(status),
              style: TextStyle(
                color: sColor,
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 9,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNokosOrderCard(Map<String, dynamic> o) {
    final status = o['status']?.toString();
    final sColor = _statusColor(status);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _SC.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: sColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: sColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: sColor.withOpacity(0.3)),
            ),
            child: Icon(FontAwesomeIcons.mobileScreen, color: sColor, size: 14),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(o['phoneNumber'] ?? o['service'] ?? 'Nomor',
                    style: const TextStyle(
                      color: _SC.text,
                      fontFamily: 'ShareTechMono',
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    )),
                const SizedBox(height: 2),
                Text(
                  '${_formatRupiah((o['price'] ?? 0) as num)} · ${_fmtDate(o['createdAt'])}',
                  style: const TextStyle(
                    color: _SC.textSub,
                    fontFamily: 'ShareTechMono',
                    fontSize: 9,
                  ),
                ),
                if (o['orderId'] != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    'ID: ${o['orderId']}',
                    style: const TextStyle(
                      color: _SC.muted,
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: sColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: sColor.withOpacity(0.3)),
            ),
            child: Text(
              _statusLabel(status),
              style: TextStyle(
                color: sColor,
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 9,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// ===== PANEL APPROVED DIALOG ================================
// ============================================================
class _PanelApprovedDialog extends StatefulWidget {
  final Map<String, dynamic> order;
  final VoidCallback onDismiss;

  const _PanelApprovedDialog({
    required this.order,
    required this.onDismiss,
  });

  @override
  State<_PanelApprovedDialog> createState() => _PanelApprovedDialogState();
}

class _PanelApprovedDialogState extends State<_PanelApprovedDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _glowController;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    )..forward();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  void _copy(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$label disalin',
          style: const TextStyle(
              color: _SC.text, fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor: _SC.success.withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final pd = widget.order['panelData'] as Map<String, dynamic>? ?? {};
    final username = pd['username'] ?? widget.order['username'] ?? '-';
    final password = pd['password'] ?? '-';
    final login = pd['login'] ?? 'https://omhc.angkasanyabobo.my.id';

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: ScaleTransition(
        scale: Tween<double>(begin: 0.7, end: 1.0).animate(
          CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
        ),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            // Glow ring
            Positioned(
              top: -20,
              child: AnimatedBuilder(
                animation: _glowController,
                builder: (_, __) => Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: _SC.accent.withOpacity(0.4 + _glowController.value * 0.3),
                        blurRadius: 30 + _glowController.value * 20,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // Main card
            Container(
              margin: const EdgeInsets.only(top: 40),
              padding: const EdgeInsets.fromLTRB(22, 36, 22, 22),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [const Color(0xFF222222), const Color(0xFF111111)],
                ),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _SC.accent.withOpacity(0.5), width: 1.5),
                boxShadow: [
                  BoxShadow(color: _SC.accent.withOpacity(0.25), blurRadius: 40),
                  BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 30),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 72, height: 72,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [_SC.accent, _SC.accent2],
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(color: _SC.accent.withOpacity(0.5), blurRadius: 20),
                      ],
                    ),
                    child: const Icon(FontAwesomeIcons.circleCheck,
                        color: Colors.white, size: 32),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'PANEL AKTIF',
                    style: TextStyle(
                      color: _SC.accent,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 3,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(width: 40, height: 2, color: _SC.accent.withOpacity(0.5)),
                  const SizedBox(height: 16),
                  Text(
                    'Panel ${widget.order['panelName'] ?? ''} kamu udah siap! Login pakai kredensial di bawah.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: _SC.muted,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      height: 1.6,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF222222),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _SC.accent.withOpacity(0.2)),
                    ),
                    child: Column(
                      children: [
                        _credRow('Username', username.toString(),
                            onTap: () => _copy(username.toString(), 'Username')),
                        const SizedBox(height: 8),
                        _credRow('Password', password.toString(),
                            onTap: () => _copy(password.toString(), 'Password')),
                        const SizedBox(height: 8),
                        _credRow('Login URL', login.toString(),
                            onTap: () => _copy(login.toString(), 'Login URL')),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton(
                      onPressed: widget.onDismiss,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _SC.accent,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: const Text('LANJUT',
                          style: TextStyle(
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          )),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _credRow(String label, String value, {VoidCallback? onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
        child: Row(
          children: [
            SizedBox(
              width: 80,
              child: Text('[$label]',
                  style: const TextStyle(
                    color: _SC.muted2,
                    fontFamily: 'ShareTechMono',
                    fontSize: 10,
                  )),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(value,
                  style: const TextStyle(
                    color: _SC.text,
                    fontFamily: 'ShareTechMono',
                    fontSize: 11,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ),
            Icon(Icons.copy_rounded, color: _SC.accent.withOpacity(0.7), size: 14),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// ===== NOKOS RESULT DIALOG (live OTP) =======================
// ============================================================
class _NokosResultDialog extends StatefulWidget {
  final Map<String, dynamic> active;
  final ValueNotifier<String> statusNotifier;
  final ValueNotifier<String?> otpNotifier;
  final VoidCallback onClose;

  const _NokosResultDialog({
    required this.active,
    required this.statusNotifier,
    required this.otpNotifier,
    required this.onClose,
  });

  @override
  State<_NokosResultDialog> createState() => _NokosResultDialogState();
}

class _NokosResultDialogState extends State<_NokosResultDialog> {
  @override
  Widget build(BuildContext context) {
    final phone = widget.active['phone'] ?? '-';
    final orderId = widget.active['orderId'] ?? '-';
    final service = widget.active['service'] ?? '-';
    final country = widget.active['country'] ?? '-';
    final price = widget.active['price'] ?? 0;

    return ValueListenableBuilder<String?>(
      valueListenable: widget.otpNotifier,
      builder: (ctx, otp, _) {
        final hasOtp = otp != null && otp.isNotEmpty;
        final statusText = widget.statusNotifier.value;
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 24),
          child: Container(
            padding: const EdgeInsets.fromLTRB(22, 26, 22, 22),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [const Color(0xFF222222), const Color(0xFF111111)],
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: hasOtp ? _SC.success.withOpacity(0.5) : _SC.accent.withOpacity(0.5),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: hasOtp ? _SC.success.withOpacity(0.25) : _SC.accent.withOpacity(0.25),
                  blurRadius: 40,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: hasOtp
                          ? [_SC.success, _SC.success]
                          : [_SC.accent, _SC.accent2],
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    hasOtp ? Icons.check_rounded : Icons.phone_iphone_rounded,
                    color: Colors.white, size: 26,
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  hasOtp ? 'OTP DITERIMA' : 'NOMOR SIAP',
                  style: TextStyle(
                    color: hasOtp ? _SC.success : _SC.accent,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 6),
                Container(width: 40, height: 2,
                    color: hasOtp ? _SC.success.withOpacity(0.5) : _SC.accent.withOpacity(0.5)),
                const SizedBox(height: 16),
                // Phone number (large)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1a1a1a),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: hasOtp
                          ? _SC.success.withOpacity(0.3)
                          : _SC.accent.withOpacity(0.3),
                    ),
                  ),
                  child: Column(
                    children: [
                      const Text('NOMOR TELEPON',
                          style: TextStyle(
                            color: _SC.muted,
                            fontFamily: 'ShareTechMono',
                            fontSize: 9,
                            letterSpacing: 1,
                          )),
                      const SizedBox(height: 4),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(ClipboardData(text: phone));
                          _snack('Nomor disalin!');
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(phone,
                                style: const TextStyle(
                                  color: _SC.text,
                                  fontFamily: 'ShareTechMono',
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                )),
                            const SizedBox(width: 8),
                            Icon(Icons.copy_rounded, color: _SC.accent, size: 14),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                if (hasOtp)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                    decoration: BoxDecoration(
                      color: _SC.success.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _SC.success.withOpacity(0.5)),
                    ),
                    child: Column(
                      children: [
                        const Text('OTP CODE',
                            style: TextStyle(
                              color: _SC.success,
                              fontFamily: 'ShareTechMono',
                              fontSize: 9,
                              letterSpacing: 1,
                            )),
                        const SizedBox(height: 4),
                        GestureDetector(
                          onTap: () {
                            Clipboard.setData(ClipboardData(text: otp));
                            _snack('OTP disalin!');
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(otp,
                                  style: const TextStyle(
                                    color: _SC.success,
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 4,
                                  )),
                              const SizedBox(width: 8),
                              Icon(Icons.copy_rounded, color: _SC.success, size: 16),
                            ],
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                    decoration: BoxDecoration(
                      color: _SC.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _SC.border2),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(
                          width: 14, height: 14,
                          child: CircularProgressIndicator(
                            color: _SC.warning, strokeWidth: 2,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(statusText,
                              style: const TextStyle(
                                color: _SC.warning,
                                fontFamily: 'ShareTechMono',
                                fontSize: 11,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 12),
                // Meta info
                Row(
                  children: [
                    Expanded(
                      child: _metaItem('Service', service.toString()),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _metaItem('Negara', country.toString()),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _metaItem('Order ID', orderId.toString()),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _metaItem('Harga', _formatRupiahLocal((price as num).toInt())),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    if (!hasOtp)
                      Expanded(
                        child: SizedBox(
                          height: 44,
                          child: OutlinedButton(
                            onPressed: widget.onClose,
                            style: OutlinedButton.styleFrom(
                              foregroundColor: _SC.textSub,
                              side: BorderSide(color: _SC.border2),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text('TUTUP',
                                style: TextStyle(
                                  fontFamily: 'MADEEvolveSansEVO',
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                )),
                          ),
                        ),
                      )
                    else
                      Expanded(
                        child: SizedBox(
                          height: 44,
                          child: ElevatedButton(
                            onPressed: widget.onClose,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _SC.success,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              elevation: 0,
                            ),
                            child: const Text('SELESAI',
                                style: TextStyle(
                                  fontFamily: 'MADEEvolveSansEVO',
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                )),
                          ),
                        ),
                      ),
                  ],
                ),
                if (!hasOtp)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      'Dialog ini bisa ditutup, OTP akan tetap muncul di card "Nomor Aktif".',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _SC.muted2,
                        fontFamily: 'ShareTechMono',
                        fontSize: 9,
                        height: 1.5,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _metaItem(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: _SC.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: _SC.border2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('[$label]',
              style: const TextStyle(
                color: _SC.muted,
                fontFamily: 'ShareTechMono',
                fontSize: 8,
              )),
          const SizedBox(height: 2),
          Text(value,
              style: const TextStyle(
                color: _SC.text,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(
              color: _SC.text, fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor: _SC.success.withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  String _formatRupiahLocal(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp $buf';
  }
}
