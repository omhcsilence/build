// vip_upgrade_page.dart — VIP Upgrade Page (Premium Theme)
//
// Alur:
// 1. User lihat daftar paket VIP + keuntungan + QRIS
// 2. User pilih paket → upload bukti transfer → submit
// 3. Polling /myVipRequest tiap 5 detik untuk tau status
// 4. Kalau approved → popup sukses premium (gold gradient)
// 5. Kalau rejected → popup tolak premium (red gradient)

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

// ── COLOR SCHEME (Premium Gold/Purple) ─────────────────────────────────────
class _VC {
  // TRANTOR Color Scheme (light, premium fintech — lavender accents for VIP)
  static const bg        = Color(0xFFFFFFFF);
  static const bg2       = Color(0xFFFAFAFA);
  static const surface   = Color(0xFFF5F5F7);
  static const card      = Color(0xFF0A0A0B);
  static const cardHigh  = Color(0xFF1C1C1E);
  static const gold      = Color(0xFFE8D5FF);
  static const goldDim   = Color(0xFFC7C7CC);
  static const goldDeep  = Color(0xFF8E8E93);
  static const purple    = Color(0xFF7FE7B8);
  static const purple2   = Color(0xFFA8F0D4);
  static const text      = Color(0xFF000000);
  static const textSub   = Color(0xFF8E8E93);
  static const muted     = Color(0xFFAEAEB2);
  static const muted2    = Color(0xFFC7C7CC);
  static const border    = Color(0xFFE5E5EA);
  static const border2   = Color(0xFFD1D1D6);
  static const danger    = Color(0xFFFF3B30);
  static const success   = Color(0xFF34C759);
}

class VipUpgradePage extends StatefulWidget {
  final String username;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const VipUpgradePage({
    super.key,
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<VipUpgradePage> createState() => _VipUpgradePageState();
}

class _VipUpgradePageState extends State<VipUpgradePage>
    with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  static const String _baseUrl = "https://omhc-host-premium.yakuza.biz.id";

  // ── Packages (mirror of API VIP_PACKAGES) ──
  final List<Map<String, dynamic>> _packages = [
    {'id': '1d',      'label': '1 Hari',    'days': 1,  'price': 5000,   'suffix': 'Cocok buat test drive fitur VIP.'},
    {'id': '3d',      'label': '3 Hari',    'days': 3,  'price': 10000,  'suffix': 'Hemat 16% dari harga harian.'},
    {'id': '7d',      'label': '7 Hari',    'days': 7,  'price': 15000,  'suffix': 'Paket mingguan, paling laris.'},
    {'id': '31d',     'label': '31 Hari',   'days': 31, 'price': 55000,  'suffix': 'Bulan full, hemat 65%.'},
    {'id': 'forever', 'label': 'Permanen',  'days': 0,  'price': 100000, 'suffix': 'Selamanya, tanpa khawatir expired.'},
  ];

  String? _selectedPackageId;
  File? _proofFile;
  String? _proofBase64;
  bool _isSubmitting = false;
  bool _isPolling = false;
  Timer? _pollTimer;

  // ── Current VIP request status (latest) ──
  Map<String, dynamic>? _myRequest;
  bool _hasShownResult = false; // biar popup approve/reject gak muncul berkali-kali

  // ── Live role & expiredDate (di-refresh dari /myVipRequest response) ──
  // Pas approve, /myVipRequest return request dengan status "approved".
  // Tapi role sebenarnya di database.json udah jadi "vip". Kita fetch
  // /myInfo buat konfirmasi, simpan di sini, biar hero card langsung
  // nunjukin "KAMU VIP" tanpa harus balik ke dashboard.
  String _currentRole = '';
  String _currentExpired = '';

  // ── Benefits list ──
  final List<Map<String, dynamic>> _benefits = [
    {'icon': FontAwesomeIcons.rocket,     'title': 'Tanpa Perlu Sender',     'desc': 'VIP gak perlu setup nomor sender sendiri — developer udah nyediain sender global otomatis.'},
    {'icon': FontAwesomeIcons.bolt,       'title': 'Cooldown Lebih Singkat', 'desc': 'Cooldown bug 10 detik (vs 70 detik member). Spam lebih lanjut.'},
    {'icon': FontAwesomeIcons.infinity,   'title': 'Bug Premium Unlock',     'desc': 'Akses ke payload bug premium yang lebih kuat dan stabil.'},
    {'icon': FontAwesomeIcons.gaugeHigh,  'title': 'Prioritas Server',       'desc': 'Request kamu diproses lebih duluan di antrian server.'},
    {'icon': FontAwesomeIcons.userShield, 'title': 'Akses Fitur Eksklusif',  'desc': 'Bisa pake GLOBAL STRIKE tanpa batas (member biasa gak bisa).'},
    {'icon': FontAwesomeIcons.headset,    'title': 'Support Prioritas',      'desc': 'Lewat Telegram, keluhan VIP direspons dalam 5 menit.'},
  ];

  @override
  void initState() {
    super.initState();
    _currentRole = widget.role;
    _currentExpired = widget.expiredDate;
    _initBgVideo();
    _fetchMyRequest(initial: true);
    _refreshRoleFromServer();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _bgVideoController.dispose();
    super.dispose();
  }

  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ── Refresh role + expiredDate dari /meByKey ──
  // Dipanggil pas init, pas polling deteksi approved, dan pas popup
  // approved di-dismiss. Bikin hero card langsung update tanpa balik dashboard.
  Future<void> _refreshRoleFromServer() async {
    try {
      final res = await http.get(Uri.parse(
        "$_baseUrl/meByKey?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final newRole = (data['role'] ?? _currentRole).toString();
        final newExpired = (data['expiredDate'] ?? _currentExpired).toString();
        if (newRole != _currentRole || newExpired != _currentExpired) {
          if (mounted) {
            setState(() {
              _currentRole = newRole;
              _currentExpired = newExpired;
            });
          }
        }
      }
    } catch (_) {}
  }

  // ── API ───────────────────────────────────────────────────────────────────

  Future<void> _fetchMyRequest({bool initial = false}) async {
    if (_isPolling) return;
    setState(() => _isPolling = true);
    try {
      final res = await http
          .get(Uri.parse("$_baseUrl/myVipRequest?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final req = data['request'] as Map<String, dynamic>?;
          final prevStatus = _myRequest?['status'];
          final newStatus = req?['status'];
          setState(() => _myRequest = req);

          // Cek apakah status baru berubah ke approved/rejected → show popup
          if (req != null &&
              (newStatus == 'approved' || newStatus == 'rejected') &&
              !_hasShownResult &&
              (initial == false || prevStatus != newStatus)) {
            // kalau initial load dan status sudah final, jangan langsung popup
            // (biar gak langsung muncul pas buka halaman). Tapi kalau polling
            // mendeteksi perubahan ke final, tampilkan.
            if (!initial) {
              _hasShownResult = true;
              // Refresh role dulu biar popup nunjukin info bener
              await _refreshRoleFromServer();
              _showResultPopup(newStatus!, req);
            }
          }
          // Reset flag kalau request baru (pending lagi)
          if (newStatus == 'pending') {
            _hasShownResult = false;
          }
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _isPolling = false);

    // Mulai polling kalau status pending
    if (_myRequest != null && _myRequest!['status'] == 'pending') {
      _startPolling();
    } else {
      _pollTimer?.cancel();
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) _fetchMyRequest();
    });
  }

  Future<void> _pickProof() async {
    try {
      final picker = ImagePicker();
      final xfile = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
        maxWidth: 1280,
      );
      if (xfile == null) return;
      final bytes = await xfile.readAsBytes();
      final b64 = base64Encode(bytes);
      final mime = xfile.mimeType ?? 'image/jpeg';
      setState(() {
        _proofFile = File(xfile.path);
        _proofBase64 = 'data:$mime;base64,$b64';
      });
    } catch (e) {
      _showSnack('Gagal memilih gambar: $e', isError: true);
    }
  }

  Future<void> _submitRequest() async {
    if (_isSubmitting) return;
    if (_selectedPackageId == null) {
      _showSnack('Pilih paket VIP dulu', isError: true);
      return;
    }
    if (_proofBase64 == null || _proofBase64!.length < 100) {
      _showSnack('Upload bukti transfer dulu', isError: true);
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      final res = await http
          .post(
            Uri.parse("$_baseUrl/requestVip"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'packageId': _selectedPackageId,
              'proofBase64': _proofBase64,
              'proofMime': 'image/jpeg',
            }),
          )
          .timeout(const Duration(seconds: 30));

      // Cek status code dulu — kalau bukan 200, kemungkinan server error
      if (res.statusCode != 200) {
        String errMsg = 'Server error (${res.statusCode})';
        // Coba parse JSON kalau ada, kalau gak bisa berarti server return HTML
        try {
          final errData = jsonDecode(res.body);
          if (errData is Map && errData['message'] != null) {
            errMsg = errData['message'];
          }
        } catch (_) {
          // Response bukan JSON (mungkin HTML error page)
          if (res.body.contains('<!DOCTYPE') || res.body.contains('<html')) {
            errMsg = 'Server error (${res.statusCode}). Server return HTML, bukan JSON. Cek API log.';
          }
        }
        _showSnack(errMsg, isError: true);
        return;
      }

      // Safe JSON decode — kalau gagal, kasih pesan jelas
      Map<String, dynamic> data;
      try {
        data = jsonDecode(res.body) as Map<String, dynamic>;
      } catch (e) {
        _showSnack('Server return format tidak valid (bukan JSON). Cek API log.', isError: true);
        return;
      }

      if (data['valid'] == true) {
        _showSnack('Request VIP terkirim! Tunggu owner konfirmasi.');
        setState(() {
          _myRequest = data['request'];
          _proofFile = null;
          _proofBase64 = null;
          _selectedPackageId = null;
          _hasShownResult = false;
        });
        _startPolling();
      } else {
        _showSnack(data['message'] ?? 'Gagal submit request', isError: true);
      }
    } catch (e) {
      _showSnack('Connection error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(
              color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor:
          isError ? _VC.danger.withOpacity(0.92) : _VC.success.withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  String _formatRupiah(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp $buf';
  }

  // ── Premium Popups ────────────────────────────────────────────────────────

  void _showResultPopup(String status, Map<String, dynamic> req) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _VipResultDialog(
        status: status,
        request: req,
        onDismiss: () {
          Navigator.of(context).pop();
          _pollTimer?.cancel();
          if (status == 'approved') {
            // Pas approve: balik ke dashboard biar role ke-refresh
            // (DashboardPage dengerin .then() → _refreshRoleFromServer())
            Navigator.of(context).pop(true);
          } else {
            // Pas reject: tetap di halaman VIP biar user bisa coba lagi.
            setState(() {
              _myRequest = null;
              _hasShownResult = false;
            });
            _fetchMyRequest(initial: true);
          }
        },
      ),
    );
  }

  // ── BUILD ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // ── Video Background ──
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFFFFFFF), Color(0xFFFAFAFA), Color(0xFFF5F5F7)],
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.65)),
        Scaffold(
          backgroundColor: Colors.transparent,
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: _VC.card.withOpacity(0.5), shape: BoxShape.circle),
              child: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new,
                    color: _VC.gold, size: 18),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(FontAwesomeIcons.crown, color: _VC.gold, size: 16),
                const SizedBox(width: 8),
                Text("UPGRADE VIP",
                    style: TextStyle(
                        color: _VC.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        fontSize: 15)),
              ],
            ),
            centerTitle: true,
            flexibleSpace: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(color: _VC.bg.withOpacity(0.4)),
              ),
            ),
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.4,
                colors: [
                  _VC.gold.withOpacity(0.08),
                  _VC.bg.withOpacity(0.0),
                ],
              ),
            ),
            child: SafeArea(
              child: RefreshIndicator(
                color: _VC.gold,
                onRefresh: () => _fetchMyRequest(initial: true),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                  children: [
                    _buildHeroCard(),
                    const SizedBox(height: 18),
                    _buildBenefitsSection(),
                    const SizedBox(height: 22),
                    _buildPackagesSection(),
                    const SizedBox(height: 22),
                    _buildQrisSection(),
                    const SizedBox(height: 18),
                    _buildProofSection(),
                    const SizedBox(height: 18),
                    _buildSubmitButton(),
                    const SizedBox(height: 18),
                    if (_myRequest != null) _buildStatusCard(),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Hero card: status VIP user saat ini ─────────────────────────────────
  Widget _buildHeroCard() {
    final isVip = _currentRole.toLowerCase() == 'vip';
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isVip
              ? [_VC.gold.withOpacity(0.2), _VC.purple.withOpacity(0.2)]
              : [_VC.card, _VC.surface],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
            color: isVip ? _VC.gold.withOpacity(0.5) : _VC.border2, width: 1.5),
        boxShadow: isVip
            ? [BoxShadow(color: _VC.gold.withOpacity(0.18), blurRadius: 24)]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isVip
                        ? [_VC.gold, _VC.goldDim]
                        : [_VC.purple, _VC.purple2],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(isVip ? FontAwesomeIcons.crown : FontAwesomeIcons.user,
                    color: isVip ? Colors.black : Colors.white, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isVip ? 'KAMU VIP' : 'AKUN MEMBER',
                      style: TextStyle(
                        color: isVip ? _VC.gold : _VC.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      isVip
                          ? 'Sampai $_currentExpired'
                          : 'Upgrade ke VIP buat unlock semua fitur premium',
                      style: TextStyle(
                        color: _VC.textSub,
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Benefits grid ───────────────────────────────────────────────────────
  Widget _buildBenefitsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(width: 3, height: 16, color: _VC.gold),
            const SizedBox(width: 8),
            Text('KEUNTUNGAN VIP',
                style: TextStyle(
                  color: _VC.gold,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
          ],
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _benefits.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.05,
          ),
          itemBuilder: (ctx, i) {
            final b = _benefits[i];
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _VC.card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _VC.border2),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 30, height: 30,
                    decoration: BoxDecoration(
                      color: _VC.gold.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _VC.gold.withOpacity(0.25)),
                    ),
                    child: Icon(b['icon'] as IconData,
                        color: _VC.gold, size: 13),
                  ),
                  const SizedBox(height: 8),
                  Text(b['title'] as String,
                      style: TextStyle(
                        color: _VC.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      )),
                  const SizedBox(height: 4),
                  Expanded(
                    child: Text(b['desc'] as String,
                        style: TextStyle(
                          color: _VC.muted,
                          fontFamily: 'ShareTechMono',
                          fontSize: 9,
                          height: 1.4,
                        )),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  // ── Packages list ───────────────────────────────────────────────────────
  Widget _buildPackagesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(width: 3, height: 16, color: _VC.gold),
            const SizedBox(width: 8),
            Text('PILIH PAKET',
                style: TextStyle(
                  color: _VC.gold,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
          ],
        ),
        const SizedBox(height: 12),
        // Kalau ada request pending, lock pilihan
        if (_myRequest != null && _myRequest!['status'] == 'pending')
          Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _VC.gold.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _VC.gold.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                const Icon(FontAwesomeIcons.hourglassHalf,
                    color: _VC.gold, size: 14),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Kamu punya request pending. Pilihan paket dikunci sampai owner konfirmasi.',
                    style: TextStyle(
                      color: _VC.textSub,
                      fontFamily: 'ShareTechMono',
                      fontSize: 10,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
        Column(
          children: _packages.map((p) {
            final selected = _selectedPackageId == p['id'];
            final locked =
                _myRequest != null && _myRequest!['status'] == 'pending';
            return Opacity(
              opacity: locked ? 0.5 : 1.0,
              child: GestureDetector(
                onTap: locked
                    ? null
                    : () => setState(() => _selectedPackageId = p['id']),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: selected ? _VC.cardHigh : _VC.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: selected ? _VC.gold : _VC.border2,
                      width: selected ? 1.5 : 1,
                    ),
                    boxShadow: selected
                        ? [BoxShadow(color: _VC.gold.withOpacity(0.15), blurRadius: 16)]
                        : null,
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 22, height: 22,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: selected ? _VC.gold : _VC.muted2,
                              width: 2),
                        ),
                        child: selected
                            ? Center(
                                child: Container(
                                  width: 10, height: 10,
                                  decoration: const BoxDecoration(
                                    color: _VC.gold,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              )
                            : null,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(p['label'] as String,
                                    style: TextStyle(
                                      color: _VC.text,
                                      fontFamily: 'MADEEvolveSansEVO',
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                    )),
                                if (p['id'] == 'forever') ...[
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 5, vertical: 1),
                                    decoration: BoxDecoration(
                                      color: _VC.gold,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text('BEST',
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'MADEEvolveSansEVO',
                                          fontSize: 7,
                                          fontWeight: FontWeight.bold,
                                        )),
                                  ),
                                ],
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text(p['suffix'] as String,
                                style: TextStyle(
                                  color: _VC.muted,
                                  fontFamily: 'ShareTechMono',
                                  fontSize: 9,
                                )),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(_formatRupiah(p['price'] as int),
                          style: TextStyle(
                            color: selected ? _VC.gold : _VC.textSub,
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          )),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  // ── QRIS section ────────────────────────────────────────────────────────
  Widget _buildQrisSection() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _VC.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _VC.gold.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: _VC.gold.withOpacity(0.08), blurRadius: 20)],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(FontAwesomeIcons.qrcode, color: _VC.gold, size: 14),
              const SizedBox(width: 8),
              Text('SCAN QRIS UNTUK BAYAR',
                  style: TextStyle(
                    color: _VC.gold,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  )),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                'https://files.catbox.moe/bohhlx.jpg',
                width: 220, height: 220, fit: BoxFit.cover,
                loadingBuilder: (ctx, child, prog) {
                  if (prog == null) return child;
                  return SizedBox(
                    width: 220, height: 220,
                    child: Center(
                      child: CircularProgressIndicator(
                        color: _VC.gold,
                        strokeWidth: 2,
                        value: prog.expectedTotalBytes != null
                            ? prog.cumulativeBytesLoaded /
                                prog.expectedTotalBytes!
                            : null,
                      ),
                    ),
                  );
                },
                errorBuilder: (ctx, e, _) => Container(
                  width: 220, height: 220,
                  color: Colors.white,
                  child: Icon(Icons.broken_image,
                      color: _VC.muted2, size: 40),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: _VC.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _VC.border2),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded,
                    color: _VC.gold.withOpacity(0.6), size: 12),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Bayar sesuai nominal paket yang dipilih. Setelah bayar, upload screenshot bukti transfer di bawah.',
                    style: TextStyle(
                      color: _VC.muted,
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Proof upload section ────────────────────────────────────────────────
  Widget _buildProofSection() {
    final locked =
        _myRequest != null && _myRequest!['status'] == 'pending';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(width: 3, height: 16, color: _VC.gold),
            const SizedBox(width: 8),
            Text('BUKTI TRANSFER',
                style: TextStyle(
                  color: _VC.gold,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
          ],
        ),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: locked ? null : _pickProof,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 160,
            decoration: BoxDecoration(
              color: _VC.card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: _proofFile != null
                    ? _VC.gold
                    : _VC.border2,
                width: _proofFile != null ? 1.5 : 1,
              ),
            ),
            child: _proofFile != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(13),
                    child: Stack(
                      children: [
                        Image.file(_proofFile!,
                            width: double.infinity,
                            height: double.infinity,
                            fit: BoxFit.cover),
                        Positioned(
                          top: 8, right: 8,
                          child: GestureDetector(
                            onTap: locked
                                ? null
                                : () => setState(() {
                                      _proofFile = null;
                                      _proofBase64 = null;
                                    }),
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.6),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.close,
                                  color: Colors.white, size: 14),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : Center(
                    child: Opacity(
                      opacity: locked ? 0.3 : 1.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(FontAwesomeIcons.cloudArrowUp,
                              color: _VC.gold.withOpacity(0.6), size: 26),
                          const SizedBox(height: 8),
                          Text('Tap buat upload bukti',
                              style: TextStyle(
                                color: _VC.muted,
                                fontFamily: 'ShareTechMono',
                                fontSize: 10,
                              )),
                          const SizedBox(height: 2),
                          Text('JPG / PNG / WEBP',
                              style: TextStyle(
                                color: _VC.muted2,
                                fontFamily: 'ShareTechMono',
                                fontSize: 8,
                              )),
                        ],
                      ),
                    ),
                  ),
          ),
        ),
      ],
    );
  }

  // ── Submit button ───────────────────────────────────────────────────────
  Widget _buildSubmitButton() {
    final locked =
        _myRequest != null && _myRequest!['status'] == 'pending';
    final canSubmit = !locked &&
        _selectedPackageId != null &&
        _proofBase64 != null &&
        !_isSubmitting;
    return GestureDetector(
      onTap: canSubmit ? _submitRequest : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 52,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: canSubmit
                ? [_VC.gold, _VC.goldDim]
                : [_VC.surface, _VC.card],
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: canSubmit
              ? [BoxShadow(color: _VC.gold.withOpacity(0.3), blurRadius: 20)]
              : null,
        ),
        child: Center(
          child: _isSubmitting
              ? const SizedBox(
                  width: 20, height: 20,
                  child: CircularProgressIndicator(
                      color: Colors.black, strokeWidth: 2),
                )
              : Text(
                  locked ? 'MENUNGGU KONFIRMASI OWNER' : 'KIRIM BUKTI TRANSFER',
                  style: TextStyle(
                    color: canSubmit ? Colors.black : _VC.muted,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
        ),
      ),
    );
  }

  // ── Status card (kalau ada request) ─────────────────────────────────────
  Widget _buildStatusCard() {
    final r = _myRequest!;
    final status = r['status'] as String;
    Color statusColor;
    String statusLabel;
    IconData statusIcon;
    switch (status) {
      case 'approved':
        statusColor = _VC.success;
        statusLabel = 'DISETUJUI';
        statusIcon = FontAwesomeIcons.circleCheck;
        break;
      case 'rejected':
        statusColor = _VC.danger;
        statusLabel = 'DITOLAK';
        statusIcon = FontAwesomeIcons.circleXmark;
        break;
      default:
        statusColor = _VC.gold;
        statusLabel = 'MENUNGGU';
        statusIcon = FontAwesomeIcons.hourglassHalf;
    }
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _VC.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: statusColor.withOpacity(0.4), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(statusIcon, color: statusColor, size: 16),
              const SizedBox(width: 8),
              Text('STATUS REQUEST',
                  style: TextStyle(
                    color: statusColor,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  )),
              const Spacer(),
              if (status == 'pending' && _isPolling)
                SizedBox(
                  width: 10, height: 10,
                  child: CircularProgressIndicator(
                      color: statusColor, strokeWidth: 1.5),
                ),
            ],
          ),
          const SizedBox(height: 12),
          _detailRow('Paket', r['packageLabel'] as String? ?? '-'),
          const SizedBox(height: 6),
          _detailRow('Nominal', _formatRupiah(r['price'] as int? ?? 0)),
          const SizedBox(height: 6),
          _detailRow('Status', statusLabel, valueColor: statusColor),
          if (status == 'rejected') ...[
            const SizedBox(height: 6),
            _detailRow('Alasan', r['rejectReason'] as String? ?? 'Pembayaran tidak valid'),
          ],
          const SizedBox(height: 6),
          _detailRow('Tanggal', _formatDate(r['createdAt'] as String?)),
          if (status == 'pending') ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _VC.gold.withOpacity(0.05),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _VC.gold.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  Icon(FontAwesomeIcons.clock,
                      color: _VC.gold.withOpacity(0.7), size: 12),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Halaman ini auto-refresh tiap 5 detik. Kamu akan dapet popup otomatis pas owner konfirmasi.',
                      style: TextStyle(
                        color: _VC.muted,
                        fontFamily: 'ShareTechMono',
                        fontSize: 9,
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _detailRow(String label, String value, {Color? valueColor}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 70,
          child: Text('[$label]',
              style: TextStyle(
                color: _VC.muted2,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
              )),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(value,
              style: TextStyle(
                color: valueColor ?? _VC.text,
                fontFamily: 'ShareTechMono',
                fontSize: 11,
              )),
        ),
      ],
    );
  }

  String _formatDate(String? iso) {
    if (iso == null) return '-';
    try {
      final d = DateTime.parse(iso);
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PREMIUM RESULT DIALOG (Approve / Reject popup)
// ═══════════════════════════════════════════════════════════════════════════
class _VipResultDialog extends StatefulWidget {
  final String status; // 'approved' | 'rejected'
  final Map<String, dynamic> request;
  final VoidCallback onDismiss;

  const _VipResultDialog({
    required this.status,
    required this.request,
    required this.onDismiss,
  });

  @override
  State<_VipResultDialog> createState() => _VipResultDialogState();
}

class _VipResultDialogState extends State<_VipResultDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _glowController;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    )..forward();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final approved = widget.status == 'approved';
    final primary = approved ? const Color(0xFFE8D5FF) : const Color(0xFFFF3B30);
    final primaryDark =
        approved ? const Color(0xFFC7C7CC) : const Color(0xFFD70015);

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: ScaleTransition(
        scale: Tween<double>(begin: 0.7, end: 1.0).animate(
          CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
        ),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            // Glow ring
            Positioned(
              top: -20,
              child: AnimatedBuilder(
                animation: _glowController,
                builder: (_, __) => Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: primary.withOpacity(0.4 + _glowController.value * 0.3),
                        blurRadius: 30 + _glowController.value * 20,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // Main card
            Container(
              margin: const EdgeInsets.only(top: 40),
              padding: const EdgeInsets.fromLTRB(22, 36, 22, 22),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFF1C1C1E),
                    const Color(0xFF0A0A0B),
                  ],
                ),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: primary.withOpacity(0.4), width: 1.5),
                boxShadow: [
                  BoxShadow(color: primary.withOpacity(0.2), blurRadius: 40),
                  BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 30),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Crown / X icon
                  Container(
                    width: 72, height: 72,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [primary, primaryDark],
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(color: primary.withOpacity(0.5), blurRadius: 20),
                      ],
                    ),
                    child: Icon(
                      approved
                          ? FontAwesomeIcons.crown
                          : FontAwesomeIcons.xmark,
                      color: Colors.white,
                      size: 32,
                    ),
                  ),
                  const SizedBox(height: 18),
                  // Title
                  Text(
                    approved ? 'VIP ACTIVATED' : 'REQUEST DITOLAK',
                    style: TextStyle(
                      color: primary,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 3,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(width: 40, height: 2, color: primary.withOpacity(0.5)),
                  const SizedBox(height: 16),
                  // Body text
                  Text(
                    approved
                        ? 'Selamat! Account kamu udah di-upgrade ke VIP. Nikmati semua fitur premium sekarang.'
                        : (widget.request['rejectReason'] as String? ??
                            'Pembayaran kamu gak valid atau gak sesuai. Silakan submit ulang dengan bukti yang benar.'),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: const Color(0xFFAEAEB2),
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      height: 1.6,
                    ),
                  ),
                  const SizedBox(height: 18),
                  // Details
                  if (approved) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1C1C1E),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: primary.withOpacity(0.2)),
                      ),
                      child: Column(
                        children: [
                          _row('Username', widget.request['username'] as String? ?? '-'),
                          const SizedBox(height: 6),
                          _row('Paket', widget.request['packageLabel'] as String? ?? '-'),
                          const SizedBox(height: 6),
                          _row('Role Baru', 'VIP', valueColor: primary),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                  ],
                  // Confirm button
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton(
                      onPressed: widget.onDismiss,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primary,
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: Text(
                        approved ? 'LANJUT GUNAKAN APP' : 'COBA LAGI',
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value, {Color? valueColor}) {
    return Row(
      children: [
        SizedBox(
          width: 80,
          child: Text('[$label]',
              style: const TextStyle(
                color: Color(0xFFC7C7CC),
                fontFamily: 'ShareTechMono',
                fontSize: 10,
              )),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(value,
              style: TextStyle(
                color: valueColor ?? const Color(0xFFFFFFFF),
                fontFamily: 'ShareTechMono',
                fontSize: 11,
              )),
        ),
      ],
    );
  }
}
