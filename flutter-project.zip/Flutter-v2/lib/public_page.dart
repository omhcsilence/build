import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:image_picker/image_picker.dart';

// ── COLOR SCHEME ──────────────────────────────────────────────────────────────
class _C {
  static const bg      = Color(0xFF000000);
  static const bg2     = Color(0xFF0a0a0a);
  static const surface = Color(0xFF111111);
  static const card    = Color(0xFF111111);
  static const accent  = Color(0xFFFF3B30);
  static const text    = Color(0xFFE0E7FF);
  static const muted   = Color(0x73E0E7FF);
  static const muted2  = Color(0x38E0E7FF);
  static const border  = Color(0x1AFF3B30);
  static const border2 = Color(0x0FFFFFFF);
  static const aiColor = Color(0xFF6C63FF);
}

class PublicChatPage extends StatefulWidget {

  final String username;
  final String sessionKey;

  const PublicChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage>
    with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  final String baseUrl = "https://api-service.yakuza.biz.id";

  final TextEditingController _msgController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _focusNode = FocusNode();

  List<dynamic> _messages = [];
  Timer? _refreshTimer;
  bool _isSending = false;
  bool _isTyping = false;
  bool _aiThinking = false;
  String? _aiSessionId;

  // ── Image picker ──
  // Image yang dipilih user buat dikirim bareng pesan.
  // Disimpen sebagai base64 data URL supaya bisa langsung dikirim ke API.
  final ImagePicker _imagePicker = ImagePicker();
  
  // Current user's role (fetched from /meByKey)
  String _currentRole = 'member';
  String? _pendingImageBase64;  // 'data:image/jpeg;base64,...'
  Uint8List? _pendingImageBytes; // buat preview lokal sebelum send

  late AnimationController _pulseController;

  static const String _aiBotName = '「AI」';

  // ── Helpers: API baru pake field `from` & `text`, API lama pake `username`
  // & `message`. Kita handle keduanya biar tetep compatible.
  String _msgFrom(dynamic msg) =>
      (msg is Map ? (msg['from'] ?? msg['username'] ?? '') : '').toString();
  String _msgText(dynamic msg) =>
      (msg is Map ? (msg['text'] ?? msg['message'] ?? '') : '').toString();
  String? _msgImage(dynamic msg) =>
      msg is Map ? (msg['image']?.toString()) : null;

  String _msgRole(dynamic msg) =>
      msg is Map ? (msg['role'] ?? 'member').toString().toLowerCase() : 'member';

  Color _roleColor(String role) {
    switch (role) {
      case 'owner': return const Color(0xFFFF0000);
      case 'vip': return const Color(0xFFFFD700);
      case 'founder': return const Color(0xFFFF6B00);
      case 'reseller': return const Color(0xFF00BFFF);
      case 'admin': return const Color(0xFF8B0000);
      case 'seles': return const Color(0xFF9370DB);
      case 'dev': return const Color(0xFF00FF7F);
      default: return const Color(0xFF888888);
    }
  }

  String _roleLabel(String role) {
    switch (role) {
      case 'owner': return 'OWNER';
      case 'vip': return 'VIP';
      case 'founder': return 'FOUNDER';
      case 'reseller': return 'RESELLER';
      case 'admin': return 'ADMIN';
      case 'seles': return 'MOD';
      case 'dev': return 'DEV';
      default: return 'MEMBER';
    }
  }

  IconData _roleIcon(String role) {
    switch (role) {
      case 'owner': return FontAwesomeIcons.crown;
      case 'vip': return FontAwesomeIcons.star;
      case 'founder': return FontAwesomeIcons.trophy;
      case 'reseller': return FontAwesomeIcons.store;
      case 'admin': return FontAwesomeIcons.shieldHalved;
      case 'seles': return FontAwesomeIcons.gavel;
      case 'dev': return FontAwesomeIcons.code;
      default: return FontAwesomeIcons.user;
    }
  }

  // ── Decode base64 image (data URL or raw) jadi Uint8List ──
  Uint8List? _decodeImage(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    var b64 = raw;
    // Strip data URL prefix: "data:image/...;base64,"
    final commaIdx = b64.indexOf(',');
    if (commaIdx != -1 && b64.startsWith('data:')) {
      b64 = b64.substring(commaIdx + 1);
    }
    try {
      return base64Decode(b64);
    } catch (_) {
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    _initBgVideo();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _msgController.addListener(() {
      final typing = _msgController.text.isNotEmpty;
      if (typing != _isTyping) setState(() => _isTyping = typing);
    });

    _fetchMessages();
    _fetchRole();
    _refreshTimer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => _fetchMessages(),
    );
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _pulseController.dispose();
    _msgController.dispose();
    _scrollController.dispose();
    _focusNode.dispose();
    _bgVideoController.dispose();
    super.dispose();
  }

  // ── API ───────────────────────────────────────────────────────────────────

  Future<void> _fetchRole() async {
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/meByKey?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() => _currentRole = (data['role'] ?? 'member').toString().toLowerCase());
        }
      }
    } catch (_) {}
  }

  Future<void> _fetchMessages() async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/get-public-chat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey}),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        // Handle both old ({success: true, messages: []}) and new ({valid: true, messages: []}) formats
        final ok = data['success'] == true || data['valid'] == true;
        if (ok && data['messages'] is List) {
          final newMsgs = data['messages'] as List;
          final shouldScroll = newMsgs.length > _messages.length;
          if (mounted) {
            setState(() => _messages = newMsgs);
            if (shouldScroll) _scrollToBottom();
          }
        }
      }
    } catch (_) {}
  }

  // ── Pick image from gallery, encode to base64 data URL ──
  // ImageQuality 50 + maxWidth 800 biar payload base64-nya gak gede banget.
  Future<void> _pickImage() async {
    if (_isSending) return;
    try {
      final xfile = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 50,
        maxWidth: 800,
      );
      if (xfile == null) return;
      final bytes = await xfile.readAsBytes();
      final b64 = base64Encode(bytes);
      if (mounted) {
        setState(() {
          _pendingImageBytes = bytes;
          _pendingImageBase64 = 'data:image/jpeg;base64,$b64';
        });
      }
    } catch (e) {
      debugPrint('Pick image error: $e');
    }
  }

  void _clearPendingImage() {
    setState(() {
      _pendingImageBase64 = null;
      _pendingImageBytes = null;
    });
  }

  Future<void> _sendMessage() async {
    final text = _msgController.text.trim();
    final hasImage = _pendingImageBase64 != null;
    // Boleh kirim kalau ada text ATAU image (atau keduanya).
    if ((text.isEmpty && !hasImage) || _isSending) return;

    _msgController.clear();
    final sendImage = _pendingImageBase64;
    setState(() {
      _isSending = true;
      _pendingImageBase64 = null;
      _pendingImageBytes = null;
    });

    try {
      await http.post(
        Uri.parse('$baseUrl/send-public-chat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': widget.username,
          'text': text,
          'role': _currentRole,
          if (sendImage != null) 'imageBase64': sendImage,
        }),
      );
      await _fetchMessages();
      _scrollToBottom();

      if (text.toLowerCase().contains('@ai')) {
        _triggerAiReply(text, widget.username);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('Gagal mengirim pesan',
              style: TextStyle(color: _C.text)),
          backgroundColor: _C.card,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10)),
        ));
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  // ── AI Integration ────────────────────────────────────────────────────────

  Future<void> _ensureAiSession() async {
    if (_aiSessionId != null) return;
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/api/tools/chat/new-session?key=${widget.sessionKey}',
      ));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          _aiSessionId = data['sessionId'];
        } else {
          debugPrint('[AI] Gagal buat sesi: ${res.body}');
        }
      }
    } catch (e) {
      debugPrint('[AI] Error ensureAiSession: $e');
    }
  }

  Future<void> _triggerAiReply(String userMessage, String senderName) async {
    await _ensureAiSession();
    if (_aiSessionId == null) {
      debugPrint('[AI] Session null, batalkan');
      if (mounted) setState(() => _aiThinking = false);
      return;
    }

    final question = userMessage
        .replaceAll(RegExp(r'@ai\s*', caseSensitive: false), '')
        .trim();
    if (question.isEmpty) {
      if (mounted) setState(() => _aiThinking = false);
      return;
    }

    if (mounted) setState(() => _aiThinking = true);

    try {
      final prompt = '$senderName bertanya: $question';
      final uri = Uri.parse(
        '$baseUrl/api/tools/chat/send'
        '?key=${widget.sessionKey}'
        '&session=$_aiSessionId'
        '&message=${Uri.encodeComponent(prompt)}',
      );

      debugPrint('[AI] Kirim ke: $uri');

      final res =
          await http.get(uri).timeout(const Duration(seconds: 30));

      debugPrint('[AI] Response ${res.statusCode}: ${res.body}');

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);

        String? aiReply = data['data']?['message']
            ?? data['data']?['response']
            ?? data['result']
            ?? (data['data'] is String ? data['data'] : null);

        debugPrint('[AI] Reply parsed: $aiReply');

        if (aiReply != null && aiReply.isNotEmpty) {
          await http.post(
            Uri.parse('$baseUrl/send-public-chat'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'username': _aiBotName,
              'text': '@$senderName $aiReply',
            }),
          );
          await _fetchMessages();
          _scrollToBottom();
        }
      }
    } catch (e) {
      debugPrint('[AI] Error: $e');
    } finally {
      if (mounted) setState(() => _aiThinking = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ── BUILD ─────────────────────────────────────────────────────────────────

  @override

  // ── Video Background ──────────────────────────────
  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  Widget build(BuildContext context) {
return Stack(
      children: [
        // ── Video Background ──
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
              ),
            ),
          ),
        // ── Dark overlay ──
        Container(color: Colors.black.withOpacity(0.6)),
        // ── Page content ──
      Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(child: _buildMessageList()),
            if (_aiThinking) _buildAiTypingIndicator(),
            _buildInputArea(),
          ],
        ),
      ),
    ),
      ],
      );
  }

  // ── HEADER ────────────────────────────────────────────────────────────────

  Widget _buildHeader() {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xEB0A0A14),
            border: Border(bottom: BorderSide(color: _C.border)),
          ),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.border2),
                  ),
                  child: const Icon(Icons.arrow_back_rounded,
                      color: _C.muted, size: 18),
                ),
              ),
              const SizedBox(width: 12),

              AnimatedBuilder(
                animation: _pulseController,
                builder: (_, __) => Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.accent,
                    boxShadow: [
                      BoxShadow(
                        color: _C.accent.withOpacity(
                            0.3 + _pulseController.value * 0.4),
                        blurRadius: 6 + _pulseController.value * 6,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('PUBLIC LOUNGE',
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: _C.text,
                          shadows: [
                            Shadow(color: _C.accent, blurRadius: 6)
                          ],
                        )),
                    Text(
                      'LIVE · ${_messages.length} messages',
                      style: const TextStyle(
                          fontSize: 10,
                          color: _C.muted,
                          letterSpacing: 1),
                    ),
                  ],
                ),
              ),

              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.aiColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                  border:
                      Border.all(color: _C.aiColor.withOpacity(0.3)),
                ),
                child: const Row(
                  children: [
                    Icon(FontAwesomeIcons.ghost,
                        color: _C.aiColor, size: 10),
                    SizedBox(width: 5),
                    Text('@AI',
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 8,
                          color: _C.aiColor,
                          fontWeight: FontWeight.bold,
                        )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── MESSAGE LIST ──────────────────────────────────────────────────────────

  Widget _buildMessageList() {
    if (_messages.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(FontAwesomeIcons.commentSlash,
                color: _C.muted2, size: 36),
            const SizedBox(height: 14),
            const Text('No messages yet',
                style: TextStyle(color: _C.muted, fontSize: 13)),
            const SizedBox(height: 4),
            const Text('Ketik @ai untuk mengajak AI ngobrol!',
                style: TextStyle(color: _C.muted2, fontSize: 11)),
          ],
        ),
      );
    }

    return ListView.builder(
      controller: _scrollController,
      padding:
          const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final msg = _messages[index];
        final from = _msgFrom(msg);
        final isMe = from == widget.username;
        final prevMsg = index > 0 ? _messages[index - 1] : null;
        final isFirst = prevMsg == null || _msgFrom(prevMsg) != from;
        return _buildBubble(msg, isMe, isFirst);
      },
    );
  }

  Widget _buildBubble(dynamic msg, bool isMe, bool isFirst) {
    final from = _msgFrom(msg);
    final text = _msgText(msg);
    final role = _msgRole(msg);
    final isAiBot = from == _aiBotName;
    final imageBytes = _decodeImage(_msgImage(msg));
    final hasImage = imageBytes != null;
    final roleColor = _roleColor(role);
    final roleLabel = _roleLabel(role);
    final roleIcon = _roleIcon(role);
    final isOwner = role == 'owner';
    final isVip = role == 'vip';

    // Role badge widget
    Widget roleBadge = Container(
      margin: const EdgeInsets.only(left: 6),
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
      decoration: BoxDecoration(
        color: roleColor.withOpacity(isOwner ? 0.25 : 0.15),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: roleColor.withOpacity(0.4), width: 0.5),
        boxShadow: isOwner ? [
          BoxShadow(color: roleColor.withOpacity(0.3), blurRadius: 4),
        ] : null,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          FaIcon(roleIcon, color: roleColor, size: 7),
          const SizedBox(width: 3),
          Text(roleLabel,
              style: TextStyle(
                  fontSize: 7,
                  color: roleColor,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5)),
        ],
      ),
    );

    // The bubble container — with role-based styling
    Widget bubbleContent = Container(
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width * 0.68,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: isMe
            ? (isOwner ? roleColor.withOpacity(0.12) : _C.accent.withOpacity(0.15))
            : isAiBot
                ? _C.aiColor.withOpacity(0.08)
                : isOwner
                    ? roleColor.withOpacity(0.08)
                    : isVip
                        ? Color(0xFFFFD700).withOpacity(0.06)
                        : _C.card,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(16),
          topRight: const Radius.circular(16),
          bottomLeft: Radius.circular(isMe ? 16 : 4),
          bottomRight: Radius.circular(isMe ? 4 : 16),
        ),
        border: Border.all(
          color: isMe
              ? (isOwner ? roleColor.withOpacity(0.5) : _C.accent.withOpacity(0.3))
              : isAiBot
                  ? _C.aiColor.withOpacity(0.25)
                  : isOwner
                      ? roleColor.withOpacity(0.4)
                      : isVip
                          ? Color(0xFFFFD700).withOpacity(0.25)
                          : _C.border2,
          width: isOwner ? 1.5 : 1,
        ),
        boxShadow: isOwner
            ? [
                BoxShadow(color: roleColor.withOpacity(0.15), blurRadius: 12),
                BoxShadow(color: roleColor.withOpacity(0.08), blurRadius: 20, spreadRadius: 2),
              ]
            : isAiBot
                ? [BoxShadow(color: _C.aiColor.withOpacity(0.06), blurRadius: 8)]
                : isMe
                    ? [BoxShadow(color: _C.accent.withOpacity(0.08), blurRadius: 8)]
                    : isVip
                        ? [BoxShadow(color: Color(0xFFFFD700).withOpacity(0.06), blurRadius: 8)]
                        : [],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (hasImage) ...[
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 200),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.memory(imageBytes,
                    width: double.infinity, fit: BoxFit.cover),
              ),
            ),
            if (text.isNotEmpty) const SizedBox(height: 8),
          ],
          if (text.isNotEmpty)
            Text(text,
                style: TextStyle(
                  color: isOwner ? Colors.white : _C.text,
                  fontSize: 13,
                  height: 1.4,
                  fontFamily: 'ShareTechMono',
                )),
        ],
      ),
    );

    // Owner: wrap in animated red aura
    if (isOwner && !isAiBot) {
      bubbleContent = AnimatedBuilder(
        animation: _pulseController,
        builder: (_, child) => Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: roleColor.withOpacity(0.15 + _pulseController.value * 0.15),
                blurRadius: 15 + _pulseController.value * 10,
                spreadRadius: 1 + _pulseController.value * 2,
              ),
            ],
          ),
          child: child,
        ),
        child: bubbleContent,
      );
    }

    return Padding(
      padding: EdgeInsets.only(bottom: 4, top: isFirst ? 10 : 2),
      child: Row(
        mainAxisAlignment:
            isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe) ...[
            if (isFirst)
              _buildAvatar(from)
            else
              const SizedBox(width: 32),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isMe
                  ? CrossAxisAlignment.end
                  : CrossAxisAlignment.start,
              children: [
                // Username + role badge
                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 4, right: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (isAiBot)
                        const Padding(
                          padding: EdgeInsets.only(right: 4),
                          child: Icon(FontAwesomeIcons.ghost,
                              color: _C.aiColor, size: 10),
                        ),
                      Flexible(
                        child: Text(
                          from.isNotEmpty ? from : 'unknown',
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 10,
                            color: isAiBot
                                ? _C.aiColor
                                : isOwner
                                    ? roleColor
                                    : isVip
                                        ? Color(0xFFFFD700)
                                        : _C.accent,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                      if (isAiBot)
                        Container(
                          margin: const EdgeInsets.only(left: 6),
                          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                          decoration: BoxDecoration(
                            color: _C.aiColor.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text('BOT',
                              style: TextStyle(fontSize: 8, color: _C.aiColor, fontWeight: FontWeight.bold)),
                        )
                      else
                        roleBadge,
                    ],
                  ),
                ),
                bubbleContent,
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAvatar(String username) {
    final isAiBot = username == _aiBotName;
    return Container(
      width: 32, height: 32,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isAiBot
            ? _C.aiColor.withOpacity(0.15)
            : _C.accent.withOpacity(0.15),
        border: Border.all(
          color: isAiBot
              ? _C.aiColor.withOpacity(0.4)
              : _C.accent.withOpacity(0.3),
        ),
      ),
      child: Center(
        child: isAiBot
            ? const Icon(FontAwesomeIcons.ghost,
                size: 14, color: _C.aiColor)
            : Text(
                username.isNotEmpty ? username[0].toUpperCase() : '?',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: _C.accent,
                ),
              ),
      ),
    );
  }

  // ── AI TYPING INDICATOR ───────────────────────────────────────────────────

  Widget _buildAiTypingIndicator() {
    return Container(
      padding: const EdgeInsets.fromLTRB(22, 6, 14, 6),
      child: Row(
        children: [
          SizedBox(
            width: 14, height: 14,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: _C.aiColor.withOpacity(0.8),
            ),
          ),
          const SizedBox(width: 10),
          const Icon(FontAwesomeIcons.ghost,
              size: 11, color: _C.aiColor),
          const SizedBox(width: 6),
          const Text(
            '$_aiBotName sedang mengetik...',
            style: TextStyle(
              fontSize: 11,
              color: _C.aiColor,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  // ── INPUT AREA ────────────────────────────────────────────────────────────

  Widget _buildInputArea() {
    final mentionsAi =
        _msgController.text.toLowerCase().contains('@ai');
    final hasPendingImage = _pendingImageBytes != null;

    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
          decoration: BoxDecoration(
            color: const Color(0xE60C0D15),
            border: Border(top: BorderSide(color: _C.border)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_isTyping && mentionsAi)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6, left: 4),
                  child: Row(
                    children: const [
                      Icon(FontAwesomeIcons.ghost,
                          size: 10, color: _C.aiColor),
                      SizedBox(width: 6),
                      Text(
                        'AI akan membalas di chat publik',
                        style: TextStyle(
                          fontSize: 10,
                          color: _C.aiColor,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),

              // ── Pending image preview ──
              // Nongol pas user udah pick image tapi belum kirim.
              if (hasPendingImage)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.memory(
                              _pendingImageBytes!,
                              height: 64,
                              width: 64,
                              fit: BoxFit.cover,
                              gaplessPlayback: true,
                            ),
                          ),
                          Positioned(
                            top: 2,
                            right: 2,
                            child: GestureDetector(
                              onTap: _clearPendingImage,
                              child: Container(
                                width: 18,
                                height: 18,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _C.accent,
                                  border: Border.all(
                                      color: _C.text, width: 1),
                                ),
                                child: const Icon(Icons.close,
                                    size: 11, color: _C.text),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'Image ready to send',
                              style: TextStyle(
                                fontSize: 11,
                                color: _C.accent,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'MADEEvolveSansEVO',
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Tap send untuk upload bareng pesan',
                              style: TextStyle(
                                fontSize: 9,
                                color: _C.muted2,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

              Row(
                children: [
                  // ── Camera / image pick button ──
                  GestureDetector(
                    onTap: _isSending ? null : _pickImage,
                    child: Container(
                      width: 44,
                      height: 44,
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: hasPendingImage
                            ? _C.accent.withOpacity(0.15)
                            : _C.surface,
                        border: Border.all(
                          color: hasPendingImage
                              ? _C.accent
                              : _C.border2,
                        ),
                      ),
                      child: Icon(
                        FontAwesomeIcons.camera,
                        size: 15,
                        color: hasPendingImage ? _C.accent : _C.muted,
                      ),
                    ),
                  ),
                  Expanded(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      decoration: BoxDecoration(
                        color: _C.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: _isTyping && mentionsAi
                              ? _C.aiColor.withOpacity(0.5)
                              : _isTyping
                                  ? _C.accent.withOpacity(0.4)
                                  : _C.border2,
                        ),
                        boxShadow: _isTyping && mentionsAi
                            ? [
                                BoxShadow(
                                  color: _C.aiColor.withOpacity(0.1),
                                  blurRadius: 8,
                                )
                              ]
                            : [],
                      ),
                      child: TextField(
                        controller: _msgController,
                        focusNode: _focusNode,
                        style: const TextStyle(
                            color: _C.text, fontSize: 13.5),
                        cursorColor: _C.accent,
                        maxLines: 4,
                        minLines: 1,
                        textCapitalization:
                            TextCapitalization.sentences,
                        decoration: const InputDecoration(
                          hintText:
                              'Pesan... (ketik @ai untuk tanya AI)',
                          hintStyle: TextStyle(
                              color: _C.muted2, fontSize: 12),
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 10),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),

                  GestureDetector(
                    onTap: _isSending ? null : _sendMessage,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 44, height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: (_isTyping || hasPendingImage)
                            ? (mentionsAi ? _C.aiColor : _C.accent)
                            : _C.surface,
                        border: Border.all(
                          color: (_isTyping || hasPendingImage)
                              ? (mentionsAi ? _C.aiColor : _C.accent)
                              : _C.border2,
                        ),
                        boxShadow: (_isTyping || hasPendingImage)
                            ? [
                                BoxShadow(
                                  color: (mentionsAi
                                          ? _C.aiColor
                                          : _C.accent)
                                      .withOpacity(0.35),
                                  blurRadius: 12,
                                )
                              ]
                            : [],
                      ),
                      child: _isSending
                          ? const Padding(
                              padding: EdgeInsets.all(11),
                              child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: _C.text),
                            )
                          : Icon(
                              FontAwesomeIcons.paperPlane,
                              size: 15,
                              color: (_isTyping || hasPendingImage)
                                  ? Colors.white
                                  : _C.muted,
                            ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}