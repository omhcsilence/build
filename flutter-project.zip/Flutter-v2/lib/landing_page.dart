import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'login_page.dart';

class _LC {
  static const accent   = Color(0xFF7FE7B8);
  static const accent2  = Color(0xFFA8F0D4);
  static const accent3  = Color(0xFF5DD9A5);
  static const bg       = Color(0xFF0f0e1a);
  static const text     = Color(0xFFE0E7FF);
  static const textDim  = Color(0x66E0E7FF);
  static const textDim2 = Color(0x33E0E7FF);
  static const border   = Color(0x4D6366F1);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  late VideoPlayerController _videoController;
  bool _isInitialized = false;
  bool _navigating = false;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  void _initVideo() {
    _videoController = VideoPlayerController.asset(
      'assets/videos/bg_video.mp4',
    )..initialize().then((_) {
      if (mounted) {
        setState(() => _isInitialized = true);
        _videoController.play();
        _videoController.setVolume(1.0);
      }
    }).catchError((e) {
      debugPrint("Intro video error: $e");
      // If video fails, go straight to login after 3 seconds
      Future.delayed(const Duration(seconds: 3), _goToLogin);
    });

    _videoController.addListener(() {
      if (_videoController.value.isInitialized &&
          _videoController.value.position >= _videoController.value.duration &&
          !_navigating) {
        _goToLogin();
      }
    });
  }

  void _goToLogin() {
    if (_navigating) return;
    _navigating = true;
    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => const LoginPage(),
          settings: const RouteSettings(name: '/login'),
        ),
      );
    }
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: _goToLogin,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Video background
            if (_isInitialized && _videoController.value.isInitialized)
              SizedBox.expand(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                ),
              )
            else
              Container(
                color: _LC.bg,
                child: const Center(
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Color(0xFF7FE7B8),
                  ),
                ),
              ),

            // Dark overlay at bottom for skip text
            Positioned(
              left: 0, right: 0, bottom: 0,
              child: Container(
                height: 120,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.6),
                    ],
                  ),
                ),
              ),
            ),

            // Skip hint text
            if (_isInitialized)
              Positioned(
                bottom: 48,
                left: 0, right: 0,
                child: Center(
                  child: Text(
                    'TAP UNTUK SKIP',
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 10,
                      letterSpacing: 3,
                      color: Colors.white.withOpacity(0.35),
                    ),
                  ),
                ),
              ),

            // Brand watermark (subtle)
            if (_isInitialized)
              Positioned(
                top: 48, left: 0, right: 0,
                child: Center(
                  child: Text(
                    'YakuzaXsilence',
                    style: TextStyle(
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 6,
                      color: Colors.white.withOpacity(0.08),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}