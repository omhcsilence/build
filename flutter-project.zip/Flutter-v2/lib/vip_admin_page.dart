// vip_admin_page.dart — Owner-side VIP request management
//
// Owner bisa:
// - Lihat list request VIP (filter by status: pending/approved/rejected/all)
// - Lihat detail request (username, paket, harga, IP, waktu)
// - Preview bukti transfer image
// - Approve → user role jadi vip + extend expiredDate
// - Reject → kasih alasan

import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class _VAC {
  // TRANTOR Color Scheme (light, premium fintech — lavender accents for VIP)
  static const bg        = Color(0xFFFFFFFF);
  static const bg2       = Color(0xFFFAFAFA);
  static const surface   = Color(0xFFF5F5F7);
  static const card      = Color(0xFFF5F5F7);
  static const gold      = Color(0xFFE8D5FF);
  static const goldDim   = Color(0xFFC7C7CC);
  static const purple    = Color(0xFF7FE7B8);
  static const text      = Color(0xFF000000);
  static const textSub   = Color(0xFF8E8E93);
  static const muted     = Color(0xFFAEAEB2);
  static const muted2    = Color(0xFFC7C7CC);
  static const border    = Color(0xFFE5E5EA);
  static const border2   = Color(0xFFD1D1D6);
  static const danger    = Color(0xFFFF3B30);
  static const success   = Color(0xFF34C759);
}

class VipAdminPage extends StatefulWidget {
  final String sessionKey;
  const VipAdminPage({super.key, required this.sessionKey});

  @override
  State<VipAdminPage> createState() => _VipAdminPageState();
}

class _VipAdminPageState extends State<VipAdminPage>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  static const String _baseUrl = "https://omhc-host-premium.yakuza.biz.id";

  List<dynamic> _requests = [];
  bool _isLoading = false;
  String _filterStatus = 'pending'; // pending | approved | rejected | all
  Timer? _refreshTimer;

  final List<Map<String, String>> _filters = [
    {'id': 'pending',  'label': 'PENDING'},
    {'id': 'approved', 'label': 'APPROVED'},
    {'id': 'rejected', 'label': 'REJECTED'},
    {'id': 'all',      'label': 'ALL'},
  ];

  @override
  void initState() {
    super.initState();
    _initBgVideo();
    _fetchRequests();
    // Auto-refresh tiap 10 detik biar owner selalu tau ada request baru
    _refreshTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      if (mounted) _fetchRequests();
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _bgVideoController.dispose();
    super.dispose();
  }

  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ── API ───────────────────────────────────────────────────────────────────

  Future<void> _fetchRequests() async {
    if (_isLoading) return;
    setState(() => _isLoading = true);
    try {
      final res = await http
          .get(Uri.parse(
              "$_baseUrl/listVipRequests?key=${widget.sessionKey}&status=$_filterStatus"))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _requests = data['requests'] ?? []);
        } else {
          _showSnack(data['message'] ?? 'Gagal memuat', isError: true);
        }
      }
    } catch (e) {
      _showSnack('Connection error', isError: true);
    }
    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _approve(String requestId) async {
    final confirmed = await _showConfirmDialog(
      title: 'Approve VIP Request?',
      message: 'User akan langsung di-upgrade ke VIP. Lanjutkan?',
      confirmLabel: 'APPROVE',
      confirmColor: _VAC.success,
    );
    if (confirmed != true) return;

    setState(() => _isLoading = true);
    try {
      final res = await http
          .post(
            Uri.parse("$_baseUrl/approveVip"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'key': widget.sessionKey, 'requestId': requestId}),
          )
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showSnack('Request approved — user upgraded to VIP');
        _fetchRequests();
      } else {
        _showSnack(data['message'] ?? 'Gagal approve', isError: true);
      }
    } catch (_) {
      _showSnack('Connection error', isError: true);
    }
    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _reject(String requestId) async {
    final reasonController = TextEditingController(text: 'Pembayaran tidak valid');
    final reason = await _showRejectDialog(reasonController);
    if (reason == null) return;

    setState(() => _isLoading = true);
    try {
      final res = await http
          .post(
            Uri.parse("$_baseUrl/rejectVip"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'requestId': requestId,
              'reason': reason,
            }),
          )
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showSnack('Request rejected');
        _fetchRequests();
      } else {
        _showSnack(data['message'] ?? 'Gagal reject', isError: true);
      }
    } catch (_) {
      _showSnack('Connection error', isError: true);
    }
    if (mounted) setState(() => _isLoading = false);
  }

  void _showProofImage(String requestId) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(16),
        child: Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: InteractiveViewer(
                child: Image.network(
                  "$_baseUrl/vipProof?key=${widget.sessionKey}&id=$requestId",
                  fit: BoxFit.contain,
                  loadingBuilder: (ctx, child, prog) {
                    if (prog == null) return child;
                    return Container(
                      color: Colors.black,
                      height: 400,
                      child: Center(
                        child: CircularProgressIndicator(
                          color: _VAC.gold,
                          strokeWidth: 2,
                          value: prog.expectedTotalBytes != null
                              ? prog.cumulativeBytesLoaded /
                                  prog.expectedTotalBytes!
                              : null,
                        ),
                      ),
                    );
                  },
                  errorBuilder: (ctx, e, _) => Container(
                    color: Colors.black,
                    height: 300,
                    child: const Center(
                      child: Text('Gagal load bukti',
                          style: TextStyle(color: Colors.white54)),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 0, right: 0,
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    color: Colors.black87,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.close, color: Colors.white, size: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(
              color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor:
          isError ? _VAC.danger.withOpacity(0.92) : _VAC.success.withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  Future<bool?> _showConfirmDialog({
    required String title,
    required String message,
    required String confirmLabel,
    required Color confirmColor,
  }) {
    return showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _VAC.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: confirmColor.withOpacity(0.4)),
        ),
        title: Text(title,
            style: TextStyle(
              color: _VAC.text,
              fontFamily: 'MADEEvolveSansEVO',
              fontSize: 14,
              fontWeight: FontWeight.bold,
            )),
        content: Text(message,
            style: TextStyle(
              color: _VAC.muted,
              fontFamily: 'ShareTechMono',
              fontSize: 11,
              height: 1.5,
            )),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('BATAL',
                style: TextStyle(color: _VAC.muted, fontSize: 11)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: confirmColor,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            child: Text(confirmLabel,
                style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 11,
                    fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<String?> _showRejectDialog(TextEditingController controller) {
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _VAC.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: _VAC.danger, width: 1),
        ),
        title: Text('Reject Request',
            style: TextStyle(
              color: _VAC.text,
              fontFamily: 'MADEEvolveSansEVO',
              fontSize: 14,
              fontWeight: FontWeight.bold,
            )),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Alasan penolakan (akan ditampilkan ke user):',
                style: TextStyle(
                  color: _VAC.muted,
                  fontFamily: 'ShareTechMono',
                  fontSize: 10,
                )),
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              style: TextStyle(color: _VAC.text, fontSize: 12),
              maxLines: 2,
              decoration: InputDecoration(
                filled: true,
                fillColor: _VAC.surface,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: _VAC.border2)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: _VAC.danger, width: 1.5)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, null),
            child: Text('BATAL',
                style: TextStyle(color: _VAC.muted, fontSize: 11)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            style: ElevatedButton.styleFrom(
              backgroundColor: _VAC.danger,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('REJECT',
                style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 11,
                    fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  String _formatRupiah(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp $buf';
  }

  String _formatDate(String? iso) {
    if (iso == null) return '-';
    try {
      final d = DateTime.parse(iso);
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }

  // ── BUILD ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFFFFFFF), Color(0xFFFAFAFA), Color(0xFFF5F5F7)],
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.65)),
        Scaffold(
          backgroundColor: Colors.transparent,
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: _VAC.card.withOpacity(0.5), shape: BoxShape.circle),
              child: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new,
                    color: _VAC.gold, size: 18),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(FontAwesomeIcons.crown, color: _VAC.gold, size: 16),
                const SizedBox(width: 8),
                Text("VIP REQUESTS",
                    style: TextStyle(
                        color: _VAC.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        fontSize: 15)),
              ],
            ),
            centerTitle: true,
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: GestureDetector(
                  onTap: _isLoading ? null : _fetchRequests,
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: _VAC.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _VAC.border2),
                    ),
                    child: Icon(Icons.refresh, color: _VAC.gold, size: 16),
                  ),
                ),
              ),
            ],
            flexibleSpace: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(color: _VAC.bg.withOpacity(0.4)),
              ),
            ),
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.4,
                colors: [_VAC.gold.withOpacity(0.06), _VAC.bg.withOpacity(0.0)],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildFilterChips(),
                  const SizedBox(height: 12),
                  Expanded(
                    child: _isLoading && _requests.isEmpty
                        ? Center(
                            child: CircularProgressIndicator(
                                color: _VAC.gold, strokeWidth: 2.5))
                        : _requests.isEmpty
                            ? _buildEmptyState()
                            : RefreshIndicator(
                                color: _VAC.gold,
                                onRefresh: _fetchRequests,
                                child: ListView.builder(
                                  padding: const EdgeInsets.fromLTRB(14, 4, 14, 32),
                                  itemCount: _requests.length,
                                  itemBuilder: (ctx, i) =>
                                      _buildRequestCard(_requests[i]),
                                ),
                              ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFilterChips() {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
      child: Row(
        children: _filters.map((f) {
          final selected = _filterStatus == f['id'];
          return Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() => _filterStatus = f['id']!);
                _fetchRequests();
              },
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 3),
                padding: const EdgeInsets.symmetric(vertical: 9),
                decoration: BoxDecoration(
                  color: selected ? _VAC.gold.withOpacity(0.18) : _VAC.card,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                      color: selected ? _VAC.gold : _VAC.border2, width: 1),
                ),
                child: Text(f['label']!,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: selected ? _VAC.gold : _VAC.muted,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    )),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(FontAwesomeIcons.inbox, color: _VAC.muted2, size: 40),
          const SizedBox(height: 14),
          Text('No requests',
              style: TextStyle(
                  color: _VAC.muted,
                  fontFamily: 'ShareTechMono',
                  fontSize: 12)),
          const SizedBox(height: 4),
          Text('Belum ada request VIP pada filter ini',
              style: TextStyle(
                  color: _VAC.muted2,
                  fontFamily: 'ShareTechMono',
                  fontSize: 10)),
        ],
      ),
    );
  }

  Widget _buildRequestCard(Map<String, dynamic> r) {
    final status = r['status'] as String? ?? 'pending';
    Color statusColor;
    String statusLabel;
    switch (status) {
      case 'approved':
        statusColor = _VAC.success;
        statusLabel = 'APPROVED';
        break;
      case 'rejected':
        statusColor = _VAC.danger;
        statusLabel = 'REJECTED';
        break;
      default:
        statusColor = _VAC.gold;
        statusLabel = 'PENDING';
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _VAC.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: statusColor.withOpacity(0.25), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [_VAC.gold, _VAC.goldDim]),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(FontAwesomeIcons.crown,
                    color: Colors.black, size: 14),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r['username'] as String? ?? '-',
                        style: TextStyle(
                          color: _VAC.text,
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        )),
                    const SizedBox(height: 2),
                    Text('${r['packageLabel'] as String? ?? '-'} • ${_formatRupiah(r['price'] as int? ?? 0)}',
                        style: TextStyle(
                          color: _VAC.textSub,
                          fontFamily: 'ShareTechMono',
                          fontSize: 10,
                        )),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: statusColor.withOpacity(0.4)),
                ),
                child: Text(statusLabel,
                    style: TextStyle(
                      color: statusColor,
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    )),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Details
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _VAC.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _VAC.border2),
            ),
            child: Column(
              children: [
                _detailRow('IP Address', r['ip'] as String? ?? '-'),
                const SizedBox(height: 5),
                _detailRow('Tanggal', _formatDate(r['createdAt'] as String?)),
                if (r['decidedAt'] != null) ...[
                  const SizedBox(height: 5),
                  _detailRow('Decided', _formatDate(r['decidedAt'] as String?)),
                ],
                if (r['decidedBy'] != null) ...[
                  const SizedBox(height: 5),
                  _detailRow('By', r['decidedBy'] as String? ?? '-'),
                ],
                if (status == 'rejected' && r['rejectReason'] != null) ...[
                  const SizedBox(height: 5),
                  _detailRow('Alasan', r['rejectReason'] as String? ?? '-',
                      valueColor: _VAC.danger),
                ],
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Action buttons
          if (status == 'pending')
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => _showProofImage(r['id'] as String),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 11),
                      decoration: BoxDecoration(
                        color: _VAC.surface,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _VAC.border2),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(FontAwesomeIcons.image,
                              color: _VAC.gold, size: 12),
                          const SizedBox(width: 6),
                          Text('LIHAT BUKTI',
                              style: TextStyle(
                                color: _VAC.gold,
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              )),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _reject(r['id'] as String),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 11),
                      decoration: BoxDecoration(
                        color: _VAC.danger.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _VAC.danger.withOpacity(0.4)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(FontAwesomeIcons.xmark,
                              color: _VAC.danger, size: 12),
                          const SizedBox(width: 6),
                          Text('REJECT',
                              style: TextStyle(
                                color: _VAC.danger,
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              )),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _approve(r['id'] as String),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 11),
                      decoration: BoxDecoration(
                        color: _VAC.success,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                              color: _VAC.success.withOpacity(0.3),
                              blurRadius: 10),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(FontAwesomeIcons.check,
                              color: Colors.black, size: 12),
                          const SizedBox(width: 6),
                          Text('APPROVE',
                              style: TextStyle(
                                color: Colors.black,
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              )),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            )
          else
            // Untuk request yang sudah decided, tetap kasih tombol "Lihat Bukti"
            GestureDetector(
              onTap: () => _showProofImage(r['id'] as String),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 11),
                decoration: BoxDecoration(
                  color: _VAC.surface,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _VAC.border2),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(FontAwesomeIcons.image, color: _VAC.gold, size: 12),
                    const SizedBox(width: 6),
                    Text('LIHAT BUKTI TRANSFER',
                        style: TextStyle(
                          color: _VAC.gold,
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        )),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _detailRow(String label, String value, {Color? valueColor}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 80,
          child: Text('[$label]',
              style: TextStyle(
                color: _VAC.muted2,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
              )),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(value,
              style: TextStyle(
                color: valueColor ?? _VAC.text,
                fontFamily: 'ShareTechMono',
                fontSize: 11,
              )),
        ),
      ],
    );
  }
}
