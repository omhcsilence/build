import 'dart:math' as math;
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';

class MapService {
  /// Membangun dunia open world dengan banyak bangunan, jalan, pohon, dan lampu.
  static WorldState generateWorld() {
    final rng = math.Random(42);
    final buildings = <Building>[];
    final roads = <Road>[];
    final collectibles = <Collectible>[];
    final trees = <Tree>[];
    final streetLights = <StreetLight>[];

    // ============================================================
    // GRID KOTA: Blok-blok perkotaan dengan variasi
    // Setiap blok punya bangunan di sepanjang jalan
    // ============================================================
    const gridSize = 8; // 8x8 blok
    const blockSize = 30.0; // jarak antar blok
    const roadWidth = 6.0;
    const halfRoad = roadWidth / 2.0;

    final buildingTypes = BuildingType.values;
    final buildingNames = [
      'Kedai Kopi Pak Budi', 'Toko Batik Malang', 'Warung Rujak Bu Eni',
      'RM Padang Jaya', 'Apotek Sehat', 'Bengkel Motor Maju',
      'Toko Elektronik', 'Laundry Kilat', 'Salon Cantik',
      'Kantor Pos', 'Masjid Al-Ikhlas', 'Sekolah Dasar 03',
      'Puskesmas Remujung', 'Toko Buku Ilmu', 'Rumah Makan Sego Tempong',
      'Kedai Mokka (Pusat)', 'Toko Buah Segar', 'Bakso Pak Kumis',
      'Mini Market', 'Depot Ayam Goreng', 'Gudang Logistik',
      'Rumah Tinggal A1', 'Rumah Tinggal A2', 'Rumah Tinggal A3',
      'Ruko Malang Indah', 'Gedung Serbaguna', 'Klinik Utama',
      'Toko Material', 'Showroom Motor', 'Kantor Desa',
      'Warung Nasi Bu Siti', 'Toko Roti bakery', 'Pangkas Rambut',
      'Toko Pakaian', 'Rental PS', 'ATM Center', 'Toko Galeri',
      'Rumah Makan Seafood', 'Toko Susu', 'Lab Komputer',
      'Gedung Olahraga', 'Toko Bangunan', 'Pabrik Tahu',
      'Toko Mainan', 'Kantin Sekolah', 'Perpustakaan',
      'Ruko Baru 01', 'Ruko Baru 02', 'Ruko Baru 03',
      'Rumah Warga B1', 'Rumah Warga B2', 'Rumah Warga B3',
      'Toko Kelontong', 'Warung Tegal', 'Pom Bensin Mini',
      'Gedung PGRI', 'Toko Online Hub', 'Studio Musik',
    };

    final wallTextures = [
      TextureInfo.brick,
      TextureInfo.plaster,
      TextureInfo.tile,
      TextureInfo.wood,
    ];

    int bIdx = 0;
    for (int gx = -gridSize ~/ 2; gx < gridSize ~/ 2; gx++) {
      for (int gz = -gridSize ~/ 2; gz < gridSize ~/ 2; gz++) {
        final blockCenterX = gx * blockSize + (rng.nextDouble() - 0.5) * 6;
        final blockCenterZ = gz * blockSize + (rng.nextDouble() - 0.5) * 6;

        // 1-3 bangunan per blok
        final count = 1 + rng.nextInt(3);
        for (int i = 0; i < count; i++) {
          final ox = (rng.nextDouble() - 0.5) * (blockSize * 0.6);
          final oz = (rng.nextDouble() - 0.5) * (blockSize * 0.6);
          final px = blockCenterX + ox;
          final pz = blockCenterZ + oz;

          // Skip jika terlalu dekat pusat (spawn point)
          if (px.abs() < 5 && pz.abs() < 5) continue;

          final bType = buildingTypes[rng.nextInt(buildingTypes.length)];
          final w = 4.0 + rng.nextDouble() * 10.0;
          final floors = 1 + rng.nextInt(bType == BuildingType.gedungTinggi ? 8 : 3);
          final h = floors * (3.0 + rng.nextDouble() * 1.5);
          final d = 4.0 + rng.nextDouble() * 10.0;

          // Warna berdasarkan tipe
          int color;
          switch (bType) {
            case BuildingType.rumahJatimulyo:
              color = [0xFFD7CCC8, 0xFFBCAAA4, 0xFFEFEBE9, 0xFFF5F5F5][rng.nextInt(4)];
              break;
            case BuildingType.rukoKomersial:
              color = [0xFFB0BEC5, 0xFF90A4AE, 0xFF78909C, 0xFFCFD8DC][rng.nextInt(4)];
              break;
            case BuildingType.gedungTinggi:
              color = [0xFF37474F, 0xFF455A64, 0xFF546E7A, 0xFF607D8B][rng.nextInt(4)];
              break;
            case BuildingType.masjid:
              color = 0xFFF5F5F5;
              break;
            case BuildingType.warungKopi:
              color = [0xFF8D6E63, 0xFF795548, 0xFF6D4C41][rng.nextInt(3)];
              break;
            case BuildingType.toko:
              color = [0xFFE0E0E0, 0xFFEEEEEE, 0xFFF5F5F5][rng.nextInt(3)];
              break;
            case BuildingType.gedungPemerintah:
              color = 0xFFECEFF1;
              break;
            case BuildingType.rumahSakit:
              color = 0xFFE3F2FD;
              break;
            case BuildingType.sekolah:
              color = [0xFFFFF9C4, 0xFFF0F4C3, 0xFFE8F5E9][rng.nextInt(3)];
              break;
          }

          buildings.add(Building(
            id: 'b$bIdx',
            name: buildingNames[bIdx % buildingNames.length],
            position: v.Vector3(px, 0, pz),
            size: v.Vector3(w, h, d),
            colorHex: color,
            type: bType,
            wallTexture: wallTextures[rng.nextInt(wallTextures.length)],
            roofTexture: bType == BuildingType.masjid
                ? const TextureInfo(material: SurfaceMaterial.tile, tileScale: 3.0)
                : TextureInfo.flat,
            floors: floors,
            hasWindows: bType != BuildingType.masjid && bType != BuildingType.gudangLogistik,
          ));
          bIdx++;
        }

        // Pohon per blok (2-5 pohon)
        final treeCount = 2 + rng.nextInt(4);
        for (int t = 0; t < treeCount; t++) {
          final tx = blockCenterX + (rng.nextDouble() - 0.5) * blockSize * 0.8;
          final tz = blockCenterZ + (rng.nextDouble() - 0.5) * blockSize * 0.8;
          // Skip jika terlalu dekat bangunan
          bool tooClose = false;
          for (var b in buildings) {
            if ((b.position.x - tx).abs() < b.size.x / 2 + 1.5 &&
                (b.position.z - tz).abs() < b.size.z / 2 + 1.5) {
              tooClose = true;
              break;
            }
          }
          if (!tooClose) {
            trees.add(Tree(
              id: 'tree_${bIdx}_$t',
              position: v.Vector3(tx, 0, tz),
              trunkHeight: 2.5 + rng.nextDouble() * 3.0,
              canopyRadius: 1.5 + rng.nextDouble() * 2.5,
              canopyColorHex: [0xFF2E7D32, 0xFF388E3C, 0xFF1B5E20, 0xFF33691E][rng.nextInt(4)],
            ));
          }
        }
      }
    }

    // ============================================================
    // JALAN GRID
    // ============================================================
    for (int i = -gridSize ~/ 2; i <= gridSize ~/ 2; i++) {
      // Jalan horizontal (sepanjang sumbu X)
      roads.add(Road(
        id: 'rh_$i',
        start: v.Vector3(-gridSize.toDouble() * blockSize / 2, 0, i * blockSize.toDouble()),
        end: v.Vector3(gridSize.toDouble() * blockSize / 2, 0, i * blockSize.toDouble()),
        width: i == 0 ? 8.0 : roadWidth,
        roadType: i == 0 ? 'primary' : 'secondary',
      ));
      // Jalan vertikal (sepanjang sumbu Z)
      roads.add(Road(
        id: 'rv_$i',
        start: v.Vector3(i * blockSize.toDouble(), 0, -gridSize.toDouble() * blockSize / 2),
        end: v.Vector3(i * blockSize.toDouble(), 0, gridSize.toDouble() * blockSize / 2),
        width: i == 0 ? 8.0 : roadWidth,
        roadType: i == 0 ? 'primary' : 'secondary',
      ));
      // Lampu jalan di jalan utama
      if (i == 0 || i.abs() == 2) {
        for (double lx = -80; lx <= 80; lx += 20) {
          streetLights.add(StreetLight(
            id: 'sl_h_${i}_$lx',
            position: v.Vector3(lx, 0, i * blockSize.toDouble() + halfRoad + 1.5),
          ));
        }
        for (double lz = -80; lz <= 80; lz += 20) {
          streetLights.add(StreetLight(
            id: 'sl_v_${i}_$lz',
            position: v.Vector3(i * blockSize.toDouble() + halfRoad + 1.5, 0, lz),
          ));
        }
      }
    }

    // ============================================================
    // COLLECTIBLES tersebar di seluruh kota
    // ============================================================
    final cTypes = CollectibleType.values;
    for (int c = 0; c < 40; c++) {
      final cx = (rng.nextDouble() - 0.5) * gridSize * blockSize * 0.7;
      final cz = (rng.nextDouble() - 0.5) * gridSize * blockSize * 0.7;
      collectibles.add(Collectible(
        id: 'c$c',
        position: v.Vector3(cx, 1.2, cz),
        type: cTypes[c % cTypes.length],
        animOffset: rng.nextDouble() * math.pi * 2,
      ));
    }

    return WorldState(
      mapSize: gridSize.toDouble() * blockSize,
      buildings: buildings,
      roads: roads,
      collectibles: collectibles,
      trees: trees,
      streetLights: streetLights,
    );
  }
}