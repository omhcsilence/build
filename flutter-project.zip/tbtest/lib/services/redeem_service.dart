class RedeemService {
  static bool redeemCode(String code) {
    if (code.toUpperCase() == 'MOKKA3D') {
      return true;
    }
    return false;
  }
}
