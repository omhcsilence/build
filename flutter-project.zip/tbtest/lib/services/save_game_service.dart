class SaveGameService {
  static int highScore = 0;

  static void saveScore(int score) {
    if (score > highScore) {
      highScore = score;
    }
  }
}
