import 'package:vector_math/vector_math_64.dart' as v;

class PlayerData {
  v.Vector3 position;
  v.Vector3 velocity;
  double yaw; // Rotasi horizontal (dalam radian)
  double pitch; // Rotasi vertikal (dalam radian)
  bool isGrounded;
  int score;
  int health;

  PlayerData({
    v.Vector3? position,
    v.Vector3? velocity,
    this.yaw = 0.0,
    this.pitch = 0.0,
    this.isGrounded = true,
    this.score = 0,
    this.health = 100,
  })  : position = position ?? v.Vector3(0.0, 1.6, 0.0),
        velocity = velocity ?? v.Vector3.zero();
}
