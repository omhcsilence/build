import 'dart:math' as math;
import 'package:vector_math/vector_math_64.dart' as v;

/// Pengaturan grafik yang bisa diatur oleh pemain.
/// Mengontrol kualitas visual dan performa secara real-time.
class GraphicsSettings {
  int shadowQuality;
  double renderDistance;
  int textureQuality;
  bool antiAliasing;
  double fogDensity;
  double terrainDetail;
  bool dayNightCycle;
  double timeOfDay;
  bool specularLighting;
  bool ambientOcclusion;
  int fpsLimit;

  GraphicsSettings({
    this.shadowQuality = 2,
    this.renderDistance = 120.0,
    this.textureQuality = 2,
    this.antiAliasing = true,
    this.fogDensity = 0.6,
    this.terrainDetail = 4.0,
    this.dayNightCycle = true,
    this.timeOfDay = 0.5,
    this.specularLighting = true,
    this.ambientOcclusion = true,
    this.fpsLimit = 0,
  });

  factory GraphicsSettings.low() => GraphicsSettings(
    shadowQuality: 0,
    renderDistance: 60.0,
    textureQuality: 0,
    antiAliasing: false,
    fogDensity: 0.4,
    terrainDetail: 8.0,
    dayNightCycle: false,
    specularLighting: false,
    ambientOcclusion: false,
    fpsLimit: 30,
  );

  factory GraphicsSettings.medium() => GraphicsSettings(
    shadowQuality: 1,
    renderDistance: 100.0,
    textureQuality: 1,
    antiAliasing: true,
    fogDensity: 0.5,
    terrainDetail: 5.0,
    dayNightCycle: true,
    specularLighting: true,
    ambientOcclusion: false,
    fpsLimit: 60,
  );

  factory GraphicsSettings.high() => GraphicsSettings(
    shadowQuality: 3,
    renderDistance: 160.0,
    textureQuality: 2,
    antiAliasing: true,
    fogDensity: 0.7,
    terrainDetail: 3.0,
    dayNightCycle: true,
    specularLighting: true,
    ambientOcclusion: true,
    fpsLimit: 0,
  );

  factory GraphicsSettings.ultra() => GraphicsSettings(
    shadowQuality: 3,
    renderDistance: 250.0,
    textureQuality: 2,
    antiAliasing: true,
    fogDensity: 0.85,
    terrainDetail: 2.0,
    dayNightCycle: true,
    specularLighting: true,
    ambientOcclusion: true,
    fpsLimit: 0,
  );

  /// Warna langit berdasarkan timeOfDay -> [topR, topG, topB, botR, botG, botB]
  List<double> get skyColors {
    final t = timeOfDay;
    if (t < 0.2 || t > 0.8) {
      return [0.02, 0.02, 0.08, 0.05, 0.05, 0.12];
    } else if (t < 0.3) {
      final f = (t - 0.2) / 0.1;
      return [
        0.02 + f * 0.10, 0.02 + f * 0.50, 0.08 + f * 0.80,
        0.05 + f * 0.45, 0.05 + f * 0.70, 0.12 + f * 0.65,
      ];
    } else if (t < 0.7) {
      return [0.12, 0.53, 0.90, 0.53, 0.81, 0.92];
    } else {
      final f = (t - 0.7) / 0.1;
      return [
        0.12 - f * 0.08, 0.53 - f * 0.40, 0.90 - f * 0.80,
        0.53 - f * 0.30, 0.81 - f * 0.60, 0.92 - f * 0.72,
      ];
    }
  }

  /// Intensitas cahaya matahari (0=malam gelap, 1=siang penuh)
  double get sunIntensity {
    if (!dayNightCycle) return 1.0;
    final t = timeOfDay;
    if (t < 0.2 || t > 0.8) return 0.08;
    if (t < 0.3) return (t - 0.2) / 0.1;
    if (t > 0.7) return (0.8 - t) / 0.1;
    return 1.0;
  }

  /// Arah cahaya matahari (berubah seiring waktu)
  v.Vector3 get sunDirection {
    final angle = timeOfDay * 2.0 * math.pi;
    return v.Vector3(
      math.cos(angle) * 0.5,
      0.8 + 0.2 * math.sin(angle * 2.0),
      math.sin(angle) * 0.3,
    ).normalized();
  }

  /// Warna ambient berdasarkan waktu
  double get ambientLevel {
    return 0.15 + sunIntensity * 0.25;
  }
}
