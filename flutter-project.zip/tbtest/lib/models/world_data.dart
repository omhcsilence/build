import 'package:vector_math/vector_math_64.dart' as v;

enum CollectibleType { coffee, coin, star }

enum BuildingType {
  rumahJatimulyo,
  rukoKomersial,
  gedungTinggi,
  masjid,
  warungKopi,
  toko,
  gedungPemerintah,
  rumahSakit,
  sekolah,
}

/// Material permukaan untuk simulasi shading/texture
enum SurfaceMaterial {
  concrete,
  brick,
  wood,
  metal,
  glass,
  grass,
  asphalt,
  tile,
  plaster,
}

/// Info tekstur prosedural per polygon (tanpa file eksternal)
class TextureInfo {
  final SurfaceMaterial material;
  /// Skala berulang texture (semakin kecil = semakin detail)
  final double tileScale;
  /// Warna variasi untuk noise texture
  final double colorVariation;
  /// Tingkat kekasaran (roughness) untuk specular
  final double roughness;
  /// UV offset untuk animasi (misal air mengalir)
  final double uvOffset;

  const TextureInfo({
    this.material = SurfaceMaterial.concrete,
    this.tileScale = 1.0,
    this.colorVariation = 0.1,
    this.roughness = 0.7,
    this.uvOffset = 0.0,
  });

  static const flat = TextureInfo(material: SurfaceMaterial.concrete, tileScale: 0, colorVariation: 0, roughness: 1.0);
  static const brick = TextureInfo(material: SurfaceMaterial.brick, tileScale: 2.0, colorVariation: 0.15, roughness: 0.9);
  static const wood = TextureInfo(material: SurfaceMaterial.wood, tileScale: 1.5, colorVariation: 0.2, roughness: 0.6);
  static const metal = TextureInfo(material: SurfaceMaterial.metal, tileScale: 0, colorVariation: 0.05, roughness: 0.2);
  static const glass = TextureInfo(material: SurfaceMaterial.glass, tileScale: 0, colorVariation: 0.0, roughness: 0.05);
  static const grass = TextureInfo(material: SurfaceMaterial.grass, tileScale: 3.0, colorVariation: 0.2, roughness: 1.0);
  static const asphalt = TextureInfo(material: SurfaceMaterial.asphalt, tileScale: 2.0, colorVariation: 0.08, roughness: 0.95);
  static const tile = TextureInfo(material: SurfaceMaterial.tile, tileScale: 4.0, colorVariation: 0.05, roughness: 0.3);
}

class Building {
  final String id;
  final String name;
  final v.Vector3 position;
  final v.Vector3 size;
  final int colorHex;
  final BuildingType type;
  final TextureInfo wallTexture;
  final TextureInfo roofTexture;
  /// Jumlah lantai (untuk variasi visual)
  final int floors;
  /// Apakah punya jendela
  final bool hasWindows;

  Building({
    required this.id,
    required this.name,
    required this.position,
    required this.size,
    required this.colorHex,
    this.type = BuildingType.rumahJatimulyo,
    this.wallTexture = TextureInfo.flat,
    this.roofTexture = TextureInfo.flat,
    this.floors = 1,
    this.hasWindows = true,
  });
}

class Road {
  final String id;
  final v.Vector3 start;
  final v.Vector3 end;
  final double width;
  final TextureInfo texture;
  /// Jenis jalan
  final String roadType; // primary, secondary, residential

  Road({
    required this.id,
    required this.start,
    required this.end,
    required this.width,
    this.texture = TextureInfo.asphalt,
    this.roadType = 'residential',
  });
}

class Collectible {
  final String id;
  v.Vector3 position;
  final CollectibleType type;
  bool isCollected;
  double animOffset;

  Collectible({
    required this.id,
    required this.position,
    required this.type,
    this.isCollected = false,
    this.animOffset = 0.0,
  });
}

/// Pohon untuk dekorasi open world
class Tree {
  final String id;
  final v.Vector3 position;
  final double trunkHeight;
  final double canopyRadius;
  final int canopyColorHex;

  Tree({
    required this.id,
    required this.position,
    this.trunkHeight = 3.0,
    this.canopyRadius = 2.0,
    this.canopyColorHex = 0xFF2E7D32,
  });
}

/// Lampu jalan untuk pencahayaan malam hari
class StreetLight {
  final String id;
  final v.Vector3 position;
  final double height;
  final double radius;

  StreetLight({
    required this.id,
    required this.position,
    this.height = 5.0,
    this.radius = 12.0,
  });
}

class WorldState {
  final double mapSize;
  final List<Building> buildings;
  final List<Road> roads;
  final List<Collectible> collectibles;
  final List<Tree> trees;
  final List<StreetLight> streetLights;

  WorldState({
    required this.mapSize,
    required this.buildings,
    required this.roads,
    required this.collectibles,
    this.trees = const [],
    this.streetLights = const [],
  });
}
