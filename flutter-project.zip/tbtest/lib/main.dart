import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/game_screen_3d.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const KdmStudioApp());
}

class KdmStudioApp extends StatelessWidget {
  const KdmStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KDM Studio 3D',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const GameScreen3D(),
    );
  }
}
