import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;

import '../camera/camera_3d.dart';
import '../models/world_data.dart';
import '../models/graphics_settings.dart';
import '../render/pipeline_3d.dart';

class WorldPainter3D extends CustomPainter {
  final Camera3D camera;
  final WorldState worldState;
  final v.Vector3 playerPos;
  final GraphicsSettings settings;
  final double gameTime; // untuk animasi

  WorldPainter3D({
    required this.camera,
    required this.worldState,
    required this.playerPos,
    required this.settings,
    this.gameTime = 0.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final viewMatrix = camera.getViewMatrix();
    final projMatrix = camera.getProjectionMatrix(size.width / size.height);
    final viewProjection = projMatrix * viewMatrix;

    // 1. Sky
    _drawSky(canvas, size);

    // 2. Kumpulkan semua polygon
    final polygons = <Polygon3D>[];

    _generateTerrainPolygons(polygons);
    _generateRoadPolygons(polygons);
    _generateBuildingPolygons(polygons);
    _generateTreePolygons(polygons);
    _generateCollectiblePolygons(polygons);

    // 3. Shadow map pre-computation
    final shadowMap = Pipeline3D.computeShadowMap(
      worldState.buildings,
      settings.sunDirection,
      settings.shadowQuality.toDouble(),
      settings.renderDistance,
    );

    // 4. Process (cull + sort)
    final sorted = Pipeline3D.processPolygons(
      polygons: polygons,
      camera: camera,
      renderDistance: settings.renderDistance,
      viewProjection: viewProjection,
    );

    // 5. Render setiap polygon
    final lightDir = settings.sunDirection;
    final sunInt = settings.sunIntensity;
    final skyC = settings.skyColors;
    final fogColor = Color.fromARGB(255,
      (skyC[3] * 255).clamp(0, 255).toInt(),
      (skyC[4] * 255).clamp(0, 255).toInt(),
      (skyC[5] * 255).clamp(0, 255).toInt(),
    );

    for (var poly in sorted) {
      final screenPoints = <Offset>[];
      bool isVisible = true;

      for (var vertex in poly.worldVertices) {
        final sp = Pipeline3D.projectVertex(vertex, viewProjection, size);
        if (sp == null) {
          isVisible = false;
          break;
        }
        screenPoints.add(sp);
      }
      if (!isVisible || screenPoints.length < 3) continue;

      // ---- SHADER PIPELINE ----

      // A) Base color
      Color baseColor = poly.color;

      // B) Procedural texture
      if (poly.texture != null && settings.textureQuality > 0) {
        // Gunakan posisi rata-rata polygon untuk UV sampling
        final cx = poly.worldVertices.fold(0.0, (s, v2) => s + v2.x) / poly.worldVertices.length;
        final cy = poly.worldVertices.fold(0.0, (s, v2) => s + v2.y) / poly.worldVertices.length;
        final cz = poly.worldVertices.fold(0.0, (s, v2) => s + v2.z) / poly.worldVertices.length;
        baseColor = Pipeline3D.applyProceduralTexture(
          baseColor, poly.texture!, cx, cy, cz, settings.textureQuality,
        );
      }

      // C) Phong shading (ambient + diffuse + specular)
      Color shadedColor;
      if (poly.isTree) {
        // Pohon: pencahayaan lebih lembut
        final dot2 = poly.normal.dot(lightDir);
        final lightI = (dot2.clamp(0.0, 1.0) * 0.5 * sunInt) + (0.3 + sunInt * 0.2);
        shadedColor = Color.from(
          alpha: 255,
          red: (baseColor.red * lightI).clamp(0, 255).toInt(),
          green: (baseColor.green * lightI).clamp(0, 255).toInt(),
          blue: (baseColor.blue * lightI).clamp(0, 255).toInt(),
        );
      } else {
        shadedColor = Pipeline3D.phongShade(
          baseColor,
          poly.normal,
          poly.worldVertices[0],
          camera.position,
          lightDir,
          settings.ambientLevel,
          poly.texture,
          settings.specularLighting,
        );
      }

      // D) Soft shadows (untuk ground polygons)
      if (poly.normal.y > 0.5 && shadowMap.isNotEmpty && poly.castShadow) {
        final cx = poly.worldVertices.fold(0.0, (s, v2) => s + v2.x) / poly.worldVertices.length;
        final cz = poly.worldVertices.fold(0.0, (s, v2) => s + v2.z) / poly.worldVertices.length;
        final shadowVal = Pipeline3D.getShadowAt(cx, cz, shadowMap);
        if (shadowVal > 0) {
          shadedColor = Color.from(
            alpha: 255,
            red: (shadedColor.red * (1.0 - shadowVal)).clamp(0, 255).toInt(),
            green: (shadedColor.green * (1.0 - shadowVal)).clamp(0, 255).toInt(),
            blue: (shadedColor.blue * (1.0 - shadowVal)).clamp(0, 255).toInt(),
          );
        }
      }

      // E) Ambient occlusion
      if (settings.ambientOcclusion && poly.normal.y < 0.5) {
        final cx = poly.worldVertices.fold(0.0, (s, v2) => s + v2.x) / poly.worldVertices.length;
        final cy = poly.worldVertices.fold(0.0, (s, v2) => s + v2.y) / poly.worldVertices.length;
        final cz = poly.worldVertices.fold(0.0, (s, v2) => s + v2.z) / poly.worldVertices.length;
        final ao = Pipeline3D.approximateAO(cx, cy, cz);
        shadedColor = Color.from(
          alpha: 255,
          red: (shadedColor.red * (1.0 - ao)).clamp(0, 255).toInt(),
          green: (shadedColor.green * (1.0 - ao)).clamp(0, 255).toInt(),
          blue: (shadedColor.blue * (1.0 - ao)).clamp(0, 255).toInt(),
        );
      }

      // F) Distance fog
      final fogFactor = (poly.distanceToCamera / (settings.renderDistance * 0.8)).clamp(0.0, 0.92) * settings.fogDensity;
      final finalColor = Color.lerp(shadedColor, fogColor, fogFactor)!;

      // G) Draw polygon
      final path = Path()..moveTo(screenPoints[0].dx, screenPoints[0].dy);
      for (int i = 1; i < screenPoints.length; i++) {
        path.lineTo(screenPoints[i].dx, screenPoints[i].dy);
      }
      path.close();

      final paint = Paint()
        ..color = finalColor
        ..style = PaintingStyle.fill;

      // Anti-aliasing
      if (settings.antiAliasing) {
        paint.strokeWidth = 0.5;
        paint.style = PaintingStyle.strokeAndFill;
        paint.strokeColor = finalColor;
      }

      canvas.drawPath(path, paint);

      // H) Subtle wireframe untuk bangunan (bukan terrain)
      if (!poly.isTree && poly.normal.y.abs() < 0.5) {
        canvas.drawPath(
          path,
          Paint()
            ..color = Colors.black.withOpacity(0.08)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 0.5,
        );
      }
    }

    // 6. Street lights (malam hari)
    if (settings.dayNightCycle && settings.sunIntensity < 0.5) {
      _drawStreetLightGlows(canvas, viewProjection, size);
    }
  }

  // ============================================================
  // SKY dengan gradient dinamis (day/night)
  // ============================================================
  void _drawSky(Canvas canvas, Size size) {
    final c = settings.skyColors;
    final top = Color.fromARGB(255,
      (c[0] * 255).clamp(0, 255).toInt(),
      (c[1] * 255).clamp(0, 255).toInt(),
      (c[2] * 255).clamp(0, 255).toInt(),
    );
    final bot = Color.fromARGB(255,
      (c[3] * 255).clamp(0, 255).toInt(),
      (c[4] * 255).clamp(0, 255).toInt(),
      (c[5] * 255).clamp(0, 255).toInt(),
    );
    final skyPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [top, bot],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), skyPaint);

    // Bintang malam hari
    if (settings.dayNightCycle && settings.sunIntensity < 0.2) {
      final starPaint = Paint()..color = Colors.white.withOpacity(0.8);
      final rng = math.Random(12345);
      for (int i = 0; i < 60; i++) {
        final sx = rng.nextDouble() * size.width;
        final sy = rng.nextDouble() * size.height * 0.5;
        final sr = 0.5 + rng.nextDouble() * 1.5;
        final twinkle = (math.sin(gameTime * 2 + i) * 0.5 + 0.5);
        starPaint.color = Colors.white.withOpacity(twinkle * 0.8 * (1.0 - settings.sunIntensity * 5));
        canvas.drawCircle(Offset(sx, sy), sr, starPaint);
      }
    }
  }

  // ============================================================
  // TERRAIN dengan height map noise
  // ============================================================
  void _generateTerrainPolygons(List<Polygon3D> polygons) {
    final step = settings.terrainDetail;
    final limit = settings.renderDistance * 0.7;
    final camX = camera.position.x;
    final camZ = camera.position.z;
    final startX = (camX / step).floor() * step;
    final startZ = (camZ / step).floor() * step;

    for (double x = startX - limit; x < startX + limit; x += step) {
      for (double z = startZ - limit; z < startZ + limit; z += step) {
        final h1 = Pipeline3D.getTerrainHeight(x, z);
        final h2 = Pipeline3D.getTerrainHeight(x + step, z);
        final h3 = Pipeline3D.getTerrainHeight(x + step, z + step);
        final h4 = Pipeline3D.getTerrainHeight(x, z + step);

        final v1 = v.Vector3(x, h1, z);
        final v2 = v.Vector3(x + step, h2, z);
        final v3 = v.Vector3(x + step, h3, z + step);
        final v4 = v.Vector3(x, h4, z + step);

        final center = (v1 + v3) * 0.5;
        final dist = camera.position.distanceTo(center);
        if (dist > settings.renderDistance) continue;

        // Hitung normal dari cross product untuk terrain miring
        final edge1 = v2 - v1;
        final edge2 = v4 - v1;
        final normal = edge1.cross(edge2).normalized();

        // Warna rumput bervariasi
        final grassNoise = Pipeline3D.fbm(x * 0.05, z * 0.05, 2);
        final g = 140 + (grassNoise * 60).toInt();
        final r = 50 + (grassNoise * 30).toInt();
        final b2 = 30 + (grassNoise * 20).toInt();

        polygons.add(Polygon3D(
          worldVertices: [v1, v2, v3, v4],
          color: Color.fromARGB(255, r, g, b2),
          normal: normal,
          distanceToCamera: dist,
          texture: TextureInfo.grass,
        ));
      }
    }
  }

  // ============================================================
  // ROADS dengan tekstur aspal
  // ============================================================
  void _generateRoadPolygons(List<Polygon3D> polygons) {
    for (var road in worldState.roads) {
      final dir = (road.end - road.start).normalized();
      final perp = v.Vector3(-dir.z, 0, dir.x) * (road.width / 2.0);
      final h = Pipeline3D.getTerrainHeight(road.start.x, road.start.z);

      final v1 = road.start - perp + v.Vector3(0, h + 0.02, 0);
      final v2 = road.start + perp + v.Vector3(0, h + 0.02, 0);
      final v3 = road.end + perp + v.Vector3(0, h + 0.02, 0);
      final v4 = road.end - perp + v.Vector3(0, h + 0.02, 0);

      final center = (v1 + v3) * 0.5;
      final dist = camera.position.distanceTo(center);
      if (dist > settings.renderDistance) continue;

      // Garis tengah jalan (road marking)
      final isPrimary = road.roadType == 'primary';

      polygons.add(Polygon3D(
        worldVertices: [v1, v2, v3, v4],
        color: isPrimary ? const Color(0xFF3A3A3A) : const Color(0xFF4A4A4A),
        normal: v.Vector3(0, 1, 0),
        distanceToCamera: dist,
        texture: TextureInfo.asphalt,
      ));

      // Road markings (hanya jika texture quality > 0)
      if (settings.textureQuality > 0) {
        _addRoadMarkings(polygons, road, h, dist);
      }
    }
  }

  void _addRoadMarkings(List<Polygon3D> polygons, Road road, double h, double roadDist) {
    final dir = (road.end - road.start);
    final len = dir.length;
    final dirN = dir.normalized();
    final perp = v.Vector3(-dirN.z, 0, dirN.x);

    // Garis putus-putus di tengah
    final dashLen = 2.0;
    final gapLen = 3.0;
    for (double d = 0; d < len; d += dashLen + gapLen) {
      final p1 = road.start + dirN * d + perp * 0.1 + v.Vector3(0, h + 0.04, 0);
      final p2 = road.start + dirN * d + perp * (-0.1) + v.Vector3(0, h + 0.04, 0);
      final p3 = road.start + dirN * (d + dashLen) + perp * (-0.1) + v.Vector3(0, h + 0.04, 0);
      final p4 = road.start + dirN * (d + dashLen) + perp * 0.1 + v.Vector3(0, h + 0.04, 0);

      final c = (p1 + p3) * 0.5;
      polygons.add(Polygon3D(
        worldVertices: [p1, p2, p3, p4],
        color: const Color(0xFFEEEEEE),
        normal: v.Vector3(0, 1, 0),
        distanceToCamera: camera.position.distanceTo(c),
        castShadow: false,
      ));
    }
  }

  // ============================================================
  // BUILDINGS dengan jendela, variasi atap, dan multi-floors
  // ============================================================
  void _generateBuildingPolygons(List<Polygon3D> polygons) {
    for (var b in worldState.buildings) {
      final hw = b.size.x / 2.0;
      final h = b.size.y;
      final hd = b.size.z / 2.0;
      final pos = b.position;
      final terrainH = Pipeline3D.getTerrainHeight(pos.x, pos.z);
      final baseY = terrainH;
      final dist = camera.position.distanceTo(pos);
      if (dist > settings.renderDistance) continue;

      // 8 vertices box
      final p = [
        v.Vector3(pos.x - hw, baseY, pos.z - hd),
        v.Vector3(pos.x + hw, baseY, pos.z - hd),
        v.Vector3(pos.x + hw, baseY, pos.z + hd),
        v.Vector3(pos.x - hw, baseY, pos.z + hd),
        v.Vector3(pos.x - hw, baseY + h, pos.z - hd),
        v.Vector3(pos.x + hw, baseY + h, pos.z - hd),
        v.Vector3(pos.x + hw, baseY + h, pos.z + hd),
        v.Vector3(pos.x - hw, baseY + h, pos.z + hd),
      ];

      final baseColor = Color(b.colorHex);
      final wallTex = b.wallTexture;
      final roofTex = b.roofTexture;

      // 4 dinding
      _addTexturedQuad(polygons, p[0], p[1], p[5], p[4], v.Vector3(0, 0, -1), baseColor, wallTex, dist);
      _addTexturedQuad(polygons, p[2], p[3], p[7], p[6], v.Vector3(0, 0, 1), baseColor, wallTex, dist);
      _addTexturedQuad(polygons, p[3], p[0], p[4], p[7], v.Vector3(-1, 0, 0), baseColor, wallTex, dist);
      _addTexturedQuad(polygons, p[1], p[2], p[6], p[5], v.Vector3(1, 0, 0), baseColor, wallTex, dist);

      // Atap
      _addTexturedQuad(polygons, p[4], p[5], p[6], p[7], v.Vector3(0, 1, 0), const Color(0xFF8D6E63), roofTex, dist);

      // Jendela (hanya jika texture quality >= 1 dan bangunan punya jendela)
      if (b.hasWindows && settings.textureQuality >= 1) {
        _addWindows(polygons, b, dist);
      }

      // Plang nama bangunan (hanya jika dekat)
      if (dist < 30) {
        // Plang tidak ditambahkan sebagai polygon (biar simpel),
        // tapi nama bisa ditampilkan di HUD
      }
    }
  }

  void _addTexturedQuad(List<Polygon3D> polys, v.Vector3 v1, v.Vector3 v2, v.Vector3 v3, v.Vector3 v4, v.Vector3 normal, Color color, TextureInfo tex, double dist) {
    polys.add(Polygon3D(
      worldVertices: [v1, v2, v3, v4],
      color: color,
      normal: normal,
      distanceToCamera: dist,
      texture: tex,
    ));
  }

  void _addWindows(List<Polygon3D> polygons, Building b, double dist) {
    final windowColor = settings.sunIntensity > 0.3
        ? Color.lerp(const Color(0xFFBBDEFB), const Color(0xFFE3F2FD), settings.sunIntensity)!
        : const Color(0xFFFFEB3B).withOpacity(0.8);
    final windowTex = settings.sunIntensity > 0.3
        ? const TextureInfo(material: SurfaceMaterial.glass, roughness: 0.05)
        : const TextureInfo(material: SurfaceMaterial.glass, roughness: 0.1);

    final floorH = b.size.y / b.floors;
    final winW = 1.0;
    final winH = floorH * 0.55;
    const winMargin = 1.5;

    // Front & back walls
    for (int f = 0; f < b.floors; f++) {
      final fy = f * floorH + floorH * 0.25;
      final hw = b.size.x / 2.0;

      // Front (z+)
      double wx = -hw + winMargin;
      while (wx < hw - winMargin) {
        final actualWx = wx < hw - winMargin - winW ? winW : hw - winMargin - wx;
        if (actualWx > 0.3) {
          _addWindowQuad(polygons,
            v.Vector3(b.position.x + wx, fy, b.position.z + b.size.z / 2.0 + 0.02),
            v.Vector3(b.position.x + wx + actualWx, fy, b.position.z + b.size.z / 2.0 + 0.02),
            v.Vector3(b.position.x + wx + actualWx, fy + winH, b.position.z + b.size.z / 2.0 + 0.02),
            v.Vector3(b.position.x + wx, fy + winH, b.position.z + b.size.z / 2.0 + 0.02),
            v.Vector3(0, 0, 1), windowColor, windowTex, dist,
          );
        }
        wx += winW + 1.0;
      }
      // Back (z-)
      wx = -hw + winMargin;
      while (wx < hw - winMargin) {
        final actualWx = wx < hw - winMargin - winW ? winW : hw - winMargin - wx;
        if (actualWx > 0.3) {
          _addWindowQuad(polygons,
            v.Vector3(b.position.x + wx, fy, b.position.z - b.size.z / 2.0 - 0.02),
            v.Vector3(b.position.x + wx + actualWx, fy, b.position.z - b.size.z / 2.0 - 0.02),
            v.Vector3(b.position.x + wx + actualWx, fy + winH, b.position.z - b.size.z / 2.0 - 0.02),
            v.Vector3(b.position.x + wx, fy + winH, b.position.z - b.size.z / 2.0 - 0.02),
            v.Vector3(0, 0, -1), windowColor, windowTex, dist,
          );
        }
        wx += winW + 1.0;
      }
    }
  }

  void _addWindowQuad(List<Polygon3D> polys, v.Vector3 v1, v.Vector3 v2, v.Vector3 v3, v.Vector3 v4, v.Vector3 normal, Color color, TextureInfo tex, double dist) {
    polys.add(Polygon3D(
      worldVertices: [v1, v2, v3, v4],
      color: color,
      normal: normal,
      distanceToCamera: dist,
      texture: tex,
      castShadow: false,
    ));
  }

  // ============================================================
  // POHON (trunk + canopy)
  // ============================================================
  void _generateTreePolygons(List<Polygon3D> polygons) {
    for (var tree in worldState.trees) {
      final dist = camera.position.distanceTo(tree.position);
      if (dist > settings.renderDistance * 0.7) continue;

      final tx = tree.position.x;
      final tz = tree.position.z;
      final th = tree.trunkHeight;
      final cr = tree.canopyRadius;
      final canopyColor = Color(tree.canopyColorHex);
      final trunkColor = const Color(0xFF5D4037);
      final sway = math.sin(gameTime * 1.5 + tx * 0.3) * 0.15; // angin

      // Trunk (box sederhana)
      final tw = 0.25;
      final tb = Pipeline3D.getTerrainHeight(tx, tz);
      _addTreeBox(polygons, tx - tw, tb, tz - tw, tx + tw, tb + th, tz + tw, trunkColor, dist);

      // Canopy (pyramid dari triangles)
      final topY = tb + th + cr * 0.8;
      final midY = tb + th + cr * 0.3;
      final s = cr + sway;

      // 4 sisi canopy
      _addTreeTriangle(polygons,
        v.Vector3(tx, topY, tz),
        v.Vector3(tx - s, midY, tz - s),
        v.Vector3(tx + s, midY, tz - s),
        canopyColor, dist,
      );
      _addTreeTriangle(polygons,
        v.Vector3(tx, topY, tz),
        v.Vector3(tx + s, midY, tz - s),
        v.Vector3(tx + s, midY, tz + s),
        canopyColor, dist,
      );
      _addTreeTriangle(polygons,
        v.Vector3(tx, topY, tz),
        v.Vector3(tx + s, midY, tz + s),
        v.Vector3(tx - s, midY, tz + s),
        canopyColor, dist,
      );
      _addTreeTriangle(polygons,
        v.Vector3(tx, topY, tz),
        v.Vector3(tx - s, midY, tz + s),
        v.Vector3(tx - s, midY, tz - s),
        canopyColor, dist,
      );

      // Alas canopy (lingkaran approx 8 segmen)
      for (int i = 0; i < 8; i++) {
        final a1 = (i / 8.0) * math.pi * 2;
        final a2 = ((i + 1) / 8.0) * math.pi * 2;
        _addTreeTriangle(polygons,
          v.Vector3(tx, midY, tz),
          v.Vector3(tx + math.cos(a1) * s, midY - cr * 0.3, tz + math.sin(a1) * s),
          v.Vector3(tx + math.cos(a2) * s, midY - cr * 0.3, tz + math.sin(a2) * s),
          canopyColor, dist,
        );
      }
    }
  }

  void _addTreeBox(List<Polygon3D> polys, double x1, double y1, double z1, double x2, double y2, double z2, Color color, double dist) {
    final v0 = v.Vector3(x1, y1, z1), v1 = v.Vector3(x2, y1, z1);
    final v2 = v.Vector3(x2, y1, z2), v3 = v.Vector3(x1, y1, z2);
    final v4 = v.Vector3(x1, y2, z1), v5 = v.Vector3(x2, y2, z1);
    final v6 = v.Vector3(x2, y2, z2), v7 = v.Vector3(x1, y2, z2);
    polys.add(Polygon3D(worldVertices: [v0, v1, v5, v4], color: color, normal: v.Vector3(0, 0, -1), distanceToCamera: dist, isTree: true));
    polys.add(Polygon3D(worldVertices: [v2, v3, v7, v6], color: color, normal: v.Vector3(0, 0, 1), distanceToCamera: dist, isTree: true));
    polys.add(Polygon3D(worldVertices: [v3, v0, v4, v7], color: color, normal: v.Vector3(-1, 0, 0), distanceToCamera: dist, isTree: true));
    polys.add(Polygon3D(worldVertices: [v1, v2, v6, v5], color: color, normal: v.Vector3(1, 0, 0), distanceToCamera: dist, isTree: true));
  }

  void _addTreeTriangle(List<Polygon3D> polys, v.Vector3 a, v.Vector3 b, v.Vector3 c, Color color, double dist) {
    final center = (a + b + c) / 3.0;
    final edge1 = b - a;
    final edge2 = c - a;
    final normal = edge1.cross(edge2).normalized();
    polys.add(Polygon3D(
      worldVertices: [a, b, c],
      color: color,
      normal: normal,
      distanceToCamera: dist,
      isTree: true,
    ));
  }

  // ============================================================
  // COLLECTIBLES (dengan animasi melayang)
  // ============================================================
  void _generateCollectiblePolygons(List<Polygon3D> polygons) {
    for (var item in worldState.collectibles) {
      if (item.isCollected) continue;
      final dist = camera.position.distanceTo(item.position);
      if (dist > settings.renderDistance * 0.5) continue;

      final p = item.position;
      final bobY = math.sin(gameTime * 3.0 + item.animOffset) * 0.3; // melayang
      const s = 0.4;

      final top = v.Vector3(p.x, p.y + s + bobY, p.z);
      final bottom = v.Vector3(p.x, p.y - s + bobY, p.z);
      final p1 = v.Vector3(p.x - s, p.y + bobY, p.z - s);
      final p2 = v.Vector3(p.x + s, p.y + bobY, p.z - s);
      final p3 = v.Vector3(p.x + s, p.y + bobY, p.z + s);
      final p4 = v.Vector3(p.x - s, p.y + bobY, p.z + s);

      Color color;
      switch (item.type) {
        case CollectibleType.coffee:
          color = const Color(0xFFFF9800);
          break;
        case CollectibleType.coin:
          color = const Color(0xFFFFD700);
          break;
        case CollectibleType.star:
          color = const Color(0xFFE040FB);
          break;
      }

      _addCollectTriangle(polygons, top, p1, p2, v.Vector3(0, 1, -1).normalized(), color, dist);
      _addCollectTriangle(polygons, top, p2, p3, v.Vector3(1, 1, 0).normalized(), color, dist);
      _addCollectTriangle(polygons, top, p3, p4, v.Vector3(0, 1, 1).normalized(), color, dist);
      _addCollectTriangle(polygons, top, p4, p1, v.Vector3(-1, 1, 0).normalized(), color, dist);
      _addCollectTriangle(polygons, bottom, p2, p1, v.Vector3(0, -1, -1).normalized(), color, dist);
      _addCollectTriangle(polygons, bottom, p3, p2, v.Vector3(1, -1, 0).normalized(), color, dist);
      _addCollectTriangle(polygons, bottom, p4, p3, v.Vector3(0, -1, 1).normalized(), color, dist);
      _addCollectTriangle(polygons, bottom, p1, p4, v.Vector3(-1, -1, 0).normalized(), color, dist);
    }
  }

  void _addCollectTriangle(List<Polygon3D> polys, v.Vector3 v1, v.Vector3 v2, v.Vector3 v3, v.Vector3 normal, Color color, double dist) {
    polys.add(Polygon3D(
      worldVertices: [v1, v2, v3],
      color: color,
      normal: normal,
      distanceToCamera: dist,
      castShadow: false,
    ));
  }

  // ============================================================
  // GLOW LAMPU JALAN MALAM
  // ============================================================
  void _drawStreetLightGlows(Canvas canvas, v.Matrix4 viewProj, Size size) {
    final glowIntensity = (0.5 - settings.sunIntensity * 2).clamp(0.0, 0.5);
    if (glowIntensity <= 0) return;

    for (var light in worldState.streetLights) {
      final dist = camera.position.distanceTo(light.position);
      if (dist > 50) continue;

      final topPos = v.Vector3(light.position.x, light.height, light.position.z);
      final sp = Pipeline3D.projectVertex(topPos, viewProj, size);
      if (sp == null) continue;

      final radius = light.radius * (20.0 / (dist + 5.0));
      final glow = Paint()
        ..color = Color(0xFFFFEB3B).withOpacity(glowIntensity * (1.0 - dist / 50.0));
      canvas.drawCircle(sp, radius, glow);
    }
  }

  @override
  bool shouldRepaint(covariant WorldPainter3D oldDelegate) => true;
}
