import 'dart:ui';
import 'package:flutter/scheduler.dart';

class GameLoop {
  final Function(double dt) onTick;
  Ticker? _ticker;
  Duration _lastElapsed = Duration.zero;
  bool _isRunning = false;
  int _frameCount = 0;
  double _fpsAccum = 0;
  double _currentFps = 0;
  Duration _fpsTimer = Duration.zero;

  GameLoop({required this.onTick});

  double get fps => _currentFps;
  double get totalTime => _fpsTimer.inMilliseconds / 1000.0;

  void start(TickerProvider vsync) {
    if (_isRunning) return;
    _isRunning = true;
    _lastElapsed = Duration.zero;
    _ticker = vsync.createTicker(_onFrame);
    _ticker!.start();
  }

  void stop() {
    _isRunning = false;
    _ticker?.stop();
    _ticker?.dispose();
    _ticker = null;
  }

  void _onFrame(Duration elapsed) {
    if (!_isRunning) return;
    final dt = (elapsed - _lastElapsed).inMicroseconds / 1000000.0;
    _lastElapsed = elapsed;
    final clampedDt = dt.clamp(0.001, 0.05);

    // FPS counter
    _frameCount++;
    _fpsAccum += dt;
    _fpsTimer += Duration(microseconds: (dt * 1000000).round());
    if (_fpsAccum >= 1.0) {
      _currentFps = _frameCount / _fpsAccum;
      _frameCount = 0;
      _fpsAccum = 0;
    }

    onTick(clampedDt);
  }
}
