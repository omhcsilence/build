import 'dart:math' as math;
import 'dart:ui';
import 'package:vector_math/vector_math_64.dart' as v;
import '../camera/camera_3d.dart';
import '../models/world_data.dart';
import '../models/graphics_settings.dart';

class Polygon3D {
  final List<v.Vector3> worldVertices;
  final Color color;
  final v.Vector3 normal;
  double distanceToCamera;
  final TextureInfo? texture;
  final bool castShadow;
  final double shadowIntensity;
  final bool isTree;

  Polygon3D({
    required this.worldVertices,
    required this.color,
    required this.normal,
    required this.distanceToCamera,
    this.texture,
    this.castShadow = true,
    this.shadowIntensity = 1.0,
    this.isTree = false,
  });
}

/// Shadow map point: posisi titik di terrain yang terkena shadow
class ShadowPoint {
  final double x;
  final double z;
  final double intensity; // 0-1, seberapa gelap
  final double softness; // radius softness
  const ShadowPoint({required this.x, required this.z, required this.intensity, this.softness = 2.0});
}

class Pipeline3D {
  /// Simple 2D hash noise untuk texture prosedural
  static double _hash2D(int ix, int iy) {
    int n = ix * 374761393 + iy * 668265263;
    n = (n ^ (n >> 13)) * 1274126177;
    n = n ^ (n >> 16);
    return (n & 0x7fffffff) / 0x7fffffff.toDouble();
  }

  /// Smooth noise (bilinear interpolated hash)
  static double _smoothNoise(double x, double y) {
    final ix = x.floor();
    final iy = y.floor();
    final fx = x - ix;
    final fy = y - iy;
    // Smoothstep
    final sx = fx * fx * (3.0 - 2.0 * fx);
    final sy = fy * fy * (3.0 - 2.0 * fy);
    final n00 = _hash2D(ix, iy);
    final n10 = _hash2D(ix + 1, iy);
    final n01 = _hash2D(ix, iy + 1);
    final n11 = _hash2D(ix + 1, iy + 1);
    final nx0 = n00 + (n10 - n00) * sx;
    final nx1 = n01 + (n11 - n01) * sx;
    return nx0 + (nx1 - nx0) * sy;
  }

  /// FBM (Fractal Brownian Motion) noise - 4 octaves
  static double fbm(double x, double y, int octaves) {
    double val = 0;
    double amp = 1.0;
    double freq = 1.0;
    double maxVal = 0;
    for (int i = 0; i < octaves; i++) {
      val += _smoothNoise(x * freq, y * freq) * amp;
      maxVal += amp;
      amp *= 0.5;
      freq *= 2.0;
    }
    return val / maxVal;
  }

  /// Mendapat tinggi terrain pada posisi (x, z) menggunakan Perlin-like noise
  static double getTerrainHeight(double x, double z) {
    return fbm(x * 0.02, z * 0.02, 4) * 3.0 - 0.5;
  }

  /// Hitung warna texture prosedural berdasarkan material & posisi UV
  static Color applyProceduralTexture(
    Color baseColor,
    TextureInfo tex,
    double worldX,
    double worldY,
    double worldZ,
    int qualityLevel,
  ) {
    if (qualityLevel == 0 || tex.tileScale == 0) return baseColor;

    double u = worldX * tex.tileScale;
    double v2 = worldY * tex.tileScale;

    double variation = (fbm(u, v2, qualityLevel == 1 ? 2 : 4) - 0.5) * 2.0 * tex.colorVariation;

    // Material-specific patterns
    switch (tex.material) {
      case SurfaceMaterial.brick:
        // Pattern batu bata
        final brickH = 1.0;
        final brickW = 2.0;
        final row = (worldY / brickH).floor();
        final offset = row.isOdd ? brickW * 0.5 : 0.0;
        final bx = ((worldX + offset) % brickW).abs();
        final by = (worldY % brickH).abs();
        final isMortar = bx < 0.08 || by < 0.08;
        if (isMortar) {
          return Color.from(alpha: baseColor.alpha, red: (baseColor.red * 0.6).clamp(0, 255).toInt(), green: (baseColor.green * 0.55).clamp(0, 255).toInt(), blue: (baseColor.blue * 0.5).clamp(0, 255).toInt());
        }
        variation += (fbm(u * 3, v2 * 3, 2) - 0.5) * 0.15;
        break;
      case SurfaceMaterial.wood:
        // Pola kayu (garis-garis sepanjang Y)
        final grain = math.sin(worldZ * 15.0 + fbm(worldX * 2, worldY * 0.5, 2) * 5.0) * 0.1;
        variation += grain;
        break;
      case SurfaceMaterial.grass:
        // Rumput dengan variasi hijau
        final grassDetail = fbm(worldX * 0.5, worldZ * 0.5, qualityLevel == 1 ? 2 : 4);
        variation = (grassDetail - 0.5) * 0.25;
        // Campur warna hijau yang berbeda
        return Color.from(
          alpha: baseColor.alpha,
          red: (baseColor.red + variation * 40).clamp(0, 255).toInt(),
          green: (baseColor.green + variation * 30).clamp(0, 255).toInt(),
          blue: (baseColor.blue + variation * 20).clamp(0, 255).toInt(),
        );
      case SurfaceMaterial.asphalt:
        // Aspal dengan butiran halus
        variation = (fbm(u * 4, v2 * 4, 3) - 0.5) * 0.12;
        break;
      case SurfaceMaterial.metal:
        // Metal dengan sedikit refleksi
        variation *= 0.3;
        break;
      case SurfaceMaterial.glass:
        // Glass - transparan/sedikit reflektif
        variation = 0;
        break;
      case SurfaceMaterial.tile:
        // Tile pattern
        final tileSize = 1.5;
        final tx = (worldX % tileSize).abs();
        final ty = (worldY % tileSize).abs();
        if (tx < 0.05 || ty < 0.05) {
          return Color.from(
            alpha: baseColor.alpha,
            red: (baseColor.red * 0.75).clamp(0, 255).toInt(),
            green: (baseColor.green * 0.75).clamp(0, 255).toInt(),
            blue: (baseColor.blue * 0.75).clamp(0, 255).toInt(),
          );
        }
        break;
      default:
        break;
    }

    return Color.from(
      alpha: baseColor.alpha,
      red: (baseColor.red * (1 + variation)).clamp(0, 255).toInt(),
      green: (baseColor.green * (1 + variation)).clamp(0, 255).toInt(),
      blue: (baseColor.blue * (1 + variation)).clamp(0, 255).toInt(),
    );
  }

  /// Frustum culling: cek apakah sphere berada dalam view frustum
  static bool isInFrustum(v.Vector3 center, double radius, v.Matrix4 viewProj) {
    final v4 = viewProj.transformed(v.Vector4(center.x, center.y, center.z, 1.0));
    // Cek 6 plane (simplified: cek NDC)
    if (v4.w <= 0) return false; // behind camera
    final ndcX = v4.x / v4.w;
    final ndcY = v4.y / v4.w;
    final ndcZ = v4.z / v4.w;
    // Margin berdasarkan radius
    final margin = radius / (v4.w.abs() + 0.001);
    return ndcX > -1.2 - margin &&
        ndcX < 1.2 + margin &&
        ndcY > -1.2 - margin &&
        ndcY < 1.2 + margin &&
        ndcZ > -1.5 &&
        ndcZ < 1.5;
  }

  /// Phong shading: ambient + diffuse + specular
  static Color phongShade(
    Color baseColor,
    v.Vector3 normal,
    v.Vector3 worldPos,
    v.Vector3 cameraPos,
    v.Vector3 lightDir,
    double ambientLevel,
    TextureInfo? texInfo,
    bool enableSpecular,
  ) {
    final n = normal.normalized();
    final l = lightDir.normalized();

    // Ambient
    double ambient = ambientLevel;

    // Diffuse (Lambertian)
    double diff = n.dot(l);
    if (diff < 0) diff = 0;
    double diffuse = diff * 0.65;

    // Specular (Blinn-Phong)
    double spec = 0.0;
    if (enableSpecular && texInfo != null && texInfo.roughness < 0.5) {
      final viewDir = (cameraPos - worldPos).normalized();
      final halfDir = (l + viewDir).normalized();
      final specAngle = n.dot(halfDir);
      if (specAngle > 0) {
        final shininess = (1.0 - texInfo.roughness) * 64.0;
        spec = math.pow(specAngle, shininess).toDouble() * (1.0 - texInfo.roughness) * 0.4;
      }
    }

    final intensity = (ambient + diffuse + spec).clamp(0.0, 1.2);

    return Color.from(
      alpha: 255,
      red: (baseColor.red * intensity + spec * 255).clamp(0, 255).toInt(),
      green: (baseColor.green * intensity + spec * 240).clamp(0, 255).toInt(),
      blue: (baseColor.blue * intensity + spec * 220).clamp(0, 255).toInt(),
    );
  }

  /// Approximate ambient occlusion berdasarkan tinggi dan density sekitar
  static double approximateAO(double worldX, double worldY, double worldZ) {
    // Semakin rendah Y (dekat tanah) dan dekat dinding = lebih gelap
    final groundFactor = (1.0 - (worldY / 20.0).clamp(0.0, 1.0)) * 0.15;
    // Noise-based corner darkening
    final cornerNoise = fbm(worldX * 0.3 + 100, worldZ * 0.3 + 100, 2);
    return groundFactor + cornerNoise * 0.1;
  }

  /// Proses semua polygon: culling + sorting + frustum check
  static List<Polygon3D> processPolygons({
    required List<Polygon3D> polygons,
    required Camera3D camera,
    required double renderDistance,
    v.Matrix4? viewProjection,
  }) {
    final visiblePolygons = <Polygon3D>[];
    final camPos = camera.position;

    for (var poly in polygons) {
      // Distance culling
      if (poly.distanceToCamera > renderDistance) continue;

      // Back-face culling
      final faceToCam = camPos - poly.worldVertices[0];
      if (poly.normal.dot(faceToCam) <= 0) continue;

      // Frustum culling (optional, jika viewProjection tersedia)
      if (viewProjection != null) {
        v.Vector3 center = v.Vector3.zero();
        for (var vtx in poly.worldVertices) {
          center += vtx;
        }
        center /= poly.worldVertices.length.toDouble();
        if (!isInFrustum(center, 2.0, viewProjection)) continue;
      }

      visiblePolygons.add(poly);
    }

    // Painter's Algorithm (far to near)
    visiblePolygons.sort((a, b) => b.distanceToCamera.compareTo(a.distanceToCamera));

    return visiblePolygons;
  }

  /// Project vertex 3D ke layar 2D
  static Offset? projectVertex(v.Vector3 vertex, v.Matrix4 viewProj, Size viewport) {
    final vec4 = v.Vector4(vertex.x, vertex.y, vertex.z, 1.0);
    final clip = viewProj.transformed(vec4);
    if (clip.w <= 0.1) return null;
    return Offset(
      (clip.x / clip.w + 1.0) * 0.5 * viewport.width,
      (1.0 - clip.y / clip.w) * 0.5 * viewport.height,
    );
  }

  /// Buat shadow map dari building (daerah gelap di ground)
  static List<ShadowPoint> computeShadowMap(
    List<Building> buildings,
    v.Vector3 lightDir,
    double quality,
    double maxDist,
  ) {
    if (quality == 0) return [];

    final shadows = <ShadowPoint>[];
    final step = quality >= 3 ? 0.5 : (quality >= 2 ? 1.0 : 2.0);

    for (var b in buildings) {
      final hw = b.size.x / 2.0 + 0.5;
      final hd = b.size.z / 2.0 + 0.5;
      // Shadow offset berdasarkan arah cahaya dan tinggi bangunan
      final shadowLen = b.size.y * 0.8;
      final sx = lightDir.x * shadowLen;
      final sz = lightDir.z * shadowLen;

      for (double dx = -hw; dx <= hw + sx.abs(); dx += step) {
        for (double dz = -hd; dz <= hd + sz.abs(); dz += step) {
          final px = b.position.x + dx;
          final pz = b.position.z + dz;
          // Hitung intensitas shadow (lebih dekat bangunan = lebih gelap)
          final distToBuilding = math.sqrt(
            math.pow((px - b.position.x) / (hw + 1), 2) +
            math.pow((pz - b.position.z) / (hd + 1), 2),
          );
          if (distToBuilding < 1.5) {
            final intensity = quality >= 3
                ? (1.0 - distToBuilding / 1.5) * 0.45 * lightDir.y.clamp(0.2, 1.0)
                : (1.0 - distToBuilding / 1.5) * 0.35;
            shadows.add(ShadowPoint(
              x: px,
              z: pz,
              intensity: intensity,
              softness: quality >= 3 ? 1.5 : (quality >= 2 ? 2.5 : 4.0),
            ));
          }
        }
      }
    }
    return shadows;
  }

  /// Cek apakah posisi terrain terkena shadow
  static double getShadowAt(double x, double z, List<ShadowPoint> shadowMap) {
    double totalShadow = 0;
    for (var s in shadowMap) {
      final dx = x - s.x;
      final dz = z - s.z;
      final dist = math.sqrt(dx * dx + dz * dz);
      if (dist < s.softness) {
        final factor = 1.0 - (dist / s.softness);
        totalShadow += s.intensity * factor;
      }
    }
    return totalShadow.clamp(0.0, 0.6);
  }
}
