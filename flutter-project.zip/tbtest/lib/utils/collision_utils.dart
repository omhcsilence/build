import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';

class CollisionUtils {
  static bool checkBuildingCollision(v.Vector3 nextPos, double playerRadius, List<Building> buildings) {
    for (var b in buildings) {
      final hw = (b.size.x / 2.0) + playerRadius;
      final hd = (b.size.z / 2.0) + playerRadius;

      final minX = b.position.x - hw;
      final maxX = b.position.x + hw;
      final minZ = b.position.z - hd;
      final maxZ = b.position.z + hd;

      if (nextPos.x >= minX && nextPos.x <= maxX && nextPos.z >= minZ && nextPos.z <= maxZ) {
        if (nextPos.y < b.position.y + b.size.y) {
          return true;
        }
      }
    }
    return false;
  }
}
