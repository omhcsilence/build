import 'package:flutter/material.dart';
import '../services/redeem_service.dart';

class RedeemDialog extends StatefulWidget {
  const RedeemDialog({super.key});

  @override
  State<RedeemDialog> createState() => _RedeemDialogState();
}

class _RedeemDialogState extends State<RedeemDialog> {
  final _controller = TextEditingController();
  String _message = '';

  void _submit() {
    final success = RedeemService.redeemCode(_controller.text);
    setState(() {
      _message = success ? 'Success! Code Redeemed.' : 'Invalid Code!';
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Redeem Promo Code'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _controller,
            decoration: const InputDecoration(
              hintText: 'Enter code (e.g. MOKKA3D)',
            ),
          ),
          const SizedBox(height: 10),
          Text(_message, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Close'),
        ),
        ElevatedButton(
          onPressed: _submit,
          child: const Text('Redeem'),
        ),
      ],
    );
  }
}
