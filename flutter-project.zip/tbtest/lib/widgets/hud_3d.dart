import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';
import '../models/graphics_settings.dart';

class Hud3D extends StatelessWidget {
  final int score;
  final int health;
  final v.Vector3 playerPos;
  final double playerYaw;
  final WorldState worldState;
  final Function(v.Vector2) onJoystickMove;
  final VoidCallback onJump;
  final VoidCallback onSettingsOpen;
  final double fps;
  final double gameTime;

  const Hud3D({
    super.key,
    required this.score,
    required this.health,
    required this.playerPos,
    required this.playerYaw,
    required this.worldState,
    required this.onJoystickMove,
    required this.onJump,
    required this.onSettingsOpen,
    this.fps = 0,
    this.gameTime = 0,
  });

  @override
  Widget build(BuildContext meContext) {
    return Stack(
      children: [
        // Top HUD
        Positioned(
          top: 20,
          left: 12,
          right: 12,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Score
              _buildStatusChip(Icons.local_cafe, 'SCORE: $score', Colors.amber),
              // FPS
              _buildStatusChip(Icons.speed, '${fps.toStringAsFixed(0)} FPS', Colors.greenAccent),
              // MiniMap
              _buildMiniMap(),
              // Settings Button
              GestureDetector(
                onTap: onSettingsOpen,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white54),
                  ),
                  child: const Icon(Icons.settings, color: Colors.white, size: 20),
                ),
              ),
            ],
          ),
        ),

        // Crosshair
        Center(
          child: CustomPaint(
            size: const Size(20, 20),
            painter: _CrosshairPainter(),
          ),
        ),

        // Virtual Joystick
        Positioned(
          bottom: 30,
          left: 20,
          child: _VirtualJoystick(onMove: onJoystickMove),
        ),

        // Jump Button
        Positioned(
          bottom: 40,
          right: 30,
          child: GestureDetector(
            onTapDown: (_) => onJump(),
            child: Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Colors.white.withOpacity(0.4), Colors.white.withOpacity(0.15)],
                ),
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: const Icon(Icons.arrow_upward, color: Colors.white, size: 36),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatusChip(IconData icon, String text, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accent, width: 1.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: accent, size: 16),
          const SizedBox(width: 6),
          Text(text, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildMiniMap() {
    return Container(
      width: 80,
      height: 80,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
      ),
      child: ClipOval(
        child: CustomPaint(
          painter: MiniMapPainter(
            playerPos: playerPos,
            playerYaw: playerYaw,
            worldState: worldState,
          ),
        ),
      ),
    );
  }
}

// ============================================================
// CROSSHAIR
// ============================================================
class _CrosshairPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final p = Paint()
      ..color = Colors.white.withOpacity(0.6)
      ..strokeWidth = 1.5;
    canvas.drawLine(Offset(c.dx - 6, c.dy), Offset(c.dx - 2, c.dy), p);
    canvas.drawLine(Offset(c.dx + 2, c.dy), Offset(c.dx + 6, c.dy), p);
    canvas.drawLine(Offset(c.dx, c.dy - 6), Offset(c.dx, c.dy - 2), p);
    canvas.drawLine(Offset(c.dx, c.dy + 2), Offset(c.dx, c.dy + 6), p);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ============================================================
// VIRTUAL JOYSTICK
// ============================================================
class _VirtualJoystick extends StatefulWidget {
  final Function(v.Vector2) onMove;
  const _VirtualJoystick({required this.onMove});

  @override
  State<_VirtualJoystick> createState() => _VirtualJoystickState();
}

class _VirtualJoystickState extends State<_VirtualJoystick> {
  Offset _delta = Offset.zero;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanUpdate: (details) {
        final newDelta = _delta + details.delta;
        final clamped = Offset(
          newDelta.dx.clamp(-40.0, 40.0),
          newDelta.dy.clamp(-40.0, 40.0),
        );
        setState(() => _delta = clamped);
        widget.onMove(v.Vector2(clamped.dx / 40.0, -clamped.dy / 40.0));
      },
      onPanEnd: (_) {
        setState(() => _delta = Offset.zero);
        widget.onMove(v.Vector2.zero());
      },
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white30, width: 2),
        ),
        child: Center(
          child: Transform.translate(
            offset: _delta,
            child: Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                color: Colors.amber,
                shape: BoxShape.circle,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// MINI MAP
// ============================================================
class MiniMapPainter extends CustomPainter {
  final v.Vector3 playerPos;
  final double playerYaw;
  final WorldState worldState;

  MiniMapPainter({
    required this.playerPos,
    required this.playerYaw,
    required this.worldState,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    const scale = 0.5;

    // Background
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..color = const Color(0xFF2E7D32).withOpacity(0.3),
    );

    // Roads
    final roadPaint = Paint()..color = Colors.grey.shade700;
    for (var road in worldState.roads) {
      final dx1 = center.dx + (road.start.x - playerPos.x) * scale;
      final dy1 = center.dy + (road.start.z - playerPos.z) * scale;
      final dx2 = center.dx + (road.end.x - playerPos.x) * scale;
      final dy2 = center.dy + (road.end.z - playerPos.z) * scale;
      canvas.drawLine(Offset(dx1, dy1), Offset(dx2, dy2), roadPaint);
    }

    // Buildings
    final buildingPaint = Paint()..color = Colors.blueGrey;
    for (var b in worldState.buildings) {
      final dx = center.dx + (b.position.x - playerPos.x) * scale;
      final dy = center.dy + (b.position.z - playerPos.z) * scale;
      if (dx < -5 || dx > size.width + 5 || dy < -5 || dy > size.height + 5) continue;
      canvas.drawRect(
        Rect.fromCenter(center: Offset(dx, dy), width: b.size.x * scale, height: b.size.z * scale),
        buildingPaint,
      );
    }

    // Player
    canvas.drawCircle(center, 3.0, Paint()..color = Colors.redAccent);
    final dirPaint = Paint()..color = Colors.yellow..strokeWidth = 2.0;
    canvas.drawLine(
      center,
      Offset(center.dx + math.sin(playerYaw) * 10, center.dy + math.cos(playerYaw) * 10),
      dirPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// ============================================================
// GRAPHICS SETTINGS PANEL
// ============================================================
class GraphicsSettingsPanel extends StatelessWidget {
  final GraphicsSettings settings;
  final Function(GraphicsSettings) onSettingsChanged;
  final VoidCallback onClose;

  const GraphicsSettingsPanel({
    super.key,
    required this.settings,
    required this.onSettingsChanged,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(40),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.85),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.amber.withOpacity(0.5), width: 1.5),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('PENGATURAN GRAFIK', style: TextStyle(color: Colors.amber, fontSize: 16, fontWeight: FontWeight.bold)),
              GestureDetector(
                onTap: onClose,
                child: const Icon(Icons.close, color: Colors.white, size: 24),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Presets
          const Text('Preset:', style: TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 6),
          Row(
            children: [
              _presetButton('Low', GraphicsSettings.low()),
              const SizedBox(width: 6),
              _presetButton('Medium', GraphicsSettings.medium()),
              const SizedBox(width: 6),
              _presetButton('High', GraphicsSettings.high()),
              const SizedBox(width: 6),
              _presetButton('Ultra', GraphicsSettings.ultra()),
            ],
          ),

          const SizedBox(height: 16),
          const Divider(color: Colors.white24),
          const SizedBox(height: 12),

          // Shadow Quality
          _buildSlider('Shadow Quality', settings.shadowQuality.toDouble(), 0, 3, (v) {
            final s = settings.clone()..shadowQuality = v.toInt();
            onSettingsChanged(s);
          }),

          // Render Distance
          _buildSlider('Render Distance', settings.renderDistance, 40, 300, (v) {
            final s = settings.clone()..renderDistance = v;
            onSettingsChanged(s);
          }, label: '${settings.renderDistance.toInt()}m'),

          // Texture Quality
          _buildSlider('Texture Detail', settings.textureQuality.toDouble(), 0, 2, (v) {
            final s = settings.clone()..textureQuality = v.toInt();
            onSettingsChanged(s);
          }),

          // Fog Density
          _buildSlider('Fog Density', settings.fogDensity, 0, 1, (v) {
            final s = settings.clone()..fogDensity = v;
            onSettingsChanged(s);
          }),

          // Terrain Detail
          _buildSlider('Terrain Detail', settings.terrainDetail, 1, 10, (v) {
            final s = settings.clone()..terrainDetail = v;
            onSettingsChanged(s);
          }),

          // FOV
          _buildSlider('FOV', 70.0, 50, 110, (v) {
            // FOV handled separately
          }, label: '70'),

          const SizedBox(height: 8),

          // Toggles
          _buildToggle('Anti-Aliasing', settings.antiAliasing, (v) {
            final s = settings.clone()..antiAliasing = v;
            onSettingsChanged(s);
          }),
          _buildToggle('Specular Light', settings.specularLighting, (v) {
            final s = settings.clone()..specularLighting = v;
            onSettingsChanged(s);
          }),
          _buildToggle('Ambient Occlusion', settings.ambientOcclusion, (v) {
            final s = settings.clone()..ambientOcclusion = v;
            onSettingsChanged(s);
          }),
          _buildToggle('Day/Night Cycle', settings.dayNightCycle, (v) {
            final s = settings.clone()..dayNightCycle = v;
            onSettingsChanged(s);
          }),
        ],
      ),
    );
  }

  Widget _presetButton(String label, GraphicsSettings preset) {
    return Expanded(
      child: GestureDetector(
        onTap: () => onSettingsChanged(preset),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: Colors.white38),
          ),
          child: Center(
            child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
          ),
        ),
      ),
    );
  }

  Widget _buildSlider(String label, double value, double min, double max, Function(double) onChanged, {String? label2}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 110, child: Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11))),
          Expanded(
            child: Slider(
              value: value,
              min: min,
              max: max,
              divisions: max.toInt() - min.toInt(),
              onChanged: onChanged,
              activeColor: Colors.amber,
              inactiveColor: Colors.white24,
              label: label2 ?? value.toInt().toString(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToggle(String label, bool value, Function(bool) onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(width: 110, child: Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11))),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: Colors.amber,
          ),
        ],
      ),
    );
  }
}

// Extension: clone GraphicsSettings
extension GraphicsSettingsClone on GraphicsSettings {
  GraphicsSettings clone() => GraphicsSettings(
    shadowQuality: shadowQuality,
    renderDistance: renderDistance,
    textureQuality: textureQuality,
    antiAliasing: antiAliasing,
    fogDensity: fogDensity,
    terrainDetail: terrainDetail,
    dayNightCycle: dayNightCycle,
    timeOfDay: timeOfDay,
    specularLighting: specularLighting,
    ambientOcclusion: ambientOcclusion,
    fpsLimit: fpsLimit,
  );
}
