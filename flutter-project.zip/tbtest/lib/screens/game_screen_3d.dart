import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vector_math/vector_math_64.dart' as v;

import '../camera/camera_3d.dart';
import '../engine/game_loop.dart';
import '../models/player_data.dart';
import '../models/world_data.dart';
import '../models/graphics_settings.dart';
import '../painters/world_painter_3d.dart';
import '../services/map_service.dart';
import '../utils/collision_utils.dart';
import '../render/pipeline_3d.dart';
import '../widgets/hud_3d.dart';

class GameScreen3D extends StatefulWidget {
  const GameScreen3D({super.key});

  @override
  State<GameScreen3D> createState() => _GameScreen3DState();
}

class _GameScreen3DState extends State<GameScreen3D> with SingleTickerProviderStateMixin {
  late GameLoop _gameLoop;
  late Camera3D _camera;
  late PlayerData _player;
  late WorldState _worldState;
  late GraphicsSettings _gfxSettings;

  v.Vector2 _joystickInput = v.Vector2.zero();
  final Set<LogicalKeyboardKey> _pressedKeys = {};
  double _gameTime = 0;
  bool _showSettings = false;

  @override
  void initState() {
    super.initState();
    _worldState = MapService.generateWorld();
    _player = PlayerData(position: v.Vector3(0.0, 1.6, -2.0));
    _camera = Camera3D(position: _player.position);
    _gfxSettings = GraphicsSettings.high();
    _camera.setRenderDistance(_gfxSettings.renderDistance);

    _gameLoop = GameLoop(onTick: _updateGame);
    _gameLoop.start(this);
  }

  @override
  void dispose() {
    _gameLoop.stop();
    super.dispose();
  }

  void _updateGame(double dt) {
    _gameTime += dt;

    // Day/Night cycle
    if (_gfxSettings.dayNightCycle) {
      _gfxSettings.timeOfDay += dt * 0.008; // satu siklus ~125 detik
      if (_gfxSettings.timeOfDay > 1.0) _gfxSettings.timeOfDay -= 1.0;
    }

    _handleMovement(dt);
    _applyPhysics(dt);
    _checkCollectibleCollision();

    _camera.position = _player.position.clone();
    _camera.position.y = _player.position.y + Pipeline3D.getTerrainHeight(
      _player.position.x, _player.position.z,
    );
    _camera.yaw = _player.yaw;
    _camera.pitch = _player.pitch;
    _camera.fov = 70.0;
    _camera.setRenderDistance(_gfxSettings.renderDistance);

    setState(() {});
  }

  void _handleMovement(double dt) {
    v.Vector3 moveDir = v.Vector3.zero();

    if (_pressedKeys.contains(LogicalKeyboardKey.keyW)) moveDir += _camera.forward;
    if (_pressedKeys.contains(LogicalKeyboardKey.keyS)) moveDir -= _camera.forward;
    if (_pressedKeys.contains(LogicalKeyboardKey.keyA)) moveDir -= _camera.right;
    if (_pressedKeys.contains(LogicalKeyboardKey.keyD)) moveDir += _camera.right;

    if (_joystickInput.length > 0) {
      moveDir += _camera.forward * _joystickInput.y;
      moveDir += _camera.right * _joystickInput.x;
    }

    moveDir.y = 0;
    if (moveDir.length > 0) {
      moveDir.normalize();
      const speed = 12.0;
      final nextPos = _player.position + (moveDir * speed * dt);

      if (!CollisionUtils.checkBuildingCollision(nextPos, 0.4, _worldState.buildings)) {
        _player.position = nextPos;
      }
    }
  }

  void _applyPhysics(double dt) {
    const gravity = -20.0;
    if (!_player.isGrounded) {
      _player.velocity.y += gravity * dt;
    }
    _player.position.y += _player.velocity.y * dt;

    // Ground level dengan terrain height
    final terrainH = Pipeline3D.getTerrainHeight(_player.position.x, _player.position.z);
    final groundLevel = 1.6 + terrainH;
    if (_player.position.y <= groundLevel) {
      _player.position.y = groundLevel;
      _player.velocity.y = 0;
      _player.isGrounded = true;
    }
  }

  void _jump() {
    if (_player.isGrounded) {
      _player.velocity.y = 8.0;
      _player.isGrounded = false;
    }
  }

  void _checkCollectibleCollision() {
    for (var item in _worldState.collectibles) {
      if (!item.isCollected) {
        final itemWorldPos = v.Vector3(item.position.x, item.position.y + math.sin(_gameTime * 3 + item.animOffset) * 0.3, item.position.z);
        if (itemWorldPos.distanceTo(_player.position) < 1.8) {
          item.isCollected = true;
          _player.score += 10;
        }
      }
    }
  }

  void _openSettings() {
    setState(() => _showSettings = true);
  }

  void _closeSettings() {
    setState(() => _showSettings = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Focus(
        autofocus: true,
        onKey: (node, event) {
          if (event is RawKeyDownEvent) {
            _pressedKeys.add(event.logicalKey);
            if (event.logicalKey == LogicalKeyboardKey.space) _jump();
            if (event.logicalKey == LogicalKeyboardKey.escape) {
              setState(() => _showSettings = !_showSettings);
            }
          } else if (event is RawKeyUpEvent) {
            _pressedKeys.remove(event.logicalKey);
          }
          return KeyEventResult.handled;
        },
        child: GestureDetector(
          onPanUpdate: (details) {
            if (_showSettings) return;
            setState(() {
              _player.yaw -= details.delta.dx * 0.004;
              _player.pitch -= details.delta.dy * 0.004;
              _player.pitch = _player.pitch.clamp(-math.pi / 3, math.pi / 3);
            });
          },
          child: Stack(
            children: [
              // 3D Engine Canvas
              CustomPaint(
                size: Size.infinite,
                painter: WorldPainter3D(
                  camera: _camera,
                  worldState: _worldState,
                  playerPos: _player.position,
                  settings: _gfxSettings,
                  gameTime: _gameTime,
                ),
              ),

              // HUD
              if (!_showSettings)
                Hud3D(
                  score: _player.score,
                  health: _player.health,
                  playerPos: _player.position,
                  playerYaw: _player.yaw,
                  worldState: _worldState,
                  onJoystickMove: (dir) => _joystickInput = dir,
                  onJump: _jump,
                  onSettingsOpen: _openSettings,
                  fps: _gameLoop.fps,
                  gameTime: _gameTime,
                ),

              // Graphics Settings Overlay
              if (_showSettings)
                Center(
                  child: GraphicsSettingsPanel(
                    settings: _gfxSettings,
                    onSettingsChanged: (s) {
                      setState(() => _gfxSettings = s);
                    },
                    onClose: _closeSettings,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
