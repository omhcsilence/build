# ☕ Kedai Mokka 3D

> Custom 3D Software Engine built entirely with Flutter Canvas.

![Flutter](https://img.shields.io/badge/Flutter-Canvas-blue?logo=flutter)
![Dart](https://img.shields.io/badge/Dart-3.x-blue?logo=dart)
![Status](https://img.shields.io/badge/Status-Development-orange)

---

# 📖 About

Kedai Mokka 3D adalah game eksplorasi 3D yang dibuat menggunakan Flutter dengan custom software renderer tanpa menggunakan Unity, Unreal Engine, Flame, maupun engine 3D lainnya.

Seluruh proses rendering dilakukan menggunakan Canvas, CustomPainter, Matrix4, dan Vector3 sehingga seluruh objek dirender secara manual.

---

# ✨ Features

- 🎮 Custom 3D Software Renderer
- 🌍 Open World
- 🏢 3D Building Rendering
- 🛣 Road Rendering
- ☁ Dynamic Sky
- 🌫 Distance Fog
- 💡 Directional Lighting
- 👤 First Person Camera
- 🚧 Collision Detection
- 🎁 Collectible Item
- 🗺 Mini Map
- 🎮 Virtual Joystick
- ⬆ Jump Physics
- 💳 Redeem Code
- 📱 Android Ready

---

# 🗂 Project Structure

```
lib/
├── camera/
├── engine/
├── models/
├── painters/
├── render/
├── screens/
├── services/
├── utils/
├── widgets/
└── main.dart
```

---

# 🛠 Engine

Rendering Pipeline

- View Matrix
- Projection Matrix
- Perspective Projection
- Back Face Culling
- Painter Algorithm
- Directional Lighting
- Distance Fog
- Wireframe Rendering

Physics

- Gravity
- Jump
- Collision Detection
- Collectible Detection

---

# 🎯 Roadmap

- Dynamic NPC
- Vehicle System
- Multiplayer
- Weather System
- Day & Night Cycle
- Texture Mapping
- Shadow Rendering
- Sound Engine
- Quest System
- Inventory System

---

# 📄 License

MIT License

---

# ❤️ Credits

Developed with Flutter.

Built using a custom software rendering engine powered by:

- Flutter Canvas
- CustomPainter
- Matrix4
- Vector3
- Dart

No Unity.
No Unreal Engine.
No Flame.

Only Flutter.