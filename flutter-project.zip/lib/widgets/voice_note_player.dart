// lib/widgets/voice_note_player.dart
// Compact inline audio player for voice messages.
// Uses flutter_sound (same package as the recorder) to avoid extra deps.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:permission_handler/permission_handler.dart';

class VoiceNotePlayer extends StatefulWidget {
  final String? url;
  final int durationMs;
  final bool isMine;

  const VoiceNotePlayer({
    super.key,
    this.url,
    this.durationMs = 0,
    this.isMine = false,
  });

  @override
  State<VoiceNotePlayer> createState() => _VoiceNotePlayerState();
}

class _VoiceNotePlayerState extends State<VoiceNotePlayer> {
  final FlutterSoundPlayer _player = FlutterSoundPlayer();
  bool _initialized = false;
  bool _playing = false;
  bool _loading = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  StreamSubscription? _posSub;
  StreamSubscription? _stateSub;
  Timer? _posTimer;
  DateTime? _startedAt;

  @override
  void initState() {
    super.initState();
    _duration = Duration(milliseconds: widget.durationMs);
    _posSub = _player.onProgress!.listen((e) {
      if (mounted) {
        setState(() {
          _position = e.position;
          _duration = e.duration;
        });
      }
    });
  }

  Future<void> _ensureInit() async {
    if (_initialized) return;
    await _player.openPlayer();
    _initialized = true;
  }

  @override
  void dispose() {
    _posSub?.cancel();
    _posTimer?.cancel();
    try { if (_initialized) _player.closePlayer(); } catch (_) {}
    super.dispose();
  }

  Future<void> _toggle() async {
    try {
      await _ensureInit();
      if (_playing) {
        await _player.pausePlayer();
        if (mounted) setState(() => _playing = false);
      } else {
        if (_position >= _duration && _duration > Duration.zero) {
          await _player.seekToPlayer(Duration.zero);
          _position = Duration.zero;
        }
        if (widget.url == null) {
          if (mounted) setState(() => _loading = false);
          return;
        }
        if (mounted) setState(() => _loading = true);
        await _player.setSubscriptionDuration(const Duration(milliseconds: 100));
        await _player.startPlayer(
          fromURI: widget.url,
          codec: Codec.aacADTS,
          whenFinished: () {
            if (mounted) {
              setState(() {
                _playing = false;
                _position = Duration.zero;
              });
            }
          },
        );
        if (mounted) {
          setState(() {
            _playing = true;
            _loading = false;
            _startedAt = DateTime.now();
          });
          _startPosTimer();
        }
      }
    } catch (_) {
      if (mounted) setState(() { _playing = false; _loading = false; });
    }
  }

  void _startPosTimer() {
    _posTimer?.cancel();
    _posTimer = Timer.periodic(const Duration(milliseconds: 200), (_) {
      if (!_playing) {
        _posTimer?.cancel();
        return;
      }
      if (_startedAt != null && mounted) {
        final elapsed = DateTime.now().difference(_startedAt!);
        if (elapsed < _duration) {
          setState(() => _position = elapsed);
        } else {
          setState(() {
            _position = _duration;
            _playing = false;
          });
          _posTimer?.cancel();
        }
      }
    });
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final progress = _duration.inMilliseconds > 0
        ? (_position.inMilliseconds / _duration.inMilliseconds).clamp(0.0, 1.0)
        : 0.0;
    final accent = widget.isMine ? Colors.white : Colors.cyanAccent;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: _loading ? null : _toggle,
          child: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: widget.isMine
                  ? Colors.white.withOpacity(0.18)
                  : Colors.cyanAccent.withOpacity(0.12),
            ),
            child: _loading
                ? Padding(
                    padding: const EdgeInsets.all(8),
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation(accent),
                    ),
                  )
                : Icon(
                    _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: accent, size: 22,
                  ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                height: 4,
                child: LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.white.withOpacity(0.18),
                  valueColor: AlwaysStoppedAnimation(accent),
                ),
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Icon(Icons.mic_rounded, size: 12, color: accent.withOpacity(0.7)),
                  const SizedBox(width: 4),
                  Text(
                    _fmt(_position > Duration.zero ? _position : _duration),
                    style: TextStyle(
                      color: accent.withOpacity(0.85),
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
