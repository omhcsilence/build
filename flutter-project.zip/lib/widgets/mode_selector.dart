import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../blocs/camera/camera_event.dart';

class ModeSelector extends StatelessWidget {
  final CameraMode currentMode;
  final Function(CameraMode) onModeChanged;

  const ModeSelector({
    super.key,
    required this.currentMode,
    required this.onModeChanged,
  });

  final List<Map<String, dynamic>> modes = const [
    {'label': 'Time-Lapse', 'mode': CameraMode.timeLapse},
    {'label': 'Video', 'mode': CameraMode.video},
    {'label': 'Foto', 'mode': CameraMode.photo},
    {'label': 'Portrait', 'mode': CameraMode.portrait},
    {'label': 'Pano', 'mode': CameraMode.pano},
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36.h,
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: modes.map((modeData) {
          final mode = modeData['mode'] as CameraMode;
          final label = modeData['label'] as String;
          final isSelected = mode == currentMode;

          return GestureDetector(
            onTap: () => onModeChanged(mode),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
              decoration: BoxDecoration(
                color: isSelected ? const Color(0xFFFF9500) : Colors.transparent,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : Colors.white.withOpacity(0.7),
                  fontSize: 13.sp,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
