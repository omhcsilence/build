import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class GridOverlay extends StatelessWidget {
  const GridOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.transparent,
            width: 0,
          ),
        ),
        child: CustomPaint(
          size: Size.infinite,
          painter: GridPainter(),
        ),
      ),
    );
  }
}

class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.3)
      ..strokeWidth = 1;

    // Vertical lines (rule of thirds)
    final x1 = size.width / 3;
    final x2 = size.width * 2 / 3;

    canvas.drawLine(
      Offset(x1, 0),
      Offset(x1, size.height),
      paint,
    );
    canvas.drawLine(
      Offset(x2, 0),
      Offset(x2, size.height),
      paint,
    );

    // Horizontal lines (rule of thirds)
    final y1 = size.height / 3;
    final y2 = size.height * 2 / 3;

    canvas.drawLine(
      Offset(0, y1),
      Offset(size.width, y1),
      paint,
    );
    canvas.drawLine(
      Offset(0, y2),
      Offset(size.width, y2),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
