import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class FocusFrame extends StatelessWidget {
  final Offset position;

  const FocusFrame({
    super.key,
    required this.position,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: position.dx * MediaQuery.of(context).size.width - 40.w,
      top: position.dy * MediaQuery.of(context).size.height - 40.w,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 80.w,
        height: 80.w,
        decoration: BoxDecoration(
          border: Border.all(
            color: const Color(0xFFFF9500),
            width: 2,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Stack(
          children: [
            // Corner markers
            Positioned(
              top: 0,
              left: 0,
              child: Container(
                width: 12.w,
                height: 2,
                color: const Color(0xFFFF9500),
              ),
            ),
            Positioned(
              top: 0,
              left: 0,
              child: Container(
                width: 2,
                height: 12.w,
                color: const Color(0xFFFF9500),
              ),
            ),
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                width: 12.w,
                height: 2,
                color: const Color(0xFFFF9500),
              ),
            ),
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                width: 2,
                height: 12.w,
                color: const Color(0xFFFF9500),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              child: Container(
                width: 12.w,
                height: 2,
                color: const Color(0xFFFF9500),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              child: Container(
                width: 2,
                height: 12.w,
                color: const Color(0xFFFF9500),
              ),
            ),
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                width: 12.w,
                height: 2,
                color: const Color(0xFFFF9500),
              ),
            ),
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                width: 2,
                height: 12.w,
                color: const Color(0xFFFF9500),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
