import 'dart:io';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../blocs/camera/camera_state.dart';
import '../blocs/gallery/gallery_bloc.dart';
import '../blocs/gallery/gallery_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CameraControls extends StatelessWidget {
  final CameraReady state;
  final VoidCallback onTakePicture;
  final VoidCallback onStartRecording;
  final VoidCallback onStopRecording;
  final VoidCallback onSwitchCamera;
  final VoidCallback onOpenGallery;

  const CameraControls({
    super.key,
    required this.state,
    required this.onTakePicture,
    required this.onStartRecording,
    required this.onStopRecording,
    required this.onSwitchCamera,
    required this.onOpenGallery,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        left: 24.w,
        right: 24.w,
        bottom: 40.h,
        top: 20.h,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [
            Colors.black.withOpacity(0.9),
            Colors.black.withOpacity(0.5),
            Colors.transparent,
          ],
        ),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Gallery Preview
            _buildGalleryPreview(),

            // Shutter Button
            _buildShutterButton(),

            // Camera Switch
            _buildCameraSwitch(),
          ],
        ),
      ),
    );
  }

  Widget _buildGalleryPreview() {
    return BlocBuilder<GalleryBloc, GalleryState>(
      builder: (context, galleryState) {
        String? thumbnailPath;
        if (galleryState is GalleryLoaded && galleryState.mediaFiles.isNotEmpty) {
          thumbnailPath = galleryState.mediaFiles.first.path;
        }

        return GestureDetector(
          onTap: onOpenGallery,
          child: Container(
            width: 55.w,
            height: 55.w,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Colors.white.withOpacity(0.3),
                width: 2,
              ),
              color: const Color(0xFF2C2C2E),
              image: thumbnailPath != null
                  ? DecorationImage(
                      image: FileImage(File(thumbnailPath)),
                      fit: BoxFit.cover,
                    )
                  : null,
            ),
            child: thumbnailPath == null
                ? Icon(
                    Icons.photo_library_outlined,
                    color: Colors.white.withOpacity(0.5),
                    size: 24.sp,
                  )
                : null,
          ),
        );
      },
    );
  }

  Widget _buildShutterButton() {
    final isRecording = state.isRecording;
    final isPhotoMode = state.mode == CameraMode.photo ||
        state.mode == CameraMode.portrait ||
        state.mode == CameraMode.pano;

    return GestureDetector(
      onTap: () {
        if (isPhotoMode) {
          if (!state.isTakingPicture) {
            onTakePicture();
          }
        } else {
          if (isRecording) {
            onStopRecording();
          } else {
            onStartRecording();
          }
        }
      },
      child: Container(
        width: 80.w,
        height: 80.w,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: Colors.white,
            width: 4,
          ),
        ),
        child: Center(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: isRecording ? 30.w : 65.w,
            height: isRecording ? 30.w : 65.w,
            decoration: BoxDecoration(
              color: isRecording ? const Color(0xFFFF3B30) : Colors.white,
              shape: isRecording ? BoxShape.rectangle : BoxShape.circle,
              borderRadius: isRecording ? BorderRadius.circular(8) : null,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCameraSwitch() {
    return GestureDetector(
      onTap: onSwitchCamera,
      child: Container(
        width: 55.w,
        height: 55.w,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          shape: BoxShape.circle,
        ),
        child: Icon(
          Icons.flip_camera_ios_outlined,
          color: Colors.white,
          size: 28.sp,
        ),
      ),
    );
  }
}
