import 'package:flutter/material.dart';
import '../render/graphics_settings.dart';

class GraphicsSettingsDialog extends StatefulWidget {
  const GraphicsSettingsDialog({super.key});

  @override
  State<GraphicsSettingsDialog> createState() => _GraphicsSettingsDialogState();
}

class _GraphicsSettingsDialogState extends State<GraphicsSettingsDialog> {
  final GraphicsSettings _settings = GraphicsSettings();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.grey[900],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.blue.withOpacity(0.5), width: 2),
      ),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.blue.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.tune, color: Colors.blue),
          ),
          const SizedBox(width: 12),
          const Text(
            'Graphics Settings',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
      content: SizedBox(
        width: 400,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Quality Presets Section
              _buildSectionHeader('Quality Preset', Icons.auto_awesome),
              const SizedBox(height: 8),
              _buildQualitySelector(),
              const Divider(height: 32, color: Colors.white24),

              // Render Distance Section
              _buildSectionHeader('Render Distance', Icons.visibility),
              const SizedBox(height: 8),
              _buildSliderTile(
                value: _settings.renderDistance,
                min: 50,
                max: 500,
                divisions: 9,
                label: '${_settings.renderDistance.toInt()}m',
                icon: Icons.remove_red_eye,
                onChanged: (value) {
                  setState(() => _settings.setRenderDistance(value));
                },
              ),
              const Divider(height: 32, color: Colors.white24),

              // Visual Effects Section
              _buildSectionHeader('Visual Effects', Icons.palette),
              const SizedBox(height: 12),

              _buildSwitchTile(
                'Dynamic Shadows',
                'Realistic shadow rendering',
                Icons.wb_sunny,
                _settings.shadowsEnabled,
                (value) => setState(() => _settings.setShadows(value)),
              ),
              
              if (_settings.shadowsEnabled)
                Padding(
                  padding: const EdgeInsets.only(left: 56, bottom: 8),
                  child: _buildMiniSlider(
                    value: _settings.shadowQuality,
                    min: 0.5,
                    max: 2.0,
                    divisions: 3,
                    label: '${(_settings.shadowQuality * 50).toInt()}%',
                    onChanged: (value) {
                      setState(() => _settings.setShadowQuality(value));
                    },
                  ),
                ),

              _buildSwitchTile(
                'Ambient Occlusion',
                'Depth and shadow at corners',
                Icons.blur_on,
                _settings.ambientOcclusion,
                (value) => setState(() => _settings.setAmbientOcclusion(value)),
              ),

              _buildSwitchTile(
                'Bloom Effect',
                'Glow on bright surfaces',
                Icons.light_mode,
                _settings.bloomEffect,
                (value) => setState(() => _settings.setBloom(value)),
              ),

              _buildSwitchTile(
                'Anti-Aliasing',
                'Smooth edges',
                Icons.grid_on,
                _settings.antiAliasing,
                (value) => setState(() => _settings.setAntiAliasing(value)),
              ),

              const Divider(height: 32, color: Colors.white24),

              // Lighting Section
              _buildSectionHeader('Lighting', Icons.wb_twilight),
              const SizedBox(height: 12),

              _buildSwitchTile(
                'Dynamic Lighting',
                'Real-time light calculations',
                Icons.wb_sunny_outlined,
                _settings.dynamicLighting,
                (value) => setState(() => _settings.setDynamicLighting(value)),
              ),

              _buildSwitchTile(
                'Texture Filtering',
                'High quality textures',
                Icons.texture,
                _settings.textureFiltering,
                (value) => setState(() => _settings.setTextureFiltering(value)),
              ),

              _buildSwitchTile(
                'Atmospheric Fog',
                'Distance fog effect',
                Icons.cloud,
                _settings.fogEnabled,
                (value) => setState(() => _settings.setFogEnabled(value)),
              ),

              const SizedBox(height: 16),

              // Performance Info
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.white12),
                ),
                child: Row(
                  children: [
                    Icon(
                      _settings.quality == GraphicsQuality.ultra
                          ? Icons.battery_alert
                          : Icons.battery_std,
                      color: _settings.quality == GraphicsQuality.ultra
                          ? Colors.orange
                          : Colors.green,
                      size: 20,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Performance: ${_getPerformanceLabel()}',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                          Text(
                            _getPerformanceDescription(),
                            style: TextStyle(
                              fontSize: 10,
                              color: Colors.grey[400],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton.icon(
          onPressed: () {
            setState(() => _settings.setQuality(GraphicsQuality.low));
          },
          icon: const Icon(Icons.restore, size: 18),
          label: const Text('Reset to Low'),
        ),
        ElevatedButton.icon(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.check, size: 18),
          label: const Text('Apply'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue,
            foregroundColor: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 18, color: Colors.blue),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _buildQualitySelector() {
    return Column(
      children: [
        SegmentedButton<GraphicsQuality>(
          segments: const [
            ButtonSegment(
              value: GraphicsQuality.low,
              label: Text('Low'),
              icon: Icon(Icons.speed, size: 16),
            ),
            ButtonSegment(
              value: GraphicsQuality.medium,
              label: Text('Med'),
              icon: Icon(Icons.trending_up, size: 16),
            ),
            ButtonSegment(
              value: GraphicsQuality.high,
              label: Text('High'),
              icon: Icon(Icons.high_quality, size: 16),
            ),
            ButtonSegment(
              value: GraphicsQuality.ultra,
              label: Text('Ultra'),
              icon: Icon(Icons.auto_awesome, size: 16),
            ),
          ],
          selected: {_settings.quality},
          onSelectionChanged: (Set<GraphicsQuality> selected) {
            if (selected.isNotEmpty) {
              setState(() => _settings.setQuality(selected.first));
            }
          },
          style: SegmentedButton.styleFrom(
            selectedForegroundColor: Colors.white,
            selectedBackgroundColor: Colors.blue,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          _getQualityDescription(),
          style: TextStyle(fontSize: 11, color: Colors.grey[400]),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildSwitchTile(
    String title,
    String subtitle,
    IconData icon,
    bool value,
    ValueChanged<bool> onChanged,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.grey),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 13)),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 10, color: Colors.grey[500]),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: Colors.blue,
          ),
        ],
      ),
    );
  }

  Widget _buildSliderTile({
    required double value,
    required double min,
    required double max,
    required int divisions,
    required String label,
    required IconData icon,
    required ValueChanged<double> onChanged,
  }) {
    return Row(
      children: [
        Icon(icon, size: 20, color: Colors.grey),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Slider(
                value: value,
                min: min,
                max: max,
                divisions: divisions,
                label: label,
                onChanged: onChanged,
                activeColor: Colors.blue,
              ),
            ],
          ),
        ),
        SizedBox(
          width: 60,
          child: Text(
            label,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
            textAlign: TextAlign.right,
          ),
        ),
      ],
    );
  }

  Widget _buildMiniSlider({
    required double value,
    required double min,
    required double max,
    required int divisions,
    required String label,
    required ValueChanged<double> onChanged,
  }) {
    return Row(
      children: [
        const Text('Quality:', style: TextStyle(fontSize: 11)),
        const SizedBox(width: 8),
        Expanded(
          child: Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions,
            label: label,
            onChanged: onChanged,
            activeColor: Colors.blue,
          ),
        ),
      ],
    );
  }

  String _getQualityDescription() {
    switch (_settings.quality) {
      case GraphicsQuality.low:
        return 'Optimized for low-end devices. Basic graphics with minimal effects.';
      case GraphicsQuality.medium:
        return 'Balanced performance. Good visuals with stable framerate.';
      case GraphicsQuality.high:
        return 'High quality visuals. Recommended for most modern devices.';
      case GraphicsQuality.ultra:
        return 'Maximum quality. Best visuals, requires powerful device.';
    }
  }

  String _getPerformanceLabel() {
    switch (_settings.quality) {
      case GraphicsQuality.low:
        return 'Battery Saver';
      case GraphicsQuality.medium:
        return 'Balanced';
      case GraphicsQuality.high:
        return 'High Performance';
      case GraphicsQuality.ultra:
        return 'Maximum';
    }
  }

  String _getPerformanceDescription() {
    switch (_settings.quality) {
      case GraphicsQuality.low:
        return 'Best battery life, lower visual quality';
      case GraphicsQuality.medium:
        return 'Good balance of visuals and battery';
      case GraphicsQuality.high:
        return 'Great visuals, moderate battery usage';
      case GraphicsQuality.ultra:
        return 'Best visuals, high battery usage';
    }
  }
}
