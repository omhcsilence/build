import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ZoomControl extends StatelessWidget {
  final double currentZoom;
  final double minZoom;
  final double maxZoom;
  final Function(double) onZoomChanged;

  const ZoomControl({
    super.key,
    required this.currentZoom,
    required this.minZoom,
    required this.maxZoom,
    required this.onZoomChanged,
  });

  final List<double> zoomPresets = const [0.5, 1.0, 2.0, 3.0];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Preset buttons
          ...zoomPresets.map((zoom) {
            final isSelected = (currentZoom - zoom).abs() < 0.1;
            return GestureDetector(
              onTap: () => onZoomChanged(zoom),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                decoration: BoxDecoration(
                  color: isSelected ? Colors.white.withOpacity(0.2) : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${zoom}x',
                  style: TextStyle(
                    color: isSelected ? Colors.white : Colors.white.withOpacity(0.7),
                    fontSize: 13.sp,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                  ),
                ),
              ),
            );
          }).toList(),

          // Slider
          SizedBox(
            width: 100.w,
            child: SliderTheme(
              data: SliderThemeData(
                trackHeight: 4.h,
                activeTrackColor: Colors.white,
                inactiveTrackColor: Colors.white.withOpacity(0.3),
                thumbColor: Colors.white,
                thumbShape: RoundSliderThumbShape(
                  enabledThumbRadius: 8.w,
                ),
                overlayShape: RoundSliderOverlayShape(
                  overlayRadius: 16.w,
                ),
              ),
              child: Slider(
                value: currentZoom.clamp(minZoom, maxZoom),
                min: minZoom,
                max: maxZoom,
                onChanged: onZoomChanged,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
