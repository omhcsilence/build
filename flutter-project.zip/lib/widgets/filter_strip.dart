import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class FilterStrip extends StatelessWidget {
  final String currentFilter;
  final Function(String) onFilterChanged;

  const FilterStrip({
    super.key,
    required this.currentFilter,
    required this.onFilterChanged,
  });

  final List<Map<String, dynamic>> filters = const [
    {'name': 'Original', 'id': 'none', 'color1': 0xFF667EEA, 'color2': 0xFF764BA2},
    {'name': 'Vivid', 'id': 'vivid', 'color1': 0xFFF093FB, 'color2': 0xFFF5576C},
    {'name': 'Dramatic', 'id': 'dramatic', 'color1': 0xFF4FACFE, 'color2': 0xFF00F2FE},
    {'name': 'Noir', 'id': 'noir', 'color1': 0xFF434343, 'color2': 0xFF000000},
    {'name': 'Chrome', 'id': 'chrome', 'color1': 0xFFFA709A, 'color2': 0xFFFEE140},
    {'name': 'Fade', 'id': 'fade', 'color1': 0xFFA8EDEA, 'color2': 0xFFFED6E3},
    {'name': 'Cool', 'id': 'cool', 'color1': 0xFF667EEA, 'color2': 0xFF764BA2},
    {'name': 'Warm', 'id': 'warm', 'color1': 0xFFF6D365, 'color2': 0xFFFDA085},
    {'name': 'Mono', 'id': 'mono', 'color1': 0xFFE0E0E0, 'color2': 0xFFBDBDBD},
    {'name': 'Silvertone', 'id': 'silvertone', 'color1': 0xFFD7D2CC, 'color2': 0xFF304352},
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 90.h,
      padding: EdgeInsets.symmetric(vertical: 10.h),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        itemCount: filters.length,
        itemBuilder: (context, index) {
          final filter = filters[index];
          final isSelected = filter['id'] == currentFilter;

          return GestureDetector(
            onTap: () => onFilterChanged(filter['id'] as String),
            child: Container(
              width: 60.w,
              margin: EdgeInsets.only(right: 12.w),
              child: Column(
                children: [
                  // Filter preview
                  Container(
                    width: 60.w,
                    height: 60.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(filter['color1'] as int),
                          Color(filter['color2'] as int),
                        ],
                      ),
                      border: isSelected
                          ? Border.all(
                              color: const Color(0xFFFF9500),
                              width: 3,
                            )
                          : null,
                    ),
                    child: _buildFilterOverlay(filter['id'] as String),
                  ),
                  SizedBox(height: 6.h),
                  // Filter name
                  Text(
                    filter['name'] as String,
                    style: TextStyle(
                      color: isSelected
                          ? const Color(0xFFFF9500)
                          : Colors.white.withOpacity(0.7),
                      fontSize: 11.sp,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildFilterOverlay(String filterId) {
    // Apply filter effects as overlays
    switch (filterId) {
      case 'vivid':
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: Colors.white.withOpacity(0.1),
          ),
        );
      case 'noir':
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: Colors.black.withOpacity(0.3),
          ),
        );
      case 'mono':
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: Colors.grey.withOpacity(0.3),
          ),
        );
      default:
        return const SizedBox.shrink();
    }
  }
}
