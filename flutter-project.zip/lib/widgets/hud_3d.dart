import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';

class Hud3D extends StatelessWidget {
  final int score;
  final int health;
  final v.Vector3 playerPos;
  final double playerYaw;
  final WorldState worldState;
  final Function(v.Vector2) onJoystickMove;
  final VoidCallback onJump;

  const Hud3D({
    super.key,
    required this.score,
    required this.health,
    required this.playerPos,
    required this.playerYaw,
    required this.worldState,
    required this.onJoystickMove,
    required this.onJump,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          top: 20,
          left: 20,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                const Icon(Icons.local_cafe, color: Colors.amber, size: 20),
                const SizedBox(width: 8),
                Text('SCORE: $score', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
        Positioned(
          bottom: 40,
          left: 20,
          child: _VirtualJoystick(onMove: onJoystickMove),
        ),
        Positioned(
          bottom: 50,
          right: 30,
          child: GestureDetector(
            onTap: onJump,
            child: Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white24,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: const Icon(Icons.arrow_upward, color: Colors.white, size: 36),
            ),
          ),
        ),
      ],
    );
  }
}

class _VirtualJoystick extends StatefulWidget {
  final Function(v.Vector2) onMove;
  const _VirtualJoystick({required this.onMove});
  @override
  State<_VirtualJoystick> createState() => _VirtualJoystickState();
}

class _VirtualJoystickState extends State<_VirtualJoystick> {
  Offset _delta = Offset.zero;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanUpdate: (d) {
        final n = _delta + d.delta;
        final c = Offset(n.dx.clamp(-40.0, 40.0), n.dy.clamp(-40.0, 40.0));
        setState(() => _delta = c);
        widget.onMove(v.Vector2(c.dx / 40.0, -c.dy / 40.0));
      },
      onPanEnd: (_) {
        setState(() => _delta = Offset.zero);
        widget.onMove(v.Vector2.zero());
      },
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          color: Colors.white10,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white30, width: 2),
        ),
        child: Center(
          child: Transform.translate(
            offset: _delta,
            child: Container(width: 40, height: 40, decoration: const BoxDecoration(color: Colors.amber, shape: BoxShape.circle)),
          ),
        ),
      ),
    );
  }
}
