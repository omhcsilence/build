import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';

class Hud3D extends StatelessWidget {
  final int score;
  final int health;
  final v.Vector3 playerPos;
  final double playerYaw;
  final WorldState worldState;
  final Function(v.Vector2) onJoystickMove;
  final VoidCallback onJump;

  const Hud3D({
    super.key,
    required this.score,
    required this.health,
    required this.playerPos,
    required this.playerYaw,
    required this.worldState,
    required this.onJoystickMove,
    required this.onJump,
  });

  @override
  Widget build(BuildContext meContext) {
    return Stack(
      children: [
        // Top HUD Status
        Positioned(
          top: 40,
          left: 20,
          right: 20,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.amber, width: 1.5),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.local_cafe, color: Colors.amber, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'SCORE: $score',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              _buildMiniMap(),
            ],
          ),
        ),

        // Virtual Controls (WASD Joystick Area)
        Positioned(
          bottom: 40,
          left: 20,
          child: _VirtualJoystick(onMove: onJoystickMove),
        ),

        // Jump Button
        Positioned(
          bottom: 50,
          right: 30,
          child: GestureDetector(
            onTapDown: (_) => onJump(),
            child: Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.3),
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: const Icon(Icons.arrow_upward, color: Colors.white, size: 36),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMiniMap() {
    return Container(
      width: 90,
      height: 90,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
      ),
      child: CustomPaint(
        painter: MiniMapPainter(
          playerPos: playerPos,
          playerYaw: playerYaw,
          worldState: worldState,
        ),
      ),
    );
  }
}

class _VirtualJoystick extends StatefulWidget {
  final Function(v.Vector2) onMove;
  const _VirtualJoystick({required this.onMove});

  @override
  State<_VirtualJoystick> createState() => _VirtualJoystickState();
}

class _VirtualJoystickState extends State<_VirtualJoystick> {
  Offset _delta = Offset.zero;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanUpdate: (details) {
        final newDelta = _delta + details.delta;
        final clamped = Offset(
          newDelta.dx.clamp(-40.0, 40.0),
          newDelta.dy.clamp(-40.0, 40.0),
        );
        setState(() => _delta = clamped);
        widget.onMove(v.Vector2(clamped.dx / 40.0, -clamped.dy / 40.0));
      },
      onPanEnd: (_) {
        setState(() => _delta = Offset.zero);
        widget.onMove(v.Vector2.zero());
      },
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white30, width: 2),
        ),
        child: Center(
          child: Transform.translate(
            offset: _delta,
            child: Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                color: Colors.amber,
                shape: BoxShape.circle,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MiniMapPainter extends CustomPainter {
  final v.Vector3 playerPos;
  final double playerYaw;
  final WorldState worldState;

  MiniMapPainter({
    required this.playerPos,
    required this.playerYaw,
    required this.worldState,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    const scale = 1.2;

    // Draw Buildings
    final buildingPaint = Paint()..color = Colors.blueGrey;
    for (var b in worldState.buildings) {
      final dx = center.dx + (b.position.x - playerPos.x) * scale;
      final dy = center.dy + (b.position.z - playerPos.z) * scale;
      canvas.drawRect(
        Rect.fromCenter(center: Offset(dx, dy), width: b.size.x * scale, height: b.size.z * scale),
        buildingPaint,
      );
    }

    // Draw Player
    final playerPaint = Paint()..color = Colors.redAccent;
    canvas.drawCircle(center, 4.0, playerPaint);

    // Player Direction Line
    final dirPaint = Paint()
      ..color = Colors.yellow
      ..strokeWidth = 2.0;
    final dirX = center.dx + math.sin(playerYaw) * 10;
    final dirY = center.dy + math.cos(playerYaw) * 10;
    canvas.drawLine(center, Offset(dirX, dirY), dirPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
