import 'package:permission_handler/permission_handler.dart';

class PermissionService {
  // Check camera permission
  Future<bool> checkCameraPermission() async {
    final status = await Permission.camera.status;
    return status.isGranted;
  }
  
  // Request camera permission
  Future<bool> requestCameraPermission() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }
  
  // Check microphone permission
  Future<bool> checkMicrophonePermission() async {
    final status = await Permission.microphone.status;
    return status.isGranted;
  }
  
  // Request microphone permission
  Future<bool> requestMicrophonePermission() async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }
  
  // Check storage permission
  Future<bool> checkStoragePermission() async {
    final status = await Permission.storage.status;
    return status.isGranted;
  }
  
  // Request storage permission
  Future<bool> requestStoragePermission() async {
    final status = await Permission.storage.request();
    return status.isGranted;
  }
  
  // Check photos permission (iOS)
  Future<bool> checkPhotosPermission() async {
    final status = await Permission.photos.status;
    return status.isGranted;
  }
  
  // Request photos permission
  Future<bool> requestPhotosPermission() async {
    final status = await Permission.photos.request();
    return status.isGranted;
  }
  
  // Check location permission
  Future<bool> checkLocationPermission() async {
    final status = await Permission.locationWhenInUse.status;
    return status.isGranted;
  }
  
  // Request location permission
  Future<bool> requestLocationPermission() async {
    final status = await Permission.locationWhenInUse.request();
    return status.isGranted;
  }
  
  // Request all required permissions
  Future<Map<String, bool>> requestAllPermissions() async {
    final results = await [
      Permission.camera,
      Permission.microphone,
      Permission.storage,
      Permission.photos,
      Permission.locationWhenInUse,
    ].request();
    
    return {
      'camera': results[Permission.camera]?.isGranted ?? false,
      'microphone': results[Permission.microphone]?.isGranted ?? false,
      'storage': results[Permission.storage]?.isGranted ?? false,
      'photos': results[Permission.photos]?.isGranted ?? false,
      'location': results[Permission.locationWhenInUse]?.isGranted ?? false,
    };
  }
  
  // Check if all required permissions are granted
  Future<bool> hasAllPermissions() async {
    final camera = await checkCameraPermission();
    final microphone = await checkMicrophonePermission();
    final storage = await checkStoragePermission();
    
    return camera && microphone && storage;
  }
  
  // Open app settings
  Future<void> openAppSettings() async {
    await openAppSettings();
  }
}
