import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';

class MapService {
  static WorldState generateWorld() {
    final buildings = <Building>[
      Building(
        id: 'b1',
        position: v.Vector3(-10, 0, 15),
        size: v.Vector3(6, 12, 6),
        colorHex: 0xFF1976D2,
      ),
      Building(
        id: 'b2',
        position: v.Vector3(12, 0, 10),
        size: v.Vector3(8, 8, 8),
        colorHex: 0xFF388E3C,
      ),
      Building(
        id: 'b3',
        position: v.Vector3(-15, 0, -10),
        size: v.Vector3(5, 15, 5),
        colorHex: 0xFFE64A19,
      ),
      Building(
        id: 'b4',
        position: v.Vector3(10, 0, -15),
        size: v.Vector3(7, 10, 7),
        colorHex: 0xFF7B1FA2,
      ),
    ];

    final roads = <Road>[
      Road(
        id: 'r1',
        start: v.Vector3(0, 0, -40),
        end: v.Vector3(0, 0, 40),
        width: 6.0,
      ),
      Road(
        id: 'r2',
        start: v.Vector3(-40, 0, 0),
        end: v.Vector3(40, 0, 0),
        width: 6.0,
      ),
    ];

    final collectibles = <Collectible>[
      Collectible(
        id: 'c1',
        position: v.Vector3(3, 1.2, 5),
        type: CollectibleType.coffee,
      ),
      Collectible(
        id: 'c2',
        position: v.Vector3(-4, 1.2, 8),
        type: CollectibleType.coin,
      ),
      Collectible(
        id: 'c3',
        position: v.Vector3(5, 1.2, -7),
        type: CollectibleType.star,
      ),
      Collectible(
        id: 'c4',
        position: v.Vector3(-8, 1.2, -5),
        type: CollectibleType.coffee,
      ),
    ];

    return WorldState(
      mapSize: 100.0,
      buildings: buildings,
      roads: roads,
      collectibles: collectibles,
    );
  }
}
