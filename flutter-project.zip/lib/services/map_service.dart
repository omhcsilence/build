import 'dart:math' as math;
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';

class MapService {
  static final _random = math.Random();

  static WorldState generateWorld() {
    final buildings = _generateOpenWorldBuildings();
    final roads = _generateOpenWorldRoads();
    final collectibles = _generateOpenWorldCollectibles();

    return WorldState(
      mapSize: 500.0,
      buildings: buildings,
      roads: roads,
      collectibles: collectibles,
    );
  }

  static List<Building> _generateOpenWorldBuildings() {
    final buildings = <Building>[
      Building(
        id: 'b1',
        name: 'Kedai Mokka Central',
        position: v.Vector3(-10, 0, 15),
        size: v.Vector3(6, 12, 6),
        colorHex: 0xFF1976D2,
        textureType: BuildingTexture.modernGlass,
      ),
      Building(
        id: 'b2',
        name: 'Sky Tower',
        position: v.Vector3(12, 0, 10),
        size: v.Vector3(8, 8, 8),
        colorHex: 0xFF388E3C,
        textureType: BuildingTexture.concrete,
      ),
      Building(
        id: 'b3',
        name: 'Red Plaza',
        position: v.Vector3(-15, 0, -10),
        size: v.Vector3(5, 15, 5),
        colorHex: 0xFFE64A19,
        textureType: BuildingTexture.brick,
      ),
      Building(
        id: 'b4',
        name: 'Purple Mall',
        position: v.Vector3(10, 0, -15),
        size: v.Vector3(7, 10, 7),
        colorHex: 0xFF7B1FA2,
        textureType: BuildingTexture.modernGlass,
      ),
      Building(
        id: 'b5',
        name: 'North Residence',
        position: v.Vector3(-50, 0, -50),
        size: v.Vector3(10, 8, 10),
        colorHex: 0xFF8D6E63,
        textureType: BuildingTexture.residential,
      ),
      Building(
        id: 'b6',
        name: 'East Office',
        position: v.Vector3(60, 0, -40),
        size: v.Vector3(12, 20, 8),
        colorHex: 0xFF455A64,
        textureType: BuildingTexture.concrete,
      ),
      Building(
        id: 'b7',
        name: 'South Market',
        position: v.Vector3(-30, 0, 70),
        size: v.Vector3(15, 6, 12),
        colorHex: 0xFFF57C00,
        textureType: BuildingTexture.brick,
      ),
      Building(
        id: 'b8',
        name: 'West Apartments',
        position: v.Vector3(80, 0, 30),
        size: v.Vector3(20, 25, 10),
        colorHex: 0xFF5E35B1,
        textureType: BuildingTexture.residential,
      ),
      Building(
        id: 'b9',
        name: 'Tech Hub',
        position: v.Vector3(-70, 0, 20),
        size: v.Vector3(14, 18, 14),
        colorHex: 0xFF00897B,
        textureType: BuildingTexture.modernGlass,
      ),
      Building(
        id: 'b10',
        name: 'Grand Hotel',
        position: v.Vector3(40, 0, 60),
        size: v.Vector3(16, 30, 12),
        colorHex: 0xFFD4AF37,
        textureType: BuildingTexture.luxury,
      ),
      Building(
        id: 'b11',
        name: 'Industrial Warehouse',
        position: v.Vector3(-90, 0, -30),
        size: v.Vector3(25, 10, 15),
        colorHex: 0xFF6D4C41,
        textureType: BuildingTexture.industrial,
      ),
      Building(
        id: 'b12',
        name: 'Shopping Center',
        position: v.Vector3(25, 0, -80),
        size: v.Vector3(30, 12, 20),
        colorHex: 0xFFAD1457,
        textureType: BuildingTexture.modernGlass,
      ),
    ];

    // Generate procedural buildings
    for (int i = 0; i < 30; i++) {
      final x = (_random.nextDouble() - 0.5) * 400;
      final z = (_random.nextDouble() - 0.5) * 400;
      if (x.abs() < 30 && z.abs() < 30) continue;

      final height = 5 + _random.nextDouble() * 20;
      final width = 5 + _random.nextDouble() * 10;
      final depth = 5 + _random.nextDouble() * 10;

      final colors = [
        0xFF1976D2, 0xFF388E3C, 0xFFE64A19,
        0xFF7B1FA2, 0xFF5D4037, 0xFF455A64,
      ];

      buildings.add(Building(
        id: 'proc_b_$i',
        name: 'Building ${i + 1}',
        position: v.Vector3(x, 0, z),
        size: v.Vector3(width, height, depth),
        colorHex: colors[_random.nextInt(colors.length)],
        textureType: BuildingTexture.values[_random.nextInt(BuildingTexture.values.length)],
      ));
    }

    return buildings;
  }

  static List<Road> _generateOpenWorldRoads() {
    return <Road>[
      Road(
        id: 'r1',
        name: 'Main Highway North',
        start: v.Vector3(-200, 0, -40),
        end: v.Vector3(200, 0, -40),
        width: 12.0,
      ),
      Road(
        id: 'r2',
        name: 'Main Highway South',
        start: v.Vector3(-200, 0, 40),
        end: v.Vector3(200, 0, 40),
        width: 12.0,
      ),
      Road(
        id: 'r3',
        name: 'Central Avenue',
        start: v.Vector3(0, 0, -200),
        end: v.Vector3(0, 0, 200),
        width: 10.0,
      ),
      Road(
        id: 'r4',
        name: 'Ring Road East',
        start: v.Vector3(150, 0, -150),
        end: v.Vector3(150, 0, 150),
        width: 8.0,
      ),
      Road(
        id: 'r5',
        name: 'Ring Road West',
        start: v.Vector3(-150, 0, -150),
        end: v.Vector3(-150, 0, 150),
        width: 8.0,
      ),
      Road(
        id: 'r6',
        name: 'Connector A',
        start: v.Vector3(-100, 0, -100),
        end: v.Vector3(100, 0, 100),
        width: 6.0,
      ),
      Road(
        id: 'r7',
        name: 'Connector B',
        start: v.Vector3(100, 0, -100),
        end: v.Vector3(-100, 0, 100),
        width: 6.0,
      ),
    ];
  }

  static List<Collectible> _generateOpenWorldCollectibles() {
    final collectibles = <Collectible>[
      Collectible(id: 'c1', position: v.Vector3(3, 1.2, 5), type: CollectibleType.coffee),
      Collectible(id: 'c2', position: v.Vector3(-4, 1.2, 8), type: CollectibleType.coin),
      Collectible(id: 'c3', position: v.Vector3(5, 1.2, -7), type: CollectibleType.star),
      Collectible(id: 'c4', position: v.Vector3(-8, 1.2, -5), type: CollectibleType.coffee),
      Collectible(id: 'c5', position: v.Vector3(50, 1.2, 50), type: CollectibleType.coin),
      Collectible(id: 'c6', position: v.Vector3(-60, 1.2, 40), type: CollectibleType.star),
      Collectible(id: 'c7', position: v.Vector3(70, 1.2, -50), type: CollectibleType.coffee),
      Collectible(id: 'c8', position: v.Vector3(-80, 1.2, -60), type: CollectibleType.coin),
    ];

    for (int i = 0; i < 20; i++) {
      final x = (_random.nextDouble() - 0.5) * 350;
      final z = (_random.nextDouble() - 0.5) * 350;
      final types = CollectibleType.values;

      collectibles.add(Collectible(
        id: 'proc_c_$i',
        position: v.Vector3(x, 1.2, z),
        type: types[_random.nextInt(types.length)],
      ));
    }

    return collectibles;
  }
}
