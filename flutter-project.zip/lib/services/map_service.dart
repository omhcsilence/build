import 'dart:math' as math;
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';

class MapService {
  static final _random = math.Random();

  static WorldState generateWorld() {
    return WorldState(
      mapSize: 500.0,
      buildings: _generateBuildings(),
      roads: _generateRoads(),
      collectibles: _generateCollectibles(),
    );
  }

  static List<Building> _generateBuildings() {
    final buildings = <Building>[
      Building(
        id: 'b1',
        name: 'Kedai Mokka Central',
        position: v.Vector3(-10, 0, 15),
        size: v.Vector3(6, 12, 6),
        colorHex: 0xFF1976D2,
        textureType: BuildingTexture.modernGlass,
      ),
      Building(
        id: 'b2',
        name: 'Sky Tower',
        position: v.Vector3(12, 0, 10),
        size: v.Vector3(8, 8, 8),
        colorHex: 0xFF388E3C,
        textureType: BuildingTexture.concrete,
      ),
      Building(
        id: 'b3',
        name: 'Red Plaza',
        position: v.Vector3(-15, 0, -10),
        size: v.Vector3(5, 15, 5),
        colorHex: 0xFFE64A19,
        textureType: BuildingTexture.brick,
      ),
      Building(
        id: 'b4',
        name: 'Purple Mall',
        position: v.Vector3(10, 0, -15),
        size: v.Vector3(7, 10, 7),
        colorHex: 0xFF7B1FA2,
        textureType: BuildingTexture.modernGlass,
      ),
      Building(
        id: 'b5',
        name: 'North Residence',
        position: v.Vector3(-50, 0, -50),
        size: v.Vector3(10, 8, 10),
        colorHex: 0xFF8D6E63,
        textureType: BuildingTexture.residential,
      ),
      Building(
        id: 'b6',
        name: 'East Office',
        position: v.Vector3(60, 0, -40),
        size: v.Vector3(12, 20, 8),
        colorHex: 0xFF455A64,
        textureType: BuildingTexture.concrete,
      ),
      Building(
        id: 'b7',
        name: 'South Market',
        position: v.Vector3(-30, 0, 70),
        size: v.Vector3(15, 6, 12),
        colorHex: 0xFFF57C00,
        textureType: BuildingTexture.brick,
      ),
      Building(
        id: 'b8',
        name: 'West Apartments',
        position: v.Vector3(80, 0, 30),
        size: v.Vector3(20, 25, 10),
        colorHex: 0xFF5E35B1,
        textureType: BuildingTexture.residential,
      ),
      Building(
        id: 'b9',
        name: 'Tech Hub',
        position: v.Vector3(-70, 0, 20),
        size: v.Vector3(14, 18, 14),
        colorHex: 0xFF00897B,
        textureType: BuildingTexture.modernGlass,
      ),
      Building(
        id: 'b10',
        name: 'Grand Hotel',
        position: v.Vector3(40, 0, 60),
        size: v.Vector3(16, 30, 12),
        colorHex: 0xFFD4AF37,
        textureType: BuildingTexture.luxury,
      ),
    ];

    // Procedural buildings
    for (int i = 0; i < 20; i++) {
      final x = (_random.nextDouble() - 0.5) * 400;
      final z = (_random.nextDouble() - 0.5) * 400;
      if (x.abs() < 30 && z.abs() < 30) continue;

      buildings.add(Building(
        id: 'proc_$i',
        name: 'Building ${i + 1}',
        position: v.Vector3(x, 0, z),
        size: v.Vector3(
          5 + _random.nextDouble() * 10,
          5 + _random.nextDouble() * 20,
          5 + _random.nextDouble() * 10,
        ),
        colorHex: [0xFF1976D2, 0xFF388E3C, 0xFFE64A19, 0xFF7B1FA2][_random.nextInt(4)],
        textureType: BuildingTexture.values[_random.nextInt(BuildingTexture.values.length)],
      ));
    }

    return buildings;
  }

  static List<Road> _generateRoads() {
    return [
      Road(id: 'r1', name: 'Highway North', start: v.Vector3(-200, 0, -40), end: v.Vector3(200, 0, -40), width: 12),
      Road(id: 'r2', name: 'Highway South', start: v.Vector3(-200, 0, 40), end: v.Vector3(200, 0, 40), width: 12),
      Road(id: 'r3', name: 'Central Ave', start: v.Vector3(0, 0, -200), end: v.Vector3(0, 0, 200), width: 10),
    ];
  }

  static List<Collectible> _generateCollectibles() {
    final items = <Collectible>[];
    for (int i = 0; i < 15; i++) {
      items.add(Collectible(
        id: 'c$i',
        position: v.Vector3(
          (_random.nextDouble() - 0.5) * 300,
          1.2,
          (_random.nextDouble() - 0.5) * 300,
        ),
        type: CollectibleType.values[_random.nextInt(3)],
      ));
    }
    return items;
  }
}
