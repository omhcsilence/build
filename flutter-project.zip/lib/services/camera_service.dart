import 'dart:async';
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' show join;
import 'package:path_provider/path_provider.dart';
import 'package:geolocator/geolocator.dart';

class CameraService {
  CameraController? _controller;
  bool _isInitialized = false;
  
  // Camera settings
  double _currentZoom = 1.0;
  double _minZoom = 1.0;
  double _maxZoom = 1.0;
  FlashMode _flashMode = FlashMode.off;
  ExposureMode _exposureMode = ExposureMode.auto;
  FocusMode _focusMode = FocusMode.auto;
  
  // Getters
  CameraController? get controller => _controller;
  bool get isInitialized => _isInitialized;
  double get currentZoom => _currentZoom;
  double get minZoom => _minZoom;
  double get maxZoom => _maxZoom;
  FlashMode get flashMode => _flashMode;
  
  // Initialize camera
  Future<void> initialize(CameraDescription camera) async {
    if (_controller != null) {
      await _controller!.dispose();
    }
    
    _controller = CameraController(
      camera,
      ResolutionPreset.ultraHigh,
      enableAudio: true,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );
    
    await _controller!.initialize();
    
    // Get zoom range
    _minZoom = await _controller!.getMinZoomLevel();
    _maxZoom = await _controller!.getMaxZoomLevel();
    _currentZoom = _minZoom;
    
    _isInitialized = true;
  }
  
  // Dispose camera
  Future<void> dispose() async {
    await _controller?.dispose();
    _controller = null;
    _isInitialized = false;
  }
  
  // Switch camera
  Future<void> switchCamera(CameraDescription camera) async {
    await initialize(camera);
  }
  
  // Set zoom
  Future<void> setZoom(double zoom) async {
    if (_controller == null || !_isInitialized) return;
    
    zoom = zoom.clamp(_minZoom, _maxZoom);
    await _controller!.setZoomLevel(zoom);
    _currentZoom = zoom;
  }
  
  // Set flash mode
  Future<void> setFlashMode(FlashMode mode) async {
    if (_controller == null || !_isInitialized) return;
    
    await _controller!.setFlashMode(mode);
    _flashMode = mode;
  }
  
  // Toggle flash
  Future<FlashMode> toggleFlash() async {
    FlashMode newMode;
    switch (_flashMode) {
      case FlashMode.off:
        newMode = FlashMode.auto;
        break;
      case FlashMode.auto:
        newMode = FlashMode.always;
        break;
      case FlashMode.always:
        newMode = FlashMode.torch;
        break;
      case FlashMode.torch:
        newMode = FlashMode.off;
        break;
    }
    await setFlashMode(newMode);
    return newMode;
  }
  
  // Set focus point
  Future<void> setFocusPoint(Offset point) async {
    if (_controller == null || !_isInitialized) return;
    
    await _controller!.setFocusPoint(point);
    await _controller!.setFocusMode(FocusMode.auto);
  }
  
  // Set exposure point
  Future<void> setExposurePoint(Offset point) async {
    if (_controller == null || !_isInitialized) return;
    
    await _controller!.setExposurePoint(point);
    await _controller!.setExposureMode(ExposureMode.auto);
  }
  
  // Set exposure offset
  Future<void> setExposureOffset(double offset) async {
    if (_controller == null || !_isInitialized) return;
    
    await _controller!.setExposureOffset(offset);
  }
  
  // Capture photo
  Future<XFile?> takePicture({bool saveToGallery = true}) async {
    if (_controller == null || !_isInitialized) return null;
    
    if (_controller!.value.isTakingPicture) return null;
    
    try {
      final XFile photo = await _controller!.takePicture();
      
      if (saveToGallery) {
        // Save to app directory
        final directory = await getApplicationDocumentsDirectory();
        final String fileName = 'IMG_${DateTime.now().millisecondsSinceEpoch}.jpg';
        final String filePath = join(directory.path, 'photos', fileName);
        
        // Create photos directory if not exists
        await Directory(join(directory.path, 'photos')).create(recursive: true);
        
        // Copy file
        final File newImage = await File(photo.path).copy(filePath);
        
        // Get location
        try {
          final position = await Geolocator.getCurrentPosition();
          // TODO: Add EXIF data with location
        } catch (e) {
          // Location not available
        }
        
        return XFile(newImage.path);
      }
      
      return photo;
    } catch (e) {
      print('Error taking picture: $e');
      return null;
    }
  }
  
  // Start video recording
  Future<void> startVideoRecording() async {
    if (_controller == null || !_isInitialized) return;
    
    if (_controller!.value.isRecordingVideo) return;
    
    try {
      await _controller!.startVideoRecording();
    } catch (e) {
      print('Error starting video: $e');
    }
  }
  
  // Stop video recording
  Future<XFile?> stopVideoRecording() async {
    if (_controller == null || !_isInitialized) return null;
    
    if (!_controller!.value.isRecordingVideo) return null;
    
    try {
      final XFile video = await _controller!.stopVideoRecording();
      
      // Save to app directory
      final directory = await getApplicationDocumentsDirectory();
      final String fileName = 'VID_${DateTime.now().millisecondsSinceEpoch}.mp4';
      final String filePath = join(directory.path, 'videos', fileName);
      
      // Create videos directory if not exists
      await Directory(join(directory.path, 'videos')).create(recursive: true);
      
      // Copy file
      final File newVideo = await File(video.path).copy(filePath);
      
      return XFile(newVideo.path);
    } catch (e) {
      print('Error stopping video: $e');
      return null;
    }
  }
  
  // Pause video recording
  Future<void> pauseVideoRecording() async {
    if (_controller == null || !_isInitialized) return;
    await _controller!.pauseVideoRecording();
  }
  
  // Resume video recording
  Future<void> resumeVideoRecording() async {
    if (_controller == null || !_isInitialized) return;
    await _controller!.resumeVideoRecording();
  }
  
  // Lock capture orientation
  Future<void> lockCaptureOrientation(DeviceOrientation orientation) async {
    if (_controller == null || !_isInitialized) return;
    await _controller!.lockCaptureOrientation(orientation);
  }
  
  // Unlock capture orientation
  Future<void> unlockCaptureOrientation() async {
    if (_controller == null || !_isInitialized) return;
    await _controller!.unlockCaptureOrientation();
  }
  
  // Get available resolutions
  List<ResolutionPreset> get availableResolutions => [
    ResolutionPreset.low,
    ResolutionPreset.medium,
    ResolutionPreset.high,
    ResolutionPreset.veryHigh,
    ResolutionPreset.ultraHigh,
    ResolutionPreset.max,
  ];
  
  // Set resolution
  Future<void> setResolution(ResolutionPreset resolution) async {
    if (_controller == null) return;
    
    final camera = _controller!.description;
    await _controller!.dispose();
    
    _controller = CameraController(
      camera,
      resolution,
      enableAudio: true,
    );
    
    await _controller!.initialize();
  }
}
