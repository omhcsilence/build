import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';

class OsmService {
  // Koordinat Jl. Remujung No. 26 Malang
  static const double centerLat = -7.9448;
  static const double centerLon = 112.6156;

  // Konversi Lat/Lon ke Koordinat Lokal Game 3D (Meter)
  static v.Vector3 latLonToLocal(double lat, double lon, double height) {
    const double metersPerDegreeLat = 111132.92;
    final double metersPerDegreeLon = 111412.84 * math.cos(centerLat * math.pi / 180);

    double x = (lon - centerLon) * metersPerDegreeLon;
    double z = (lat - centerLat) * metersPerDegreeLat;

    return v.Vector3(x, height, z);
  }

  static Future<WorldState> fetchRealMalangWorld() async {
    // Query Overpass API untuk mengambil polygon gedung & jalan di sekitar Remujung
    final query = '''
      [out:json];
      (
        building(around:600, $centerLat, $centerLon);
        way["highway"](around:600, $centerLat, $centerLon);
      );
      out body;
      >;
      out skel qt;
    ''';

    final url = Uri.parse('https://overpass-api.de/api/interpreter?data=${Uri.encodeComponent(query)}');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return _parseOsmData(data);
      }
    } catch (e) {
      print("Error fetching OSM data: $e");
    }

    // Fallback jika offline/error
    return WorldState(mapSize: 200, buildings: [], roads: [], collectibles: []);
  }

  static WorldState _parseOsmData(Map<String, dynamic> json) {
    final nodes = <int, Map<String, double>>{};
    final buildings = <Building>[];
    final roads = <Road>[];

    // 1. Parsing Nodes (Titik Koordinat)
    final elements = json['elements'] as List;
    for (var elem in elements) {
      if (elem['type'] == 'node') {
        nodes[elem['id']] = {
          'lat': elem['lat'].toDouble(),
          'lon': elem['lon'].toDouble(),
        };
      }
    }

    // 2. Parsing Ways (Gedung & Jalan)
    int buildingIdCounter = 0;
    for (var elem in elements) {
      if (elem['type'] == 'way') {
        final tags = elem['tags'] ?? {};
        final nodeIds = List<int>.from(elem['nodes'] ?? []);

        // Jika ini Gedung
        if (tags.containsKey('building')) {
          final polygonVertices = <v.Vector3>[];
          double levels = double.tryParse(tags['building:levels'] ?? '1') ?? 1.0;
          double height = double.tryParse(tags['height'] ?? '') ?? (levels * 3.5);

          for (var nodeId in nodeIds) {
            if (nodes.containsKey(nodeId)) {
              final lat = nodes[nodeId]!['lat']!;
              final lon = nodes[nodeId]!['lon']!;
              polygonVertices.add(latLonToLocal(lat, lon, 0));
            }
          }

          if (polygonVertices.length >= 3) {
            // Hitung Center Position Gedung
            v.Vector3 center = v.Vector3.zero();
            for (var vtx in polygonVertices) {
              center += vtx;
            }
            center /= polygonVertices.length.toDouble();

            buildings.add(
              Building(
                id: 'osm_b_$buildingIdCounter',
                position: center,
                size: v.Vector3(10, height, 10), // Dihitung presisi berdasarkan polygon
                colorHex: 0xFF8D6E63,
                type: BuildingType.rumahJatimulyo,
              ),
            );
            buildingIdCounter++;
          }
        }

        // Jika ini Jalan Utama/Lokal
        else if (tags.containsKey('highway')) {
          for (int i = 0; i < nodeIds.length - 1; i++) {
            final n1 = nodes[nodeIds[i]];
            final n2 = nodes[nodeIds[i + 1]];
            if (n1 != null && n2 != null) {
              roads.add(
                Road(
                  id: 'road_${elem['id']}_$i',
                  start: latLonToLocal(n1['lat']!, n1['lon']!, 0),
                  end: latLonToLocal(n2['lat']!, n2['lon']!, 0),
                  width: tags['highway'] == 'primary' ? 8.0 : 4.0,
                ),
              );
            }
          }
        }
      }
    }

    return WorldState(
      mapSize: 300.0,
      buildings: buildings,
      roads: roads,
      collectibles: [],
    );
  }
}
