import 'dart:convert';
import 'dart:math' as math;
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';

class OsmService {
  static const double centerLat = -7.9448;
  static const double centerLon = 112.6156;

  static v.Vector3 latLonToLocal(double lat, double lon, double height) {
    const double metersPerDegreeLat = 111132.92;
    final double metersPerDegreeLon = 111412.84 * math.cos(centerLat * math.pi / 180);

    double x = (lon - centerLon) * metersPerDegreeLon;
    double z = (lat - centerLat) * metersPerDegreeLat;

    return v.Vector3(x, height, z);
  }

  static Future<WorldState> fetchRealMalangWorld() async {
    return WorldState(mapSize: 200, buildings: [], roads: [], collectibles: []);
  }
}
