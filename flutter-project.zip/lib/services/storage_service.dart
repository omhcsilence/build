import 'dart:io';
import 'package:camera/camera.dart';
import 'package:path/path.dart' show join;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class StorageService {
  static const String _photosKey = 'photos';
  static const String _videosKey = 'videos';
  static const String _settingsKey = 'settings';
  
  late SharedPreferences _prefs;
  
  // Initialize
  Future<void> initialize() async {
    _prefs = await SharedPreferences.getInstance();
  }
  
  // Get photos directory
  Future<Directory> getPhotosDirectory() async {
    final directory = await getApplicationDocumentsDirectory();
    final photosDir = Directory(join(directory.path, 'photos'));
    if (!await photosDir.exists()) {
      await photosDir.create(recursive: true);
    }
    return photosDir;
  }
  
  // Get videos directory
  Future<Directory> getVideosDirectory() async {
    final directory = await getApplicationDocumentsDirectory();
    final videosDir = Directory(join(directory.path, 'videos'));
    if (!await videosDir.exists()) {
      await videosDir.create(recursive: true);
    }
    return videosDir;
  }
  
  // Save photo metadata
  Future<void> savePhotoMetadata(Map<String, dynamic> metadata) async {
    final photos = await getPhotosMetadata();
    photos.add(metadata);
    await _prefs.setString(_photosKey, jsonEncode(photos));
  }
  
  // Get photos metadata
  Future<List<Map<String, dynamic>>> getPhotosMetadata() async {
    final String? data = _prefs.getString(_photosKey);
    if (data == null) return [];
    
    try {
      final List<dynamic> decoded = jsonDecode(data);
      return decoded.cast<Map<String, dynamic>>();
    } catch (e) {
      return [];
    }
  }
  
  // Save video metadata
  Future<void> saveVideoMetadata(Map<String, dynamic> metadata) async {
    final videos = await getVideosMetadata();
    videos.add(metadata);
    await _prefs.setString(_videosKey, jsonEncode(videos));
  }
  
  // Get videos metadata
  Future<List<Map<String, dynamic>>> getVideosMetadata() async {
    final String? data = _prefs.getString(_videosKey);
    if (data == null) return [];
    
    try {
      final List<dynamic> decoded = jsonDecode(data);
      return decoded.cast<Map<String, dynamic>>();
    } catch (e) {
      return [];
    }
  }
  
  // Get all media files
  Future<List<FileSystemEntity>> getAllMediaFiles() async {
    final List<FileSystemEntity> files = [];
    
    // Get photos
    final photosDir = await getPhotosDirectory();
    if (await photosDir.exists()) {
      files.addAll(await photosDir.list().toList());
    }
    
    // Get videos
    final videosDir = await getVideosDirectory();
    if (await videosDir.exists()) {
      files.addAll(await videosDir.list().toList());
    }
    
    // Sort by modification time (newest first)
    files.sort((a, b) {
      final aStat = a.statSync();
      final bStat = b.statSync();
      return bStat.modified.compareTo(aStat.modified);
    });
    
    return files;
  }
  
  // Delete file
  Future<bool> deleteFile(String path) async {
    try {
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      print('Error deleting file: $e');
      return false;
    }
  }
  
  // Get file size
  Future<String> getFileSize(String path) async {
    try {
      final file = File(path);
      final bytes = await file.length();
      
      if (bytes < 1024) {
        return '$bytes B';
      } else if (bytes < 1024 * 1024) {
        return '${(bytes / 1024).toStringAsFixed(1)} KB';
      } else if (bytes < 1024 * 1024 * 1024) {
        return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
      } else {
        return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
      }
    } catch (e) {
      return 'Unknown';
    }
  }
  
  // Get storage info
  Future<Map<String, dynamic>> getStorageInfo() async {
    final directory = await getApplicationDocumentsDirectory();
    final photosDir = await getPhotosDirectory();
    final videosDir = await getVideosDirectory();
    
    int photosSize = 0;
    int videosSize = 0;
    int photoCount = 0;
    int videoCount = 0;
    
    // Calculate photos size
    if (await photosDir.exists()) {
      await for (final file in photosDir.list()) {
        if (file is File) {
          photosSize += await file.length();
          photoCount++;
        }
      }
    }
    
    // Calculate videos size
    if (await videosDir.exists()) {
      await for (final file in videosDir.list()) {
        if (file is File) {
          videosSize += await file.length();
          videoCount++;
        }
      }
    }
    
    return {
      'photosSize': photosSize,
      'videosSize': videosSize,
      'totalSize': photosSize + videosSize,
      'photoCount': photoCount,
      'videoCount': videoCount,
      'freeSpace': await _getFreeSpace(),
    };
  }
  
  // Get free space
  Future<int> _getFreeSpace() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final stat = await directory.stat();
      // This is a simplified version - actual free space calculation
      // would require platform-specific code
      return 1024 * 1024 * 1024; // 1 GB placeholder
    } catch (e) {
      return 0;
    }
  }
  
  // Save settings
  Future<void> saveSettings(Map<String, dynamic> settings) async {
    await _prefs.setString(_settingsKey, jsonEncode(settings));
  }
  
  // Get settings
  Future<Map<String, dynamic>> getSettings() async {
    final String? data = _prefs.getString(_settingsKey);
    if (data == null) return {};
    
    try {
      return jsonDecode(data);
    } catch (e) {
      return {};
    }
  }
  
  // Clear all data
  Future<void> clearAllData() async {
    final photosDir = await getPhotosDirectory();
    final videosDir = await getVideosDirectory();
    
    // Delete all photos
    if (await photosDir.exists()) {
      await photosDir.delete(recursive: true);
    }
    
    // Delete all videos
    if (await videosDir.exists()) {
      await videosDir.delete(recursive: true);
    }
    
    // Clear preferences
    await _prefs.remove(_photosKey);
    await _prefs.remove(_videosKey);
  }
}
