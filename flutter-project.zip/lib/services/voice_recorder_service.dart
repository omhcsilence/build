// lib/services/voice_recorder_service.dart
// Records audio for voice notes, returns base64 + duration.

import 'dart:convert';
import 'dart:io';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class VoiceRecorderService {
  VoiceRecorderService._();
  static final VoiceRecorderService instance = VoiceRecorderService._();

  final AudioRecorder _recorder = AudioRecorder();
  String? _currentPath;
  bool _recording = false;
  DateTime? _startedAt;

  bool get isRecording => _recording;

  Future<bool> _hasPermission() async {
    final status = await Permission.microphone.status;
    if (!status.isGranted) {
      final result = await Permission.microphone.request();
      return result.isGranted;
    }
    return true;
  }

  Future<void> start() async {
    if (_recording) return;
    final granted = await _hasPermission();
    if (!granted) return;

    final dir = await getTemporaryDirectory();
    final fileName = 'voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
    _currentPath = '${dir.path}/$fileName';
    _startedAt = DateTime.now();

    await _recorder.start(
      const RecordConfig(
        encoder: AudioEncoder.aacLc,
        bitRate: 64000,
        sampleRate: 44100,
        numChannels: 1,
      ),
      path: _currentPath!,
    );
    _recording = true;
  }

  /// Stops recording. Returns (base64String, durationMs) or null on failure.
  Future<({String base64, int durationMs})?> stop() async {
    if (!_recording) return null;
    try {
      final path = await _recorder.stop();
      _recording = false;
      final durationMs = _startedAt != null
          ? DateTime.now().difference(_startedAt!).inMilliseconds
          : 0;
      final actualPath = path ?? _currentPath;
      if (actualPath == null) return null;
      final bytes = await File(actualPath).readAsBytes();
      final b64 = base64Encode(bytes);
      try { await File(actualPath).delete(); } catch (_) {}
      return (base64: 'data:audio/mp4;base64,$b64', durationMs: durationMs);
    } catch (_) {
      _recording = false;
      return null;
    }
  }

  Future<void> cancel() async {
    if (!_recording) return;
    try { await _recorder.stop(); } catch (_) {}
    _recording = false;
    if (_currentPath != null) {
      try { await File(_currentPath!).delete(); } catch (_) {}
    }
  }

  void dispose() {
    _recorder.dispose();
  }
}
