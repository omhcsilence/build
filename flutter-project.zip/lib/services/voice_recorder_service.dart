// lib/services/voice_recorder_service.dart
// Records audio for voice notes using flutter_sound.
// Returns base64-encoded .aac audio + duration in milliseconds.

import 'dart:convert';
import 'dart:io';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class VoiceRecorderService {
  VoiceRecorderService._();
  static final VoiceRecorderService instance = VoiceRecorderService._();

  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  bool _initialized = false;
  bool _recording = false;
  String? _currentPath;
  DateTime? _startedAt;
  StreamSubscription? _dbPeakSubscription;

  bool get isRecording => _recording;

  Future<void> _ensureInitialized() async {
    if (_initialized) return;
    await _recorder.openRecorder();
    _initialized = true;
  }

  Future<bool> _hasPermission() async {
    final status = await Permission.microphone.status;
    if (!status.isGranted) {
      final result = await Permission.microphone.request();
      return result.isGranted;
    }
    return true;
  }

  Future<void> start() async {
    if (_recording) return;
    final granted = await _hasPermission();
    if (!granted) return;
    await _ensureInitialized();

    final dir = await getTemporaryDirectory();
    final fileName = 'voice_${DateTime.now().millisecondsSinceEpoch}.aac';
    _currentPath = '${dir.path}/$fileName';
    _startedAt = DateTime.now();

    try {
      await _recorder.startRecorder(
        toFile: _currentPath,
        codec: Codec.aacADTS,
        sampleRate: 44100,
        numChannels: 1,
        bitRate: 64000,
      );
      _recording = true;
    } catch (_) {
      _recording = false;
    }
  }

  /// Stops recording. Returns (base64String, durationMs) or null on failure.
  Future<({String base64, int durationMs})?> stop() async {
    if (!_recording) return null;
    try {
      final path = await _recorder.stopRecorder();
      _recording = false;
      final durationMs = _startedAt != null
          ? DateTime.now().difference(_startedAt!).inMilliseconds
          : 0;
      final actualPath = path ?? _currentPath;
      if (actualPath == null) return null;
      final file = File(actualPath);
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      final b64 = base64Encode(bytes);
      try { await file.delete(); } catch (_) {}
      return (base64: 'data:audio/aac;base64,$b64', durationMs: durationMs);
    } catch (_) {
      _recording = false;
      return null;
    }
  }

  Future<void> cancel() async {
    if (!_recording) return;
    try { await _recorder.stopRecorder(); } catch (_) {}
    _recording = false;
    if (_currentPath != null) {
      try { await File(_currentPath!).delete(); } catch (_) {}
    }
  }

  void dispose() {
    try { _recorder.closeRecorder(); } catch (_) {}
  }
}
