import 'package:flutter/scheduler.dart';

class GameLoop {
  final Function(double dt) onTick;
  Ticker? _ticker;
  Duration _lastElapsed = Duration.zero;
  bool _isRunning = false;

  GameLoop({required this.onTick});

  void start(TickerProvider vsync) {
    if (_isRunning) return;
    _isRunning = true;
    _lastElapsed = Duration.zero;
    _ticker = vsync.createTicker(_onFrame);
    _ticker?.start();
  }

  void stop() {
    _isRunning = false;
    _ticker?.stop();
    _ticker?.dispose();
    _ticker = null;
  }

  void _onFrame(Duration elapsed) {
    if (!_isRunning) return;
    final dt = (elapsed - _lastElapsed).inMicroseconds / 1000000.0;
    _lastElapsed = elapsed;
    // Cap delta time to prevent physics clipping/explosions on lag
    final clampedDt = dt.clamp(0.001, 0.05);
    onTick(clampedDt);
  }
}
