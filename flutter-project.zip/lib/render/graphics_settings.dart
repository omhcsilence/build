import 'package:flutter/material.dart';

enum GraphicsQuality { low, medium, high, ultra }

class GraphicsSettings extends ChangeNotifier {
  static final GraphicsSettings _instance = GraphicsSettings._internal();
  factory GraphicsSettings() => _instance;
  GraphicsSettings._internal();

  GraphicsQuality _quality = GraphicsQuality.high;
  bool _shadowsEnabled = true;
  bool _ambientOcclusion = true;
  bool _bloomEffect = true;
  bool _antiAliasing = true;
  double _renderDistance = 150.0;
  double _shadowQuality = 1.0;
  bool _dynamicLighting = true;
  bool _textureFiltering = true;
  bool _fogEnabled = true;

  GraphicsQuality get quality => _quality;
  bool get shadowsEnabled => _shadowsEnabled;
  bool get ambientOcclusion => _ambientOcclusion;
  bool get bloomEffect => _bloomEffect;
  bool get antiAliasing => _antiAliasing;
  double get renderDistance => _renderDistance;
  double get shadowQuality => _shadowQuality;
  bool get dynamicLighting => _dynamicLighting;
  bool get textureFiltering => _textureFiltering;
  bool get fogEnabled => _fogEnabled;

  void setQuality(GraphicsQuality q) {
    _quality = q;
    switch (q) {
      case GraphicsQuality.low:
        _shadowsEnabled = false;
        _ambientOcclusion = false;
        _bloomEffect = false;
        _antiAliasing = false;
        _renderDistance = 80.0;
        _shadowQuality = 0.0;
        _dynamicLighting = false;
        _textureFiltering = false;
        break;
      case GraphicsQuality.medium:
        _shadowsEnabled = true;
        _ambientOcclusion = false;
        _bloomEffect = false;
        _antiAliasing = true;
        _renderDistance = 120.0;
        _shadowQuality = 0.5;
        _dynamicLighting = true;
        _textureFiltering = true;
        break;
      case GraphicsQuality.high:
        _shadowsEnabled = true;
        _ambientOcclusion = true;
        _bloomEffect = true;
        _antiAliasing = true;
        _renderDistance = 200.0;
        _shadowQuality = 1.0;
        _dynamicLighting = true;
        _textureFiltering = true;
        break;
      case GraphicsQuality.ultra:
        _shadowsEnabled = true;
        _ambientOcclusion = true;
        _bloomEffect = true;
        _antiAliasing = true;
        _renderDistance = 400.0;
        _shadowQuality = 2.0;
        _dynamicLighting = true;
        _textureFiltering = true;
        break;
    }
    notifyListeners();
  }

  String get qualityLabel => _quality.name[0].toUpperCase() + _quality.name.substring(1);
}
