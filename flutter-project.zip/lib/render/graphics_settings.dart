import 'package:flutter/material.dart';

enum GraphicsQuality {
  low,
  medium,
  high,
  ultra,
}

class GraphicsSettings extends ChangeNotifier {
  static final GraphicsSettings _instance = GraphicsSettings._internal();
  factory GraphicsSettings() => _instance;
  GraphicsSettings._internal();

  GraphicsQuality _quality = GraphicsQuality.high;
  bool _shadowsEnabled = true;
  bool _ambientOcclusion = true;
  bool _bloomEffect = true;
  bool _antiAliasing = true;
  double _renderDistance = 150.0;
  double _shadowQuality = 1.0;
  bool _dynamicLighting = true;
  bool _textureFiltering = true;
  bool _fogEnabled = true;

  // Getters
  GraphicsQuality get quality => _quality;
  bool get shadowsEnabled => _shadowsEnabled;
  bool get ambientOcclusion => _ambientOcclusion;
  bool get bloomEffect => _bloomEffect;
  bool get antiAliasing => _antiAliasing;
  double get renderDistance => _renderDistance;
  double get shadowQuality => _shadowQuality;
  bool get dynamicLighting => _dynamicLighting;
  bool get textureFiltering => _textureFiltering;
  bool get fogEnabled => _fogEnabled;

  // Preset configurations
  void setQuality(GraphicsQuality quality) {
    _quality = quality;
    switch (quality) {
      case GraphicsQuality.low:
        _shadowsEnabled = false;
        _ambientOcclusion = false;
        _bloomEffect = false;
        _antiAliasing = false;
        _renderDistance = 80.0;
        _shadowQuality = 0.0;
        _dynamicLighting = false;
        _textureFiltering = false;
        _fogEnabled = true;
        break;
      case GraphicsQuality.medium:
        _shadowsEnabled = true;
        _ambientOcclusion = false;
        _bloomEffect = false;
        _antiAliasing = true;
        _renderDistance = 120.0;
        _shadowQuality = 0.5;
        _dynamicLighting = true;
        _textureFiltering = true;
        _fogEnabled = true;
        break;
      case GraphicsQuality.high:
        _shadowsEnabled = true;
        _ambientOcclusion = true;
        _bloomEffect = true;
        _antiAliasing = true;
        _renderDistance = 200.0;
        _shadowQuality = 1.0;
        _dynamicLighting = true;
        _textureFiltering = true;
        _fogEnabled = true;
        break;
      case GraphicsQuality.ultra:
        _shadowsEnabled = true;
        _ambientOcclusion = true;
        _bloomEffect = true;
        _antiAliasing = true;
        _renderDistance = 400.0;
        _shadowQuality = 2.0;
        _dynamicLighting = true;
        _textureFiltering = true;
        _fogEnabled = true;
        break;
    }
    notifyListeners();
  }

  // Individual setters
  void setShadows(bool value) {
    _shadowsEnabled = value;
    notifyListeners();
  }

  void setAmbientOcclusion(bool value) {
    _ambientOcclusion = value;
    notifyListeners();
  }

  void setBloom(bool value) {
    _bloomEffect = value;
    notifyListeners();
  }

  void setAntiAliasing(bool value) {
    _antiAliasing = value;
    notifyListeners();
  }

  void setRenderDistance(double value) {
    _renderDistance = value;
    notifyListeners();
  }

  void setShadowQuality(double value) {
    _shadowQuality = value;
    notifyListeners();
  }

  void setDynamicLighting(bool value) {
    _dynamicLighting = value;
    notifyListeners();
  }

  void setTextureFiltering(bool value) {
    _textureFiltering = value;
    notifyListeners();
  }

  void setFogEnabled(bool value) {
    _fogEnabled = value;
    notifyListeners();
  }

  // Get quality label
  String get qualityLabel {
    switch (_quality) {
      case GraphicsQuality.low:
        return 'Low';
      case GraphicsQuality.medium:
        return 'Medium';
      case GraphicsQuality.high:
        return 'High';
      case GraphicsQuality.ultra:
        return 'Ultra';
    }
  }

  // Get polygon detail level based on quality
  int get polygonDetailLevel {
    switch (_quality) {
      case GraphicsQuality.low:
        return 1;
      case GraphicsQuality.medium:
        return 2;
      case GraphicsQuality.high:
        return 3;
      case GraphicsQuality.ultra:
        return 4;
    }
  }

  // Get shadow map resolution
  int get shadowMapResolution {
    switch (_quality) {
      case GraphicsQuality.low:
        return 0;
      case GraphicsQuality.medium:
        return 512;
      case GraphicsQuality.high:
        return 1024;
      case GraphicsQuality.ultra:
        return 2048;
    }
  }
}
