import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;
import '../camera/camera_3d.dart';
import '../models/world_data.dart';
import 'graphics_settings.dart';
import 'pipeline_3d.dart';

class ShaderEffects {
  // Smooth shadow calculation with PCF (Percentage Closer Filtering)
  static double calculateShadow(
    v.Vector3 worldPos,
    v.Vector3 normal,
    v.Vector3 lightDir,
    List<Building> buildings,
    GraphicsSettings settings,
  ) {
    if (!settings.shadowsEnabled) return 1.0;

    double shadow = 1.0;
    final shadowRay = worldPos + normal * 0.1;
    final shadowStep = lightDir * 0.5;

    // PCF sampling for soft shadows
    final sampleOffsets = settings.quality == GraphicsQuality.ultra
        ? [
            v.Vector3(0, 0, 0),
            v.Vector3(0.1, 0, 0.1),
            v.Vector3(-0.1, 0, 0.1),
            v.Vector3(0.1, 0, -0.1),
            v.Vector3(-0.1, 0, -0.1),
          ]
        : settings.quality == GraphicsQuality.high
            ? [
                v.Vector3(0, 0, 0),
                v.Vector3(0.15, 0, 0.15),
                v.Vector3(-0.15, 0, -0.15),
              ]
            : [v.Vector3(0, 0, 0)];

    for (var offset in sampleOffsets) {
      final samplePos = shadowRay + offset;
      bool inShadow = false;

      for (int i = 1; i <= (5 * settings.shadowQuality).toInt(); i++) {
        final checkPos = samplePos + (shadowStep * i.toDouble());

        for (var building in buildings) {
          if (_isPointInBuildingShadow(checkPos, building, lightDir)) {
            inShadow = true;
            break;
          }
        }
        if (inShadow) break;
      }

      if (inShadow) {
        shadow -= 0.2 * settings.shadowQuality;
      }
    }

    return shadow.clamp(0.3, 1.0);
  }

  static bool _isPointInBuildingShadow(
    v.Vector3 point,
    Building building,
    v.Vector3 lightDir,
  ) {
    final hw = building.size.x / 2.0;
    final hd = building.size.z / 2.0;
    final h = building.size.y;
    final pos = building.position;

    // Check if point is within building bounds
    return point.x >= pos.x - hw &&
        point.x <= pos.x + hw &&
        point.z >= pos.z - hd &&
        point.z <= pos.z + hd &&
        point.y >= pos.y &&
        point.y <= pos.y + h;
  }

  // Ambient Occlusion calculation
  static double calculateAO(
    v.Vector3 worldPos,
    v.Vector3 normal,
    List<Building> buildings,
    GraphicsSettings settings,
  ) {
    if (!settings.ambientOcclusion) return 1.0;

    double ao = 1.0;
    final sampleRadius = 2.0;
    final numSamples = settings.quality == GraphicsQuality.ultra
        ? 8
        : settings.quality == GraphicsQuality.high
            ? 5
            : 3;

    for (int i = 0; i < numSamples; i++) {
      final angle = (i / numSamples) * 2 * math.pi;
      final sampleDir = v.Vector3(
        math.cos(angle),
        0.2,
        math.sin(angle),
      );

      final samplePos = worldPos + normal * 0.1 + sampleDir * sampleRadius;

      for (var building in buildings) {
        if (_isPointNearBuilding(samplePos, building)) {
          ao -= 0.1;
        }
      }
    }

    return ao.clamp(0.4, 1.0);
  }

  static bool _isPointNearBuilding(v.Vector3 point, Building building) {
    final hw = building.size.x / 2.0 + 1.0;
    final hd = building.size.z / 2.0 + 1.0;
    final pos = building.position;

    return point.x >= pos.x - hw &&
        point.x <= pos.x + hw &&
        point.z >= pos.z - hd &&
        point.z <= pos.z + hd &&
        point.y >= pos.y &&
        point.y <= pos.y + building.size.y;
  }

  // Bloom effect simulation
  static Color applyBloom(Color color, double intensity, GraphicsSettings settings) {
    if (!settings.bloomEffect) return color;

    final brightness = (color.red + color.green + color.blue) / 3 / 255;
    if (brightness > 0.7) {
      final bloomFactor = (brightness - 0.7) * intensity * 0.5;
      return Color.fromRGBO(
        (color.red + bloomFactor * 255).toInt().clamp(0, 255),
        (color.green + bloomFactor * 255).toInt().clamp(0, 255),
        (color.blue + bloomFactor * 255).toInt().clamp(0, 255),
        1.0,
      );
    }
    return color;
  }

  // Texture pattern generation
  static Color applyTexturePattern(
    v.Vector3 worldPos,
    Color baseColor,
    BuildingTexture textureType,
    GraphicsSettings settings,
  ) {
    if (!settings.textureFiltering) return baseColor;

    final x = worldPos.x.abs();
    final y = worldPos.y.abs();
    final z = worldPos.z.abs();

    double pattern = 0.0;

    switch (textureType) {
      case BuildingTexture.brick:
        // Brick pattern
        final brickWidth = 1.0;
        final brickHeight = 0.5;
        final brickX = (x % brickWidth) / brickWidth;
        final brickY = (y % brickHeight) / brickHeight;
        final isMortar = brickX < 0.05 || brickY < 0.05 || (brickY > 0.45 && brickY < 0.55);
        pattern = isMortar ? 0.9 : 1.0;
        break;

      case BuildingTexture.concrete:
        // Concrete noise pattern
        pattern = 0.95 + (math.sin(x * 3) * math.cos(z * 3) * 0.05);
        break;

      case BuildingTexture.modernGlass:
        // Glass reflection pattern
        final reflection = math.sin(x + z) * 0.1 + 0.9;
        pattern = reflection;
        break;

      case BuildingTexture.residential:
        // Residential siding pattern
        final siding = (y % 0.3) < 0.02 ? 0.85 : 1.0;
        pattern = siding;
        break;

      case BuildingTexture.luxury:
        // Luxury marble pattern
        pattern = 0.9 + (math.sin(x * 2) + math.cos(z * 2)) * 0.05;
        break;

      case BuildingTexture.industrial:
        // Industrial metal pattern
        final panel = ((x % 2.0) < 0.05 || (z % 2.0) < 0.05) ? 0.7 : 1.0;
        pattern = panel;
        break;
    }

    return Color.fromRGBO(
      (baseColor.red * pattern).toInt().clamp(0, 255),
      (baseColor.green * pattern).toInt().clamp(0, 255),
      (baseColor.blue * pattern).toInt().clamp(0, 255),
      1.0,
    );
  }

  // Fog effect
  static Color applyFog(
    Color color,
    double distance,
    GraphicsSettings settings,
  ) {
    if (!settings.fogEnabled) return color;

    final fogStart = settings.renderDistance * 0.5;
    final fogEnd = settings.renderDistance;

    if (distance < fogStart) return color;

    final fogFactor = ((distance - fogStart) / (fogEnd - fogStart)).clamp(0.0, 1.0);
    const fogColor = Color(0xFF87CEEB);

    return Color.lerp(color, fogColor, fogFactor * 0.9)!;
  }

  // Dynamic lighting calculation
  static double calculateDynamicLighting(
    v.Vector3 worldPos,
    v.Vector3 normal,
    v.Vector3 cameraPos,
    List<Building> buildings,
    GraphicsSettings settings,
  ) {
    if (!settings.dynamicLighting) return 1.0;

    // Main sun direction
    final sunDir = v.Vector3(0.5, 1.0, 0.3).normalized();
    double lightIntensity = normal.dot(sunDir).clamp(0.0, 1.0);

    // Add ambient light
    lightIntensity = lightIntensity * 0.6 + 0.4;

    // Specular highlight for glass buildings
    if (settings.quality == GraphicsQuality.high || settings.quality == GraphicsQuality.ultra) {
      final viewDir = (cameraPos - worldPos).normalized();
      final halfDir = (sunDir + viewDir).normalized();
      final specular = math.pow(normal.dot(halfDir).clamp(0.0, 1.0), 32).toDouble();
      lightIntensity += specular * 0.3;
    }

    return lightIntensity.clamp(0.0, 1.5);
  }

  // Anti-aliasing color blending
  static Color applyAntiAliasing(
    Color centerColor,
    List<Color> neighborColors,
    GraphicsSettings settings,
  ) {
    if (!settings.antiAliasing) return centerColor;

    double r = centerColor.red.toDouble();
    double g = centerColor.green.toDouble();
    double b = centerColor.blue.toDouble();

    for (var neighbor in neighborColors) {
      r += neighbor.red;
      g += neighbor.green;
      b += neighbor.blue;
    }

    final count = neighborColors.length + 1;
    return Color.fromRGBO(
      (r / count).toInt(),
      (g / count).toInt(),
      (b / count).toInt(),
      1.0,
    );
  }
}
