import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';
import 'graphics_settings.dart';

class ShaderEffects {
  static double calculateShadow(v.Vector3 pos, v.Vector3 normal, v.Vector3 lightDir, List<Building> buildings, GraphicsSettings s) {
    if (!s.shadowsEnabled) return 1.0;
    return 1.0;
  }

  static double calculateAO(v.Vector3 pos, v.Vector3 normal, List<Building> buildings, GraphicsSettings s) {
    if (!s.ambientOcclusion) return 1.0;
    return 1.0;
  }

  static Color applyBloom(Color color, double intensity, GraphicsSettings s) {
    if (!s.bloomEffect) return color;
    return color;
  }

  static Color applyTexturePattern(v.Vector3 pos, Color base, BuildingTexture type, GraphicsSettings s) {
    if (!s.textureFiltering) return base;
    return base;
  }

  static Color applyFog(Color color, double distance, GraphicsSettings s) {
    if (!s.fogEnabled) return color;
    final factor = (distance / s.renderDistance).clamp(0.0, 0.9);
    return Color.lerp(color, const Color(0xFF87CEEB), factor)!;
  }

  static double calculateDynamicLighting(v.Vector3 pos, v.Vector3 normal, v.Vector3 cam, List<Building> b, GraphicsSettings s) {
    if (!s.dynamicLighting) return 1.0;
    final sunDir = v.Vector3(0.5, 1.0, 0.3).normalized();
    return (normal.dot(sunDir).clamp(0.0, 1.0) * 0.6 + 0.4);
  }
}
