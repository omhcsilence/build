import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;
import '../models/world_data.dart';
import 'graphics_settings.dart';

/// Particle system for visual effects (dust, leaves, etc.)
class ParticleSystem {
  final List<Particle> particles = [];
  final math.Random _random = math.Random();
  
  void update(double dt, v.Vector3 playerPos, GraphicsSettings settings) {
    // Remove dead particles
    particles.removeWhere((p) => p.life <= 0);
    
    // Add new particles based on quality
    final maxParticles = settings.quality == GraphicsQuality.ultra
        ? 50
        : settings.quality == GraphicsQuality.high
            ? 30
            : settings.quality == GraphicsQuality.medium
                ? 15
                : 5;
    
    while (particles.length < maxParticles) {
      particles.add(Particle.random(playerPos, _random));
    }
    
    // Update existing particles
    for (var p in particles) {
      p.update(dt);
    }
  }
}

class Particle {
  v.Vector3 position;
  v.Vector3 velocity;
  double life;
  double size;
  Color color;
  
  Particle({
    required this.position,
    required this.velocity,
    required this.life,
    required this.size,
    required this.color,
  });
  
  factory Particle.random(v.Vector3 playerPos, math.Random random) {
    final angle = random.nextDouble() * 2 * math.pi;
    final distance = 5 + random.nextDouble() * 15;
    
    return Particle(
      position: v.Vector3(
        playerPos.x + math.cos(angle) * distance,
        0.5 + random.nextDouble() * 3,
        playerPos.z + math.sin(angle) * distance,
      ),
      velocity: v.Vector3(
        (random.nextDouble() - 0.5) * 2,
        random.nextDouble() * 0.5,
        (random.nextDouble() - 0.5) * 2,
      ),
      life: 2 + random.nextDouble() * 3,
      size: 0.05 + random.nextDouble() * 0.1,
      color: Color.fromRGBO(
        200 + random.nextInt(55),
        180 + random.nextInt(50),
        150 + random.nextInt(50),
        0.3 + random.nextDouble() * 0.3,
      ),
    );
  }
  
  void update(double dt) {
    position += velocity * dt;
    life -= dt;
    velocity.y -= dt * 0.1; // Gravity
  }
}

/// Environmental details (trees, lamp posts, benches, etc.)
class EnvironmentDetail {
  final String id;
  final v.Vector3 position;
  final DetailType type;
  
  EnvironmentDetail({
    required this.id,
    required this.position,
    required this.type,
  });
}

enum DetailType {
  tree,
  lampPost,
  bench,
  trashCan,
  fireHydrant,
  streetSign,
}

/// Generates environmental details for the world
class EnvironmentGenerator {
  static final _random = math.Random();
  
  static List<EnvironmentDetail> generateDetails(List<Building> buildings, List<Road> roads) {
    final details = <EnvironmentDetail>[];
    int idCounter = 0;
    
    // Add trees near buildings
    for (var building in buildings) {
      if (_random.nextDouble() > 0.7) continue;
      
      final numTrees = 1 + _random.nextInt(3);
      for (int i = 0; i < numTrees; i++) {
        final offset = _random.nextDouble() * 10 + 5;
        final angle = _random.nextDouble() * 2 * math.pi;
        
        details.add(EnvironmentDetail(
          id: 'tree_$idCounter',
          position: v.Vector3(
            building.position.x + math.cos(angle) * offset,
            0,
            building.position.z + math.sin(angle) * offset,
          ),
          type: DetailType.tree,
        ));
        idCounter++;
      }
    }
    
    // Add lamp posts along roads
    for (var road in roads) {
      final length = (road.end - road.start).length;
      final numLamps = (length / 20).floor();
      final dir = (road.end - road.start).normalized();
      
      for (int i = 0; i < numLamps; i++) {
        final t = (i + 1) / (numLamps + 1);
        final pos = road.start + (road.end - road.start) * t;
        
        // Alternate sides
        final side = i % 2 == 0 ? 1 : -1;
        final perp = v.Vector3(-dir.z, 0, dir.x) * (road.width / 2 + 2) * side;
        
        details.add(EnvironmentDetail(
          id: 'lamp_$idCounter',
          position: pos + perp,
          type: DetailType.lampPost,
        ));
        idCounter++;
      }
    }
    
    // Add benches randomly
    for (int i = 0; i < 20; i++) {
      final x = (_random.nextDouble() - 0.5) * 300;
      final z = (_random.nextDouble() - 0.5) * 300;
      
      details.add(EnvironmentDetail(
        id: 'bench_$idCounter',
        position: v.Vector3(x, 0, z),
        type: DetailType.bench,
      ));
      idCounter++;
    }
    
    return details;
  }
}

/// Sky system with day/night cycle
class SkySystem {
  double timeOfDay = 0.5; // 0 = midnight, 0.5 = noon, 1 = midnight
  
  void update(double dt) {
    // Slow day/night cycle (1 full day = 10 minutes real time)
    timeOfDay += dt / 600.0;
    if (timeOfDay > 1.0) timeOfDay -= 1.0;
  }
  
  v.Vector3 getSunDirection() {
    final angle = (timeOfDay - 0.25) * 2 * math.pi;
    return v.Vector3(
      math.cos(angle),
      math.sin(angle),
      0.3,
    ).normalized();
  }
  
  Color getSkyColor() {
    // Sky color based on time of day
    if (timeOfDay < 0.25) {
      // Night to dawn
      final t = timeOfDay / 0.25;
      return Color.lerp(
        const Color(0xFF0D1B2A),
        const Color(0xFFFF7043),
        t,
      )!;
    } else if (timeOfDay < 0.5) {
      // Dawn to noon
      final t = (timeOfDay - 0.25) / 0.25;
      return Color.lerp(
        const Color(0xFFFF7043),
        const Color(0xFF87CEEB),
        t,
      )!;
    } else if (timeOfDay < 0.75) {
      // Noon to dusk
      final t = (timeOfDay - 0.5) / 0.25;
      return Color.lerp(
        const Color(0xFF87CEEB),
        const Color(0xFFFF5722),
        t,
      )!;
    } else {
      // Dusk to night
      final t = (timeOfDay - 0.75) / 0.25;
      return Color.lerp(
        const Color(0xFFFF5722),
        const Color(0xFF0D1B2A),
        t,
      )!;
    }
  }
  
  double getAmbientLight() {
    // Light intensity based on time
    if (timeOfDay < 0.2 || timeOfDay > 0.8) {
      return 0.2; // Night
    } else if (timeOfDay < 0.3) {
      return 0.2 + (timeOfDay - 0.2) / 0.1 * 0.5; // Dawn
    } else if (timeOfDay > 0.7) {
      return 0.7 - (timeOfDay - 0.7) / 0.1 * 0.5; // Dusk
    } else {
      return 0.7 + math.sin((timeOfDay - 0.3) / 0.4 * math.pi) * 0.3; // Day
    }
  }
}
