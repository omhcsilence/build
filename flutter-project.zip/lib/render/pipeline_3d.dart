import 'dart:ui';
import 'package:vector_math/vector_math_64.dart' as v;
import '../camera/camera_3d.dart';
import '../models/world_data.dart';

class Polygon3D {
  final List<v.Vector3> worldVertices;
  final Color color;
  final v.Vector3 normal;
  final double distanceToCamera;
  final BuildingTexture textureType;

  Polygon3D({
    required this.worldVertices,
    required this.color,
    required this.normal,
    required this.distanceToCamera,
    this.textureType = BuildingTexture.concrete,
  });
}

class Pipeline3D {
  static List<Polygon3D> processPolygons({
    required List<Polygon3D> polygons,
    required Camera3D camera,
    double renderDistance = 150.0,
  }) {
    return polygons.where((p) {
      if (p.distanceToCamera > renderDistance) return false;
      final faceToCam = camera.position - p.worldVertices[0];
      return p.normal.dot(faceToCam) > 0;
    }).toList()
      ..sort((a, b) => b.distanceToCamera.compareTo(a.distanceToCamera));
  }

  static Offset? projectVertex(v.Vector3 vertex, v.Matrix4 viewProj, Size size) {
    final vec4 = v.Vector4(vertex.x, vertex.y, vertex.z, 1.0);
    final clip = viewProj.transformed(vec4);
    if (clip.w <= 0.1) return null;
    return Offset(
      (clip.x / clip.w + 1.0) * 0.5 * size.width,
      (1.0 - clip.y / clip.w) * 0.5 * size.height,
    );
  }
}
