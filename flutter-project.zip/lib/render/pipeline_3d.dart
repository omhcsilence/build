import 'dart:ui';
import 'package:vector_math/vector_math_64.dart' as v;
import '../camera/camera_3d.dart';

class Polygon3D {
  final List<v.Vector3> worldVertices;
  final Color color;
  final v.Vector3 normal;
  final double distanceToCamera;

  Polygon3D({
    required this.worldVertices,
    required this.color,
    required this.normal,
    required this.distanceToCamera,
  });
}

class Pipeline3D {
  static List<Polygon3D> processPolygons({
    required List<Polygon3D> polygons,
    required Camera3D camera,
  }) {
    final visiblePolygons = <Polygon3D>[];

    for (var poly in polygons) {
      // 1. Back-face culling
      final faceToCam = camera.position - poly.worldVertices[0];
      if (poly.normal.dot(faceToCam) <= 0) {
        continue; // Face is pointing away from camera
      }

      visiblePolygons.add(poly);
    }

    // Sort Painter's Algorithm (Far to Near)
    visiblePolygons.sort((a, b) => b.distanceToCamera.compareTo(a.distanceToCamera));

    return visiblePolygons;
  }

  static Offset? projectVertex(
    v.Vector3 vertex,
    v.Matrix4 viewProjectionMatrix,
    Size viewportSize,
  ) {
    final vec4 = v.Vector4(vertex.x, vertex.y, vertex.z, 1.0);
    final clipSpace = viewProjectionMatrix.transformed(vec4);

    if (clipSpace.w <= 0.1) return null; // Behind camera or near plane clipping

    final ndcX = clipSpace.x / clipSpace.w;
    final ndcY = clipSpace.y / clipSpace.w;

    // Viewport Transformation
    final screenX = (ndcX + 1.0) * 0.5 * viewportSize.width;
    final screenY = (1.0 - ndcY) * 0.5 * viewportSize.height;

    return Offset(screenX, screenY);
  }
}
