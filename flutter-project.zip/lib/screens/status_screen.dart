// lib/screens/status_screen.dart
// View contacts' status updates + post your own (text/image/video).

import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/wa_models.dart';
import '../services/whatsapp_service.dart';

class StatusScreen extends StatefulWidget {
  final String sessionKey;
  final String baseUrl;

  const StatusScreen({super.key, required this.sessionKey, required this.baseUrl});

  @override
  State<StatusScreen> createState() => _StatusScreenState();
}

class _StatusScreenState extends State<StatusScreen> {
  List<Map<String, dynamic>> _statusList = [];
  bool _loading = true;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _fetchStatus();
    _refreshTimer = Timer.periodic(const Duration(seconds: 10), (_) => _fetchStatus());
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchStatus() async {
    final list = await WhatsAppService.instance.getStatusList();
    if (mounted) {
      setState(() {
        _statusList = list;
        _loading = false;
      });
    }
  }

  Future<void> _postTextStatus() async {
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) {
        final ctrl = TextEditingController();
        return AlertDialog(
          backgroundColor: const Color(0xFF111111),
          title: const Text('Post Text Status', style: TextStyle(color: Colors.white)),
          content: TextField(
            controller: ctrl,
            style: const TextStyle(color: Colors.white),
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: 'Type your status...',
              hintStyle: TextStyle(color: Colors.white38),
              enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white24)),
              focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.cyanAccent)),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: const Text('Post'),
            ),
          ],
        );
      },
    );
    if (text == null || text.isEmpty) return;
    final ok = await WhatsAppService.instance.postStatus(type: 'text', text: text);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(ok ? 'Status posted!' : 'Failed to post status'),
        backgroundColor: ok ? Colors.green : Colors.red,
      ));
      if (ok) _fetchStatus();
    }
  }

  Future<void> _postImageStatus() async {
    final picker = ImagePicker();
    final xfile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 1200);
    if (xfile == null) return;
    final bytes = await xfile.readAsBytes();
    final b64 = 'data:image/jpeg;base64,${base64Encode(bytes)}';
    final ok = await WhatsAppService.instance.postStatus(type: 'image', mediaBase64: b64);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(ok ? 'Status image posted!' : 'Failed to post image'),
        backgroundColor: ok ? Colors.green : Colors.red,
      ));
      if (ok) _fetchStatus();
    }
  }

  void _showPostOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111111),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.text_fields, color: Colors.cyanAccent),
              title: const Text('Text Status', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono')),
              onTap: () { Navigator.pop(ctx); _postTextStatus(); },
            ),
            ListTile(
              leading: const Icon(Icons.image, color: Colors.cyanAccent),
              title: const Text('Image Status', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono')),
              onTap: () { Navigator.pop(ctx); _postImageStatus(); },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF070D17),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Status', style: TextStyle(color: Colors.white, fontFamily: 'MADEEvolveSansEVO')),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_a_photo_outlined, color: Colors.cyanAccent),
            onPressed: _showPostOptions,
            tooltip: 'Post Status',
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.cyanAccent))
          : _statusList.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.update_rounded, size: 64, color: Colors.cyanAccent.withValues(alpha: 0.3)),
                      const SizedBox(height: 12),
                      const Text(
                        'No recent status updates.\nPull down to refresh.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 12),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchStatus,
                  color: Colors.cyanAccent,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _statusList.length,
                    itemBuilder: (ctx, i) {
                      final entry = _statusList[i];
                      final items = (entry['items'] as List? ?? []).cast<Map<String, dynamic>>();
                      if (items.isEmpty) return const SizedBox.shrink();
                      final name = entry['name']?.toString() ?? 'Unknown';
                      final last = WAStatus.fromMap(items.last);
                      return _buildStatusCard(name, items.length, last);
                    },
                  ),
                ),
    );
  }

  Widget _buildStatusCard(String name, int count, WAStatus last) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.cyanAccent.withValues(alpha: 0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [Colors.cyanAccent.withValues(alpha: 0.5), Colors.purple.withValues(alpha: 0.3)],
              ),
            ),
            child: Center(
              child: Text(
                name.isNotEmpty ? name[0].toUpperCase() : '?',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'MADEEvolveSansEVO')),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      last.type == 'image' ? Icons.photo : (last.type == 'video' ? Icons.videocam : Icons.text_snippet),
                      size: 12, color: Colors.cyanAccent.withValues(alpha: 0.7),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      last.text.isEmpty ? '[${last.type}]' : last.text,
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.white.withValues(alpha: 0.7), fontSize: 11, fontFamily: 'ShareTechMono'),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  '$count update${count > 1 ? 's' : ''} · ${_fmtTime(last.time)}',
                  style: TextStyle(color: Colors.white.withValues(alpha: 0.4), fontSize: 9, fontFamily: 'ShareTechMono'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _fmtTime(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}
