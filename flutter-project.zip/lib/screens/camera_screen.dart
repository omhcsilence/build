import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:camera/camera.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../blocs/camera/camera_bloc.dart';
import '../blocs/camera/camera_event.dart';
import '../blocs/camera/camera_state.dart';
import '../blocs/gallery/gallery_bloc.dart';
import '../blocs/gallery/gallery_event.dart';
import '../blocs/settings/settings_bloc.dart';
import '../blocs/settings/settings_state.dart';
import 'gallery_screen.dart';
import 'settings_screen.dart';
import '../widgets/camera_preview_widget.dart';
import '../widgets/camera_controls.dart';
import '../widgets/mode_selector.dart';
import '../widgets/zoom_control.dart';
import '../widgets/filter_strip.dart';
import '../widgets/grid_overlay.dart';
import '../widgets/focus_frame.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen>
    with TickerProviderStateMixin {
  late AnimationController _flashAnimationController;

  @override
  void initState() {
    super.initState();
    _flashAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
  }

  @override
  void dispose() {
    _flashAnimationController.dispose();
    super.dispose();
  }

  void _onViewFinderTap(TapUpDetails details, BoxConstraints constraints) {
    final bloc = context.read<CameraBloc>();
    final state = bloc.state;

    if (state is CameraReady) {
      final Offset offset = Offset(
        details.localPosition.dx / constraints.maxWidth,
        details.localPosition.dy / constraints.maxHeight,
      );

      bloc.add(SetFocusPoint(offset));
      bloc.add(SetExposurePoint(offset));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: BlocConsumer<CameraBloc, CameraState>(
        listener: (context, state) {
          if (state is PictureCaptured) {
            // Flash effect
            _flashAnimationController
              ..reset()
              ..forward();
            
            // Refresh gallery
            context.read<GalleryBloc>().add(RefreshGallery());
          }
        },
        builder: (context, state) {
          if (state is CameraInitial || state is CameraLoading) {
            return const _LoadingView();
          }

          if (state is CameraPermissionDeniedState) {
            return const _PermissionDeniedView();
          }

          if (state is CameraError) {
            return _ErrorView(message: (state as CameraError).message);
          }

          if (state is CameraReady) {
            return _buildCameraUI(state);
          }

          if (state is TimerCountdown) {
            return _buildTimerView(state);
          }

          return const _LoadingView();
        },
      ),
    );
  }

  Widget _buildCameraUI(CameraReady state) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // Camera Preview
        LayoutBuilder(
          builder: (context, constraints) {
            return GestureDetector(
              onTapUp: (details) => _onViewFinderTap(details, constraints),
              child: CameraPreviewWidget(controller: state.controller),
            );
          },
        ),

        // Grid Overlay
        if (state.showGrid)
          const GridOverlay(),

        // Focus Frame
        if (state.focusPoint != null)
          FocusFrame(position: state.focusPoint!),

        // Flash Animation
        AnimatedBuilder(
          animation: _flashAnimationController,
          builder: (context, child) {
            return Container(
              color: Colors.white.withOpacity(
                (1 - _flashAnimationController.value) * 0.8,
              ),
            );
          },
        ),

        // Top Controls
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: _buildTopControls(state),
        ),

        // Mode Selector
        Positioned(
          top: 100.h,
          left: 0,
          right: 0,
          child: ModeSelector(
            currentMode: state.mode,
            onModeChanged: (mode) {
              context.read<CameraBloc>().add(ChangeCameraMode(mode));
            },
          ),
        ),

        // Zoom Control
        Positioned(
          top: 160.h,
          left: 0,
          right: 0,
          child: ZoomControl(
            currentZoom: state.currentZoom,
            minZoom: state.minZoom,
            maxZoom: state.maxZoom,
            onZoomChanged: (zoom) {
              context.read<CameraBloc>().add(SetZoom(zoom));
            },
          ),
        ),

        // Filter Strip
        Positioned(
          bottom: 180.h,
          left: 0,
          right: 0,
          child: FilterStrip(
            currentFilter: state.currentFilter,
            onFilterChanged: (filter) {
              context.read<CameraBloc>().add(SetFilter(filter));
            },
          ),
        ),

        // Bottom Controls
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: CameraControls(
            state: state,
            onTakePicture: () {
              context.read<CameraBloc>().add(const TakePicture());
            },
            onStartRecording: () {
              context.read<CameraBloc>().add(StartVideoRecording());
            },
            onStopRecording: () {
              context.read<CameraBloc>().add(StopVideoRecording());
            },
            onSwitchCamera: () {
              context.read<CameraBloc>().add(SwitchCamera());
            },
            onOpenGallery: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const GalleryScreen()),
              );
            },
          ),
        ),

        // Recording Indicator
        if (state.isRecording)
          Positioned(
            top: 60.h,
            center: null,
            left: 20.w,
            child: _buildRecordingIndicator(state),
          ),
      ],
    );
  }

  Widget _buildTopControls(CameraReady state) {
    return SafeArea(
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black.withOpacity(0.7),
              Colors.transparent,
            ],
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Left Controls
            Row(
              children: [
                _buildIconButton(
                  icon: _getFlashIcon(state.flashMode),
                  onTap: () {
                    context.read<CameraBloc>().add(ToggleFlash());
                  },
                ),
                SizedBox(width: 12.w),
                _buildIconButton(
                  icon: Icons.hdr_plus_outlined,
                  onTap: () {
                    // Toggle HDR
                  },
                  isActive: false,
                ),
              ],
            ),

            // Right Controls
            Row(
              children: [
                _buildIconButton(
                  icon: state.timerSeconds > 0
                      ? Icons.timer
                      : Icons.timer_outlined,
                  onTap: () {
                    _showTimerPicker(context, state.timerSeconds);
                  },
                  badge: state.timerSeconds > 0 ? '${state.timerSeconds}s' : null,
                ),
                SizedBox(width: 12.w),
                _buildIconButton(
                  icon: Icons.filter_b_and_w_outlined,
                  onTap: () {
                    // Toggle filters
                  },
                ),
                SizedBox(width: 12.w),
                _buildIconButton(
                  icon: Icons.settings_outlined,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SettingsScreen()),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIconButton({
    required IconData icon,
    required VoidCallback onTap,
    bool isActive = false,
    String? badge,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40.w,
        height: 40.w,
        decoration: BoxDecoration(
          color: isActive
              ? const Color(0xFFFF9500).withOpacity(0.3)
              : Colors.white.withOpacity(0.15),
          shape: BoxShape.circle,
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Icon(
              icon,
              color: isActive ? const Color(0xFFFF9500) : Colors.white,
              size: 20.sp,
            ),
            if (badge != null)
              Positioned(
                top: 4,
                right: 4,
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(
                    color: Color(0xFFFF9500),
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    badge,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 8.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  IconData _getFlashIcon(FlashMode mode) {
    switch (mode) {
      case FlashMode.off:
        return Icons.flash_off;
      case FlashMode.auto:
        return Icons.flash_auto;
      case FlashMode.always:
        return Icons.flash_on;
      case FlashMode.torch:
        return Icons.highlight;
    }
  }

  Widget _buildRecordingIndicator(CameraReady state) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8.w,
            height: 8.w,
            decoration: const BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
            ),
          ),
          SizedBox(width: 8.w),
          Text(
            _formatDuration(state.recordingDuration),
            style: TextStyle(
              color: Colors.white,
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
          if (state.isPaused) ...[
            SizedBox(width: 8.w),
            Text(
              'PAUSED',
              style: TextStyle(
                color: Colors.yellow,
                fontSize: 10.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return duration.inHours > 0
        ? '$hours:$minutes:$seconds'
        : '$minutes:$seconds';
  }

  Widget _buildTimerView(TimerCountdown state) {
    return Container(
      color: Colors.black,
      child: Center(
        child: Text(
          '${state.secondsRemaining}',
          style: TextStyle(
            color: Colors.white,
            fontSize: 120.sp,
            fontWeight: FontWeight.w200,
            shadows: [
              Shadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 20,
                offset: const Offset(0, 4),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showTimerPicker(BuildContext context, int currentTimer) {
    final timers = [0, 3, 5, 10];
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1C1C1E),
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
          ),
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 8.h),
                  width: 40.w,
                  height: 4.h,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Text(
                  'Timer',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 16.h),
                ...timers.map((timer) {
                  final isSelected = timer == currentTimer;
                  return ListTile(
                    onTap: () {
                      context.read<CameraBloc>().add(SetTimer(timer));
                      Navigator.pop(context);
                    },
                    title: Text(
                      timer == 0 ? 'Off' : '$timer seconds',
                      style: TextStyle(
                        color: isSelected
                            ? const Color(0xFFFF9500)
                            : Colors.white,
                        fontSize: 16.sp,
                      ),
                    ),
                    trailing: isSelected
                        ? const Icon(
                            Icons.check,
                            color: Color(0xFFFF9500),
                          )
                        : null,
                  );
                }).toList(),
                SizedBox(height: 16.h),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _LoadingView extends StatelessWidget {
  const _LoadingView();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF007AFF)),
            ),
            SizedBox(height: 16.h),
            Text(
              'Memuat kamera...',
              style: TextStyle(
                color: Colors.white.withOpacity(0.7),
                fontSize: 14.sp,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PermissionDeniedView extends StatelessWidget {
  const _PermissionDeniedView();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Center(
        child: Padding(
          padding: EdgeInsets.all(32.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.camera_alt_outlined,
                size: 64.sp,
                color: Colors.white.withOpacity(0.5),
              ),
              SizedBox(height: 16.h),
              Text(
                'Izin Kamera Diperlukan',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.sp,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 8.h),
              Text(
                'ProCam memerlukan akses ke kamera untuk mengambil foto dan video.',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 14.sp,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24.h),
              ElevatedButton(
                onPressed: () {
                  context.read<CameraBloc>().add(InitializeCamera());
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF007AFF),
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(
                    horizontal: 32.w,
                    vertical: 12.h,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text('Coba Lagi'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;

  const _ErrorView({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Center(
        child: Padding(
          padding: EdgeInsets.all(32.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.error_outline,
                size: 64.sp,
                color: const Color(0xFFFF3B30),
              ),
              SizedBox(height: 16.h),
              Text(
                'Terjadi Kesalahan',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 8.h),
              Text(
                message,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 14.sp,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24.h),
              ElevatedButton(
                onPressed: () {
                  context.read<CameraBloc>().add(InitializeCamera());
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF007AFF),
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(
                    horizontal: 32.w,
                    vertical: 12.h,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text('Coba Lagi'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
