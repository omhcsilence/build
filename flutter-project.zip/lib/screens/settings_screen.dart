import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:camera/camera.dart';

import '../blocs/settings/settings_bloc.dart';
import '../blocs/settings/settings_event.dart';
import '../blocs/settings/settings_state.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: Text(
          'Pengaturan',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: BlocBuilder<SettingsBloc, SettingsState>(
        builder: (context, state) {
          if (state is SettingsLoading) {
            return const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF007AFF)),
              ),
            );
          }

          if (state is SettingsLoaded) {
            return ListView(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
              children: [
                _buildSectionTitle('Kamera'),
                _buildSettingItem(
                  label: 'Resolusi',
                  value: _getResolutionLabel(state.resolution),
                  onTap: () => _showResolutionPicker(context, state.resolution),
                ),
                _buildSettingItem(
                  label: 'Aspect Ratio',
                  value: state.aspectRatio,
                  onTap: () => _showAspectRatioPicker(context, state.aspectRatio),
                ),
                _buildToggleItem(
                  label: 'Grid',
                  value: state.showGrid,
                  onChanged: (value) {
                    context.read<SettingsBloc>().add(ToggleGrid());
                  },
                ),
                _buildToggleItem(
                  label: 'Level',
                  value: state.showLevel,
                  onChanged: (value) {
                    context.read<SettingsBloc>().add(ToggleLevel());
                  },
                ),
                SizedBox(height: 24.h),
                _buildSectionTitle('Penyimpanan'),
                _buildSettingItem(
                  label: 'Format Foto',
                  value: 'JPEG',
                  onTap: () {},
                ),
                _buildToggleItem(
                  label: 'Simpan ke Galeri',
                  value: state.saveToGallery,
                  onChanged: (value) {
                    context.read<SettingsBloc>().add(ToggleSaveToGallery());
                  },
                ),
                _buildInfoItem(
                  label: 'Penyimpanan Terpakai',
                  value: _formatBytes(state.storageInfo['totalSize'] ?? 0),
                ),
                SizedBox(height: 24.h),
                _buildSectionTitle('Lanjutan'),
                _buildToggleItem(
                  label: 'RAW Capture',
                  value: state.rawCapture,
                  onChanged: (value) {
                    context.read<SettingsBloc>().add(ToggleRawCapture());
                  },
                ),
                _buildToggleItem(
                  label: 'Geotag',
                  value: state.geotagEnabled,
                  onChanged: (value) {
                    context.read<SettingsBloc>().add(ToggleGeotag());
                  },
                ),
                SizedBox(height: 24.h),
                _buildSectionTitle('Aksi'),
                _buildActionItem(
                  label: 'Hapus Cache',
                  color: Colors.orange,
                  onTap: () {
                    context.read<SettingsBloc>().add(ClearCache());
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Cache dihapus')),
                    );
                  },
                ),
                _buildActionItem(
                  label: 'Reset Pengaturan',
                  color: Colors.red,
                  onTap: () {
                    _showResetConfirmation(context);
                  },
                ),
              ],
            );
          }

          return const SizedBox.shrink();
        },
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: EdgeInsets.only(left: 8.w, bottom: 8.h),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          color: Colors.white.withOpacity(0.5),
          fontSize: 13.sp,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildSettingItem({
    required String label,
    required String value,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      title: Text(
        label,
        style: TextStyle(
          color: Colors.white,
          fontSize: 16.sp,
        ),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            value,
            style: TextStyle(
              color: Colors.white.withOpacity(0.5),
              fontSize: 16.sp,
            ),
          ),
          SizedBox(width: 4.w),
          Icon(
            Icons.chevron_right,
            color: Colors.white.withOpacity(0.3),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleItem({
    required String label,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return ListTile(
      title: Text(
        label,
        style: TextStyle(
          color: Colors.white,
          fontSize: 16.sp,
        ),
      ),
      trailing: Switch(
        value: value,
        onChanged: onChanged,
        activeColor: const Color(0xFF34C759),
      ),
    );
  }

  Widget _buildInfoItem({
    required String label,
    required String value,
  }) {
    return ListTile(
      title: Text(
        label,
        style: TextStyle(
          color: Colors.white,
          fontSize: 16.sp,
        ),
      ),
      trailing: Text(
        value,
        style: TextStyle(
          color: Colors.white.withOpacity(0.5),
          fontSize: 16.sp,
        ),
      ),
    );
  }

  Widget _buildActionItem({
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      title: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 16.sp,
        ),
      ),
    );
  }

  String _getResolutionLabel(ResolutionPreset resolution) {
    switch (resolution) {
      case ResolutionPreset.low:
        return 'Low (480p)';
      case ResolutionPreset.medium:
        return 'Medium (720p)';
      case ResolutionPreset.high:
        return 'High (1080p)';
      case ResolutionPreset.veryHigh:
        return 'Very High (2K)';
      case ResolutionPreset.ultraHigh:
        return 'Ultra High (4K)';
      case ResolutionPreset.max:
        return 'Maximum';
    }
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) {
      return '$bytes B';
    } else if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} KB';
    } else if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    } else {
      return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    }
  }

  void _showResolutionPicker(BuildContext context, ResolutionPreset current) {
    final resolutions = [
      ResolutionPreset.low,
      ResolutionPreset.medium,
      ResolutionPreset.high,
      ResolutionPreset.veryHigh,
      ResolutionPreset.ultraHigh,
      ResolutionPreset.max,
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1C1C1E),
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
          ),
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 8.h),
                  width: 40.w,
                  height: 4.h,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Text(
                  'Resolusi',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 16.h),
                ...resolutions.map((resolution) {
                  final isSelected = resolution == current;
                  return ListTile(
                    onTap: () {
                      context.read<SettingsBloc>().add(
                        UpdateResolution(resolution),
                      );
                      Navigator.pop(context);
                    },
                    title: Text(
                      _getResolutionLabel(resolution),
                      style: TextStyle(
                        color: isSelected
                            ? const Color(0xFFFF9500)
                            : Colors.white,
                        fontSize: 16.sp,
                      ),
                    ),
                    trailing: isSelected
                        ? const Icon(
                            Icons.check,
                            color: Color(0xFFFF9500),
                          )
                        : null,
                  );
                }).toList(),
                SizedBox(height: 16.h),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showAspectRatioPicker(BuildContext context, String current) {
    final ratios = ['4:3', '16:9', '1:1'];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1C1C1E),
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
          ),
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 8.h),
                  width: 40.w,
                  height: 4.h,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Text(
                  'Aspect Ratio',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 16.h),
                ...ratios.map((ratio) {
                  final isSelected = ratio == current;
                  return ListTile(
                    onTap: () {
                      context.read<SettingsBloc>().add(
                        UpdateAspectRatio(ratio),
                      );
                      Navigator.pop(context);
                    },
                    title: Text(
                      ratio,
                      style: TextStyle(
                        color: isSelected
                            ? const Color(0xFFFF9500)
                            : Colors.white,
                        fontSize: 16.sp,
                      ),
                    ),
                    trailing: isSelected
                        ? const Icon(
                            Icons.check,
                            color: Color(0xFFFF9500),
                          )
                        : null,
                  );
                }).toList(),
                SizedBox(height: 16.h),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showResetConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1C1C1E),
        title: const Text(
          'Reset Pengaturan?',
          style: TextStyle(color: Colors.white),
        ),
        content: Text(
          'Semua pengaturan akan dikembalikan ke default.',
          style: TextStyle(color: Colors.white.withOpacity(0.7)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              context.read<SettingsBloc>().add(ResetSettings());
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Pengaturan direset')),
              );
            },
            child: const Text(
              'Reset',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }
}
