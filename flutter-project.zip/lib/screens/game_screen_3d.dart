import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vector_math/vector_math_64.dart' as v;
import '../camera/camera_3d.dart';
import '../engine/game_loop.dart';
import '../models/player_data.dart';
import '../models/world_data.dart';
import '../painters/world_painter_3d.dart';
import '../render/graphics_settings.dart';
import '../services/map_service.dart';
import '../utils/collision_utils.dart';
import '../widgets/hud_3d.dart';

class GameScreen3D extends StatefulWidget {
  const GameScreen3D({super.key});
  @override
  State<GameScreen3D> createState() => _GameScreen3DState();
}

class _GameScreen3DState extends State<GameScreen3D> with SingleTickerProviderStateMixin {
  late GameLoop _gameLoop;
  late Camera3D _camera;
  late PlayerData _player;
  late WorldState _worldState;
  final GraphicsSettings _graphicsSettings = GraphicsSettings();
  v.Vector2 _joystickInput = v.Vector2.zero();
  final Set<LogicalKeyboardKey> _pressedKeys = {};

  @override
  void initState() {
    super.initState();
    _worldState = MapService.generateWorld();
    _player = PlayerData(position: v.Vector3(0.0, 1.6, -2.0));
    _camera = Camera3D(position: _player.position);
    _gameLoop = GameLoop(onTick: _updateGame);
    _gameLoop.start(this);
  }

  @override
  void dispose() {
    _gameLoop.stop();
    super.dispose();
  }

  void _updateGame(double dt) {
    _handleMovement(dt);
    _applyPhysics(dt);
    _checkCollectibles();
    _camera.position = _player.position.clone();
    _camera.yaw = _player.yaw;
    _camera.pitch = _player.pitch;
    setState(() {});
  }

  void _handleMovement(double dt) {
    v.Vector3 moveDir = v.Vector3.zero();
    if (_pressedKeys.contains(LogicalKeyboardKey.keyW)) moveDir += _camera.forward;
    if (_pressedKeys.contains(LogicalKeyboardKey.keyS)) moveDir -= _camera.forward;
    if (_pressedKeys.contains(LogicalKeyboardKey.keyA)) moveDir -= _camera.right;
    if (_pressedKeys.contains(LogicalKeyboardKey.keyD)) moveDir += _camera.right;
    if (_joystickInput.length > 0) {
      moveDir += _camera.forward * _joystickInput.y;
      moveDir += _camera.right * _joystickInput.x;
    }
    moveDir.y = 0;
    if (moveDir.length > 0) {
      moveDir.normalize();
      final nextPos = _player.position + moveDir * 10.0 * dt;
      if (!CollisionUtils.checkBuildingCollision(nextPos, 0.4, _worldState.buildings)) {
        _player.position = nextPos;
      }
    }
  }

  void _applyPhysics(double dt) {
    if (!_player.isGrounded) _player.velocity.y -= 18.0 * dt;
    _player.position.y += _player.velocity.y * dt;
    if (_player.position.y <= 1.6) {
      _player.position.y = 1.6;
      _player.velocity.y = 0;
      _player.isGrounded = true;
    }
  }

  void _jump() {
    if (_player.isGrounded) {
      _player.velocity.y = 7.0;
      _player.isGrounded = false;
    }
  }

  void _checkCollectibles() {
    for (var item in _worldState.collectibles) {
      if (!item.isCollected && item.position.distanceTo(_player.position) < 1.5) {
        item.isCollected = true;
        _player.score += 10;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Focus(
        autofocus: true,
        onKey: (node, event) {
          if (event is RawKeyDownEvent) {
            _pressedKeys.add(event.logicalKey);
            if (event.logicalKey == LogicalKeyboardKey.space) _jump();
          } else if (event is RawKeyUpEvent) {
            _pressedKeys.remove(event.logicalKey);
          }
          return KeyEventResult.handled;
        },
        child: GestureDetector(
          onPanUpdate: (d) {
            setState(() {
              _player.yaw -= d.delta.dx * 0.005;
              _player.pitch = (_player.pitch - d.delta.dy * 0.005).clamp(-math.pi / 3, math.pi / 3);
            });
          },
          child: Stack(
            children: [
              CustomPaint(
                size: Size.infinite,
                painter: WorldPainter3D(
                  camera: _camera,
                  worldState: _worldState,
                  playerPos: _player.position,
                  graphicsSettings: _graphicsSettings,
                ),
              ),
              Hud3D(
                score: _player.score,
                health: _player.health,
                playerPos: _player.position,
                playerYaw: _player.yaw,
                worldState: _worldState,
                onJoystickMove: (dir) => _joystickInput = dir,
                onJump: _jump,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
