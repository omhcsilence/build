// lib/screens/pairing_screen.dart
// WhatsApp pairing screen — supports QR code + pairing code.
// Only accessible to role=owner or role=vip (enforced server-side too).

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../services/whatsapp_service.dart';

class PairingScreen extends StatefulWidget {
  final String sessionKey;
  final String androidId;
  final String username;
  final String baseUrl;
  final VoidCallback? onPaired;

  const PairingScreen({
    super.key,
    required this.sessionKey,
    required this.androidId,
    required this.username,
    required this.baseUrl,
    this.onPaired,
  });

  @override
  State<PairingScreen> createState() => _PairingScreenState();
}

enum _PairMode { qr, code }

class _PairingScreenState extends State<PairingScreen> with SingleTickerProviderStateMixin {
  _PairMode _mode = _PairMode.qr;
  bool _loading = false;
  String? _qrData;
  String? _pairingCode;
  String? _errorMsg;
  String _phoneInput = '';
  Timer? _pollTimer;
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    WhatsAppService.instance.configure(
      baseUrl: widget.baseUrl,
      sessionKey: widget.sessionKey,
      androidId: widget.androidId,
      username: widget.username,
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _startPairing() async {
    setState(() {
      _loading = true;
      _qrData = null;
      _pairingCode = null;
      _errorMsg = null;
    });
    try {
      final Map<String, dynamic> result;
      if (_mode == _PairMode.qr) {
        result = await WhatsAppService.instance.pairWithQR();
        if (result['valid'] == true) {
          setState(() {
            _qrData = result['qr']?.toString();
            _startPolling();
          });
        } else {
          setState(() {
            _errorMsg = result['message']?.toString() ?? 'Failed to start pairing';
          });
        }
      } else {
        if (_phoneInput.isEmpty || _phoneInput.replaceAll(RegExp(r'\D'), '').length < 8) {
          setState(() { _errorMsg = 'Enter a valid phone number (e.g. 62812345678)'; });
          return;
        }
        result = await WhatsAppService.instance.pairWithCode(_phoneInput.replaceAll(RegExp(r'\D'), ''));
        if (result['valid'] == true) {
          setState(() {
            _pairingCode = result['pairingCode']?.toString();
            _startPolling();
          });
        } else {
          setState(() {
            _errorMsg = result['message']?.toString() ?? 'Failed to get pairing code';
          });
        }
      }
    } catch (e) {
      setState(() {
        _errorMsg = 'Error: $e';
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      final status = await WhatsAppService.instance.pairStatus();
      if (status['status'] == 'connected') {
        _pollTimer?.cancel();
        if (mounted) {
          setState(() {
            _qrData = null;
            _pairingCode = null;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('WhatsApp connected! 🎉'),
              backgroundColor: Colors.green,
            ),
          );
          widget.onPaired?.call();
        }
      }
    });
  }

  Future<void> _unpair() async {
    setState(() => _loading = true);
    try {
      await WhatsAppService.instance.unpair();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Unpaired'), backgroundColor: Colors.orange),
        );
        setState(() {
          _qrData = null;
          _pairingCode = null;
        });
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF070D17),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Pair WhatsApp', style: TextStyle(color: Colors.white, fontFamily: 'MADEEvolveSansEVO')),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Mode toggle
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() {
                          _mode = _PairMode.qr;
                          _qrData = null;
                          _pairingCode = null;
                          _errorMsg = null;
                        }),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: _mode == _PairMode.qr
                                ? Colors.cyanAccent.withValues(alpha: 0.2)
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                            border: _mode == _PairMode.qr
                                ? Border.all(color: Colors.cyanAccent.withValues(alpha: 0.5))
                                : null,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.qr_code_rounded, color: _mode == _PairMode.qr ? Colors.cyanAccent : Colors.white54, size: 16),
                              const SizedBox(width: 6),
                              Text('QR Code', style: TextStyle(
                                color: _mode == _PairMode.qr ? Colors.cyanAccent : Colors.white54,
                                fontSize: 12,
                                fontFamily: 'ShareTechMono',
                              )),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() {
                          _mode = _PairMode.code;
                          _qrData = null;
                          _pairingCode = null;
                          _errorMsg = null;
                        }),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: _mode == _PairMode.code
                                ? Colors.cyanAccent.withValues(alpha: 0.2)
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                            border: _mode == _PairMode.code
                                ? Border.all(color: Colors.cyanAccent.withValues(alpha: 0.5))
                                : null,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.dialpad_rounded, color: _mode == _PairMode.code ? Colors.cyanAccent : Colors.white54, size: 16),
                              const SizedBox(width: 6),
                              Text('Pairing Code', style: TextStyle(
                                color: _mode == _PairMode.code ? Colors.cyanAccent : Colors.white54,
                                fontSize: 12,
                                fontFamily: 'ShareTechMono',
                              )),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              if (_mode == _PairMode.code) ...[
                TextField(
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
                  decoration: InputDecoration(
                    hintText: 'Phone number (e.g. 62812345678)',
                    hintStyle: const TextStyle(color: Colors.white38),
                    filled: true,
                    fillColor: Colors.white.withValues(alpha: 0.05),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.cyanAccent.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: Colors.cyanAccent),
                    ),
                  ),
                  onChanged: (v) => _phoneInput = v,
                ),
                const SizedBox(height: 20),
              ],
              if (_qrData != null) ...[
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.cyanAccent.withValues(alpha: 0.4),
                          blurRadius: 30,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: QrImageView(
                      data: _qrData!,
                      version: QrVersions.auto,
                      size: 240,
                      gapless: true,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Center(
                  child: AnimatedBuilder(
                    animation: _pulseCtrl,
                    builder: (_, __) => Text(
                      'Open WhatsApp → Settings → Linked Devices → Link a Device → Scan QR',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.cyanAccent.withValues(alpha: 0.6 + _pulseCtrl.value * 0.4),
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ),
                ),
              ] else if (_pairingCode != null) ...[
                Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
                    decoration: BoxDecoration(
                      color: Colors.cyanAccent.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.cyanAccent.withValues(alpha: 0.5), width: 2),
                    ),
                    child: Column(
                      children: [
                        const Text('Your pairing code', style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'ShareTechMono')),
                        const SizedBox(height: 8),
                        Text(
                          _pairingCode!,
                          style: const TextStyle(
                            color: Colors.cyanAccent,
                            fontSize: 36,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 8,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const Center(
                  child: Text(
                    'Open WhatsApp → Settings → Linked Devices → Link a Device → Enter code',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white54, fontSize: 11, fontFamily: 'ShareTechMono'),
                  ),
                ),
              ] else ...[
                Center(
                  child: Icon(
                    _mode == _PairMode.qr ? Icons.qr_code_2_rounded : Icons.dialpad_rounded,
                    color: Colors.cyanAccent.withValues(alpha: 0.3),
                    size: 120,
                  ),
                ),
                const SizedBox(height: 20),
                const Center(
                  child: Text(
                    'Tap "Start Pairing" below to generate a QR code or pairing code.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'ShareTechMono'),
                  ),
                ),
              ],
              if (_errorMsg != null) ...[
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.red.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.red.withValues(alpha: 0.4)),
                  ),
                  child: Text(_errorMsg!, style: const TextStyle(color: Colors.redAccent, fontSize: 11, fontFamily: 'ShareTechMono')),
                ),
              ],
              const Spacer(),
              if (_qrData == null && _pairingCode == null)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _loading ? null : _startPairing,
                    icon: _loading
                        ? const Padding(
                            padding: EdgeInsets.all(2),
                            child: SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black)),
                          )
                        : const Icon(Icons.link_rounded),
                    label: const Text('Start Pairing', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.cyanAccent,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              if (_qrData != null || _pairingCode != null) ...[
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _loading ? null : () {
                          setState(() {
                            _qrData = null;
                            _pairingCode = null;
                            _errorMsg = null;
                          });
                          _pollTimer?.cancel();
                        },
                        icon: const Icon(Icons.refresh, color: Colors.white70),
                        label: const Text('Restart', style: TextStyle(color: Colors.white70)),
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: Colors.white.withValues(alpha: 0.2)),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _loading ? null : _unpair,
                        icon: const Icon(Icons.link_off_rounded),
                        label: const Text('Cancel'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
