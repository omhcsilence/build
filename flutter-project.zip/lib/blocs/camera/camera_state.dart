import 'package:equatable/equatable.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'camera_event.dart';

abstract class CameraState extends Equatable {
  const CameraState();

  @override
  List<Object?> get props => [];
}

// Initial state
class CameraInitial extends CameraState {}

// Loading state
class CameraLoading extends CameraState {}

// Ready state
class CameraReady extends CameraState {
  final CameraController controller;
  final CameraDescription currentCamera;
  final List<CameraDescription> availableCameras;
  final double currentZoom;
  final double minZoom;
  final double maxZoom;
  final FlashMode flashMode;
  final CameraMode mode;
  final int timerSeconds;
  final String currentFilter;
  final bool showGrid;
  final bool showLevel;
  final AspectRatio aspectRatio;
  final bool isRecording;
  final bool isPaused;
  final Duration recordingDuration;
  final Offset? focusPoint;
  final Offset? exposurePoint;
  final bool isTakingPicture;

  const CameraReady({
    required this.controller,
    required this.currentCamera,
    required this.availableCameras,
    this.currentZoom = 1.0,
    this.minZoom = 1.0,
    this.maxZoom = 1.0,
    this.flashMode = FlashMode.off,
    this.mode = CameraMode.photo,
    this.timerSeconds = 0,
    this.currentFilter = 'none',
    this.showGrid = false,
    this.showLevel = false,
    this.aspectRatio = AspectRatio.ratio4_3,
    this.isRecording = false,
    this.isPaused = false,
    this.recordingDuration = Duration.zero,
    this.focusPoint,
    this.exposurePoint,
    this.isTakingPicture = false,
  });

  CameraReady copyWith({
    CameraController? controller,
    CameraDescription? currentCamera,
    List<CameraDescription>? availableCameras,
    double? currentZoom,
    double? minZoom,
    double? maxZoom,
    FlashMode? flashMode,
    CameraMode? mode,
    int? timerSeconds,
    String? currentFilter,
    bool? showGrid,
    bool? showLevel,
    AspectRatio? aspectRatio,
    bool? isRecording,
    bool? isPaused,
    Duration? recordingDuration,
    Offset? focusPoint,
    Offset? exposurePoint,
    bool? isTakingPicture,
  }) {
    return CameraReady(
      controller: controller ?? this.controller,
      currentCamera: currentCamera ?? this.currentCamera,
      availableCameras: availableCameras ?? this.availableCameras,
      currentZoom: currentZoom ?? this.currentZoom,
      minZoom: minZoom ?? this.minZoom,
      maxZoom: maxZoom ?? this.maxZoom,
      flashMode: flashMode ?? this.flashMode,
      mode: mode ?? this.mode,
      timerSeconds: timerSeconds ?? this.timerSeconds,
      currentFilter: currentFilter ?? this.currentFilter,
      showGrid: showGrid ?? this.showGrid,
      showLevel: showLevel ?? this.showLevel,
      aspectRatio: aspectRatio ?? this.aspectRatio,
      isRecording: isRecording ?? this.isRecording,
      isPaused: isPaused ?? this.isPaused,
      recordingDuration: recordingDuration ?? this.recordingDuration,
      focusPoint: focusPoint ?? this.focusPoint,
      exposurePoint: exposurePoint ?? this.exposurePoint,
      isTakingPicture: isTakingPicture ?? this.isTakingPicture,
    );
  }

  @override
  List<Object?> get props => [
    controller,
    currentCamera,
    availableCameras,
    currentZoom,
    minZoom,
    maxZoom,
    flashMode,
    mode,
    timerSeconds,
    currentFilter,
    showGrid,
    showLevel,
    aspectRatio,
    isRecording,
    isPaused,
    recordingDuration,
    focusPoint,
    exposurePoint,
    isTakingPicture,
  ];
}

// Error state
class CameraError extends CameraState {
  final String message;

  const CameraError(this.message);

  @override
  List<Object?> get props => [message];
}

// Permission denied state
class CameraPermissionDeniedState extends CameraState {}

// Picture captured state
class PictureCaptured extends CameraState {
  final XFile photo;
  final CameraReady previousState;

  const PictureCaptured(this.photo, this.previousState);

  @override
  List<Object?> get props => [photo, previousState];
}

// Video recorded state
class VideoRecorded extends CameraState {
  final XFile video;
  final CameraReady previousState;

  const VideoRecorded(this.video, this.previousState);

  @override
  List<Object?> get props => [video, previousState];
}

// Timer countdown state
class TimerCountdown extends CameraState {
  final int secondsRemaining;
  final CameraReady previousState;

  const TimerCountdown(this.secondsRemaining, this.previousState);

  @override
  List<Object?> get props => [secondsRemaining, previousState];
}
