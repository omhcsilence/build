import 'package:equatable/equatable.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

abstract class CameraEvent extends Equatable {
  const CameraEvent();

  @override
  List<Object?> get props => [];
}

// Initialize camera
class InitializeCamera extends CameraEvent {
  final CameraDescription? camera;
  
  const InitializeCamera({this.camera});
  
  @override
  List<Object?> get props => [camera];
}

// Switch camera
class SwitchCamera extends CameraEvent {}

// Set zoom
class SetZoom extends CameraEvent {
  final double zoom;
  
  const SetZoom(this.zoom);
  
  @override
  List<Object?> get props => [zoom];
}

// Set flash mode
class SetFlashMode extends CameraEvent {
  final FlashMode mode;
  
  const SetFlashMode(this.mode);
  
  @override
  List<Object?> get props => [mode];
}

// Toggle flash
class ToggleFlash extends CameraEvent {}

// Set focus point
class SetFocusPoint extends CameraEvent {
  final Offset point;
  
  const SetFocusPoint(this.point);
  
  @override
  List<Object?> get props => [point];
}

// Set exposure point
class SetExposurePoint extends CameraEvent {
  final Offset point;
  
  const SetExposurePoint(this.point);
  
  @override
  List<Object?> get props => [point];
}

// Take picture
class TakePicture extends CameraEvent {
  final bool saveToGallery;
  
  const TakePicture({this.saveToGallery = true});
  
  @override
  List<Object?> get props => [saveToGallery];
}

// Start video recording
class StartVideoRecording extends CameraEvent {}

// Stop video recording
class StopVideoRecording extends CameraEvent {}

// Pause video recording
class PauseVideoRecording extends CameraEvent {}

// Resume video recording
class ResumeVideoRecording extends CameraEvent {}

// Change camera mode
class ChangeCameraMode extends CameraEvent {
  final CameraMode mode;
  
  const ChangeCameraMode(this.mode);
  
  @override
  List<Object?> get props => [mode];
}

// Set timer
class SetTimer extends CameraEvent {
  final int seconds;
  
  const SetTimer(this.seconds);
  
  @override
  List<Object?> get props => [seconds];
}

// Set filter
class SetFilter extends CameraEvent {
  final String filter;
  
  const SetFilter(this.filter);
  
  @override
  List<Object?> get props => [filter];
}

// Set resolution
class SetResolution extends CameraEvent {
  final ResolutionPreset resolution;
  
  const SetResolution(this.resolution);
  
  @override
  List<Object?> get props => [resolution];
}

// Set aspect ratio
class SetAspectRatio extends CameraEvent {
  final AspectRatio ratio;
  
  const SetAspectRatio(this.ratio);
  
  @override
  List<Object?> get props => [ratio];
}

// Toggle grid
class ToggleGrid extends CameraEvent {}

// Toggle level
class ToggleLevel extends CameraEvent {}

// Camera mode enum
enum CameraMode { photo, video, portrait, pano, timeLapse }

// Aspect ratio enum
enum AspectRatio { ratio4_3, ratio16_9, ratio1_1 }

// Camera initialized
class CameraInitialized extends CameraEvent {}

// Camera disposed
class DisposeCamera extends CameraEvent {}

// Permission denied
class CameraPermissionDenied extends CameraEvent {}

// Permission granted
class CameraPermissionGranted extends CameraEvent {}
