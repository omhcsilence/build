import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:camera/camera.dart';
import '../../services/camera_service.dart';
import '../../services/permission_service.dart';
import '../../main.dart';
import 'camera_event.dart';
import 'camera_state.dart';

class CameraBloc extends Bloc<CameraEvent, CameraState> {
  final CameraService _cameraService;
  final PermissionService _permissionService;
  Timer? _recordingTimer;
  Timer? _countdownTimer;

  CameraBloc({
    required CameraService cameraService,
    required PermissionService permissionService,
  })  : _cameraService = cameraService,
        _permissionService = permissionService,
        super(CameraInitial()) {
    on<InitializeCamera>(_onInitializeCamera);
    on<SwitchCamera>(_onSwitchCamera);
    on<SetZoom>(_onSetZoom);
    on<SetFlashMode>(_onSetFlashMode);
    on<ToggleFlash>(_onToggleFlash);
    on<SetFocusPoint>(_onSetFocusPoint);
    on<SetExposurePoint>(_onSetExposurePoint);
    on<TakePicture>(_onTakePicture);
    on<StartVideoRecording>(_onStartVideoRecording);
    on<StopVideoRecording>(_onStopVideoRecording);
    on<PauseVideoRecording>(_onPauseVideoRecording);
    on<ResumeVideoRecording>(_onResumeVideoRecording);
    on<ChangeCameraMode>(_onChangeCameraMode);
    on<SetTimer>(_onSetTimer);
    on<SetFilter>(_onSetFilter);
    on<SetResolution>(_onSetResolution);
    on<SetAspectRatio>(_onSetAspectRatio);
    on<ToggleGrid>(_onToggleGrid);
    on<ToggleLevel>(_onToggleLevel);
    on<DisposeCamera>(_onDisposeCamera);
  }

  Future<void> _onInitializeCamera(
    InitializeCamera event,
    Emitter<CameraState> emit,
  ) async {
    emit(CameraLoading());

    try {
      // Check permissions
      final hasPermission = await _permissionService.requestCameraPermission();
      if (!hasPermission) {
        emit(CameraPermissionDeniedState());
        return;
      }

      // Request microphone permission for video
      await _permissionService.requestMicrophonePermission();

      // Initialize camera
      final camera = event.camera ?? cameras.first;
      await _cameraService.initialize(camera);

      emit(CameraReady(
        controller: _cameraService.controller!,
        currentCamera: camera,
        availableCameras: cameras,
        minZoom: _cameraService.minZoom,
        maxZoom: _cameraService.maxZoom,
      ));
    } catch (e) {
      emit(CameraError('Failed to initialize camera: $e'));
    }
  }

  Future<void> _onSwitchCamera(
    SwitchCamera event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    emit(CameraLoading());

    try {
      // Find next camera
      final currentIndex = currentState.availableCameras
          .indexWhere((c) => c.lensDirection == currentState.currentCamera.lensDirection);
      final nextIndex = (currentIndex + 1) % currentState.availableCameras.length;
      final nextCamera = currentState.availableCameras[nextIndex];

      await _cameraService.switchCamera(nextCamera);

      emit(currentState.copyWith(
        controller: _cameraService.controller!,
        currentCamera: nextCamera,
      ));
    } catch (e) {
      emit(CameraError('Failed to switch camera: $e'));
    }
  }

  Future<void> _onSetZoom(
    SetZoom event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    await _cameraService.setZoom(event.zoom);

    emit(currentState.copyWith(currentZoom: _cameraService.currentZoom));
  }

  Future<void> _onSetFlashMode(
    SetFlashMode event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    await _cameraService.setFlashMode(event.mode);

    emit(currentState.copyWith(flashMode: event.mode));
  }

  Future<void> _onToggleFlash(
    ToggleFlash event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    final newMode = await _cameraService.toggleFlash();

    emit(currentState.copyWith(flashMode: newMode));
  }

  Future<void> _onSetFocusPoint(
    SetFocusPoint event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    await _cameraService.setFocusPoint(event.point);

    emit(currentState.copyWith(focusPoint: event.point));

    // Clear focus point after animation
    await Future.delayed(const Duration(seconds: 2));
    if (state is CameraReady) {
      emit((state as CameraReady).copyWith(focusPoint: null));
    }
  }

  Future<void> _onSetExposurePoint(
    SetExposurePoint event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    await _cameraService.setExposurePoint(event.point);

    emit(currentState.copyWith(exposurePoint: event.point));

    // Clear exposure point after animation
    await Future.delayed(const Duration(seconds: 2));
    if (state is CameraReady) {
      emit((state as CameraReady).copyWith(exposurePoint: null));
    }
  }

  Future<void> _onTakePicture(
    TakePicture event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;

    // Handle timer
    if (currentState.timerSeconds > 0) {
      for (int i = currentState.timerSeconds; i > 0; i--) {
        emit(TimerCountdown(i, currentState));
        await Future.delayed(const Duration(seconds: 1));
      }
    }

    emit(currentState.copyWith(isTakingPicture: true));

    try {
      final photo = await _cameraService.takePicture(
        saveToGallery: event.saveToGallery,
      );

      if (photo != null) {
        emit(PictureCaptured(photo, currentState));
        emit(currentState.copyWith(isTakingPicture: false));
      } else {
        emit(currentState.copyWith(isTakingPicture: false));
      }
    } catch (e) {
      emit(CameraError('Failed to take picture: $e'));
    }
  }

  Future<void> _onStartVideoRecording(
    StartVideoRecording event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    await _cameraService.startVideoRecording();

    // Start recording timer
    _recordingTimer?.cancel();
    _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      // Update recording duration in state
    });

    emit(currentState.copyWith(isRecording: true));
  }

  Future<void> _onStopVideoRecording(
    StopVideoRecording event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    _recordingTimer?.cancel();

    try {
      final video = await _cameraService.stopVideoRecording();

      if (video != null) {
        emit(VideoRecorded(video, currentState));
        emit(currentState.copyWith(
          isRecording: false,
          isPaused: false,
          recordingDuration: Duration.zero,
        ));
      }
    } catch (e) {
      emit(CameraError('Failed to stop recording: $e'));
    }
  }

  Future<void> _onPauseVideoRecording(
    PauseVideoRecording event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    await _cameraService.pauseVideoRecording();

    _recordingTimer?.cancel();

    emit(currentState.copyWith(isPaused: true));
  }

  Future<void> _onResumeVideoRecording(
    ResumeVideoRecording event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    await _cameraService.resumeVideoRecording();

    _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      // Update recording duration in state
    });

    emit(currentState.copyWith(isPaused: false));
  }

  Future<void> _onChangeCameraMode(
    ChangeCameraMode event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    emit(currentState.copyWith(mode: event.mode));
  }

  Future<void> _onSetTimer(
    SetTimer event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    emit(currentState.copyWith(timerSeconds: event.seconds));
  }

  Future<void> _onSetFilter(
    SetFilter event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    emit(currentState.copyWith(currentFilter: event.filter));
  }

  Future<void> _onSetResolution(
    SetResolution event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    emit(CameraLoading());

    try {
      await _cameraService.setResolution(event.resolution);
      emit(currentState.copyWith(
        controller: _cameraService.controller!,
      ));
    } catch (e) {
      emit(CameraError('Failed to set resolution: $e'));
    }
  }

  Future<void> _onSetAspectRatio(
    SetAspectRatio event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    emit(currentState.copyWith(aspectRatio: event.ratio));
  }

  Future<void> _onToggleGrid(
    ToggleGrid event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    emit(currentState.copyWith(showGrid: !currentState.showGrid));
  }

  Future<void> _onToggleLevel(
    ToggleLevel event,
    Emitter<CameraState> emit,
  ) async {
    if (state is! CameraReady) return;

    final currentState = state as CameraReady;
    emit(currentState.copyWith(showLevel: !currentState.showLevel));
  }

  Future<void> _onDisposeCamera(
    DisposeCamera event,
    Emitter<CameraState> emit,
  ) async {
    _recordingTimer?.cancel();
    _countdownTimer?.cancel();
    await _cameraService.dispose();
    emit(CameraInitial());
  }

  @override
  Future<void> close() {
    _recordingTimer?.cancel();
    _countdownTimer?.cancel();
    _cameraService.dispose();
    return super.close();
  }
}

