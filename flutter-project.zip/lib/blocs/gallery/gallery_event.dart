import 'package:equatable/equatable.dart';
import 'dart:io';

abstract class GalleryEvent extends Equatable {
  const GalleryEvent();

  @override
  List<Object?> get props => [];
}

class LoadGallery extends GalleryEvent {}

class RefreshGallery extends GalleryEvent {}

class DeleteMedia extends GalleryEvent {
  final String path;
  
  const DeleteMedia(this.path);
  
  @override
  List<Object?> get props => [path];
}

class ShareMedia extends GalleryEvent {
  final String path;
  
  const ShareMedia(this.path);
  
  @override
  List<Object?> get props => [path];
}

class SelectMedia extends GalleryEvent {
  final String path;
  
  const SelectMedia(this.path);
  
  @override
  List<Object?> get props => [path];
}

class ClearSelection extends GalleryEvent {}

class DeleteSelected extends GalleryEvent {}
