import 'package:flutter_bloc/flutter_bloc.dart';
import '../../services/storage_service.dart';
import 'gallery_event.dart';
import 'gallery_state.dart';

class GalleryBloc extends Bloc<GalleryEvent, GalleryState> {
  final StorageService _storageService;

  GalleryBloc({required StorageService storageService})
      : _storageService = storageService,
        super(GalleryInitial()) {
    on<LoadGallery>(_onLoadGallery);
    on<RefreshGallery>(_onRefreshGallery);
    on<DeleteMedia>(_onDeleteMedia);
    on<SelectMedia>(_onSelectMedia);
    on<ClearSelection>(_onClearSelection);
    on<DeleteSelected>(_onDeleteSelected);
  }

  Future<void> _onLoadGallery(
    LoadGallery event,
    Emitter<GalleryState> emit,
  ) async {
    emit(GalleryLoading());

    try {
      await _storageService.initialize();
      final files = await _storageService.getAllMediaFiles();
      final storageInfo = await _storageService.getStorageInfo();

      // Get file sizes
      final Map<String, String> fileSizes = {};
      for (final file in files) {
        fileSizes[file.path] = await _storageService.getFileSize(file.path);
      }

      emit(GalleryLoaded(
        mediaFiles: files,
        fileSizes: fileSizes,
        photoCount: storageInfo['photoCount'] ?? 0,
        videoCount: storageInfo['videoCount'] ?? 0,
      ));
    } catch (e) {
      emit(GalleryError('Failed to load gallery: $e'));
    }
  }

  Future<void> _onRefreshGallery(
    RefreshGallery event,
    Emitter<GalleryState> emit,
  ) async {
    if (state is GalleryLoaded) {
      final currentState = state as GalleryLoaded;
      
      try {
        final files = await _storageService.getAllMediaFiles();
        final storageInfo = await _storageService.getStorageInfo();

        final Map<String, String> fileSizes = {};
        for (final file in files) {
          fileSizes[file.path] = await _storageService.getFileSize(file.path);
        }

        emit(currentState.copyWith(
          mediaFiles: files,
          fileSizes: fileSizes,
          photoCount: storageInfo['photoCount'] ?? 0,
          videoCount: storageInfo['videoCount'] ?? 0,
        ));
      } catch (e) {
        emit(GalleryError('Failed to refresh gallery: $e'));
      }
    }
  }

  Future<void> _onDeleteMedia(
    DeleteMedia event,
    Emitter<GalleryState> emit,
  ) async {
    if (state is! GalleryLoaded) return;

    final currentState = state as GalleryLoaded;

    try {
      await _storageService.deleteFile(event.path);
      
      final files = await _storageService.getAllMediaFiles();
      final storageInfo = await _storageService.getStorageInfo();

      emit(currentState.copyWith(
        mediaFiles: files,
        photoCount: storageInfo['photoCount'] ?? 0,
        videoCount: storageInfo['videoCount'] ?? 0,
      ));
    } catch (e) {
      emit(GalleryError('Failed to delete media: $e'));
    }
  }

  Future<void> _onSelectMedia(
    SelectMedia event,
    Emitter<GalleryState> emit,
  ) async {
    if (state is! GalleryLoaded) return;

    final currentState = state as GalleryLoaded;
    final selectedPaths = List<String>.from(currentState.selectedPaths);

    if (selectedPaths.contains(event.path)) {
      selectedPaths.remove(event.path);
    } else {
      selectedPaths.add(event.path);
    }

    emit(currentState.copyWith(selectedPaths: selectedPaths));
  }

  Future<void> _onClearSelection(
    ClearSelection event,
    Emitter<GalleryState> emit,
  ) async {
    if (state is! GalleryLoaded) return;

    final currentState = state as GalleryLoaded;
    emit(currentState.copyWith(selectedPaths: []));
  }

  Future<void> _onDeleteSelected(
    DeleteSelected event,
    Emitter<GalleryState> emit,
  ) async {
    if (state is! GalleryLoaded) return;

    final currentState = state as GalleryLoaded;

    try {
      for (final path in currentState.selectedPaths) {
        await _storageService.deleteFile(path);
      }

      final files = await _storageService.getAllMediaFiles();
      final storageInfo = await _storageService.getStorageInfo();

      emit(currentState.copyWith(
        mediaFiles: files,
        selectedPaths: [],
        photoCount: storageInfo['photoCount'] ?? 0,
        videoCount: storageInfo['videoCount'] ?? 0,
      ));
    } catch (e) {
      emit(GalleryError('Failed to delete selected media: $e'));
    }
  }
}
