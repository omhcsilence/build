import 'package:equatable/equatable.dart';
import 'dart:io';

abstract class GalleryState extends Equatable {
  const GalleryState();

  @override
  List<Object?> get props => [];
}

class GalleryInitial extends GalleryState {}

class GalleryLoading extends GalleryState {}

class GalleryLoaded extends GalleryState {
  final List<FileSystemEntity> mediaFiles;
  final List<String> selectedPaths;
  final Map<String, String> fileSizes;
  final int photoCount;
  final int videoCount;

  const GalleryLoaded({
    required this.mediaFiles,
    this.selectedPaths = const [],
    this.fileSizes = const {},
    this.photoCount = 0,
    this.videoCount = 0,
  });

  GalleryLoaded copyWith({
    List<FileSystemEntity>? mediaFiles,
    List<String>? selectedPaths,
    Map<String, String>? fileSizes,
    int? photoCount,
    int? videoCount,
  }) {
    return GalleryLoaded(
      mediaFiles: mediaFiles ?? this.mediaFiles,
      selectedPaths: selectedPaths ?? this.selectedPaths,
      fileSizes: fileSizes ?? this.fileSizes,
      photoCount: photoCount ?? this.photoCount,
      videoCount: videoCount ?? this.videoCount,
    );
  }

  @override
  List<Object?> get props => [
    mediaFiles,
    selectedPaths,
    fileSizes,
    photoCount,
    videoCount,
  ];
}

class GalleryError extends GalleryState {
  final String message;

  const GalleryError(this.message);

  @override
  List<Object?> get props => [message];
}
