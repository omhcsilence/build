import 'package:equatable/equatable.dart';
import 'package:camera/camera.dart';

abstract class SettingsEvent extends Equatable {
  const SettingsEvent();

  @override
  List<Object?> get props => [];
}

class LoadSettings extends SettingsEvent {}

class UpdateResolution extends SettingsEvent {
  final ResolutionPreset resolution;
  
  const UpdateResolution(this.resolution);
  
  @override
  List<Object?> get props => [resolution];
}

class UpdateAspectRatio extends SettingsEvent {
  final String ratio;
  
  const UpdateAspectRatio(this.ratio);
  
  @override
  List<Object?> get props => [ratio];
}

class ToggleGrid extends SettingsEvent {}

class ToggleLevel extends SettingsEvent {}

class ToggleGeotag extends SettingsEvent {}

class ToggleSaveToGallery extends SettingsEvent {}

class ToggleRawCapture extends SettingsEvent {}

class UpdateTimer extends SettingsEvent {
  final int seconds;
  
  const UpdateTimer(this.seconds);
  
  @override
  List<Object?> get props => [seconds];
}

class ClearCache extends SettingsEvent {}

class ResetSettings extends SettingsEvent {}
