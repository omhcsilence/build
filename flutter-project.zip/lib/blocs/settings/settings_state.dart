import 'package:equatable/equatable.dart';
import 'package:camera/camera.dart';

abstract class SettingsState extends Equatable {
  const SettingsState();

  @override
  List<Object?> get props => [];
}

class SettingsInitial extends SettingsState {}

class SettingsLoading extends SettingsState {}

class SettingsLoaded extends SettingsState {
  final ResolutionPreset resolution;
  final String aspectRatio;
  final bool showGrid;
  final bool showLevel;
  final bool geotagEnabled;
  final bool saveToGallery;
  final bool rawCapture;
  final int defaultTimer;
  final Map<String, dynamic> storageInfo;

  const SettingsLoaded({
    this.resolution = ResolutionPreset.high,
    this.aspectRatio = '4:3',
    this.showGrid = false,
    this.showLevel = false,
    this.geotagEnabled = true,
    this.saveToGallery = true,
    this.rawCapture = false,
    this.defaultTimer = 0,
    this.storageInfo = const {},
  });

  SettingsLoaded copyWith({
    ResolutionPreset? resolution,
    String? aspectRatio,
    bool? showGrid,
    bool? showLevel,
    bool? geotagEnabled,
    bool? saveToGallery,
    bool? rawCapture,
    int? defaultTimer,
    Map<String, dynamic>? storageInfo,
  }) {
    return SettingsLoaded(
      resolution: resolution ?? this.resolution,
      aspectRatio: aspectRatio ?? this.aspectRatio,
      showGrid: showGrid ?? this.showGrid,
      showLevel: showLevel ?? this.showLevel,
      geotagEnabled: geotagEnabled ?? this.geotagEnabled,
      saveToGallery: saveToGallery ?? this.saveToGallery,
      rawCapture: rawCapture ?? this.rawCapture,
      defaultTimer: defaultTimer ?? this.defaultTimer,
      storageInfo: storageInfo ?? this.storageInfo,
    );
  }

  @override
  List<Object?> get props => [
    resolution,
    aspectRatio,
    showGrid,
    showLevel,
    geotagEnabled,
    saveToGallery,
    rawCapture,
    defaultTimer,
    storageInfo,
  ];
}

class SettingsError extends SettingsState {
  final String message;

  const SettingsError(this.message);

  @override
  List<Object?> get props => [message];
}

class SettingsSaved extends SettingsState {}
