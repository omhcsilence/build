import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:camera/camera.dart';
import '../../services/storage_service.dart';
import 'settings_event.dart';
import 'settings_state.dart';

class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  final StorageService _storageService;

  SettingsBloc({required StorageService storageService})
      : _storageService = storageService,
        super(SettingsInitial()) {
    on<LoadSettings>(_onLoadSettings);
    on<UpdateResolution>(_onUpdateResolution);
    on<UpdateAspectRatio>(_onUpdateAspectRatio);
    on<ToggleGrid>(_onToggleGrid);
    on<ToggleLevel>(_onToggleLevel);
    on<ToggleGeotag>(_onToggleGeotag);
    on<ToggleSaveToGallery>(_onToggleSaveToGallery);
    on<ToggleRawCapture>(_onToggleRawCapture);
    on<UpdateTimer>(_onUpdateTimer);
    on<ClearCache>(_onClearCache);
    on<ResetSettings>(_onResetSettings);
  }

  Future<void> _onLoadSettings(
    LoadSettings event,
    Emitter<SettingsState> emit,
  ) async {
    emit(SettingsLoading());

    try {
      await _storageService.initialize();
      final settings = await _storageService.getSettings();
      final storageInfo = await _storageService.getStorageInfo();

      emit(SettingsLoaded(
        resolution: _parseResolution(settings['resolution']),
        aspectRatio: settings['aspectRatio'] ?? '4:3',
        showGrid: settings['showGrid'] ?? false,
        showLevel: settings['showLevel'] ?? false,
        geotagEnabled: settings['geotagEnabled'] ?? true,
        saveToGallery: settings['saveToGallery'] ?? true,
        rawCapture: settings['rawCapture'] ?? false,
        defaultTimer: settings['defaultTimer'] ?? 0,
        storageInfo: storageInfo,
      ));
    } catch (e) {
      emit(SettingsError('Failed to load settings: $e'));
    }
  }

  Future<void> _onUpdateResolution(
    UpdateResolution event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is! SettingsLoaded) return;

    final currentState = state as SettingsLoaded;
    final newState = currentState.copyWith(resolution: event.resolution);
    
    await _saveSettings(newState);
    emit(newState);
  }

  Future<void> _onUpdateAspectRatio(
    UpdateAspectRatio event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is! SettingsLoaded) return;

    final currentState = state as SettingsLoaded;
    final newState = currentState.copyWith(aspectRatio: event.ratio);
    
    await _saveSettings(newState);
    emit(newState);
  }

  Future<void> _onToggleGrid(
    ToggleGrid event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is! SettingsLoaded) return;

    final currentState = state as SettingsLoaded;
    final newState = currentState.copyWith(showGrid: !currentState.showGrid);
    
    await _saveSettings(newState);
    emit(newState);
  }

  Future<void> _onToggleLevel(
    ToggleLevel event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is! SettingsLoaded) return;

    final currentState = state as SettingsLoaded;
    final newState = currentState.copyWith(showLevel: !currentState.showLevel);
    
    await _saveSettings(newState);
    emit(newState);
  }

  Future<void> _onToggleGeotag(
    ToggleGeotag event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is! SettingsLoaded) return;

    final currentState = state as SettingsLoaded;
    final newState = currentState.copyWith(geotagEnabled: !currentState.geotagEnabled);
    
    await _saveSettings(newState);
    emit(newState);
  }

  Future<void> _onToggleSaveToGallery(
    ToggleSaveToGallery event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is! SettingsLoaded) return;

    final currentState = state as SettingsLoaded;
    final newState = currentState.copyWith(saveToGallery: !currentState.saveToGallery);
    
    await _saveSettings(newState);
    emit(newState);
  }

  Future<void> _onToggleRawCapture(
    ToggleRawCapture event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is! SettingsLoaded) return;

    final currentState = state as SettingsLoaded;
    final newState = currentState.copyWith(rawCapture: !currentState.rawCapture);
    
    await _saveSettings(newState);
    emit(newState);
  }

  Future<void> _onUpdateTimer(
    UpdateTimer event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is! SettingsLoaded) return;

    final currentState = state as SettingsLoaded;
    final newState = currentState.copyWith(defaultTimer: event.seconds);
    
    await _saveSettings(newState);
    emit(newState);
  }

  Future<void> _onClearCache(
    ClearCache event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is! SettingsLoaded) return;

    try {
      // Clear temporary files
      // This would be implemented based on your caching strategy
      
      final currentState = state as SettingsLoaded;
      final storageInfo = await _storageService.getStorageInfo();
      emit(currentState.copyWith(storageInfo: storageInfo));
    } catch (e) {
      emit(SettingsError('Failed to clear cache: $e'));
    }
  }

  Future<void> _onResetSettings(
    ResetSettings event,
    Emitter<SettingsState> emit,
  ) async {
    final defaultSettings = const SettingsLoaded();
    await _saveSettings(defaultSettings);
    emit(defaultSettings);
  }

  Future<void> _saveSettings(SettingsLoaded settings) async {
    await _storageService.saveSettings({
      'resolution': settings.resolution.toString(),
      'aspectRatio': settings.aspectRatio,
      'showGrid': settings.showGrid,
      'showLevel': settings.showLevel,
      'geotagEnabled': settings.geotagEnabled,
      'saveToGallery': settings.saveToGallery,
      'rawCapture': settings.rawCapture,
      'defaultTimer': settings.defaultTimer,
    });
  }

  ResolutionPreset _parseResolution(String? value) {
    switch (value) {
      case 'ResolutionPreset.low':
        return ResolutionPreset.low;
      case 'ResolutionPreset.medium':
        return ResolutionPreset.medium;
      case 'ResolutionPreset.high':
        return ResolutionPreset.high;
      case 'ResolutionPreset.veryHigh':
        return ResolutionPreset.veryHigh;
      case 'ResolutionPreset.ultraHigh':
        return ResolutionPreset.ultraHigh;
      case 'ResolutionPreset.max':
        return ResolutionPreset.max;
      default:
        return ResolutionPreset.high;
    }
  }
}
