import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;

import '../camera/camera_3d.dart';
import '../models/world_data.dart';
import '../render/pipeline_3d.dart';

class WorldPainter3D extends CustomPainter {
  final Camera3D camera;
  final WorldState worldState;
  final v.Vector3 playerPos;

  WorldPainter3D({
    required this.camera,
    required this.worldState,
    required this.playerPos,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final viewMatrix = camera.getViewMatrix();
    final projMatrix = camera.getProjectionMatrix(size.width / size.height);
    final viewProjection = projMatrix * viewMatrix;

    _drawSkyAndFog(canvas, size);

    final polygons = <Polygon3D>[];

    // Build Ground Polygons (Grid & Terrain)
    _generateTerrainPolygons(polygons);

    // Build Road Polygons
    _generateRoadPolygons(polygons);

    // Build Building Polygons
    _generateBuildingPolygons(polygons);

    // Build Collectible Polygons
    _generateCollectiblePolygons(polygons);

    // Filter & Sort Polygons (Occlusion & Back-face culling)
    final sortedPolygons = Pipeline3D.processPolygons(
      polygons: polygons,
      camera: camera,
    );

    // Light Direction (Sun)
    final lightDir = v.Vector3(0.5, 1.0, 0.3).normalized();

    // Render Polygons
    for (var poly in sortedPolygons) {
      final screenPoints = <Offset>[];
      bool isVisible = true;

      for (var vertex in poly.worldVertices) {
        final screenPoint = Pipeline3D.projectVertex(vertex, viewProjection, size);
        if (screenPoint == null) {
          isVisible = false;
          break;
        }
        screenPoints.add(screenPoint);
      }

      if (!isVisible || screenPoints.length < 3) continue;

      // Directional Lighting calculation
      double dot = poly.normal.dot(lightDir);
      double lightIntensity = (dot.clamp(0.0, 1.0) * 0.6) + 0.4;

      // Distance Fog calculation
      final fogFactor = (poly.distanceToCamera / 80.0).clamp(0.0, 0.85);

      final shadedColor = Color.fromRGBO(
        (poly.color.red * lightIntensity).toInt(),
        (poly.color.green * lightIntensity).toInt(),
        (poly.color.blue * lightIntensity).toInt(),
        1.0,
      );

      final finalColor = Color.lerp(shadedColor, const Color(0xFF87CEEB), fogFactor)!;

      final path = Path()..moveTo(screenPoints[0].dx, screenPoints[0].dy);
      for (int i = 1; i < screenPoints.length; i++) {
        path.lineTo(screenPoints[i].dx, screenPoints[i].dy);
      }
      path.close();

      final paint = Paint()
        ..color = finalColor
        ..style = PaintingStyle.fill;

      canvas.drawPath(path, paint);

      // Wireframe outline for styling
      final strokePaint = Paint()
        ..color = Colors.black.withOpacity(0.15)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0;

      canvas.drawPath(path, strokePaint);
    }

    _drawGroundShadows(canvas, viewProjection, size);
  }

  void _drawSkyAndFog(Canvas canvas, Size size) {
    final skyPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF1E88E5), Color(0xFF87CEEB)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height * 0.6));

    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), skyPaint);
  }

  void _generateTerrainPolygons(List<Polygon3D> polygons) {
    const double step = 5.0;
    const double limit = 50.0;

    for (double x = -limit; x < limit; x += step) {
      for (double z = -limit; z < limit; z += step) {
        final v1 = v.Vector3(x, 0, z);
        final v2 = v.Vector3(x + step, 0, z);
        final v3 = v.Vector3(x + step, 0, z + step);
        final v4 = v.Vector3(x, 0, z + step);

        final center = (v1 + v3) * 0.5;
        final dist = camera.position.distanceTo(center);

        polygons.add(Polygon3D(
          worldVertices: [v1, v2, v3, v4],
          color: const Color(0xFF4CAF50),
          normal: v.Vector3(0, 1, 0),
          distanceToCamera: dist,
        ));
      }
    }
  }

  void _generateRoadPolygons(List<Polygon3D> polygons) {
    for (var road in worldState.roads) {
      final dir = (road.end - road.start).normalized();
      final perp = v.Vector3(-dir.z, 0, dir.x) * (road.width / 2.0);

      final v1 = road.start - perp + v.Vector3(0, 0.01, 0);
      final v2 = road.start + perp + v.Vector3(0, 0.01, 0);
      final v3 = road.end + perp + v.Vector3(0, 0.01, 0);
      final v4 = road.end - perp + v.Vector3(0, 0.01, 0);

      final center = (v1 + v3) * 0.5;

      polygons.add(Polygon3D(
        worldVertices: [v1, v2, v3, v4],
        color: const Color(0xFF424242),
        normal: v.Vector3(0, 1, 0),
        distanceToCamera: camera.position.distanceTo(center),
      ));
    }
  }

  void _generateBuildingPolygons(List<Polygon3D> polygons) {
    for (var b in worldState.buildings) {
      final hw = b.size.x / 2.0;
      final h = b.size.y;
      final hd = b.size.z / 2.0;
      final pos = b.position;

      final p = [
        v.Vector3(pos.x - hw, pos.y, pos.z - hd), // 0
        v.Vector3(pos.x + hw, pos.y, pos.z - hd), // 1
        v.Vector3(pos.x + hw, pos.y, pos.z + hd), // 2
        v.Vector3(pos.x - hw, pos.y, pos.z + hd), // 3
        v.Vector3(pos.x - hw, pos.y + h, pos.z - hd), // 4
        v.Vector3(pos.x + hw, pos.y + h, pos.z - hd), // 5
        v.Vector3(pos.x + hw, pos.y + h, pos.z + hd), // 6
        v.Vector3(pos.x - hw, pos.y + h, pos.z + hd), // 7
      ];

      final baseColor = Color(b.colorHex);

      // Walls
      _addQuad(polygons, p[0], p[1], p[5], p[4], v.Vector3(0, 0, -1), baseColor); // Back
      _addQuad(polygons, p[2], p[3], p[7], p[6], v.Vector3(0, 0, 1), baseColor); // Front
      _addQuad(polygons, p[3], p[0], p[4], p[7], v.Vector3(-1, 0, 0), baseColor); // Left
      _addQuad(polygons, p[1], p[2], p[6], p[5], v.Vector3(1, 0, 0), baseColor); // Right

      // Roof
      _addQuad(polygons, p[4], p[5], p[6], p[7], v.Vector3(0, 1, 0), const Color(0xFFB71C1C));
    }
  }

  void _generateCollectiblePolygons(List<Polygon3D> polygons) {
    for (var item in worldState.collectibles) {
      if (item.isCollected) continue;

      final p = item.position;
      const s = 0.4; // Size

      final top = v.Vector3(p.x, p.y + s, p.z);
      final bottom = v.Vector3(p.x, p.y - s, p.z);
      final p1 = v.Vector3(p.x - s, p.y, p.z - s);
      final p2 = v.Vector3(p.x + s, p.y, p.z - s);
      final p3 = v.Vector3(p.x + s, p.y, p.z + s);
      final p4 = v.Vector3(p.x - s, p.y, p.z + s);

      final color = item.type == CollectibleType.coffee
          ? const Color(0xFFFF9800)
          : const Color(0xFFFFD700);

      _addTriangle(polygons, top, p1, p2, v.Vector3(0, 1, -1).normalized(), color);
      _addTriangle(polygons, top, p2, p3, v.Vector3(1, 1, 0).normalized(), color);
      _addTriangle(polygons, top, p3, p4, v.Vector3(0, 1, 1).normalized(), color);
      _addTriangle(polygons, top, p4, p1, v.Vector3(-1, 1, 0).normalized(), color);

      _addTriangle(polygons, bottom, p2, p1, v.Vector3(0, -1, -1).normalized(), color);
      _addTriangle(polygons, bottom, p3, p2, v.Vector3(1, -1, 0).normalized(), color);
      _addTriangle(polygons, bottom, p4, p3, v.Vector3(0, -1, 1).normalized(), color);
      _addTriangle(polygons, bottom, p1, p4, v.Vector3(-1, -1, 0).normalized(), color);
    }
  }

  void _addQuad(List<Polygon3D> polys, v.Vector3 v1, v.Vector3 v2, v.Vector3 v3, v.Vector3 v4, v.Vector3 normal, Color color) {
    final center = (v1 + v2 + v3 + v4) * 0.25;
    polys.add(Polygon3D(
      worldVertices: [v1, v2, v3, v4],
      color: color,
      normal: normal,
      distanceToCamera: camera.position.distanceTo(center),
    ));
  }

  void _addTriangle(List<Polygon3D> polys, v.Vector3 v1, v.Vector3 v2, v.Vector3 v3, v.Vector3 normal, Color color) {
    final center = (v1 + v2 + v3) / 3.0;
    polys.add(Polygon3D(
      worldVertices: [v1, v2, v3],
      color: color,
      normal: normal,
      distanceToCamera: camera.position.distanceTo(center),
    ));
  }

  void _drawGroundShadows(Canvas canvas, v.Matrix4 viewProj, Size size) {
    final shadowPaint = Paint()..color = Colors.black.withOpacity(0.3);

    for (var b in worldState.buildings) {
      final hw = b.size.x / 2.0;
      final hd = b.size.z / 2.0;
      final pos = b.position;

      final points = [
        v.Vector3(pos.x - hw + 0.5, 0.02, pos.z - hd),
        v.Vector3(pos.x + hw + 0.5, 0.02, pos.z - hd),
        v.Vector3(pos.x + hw + 0.5, 0.02, pos.z + hd + 1.0),
        v.Vector3(pos.x - hw + 0.5, 0.02, pos.z + hd + 1.0),
      ];

      final offsets = <Offset>[];
      bool valid = true;
      for (var pt in points) {
        final screenPoint = Pipeline3D.projectVertex(pt, viewProj, size);
        if (screenPoint == null) {
          valid = false;
          break;
        }
        offsets.add(screenPoint);
      }

      if (valid && offsets.length == 4) {
        final path = Path()..moveTo(offsets[0].dx, offsets[0].dy);
        for (int i = 1; i < 4; i++) {
          path.lineTo(offsets[i].dx, offsets[i].dy);
        }
        path.close();
        canvas.drawPath(path, shadowPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant WorldPainter3D oldDelegate) => true;
}
