import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;
import '../camera/camera_3d.dart';
import '../models/world_data.dart';
import '../render/graphics_settings.dart';
import '../render/pipeline_3d.dart';
import '../render/shader_effects.dart';

class WorldPainter3D extends CustomPainter {
  final Camera3D camera;
  final WorldState worldState;
  final v.Vector3 playerPos;
  final GraphicsSettings graphicsSettings;

  WorldPainter3D({
    required this.camera,
    required this.worldState,
    required this.playerPos,
    GraphicsSettings? graphicsSettings,
  }) : graphicsSettings = graphicsSettings ?? GraphicsSettings();

  @override
  void paint(Canvas canvas, Size size) {
    final viewMatrix = camera.getViewMatrix();
    final projMatrix = camera.getProjectionMatrix(size.width / size.height);
    final viewProjection = projMatrix * viewMatrix;

    // Sky
    final skyPaint = Paint()..shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF1565C0), Color(0xFF87CEEB)],
    ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), skyPaint);

    final polygons = <Polygon3D>[];
    _generateTerrain(polygons);
    _generateRoads(polygons);
    _generateBuildings(polygons);
    _generateCollectibles(polygons);

    final sorted = Pipeline3D.processPolygons(
      polygons: polygons,
      camera: camera,
      renderDistance: graphicsSettings.renderDistance,
    );

    final lightDir = v.Vector3(0.5, 1.0, 0.3).normalized();

    for (var poly in sorted) {
      final points = <Offset>[];
      for (var vertex in poly.worldVertices) {
        final p = Pipeline3D.projectVertex(vertex, viewProjection, size);
        if (p == null) continue;
        points.add(p);
      }
      if (points.length < 3) continue;

      final center = poly.worldVertices.reduce((a, b) => a + b) / poly.worldVertices.length.toDouble();
      
      double light = ShaderEffects.calculateDynamicLighting(
        center, poly.normal, camera.position, worldState.buildings, graphicsSettings);
      double shadow = ShaderEffects.calculateShadow(
        center, poly.normal, lightDir, worldState.buildings, graphicsSettings);
      double ao = ShaderEffects.calculateAO(
        center, poly.normal, worldState.buildings, graphicsSettings);

      Color c = ShaderEffects.applyTexturePattern(
        center, poly.color, poly.textureType, graphicsSettings);
      
      c = Color.fromRGBO(
        (c.red * light * shadow * ao).toInt().clamp(0, 255),
        (c.green * light * shadow * ao).toInt().clamp(0, 255),
        (c.blue * light * shadow * ao).toInt().clamp(0, 255),
        1.0,
      );

      c = ShaderEffects.applyBloom(c, 1.0, graphicsSettings);
      c = ShaderEffects.applyFog(c, poly.distanceToCamera, graphicsSettings);

      final path = Path()..moveTo(points[0].dx, points[0].dy);
      for (int i = 1; i < points.length; i++) {
        path.lineTo(points[i].dx, points[i].dy);
      }
      path.close();

      canvas.drawPath(path, Paint()..color = c);
    }
  }

  void _generateTerrain(List<Polygon3D> polygons) {
    final limit = graphicsSettings.renderDistance * 0.6;
    for (double x = -limit; x < limit; x += 5) {
      for (double z = -limit; z < limit; z += 5) {
        final v1 = v.Vector3(x, 0, z);
        final v2 = v.Vector3(x + 5, 0, z);
        final v3 = v.Vector3(x + 5, 0, z + 5);
        final v4 = v.Vector3(x, 0, z + 5);
        final center = (v1 + v3) * 0.5;
        polygons.add(Polygon3D(
          worldVertices: [v1, v2, v3, v4],
          color: const Color(0xFF4CAF50),
          normal: v.Vector3(0, 1, 0),
          distanceToCamera: camera.position.distanceTo(center),
        ));
      }
    }
  }

  void _generateRoads(List<Polygon3D> polygons) {
    for (var road in worldState.roads) {
      final dir = (road.end - road.start).normalized();
      final perp = v.Vector3(-dir.z, 0, dir.x) * (road.width / 2);
      final v1 = road.start - perp + v.Vector3(0, 0.01, 0);
      final v2 = road.start + perp + v.Vector3(0, 0.01, 0);
      final v3 = road.end + perp + v.Vector3(0, 0.01, 0);
      final v4 = road.end - perp + v.Vector3(0, 0.01, 0);
      final center = (v1 + v3) * 0.5;
      polygons.add(Polygon3D(
        worldVertices: [v1, v2, v3, v4],
        color: const Color(0xFF424242),
        normal: v.Vector3(0, 1, 0),
        distanceToCamera: camera.position.distanceTo(center),
      ));
    }
  }

  void _generateBuildings(List<Polygon3D> polygons) {
    for (var b in worldState.buildings) {
      final hw = b.size.x / 2, h = b.size.y, hd = b.size.z / 2;
      final p = b.position;
      final corners = [
        v.Vector3(p.x - hw, p.y, p.z - hd),
        v.Vector3(p.x + hw, p.y, p.z - hd),
        v.Vector3(p.x + hw, p.y, p.z + hd),
        v.Vector3(p.x - hw, p.y, p.z + hd),
        v.Vector3(p.x - hw, p.y + h, p.z - hd),
        v.Vector3(p.x + hw, p.y + h, p.z - hd),
        v.Vector3(p.x + hw, p.y + h, p.z + hd),
        v.Vector3(p.x - hw, p.y + h, p.z + hd),
      ];
      final baseColor = Color(b.colorHex);
      _addQuad(polygons, corners[0], corners[1], corners[5], corners[4], v.Vector3(0, 0, -1), baseColor, b.textureType);
      _addQuad(polygons, corners[2], corners[3], corners[7], corners[6], v.Vector3(0, 0, 1), baseColor, b.textureType);
      _addQuad(polygons, corners[3], corners[0], corners[4], corners[7], v.Vector3(-1, 0, 0), baseColor, b.textureType);
      _addQuad(polygons, corners[1], corners[2], corners[6], corners[5], v.Vector3(1, 0, 0), baseColor, b.textureType);
      _addQuad(polygons, corners[4], corners[5], corners[6], corners[7], v.Vector3(0, 1, 0), const Color(0xFFB71C1C), BuildingTexture.concrete);
    }
  }

  void _addQuad(List<Polygon3D> p, v.Vector3 v1, v.Vector3 v2, v.Vector3 v3, v.Vector3 v4, v.Vector3 n, Color c, BuildingTexture t) {
    final center = (v1 + v2 + v3 + v4) * 0.25;
    p.add(Polygon3D(worldVertices: [v1, v2, v3, v4], color: c, normal: n, distanceToCamera: camera.position.distanceTo(center), textureType: t));
  }

  void _generateCollectibles(List<Polygon3D> polygons) {
    for (var item in worldState.collectibles) {
      if (item.isCollected) continue;
      final p = item.position;
      const s = 0.4;
      final top = v.Vector3(p.x, p.y + s, p.z);
      final p1 = v.Vector3(p.x - s, p.y, p.z - s);
      final p2 = v.Vector3(p.x + s, p.y, p.z - s);
      final p3 = v.Vector3(p.x + s, p.y, p.z + s);
      final p4 = v.Vector3(p.x - s, p.y, p.z + s);
      final color = item.type == CollectibleType.coffee ? const Color(0xFFFF9800) : const Color(0xFFFFD700);
      for (var pts in [[top, p1, p2], [top, p2, p3], [top, p3, p4], [top, p4, p1]]) {
        final center = pts.reduce((a, b) => a + b) / 3.0;
        polygons.add(Polygon3D(worldVertices: pts, color: color, normal: v.Vector3(0, 1, 0), distanceToCamera: camera.position.distanceTo(center)));
      }
    }
  }

  @override
  bool shouldRepaint(covariant WorldPainter3D old) => true;
}
