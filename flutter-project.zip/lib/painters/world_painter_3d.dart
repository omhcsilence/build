import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as v;

import '../camera/camera_3d.dart';
import '../models/world_data.dart';
import '../render/graphics_settings.dart';
import '../render/pipeline_3d.dart';
import '../render/shader_effects.dart';

class WorldPainter3D extends CustomPainter {
  final Camera3D camera;
  final WorldState worldState;
  final v.Vector3 playerPos;
  final GraphicsSettings graphicsSettings;

  WorldPainter3D({
    required this.camera,
    required this.worldState,
    required this.playerPos,
    GraphicsSettings? graphicsSettings,
  }) : graphicsSettings = graphicsSettings ?? GraphicsSettings();

  @override
  void paint(Canvas canvas, Size size) {
    final viewMatrix = camera.getViewMatrix();
    final projMatrix = camera.getProjectionMatrix(size.width / size.height);
    final viewProjection = projMatrix * viewMatrix;

    _drawSkyAndFog(canvas, size);

    final polygons = <Polygon3D>[];

    // Build Ground Polygons (Grid & Terrain)
    _generateTerrainPolygons(polygons);

    // Build Road Polygons
    _generateRoadPolygons(polygons);

    // Build Building Polygons
    _generateBuildingPolygons(polygons);

    // Build Collectible Polygons
    _generateCollectiblePolygons(polygons);

    // Filter & Sort Polygons (Occlusion & Back-face culling)
    final sortedPolygons = Pipeline3D.processPolygons(
      polygons: polygons,
      camera: camera,
      renderDistance: graphicsSettings.renderDistance,
    );

    // Light Direction (Sun)
    final lightDir = v.Vector3(0.5, 1.0, 0.3).normalized();

    // Render Polygons with advanced shaders
    for (var poly in sortedPolygons) {
      final screenPoints = <Offset>[];
      bool isVisible = true;

      for (var vertex in poly.worldVertices) {
        final screenPoint = Pipeline3D.projectVertex(vertex, viewProjection, size);
        if (screenPoint == null) {
          isVisible = false;
          break;
        }
        screenPoints.add(screenPoint);
      }

      if (!isVisible || screenPoints.length < 3) continue;

      // Calculate center point for lighting
      v.Vector3 center = v.Vector3.zero();
      for (var vertex in poly.worldVertices) {
        center += vertex;
      }
      center /= poly.worldVertices.length.toDouble();

      // Dynamic lighting with shadow calculation
      double lightIntensity = ShaderEffects.calculateDynamicLighting(
        center,
        poly.normal,
        camera.position,
        worldState.buildings,
        graphicsSettings,
      );

      // Shadow calculation
      double shadowFactor = ShaderEffects.calculateShadow(
        center,
        poly.normal,
        lightDir,
        worldState.buildings,
        graphicsSettings,
      );

      // Ambient Occlusion
      double aoFactor = ShaderEffects.calculateAO(
        center,
        poly.normal,
        worldState.buildings,
        graphicsSettings,
      );

      // Apply texture pattern
      Color texturedColor = ShaderEffects.applyTexturePattern(
        center,
        poly.color,
        poly.textureType,
        graphicsSettings,
      );

      // Combine lighting effects
      final combinedIntensity = lightIntensity * shadowFactor * aoFactor;

      Color shadedColor = Color.fromRGBO(
        (texturedColor.red * combinedIntensity).toInt().clamp(0, 255),
        (texturedColor.green * combinedIntensity).toInt().clamp(0, 255),
        (texturedColor.blue * combinedIntensity).toInt().clamp(0, 255),
        1.0,
      );

      // Apply bloom effect
      shadedColor = ShaderEffects.applyBloom(
        shadedColor,
        1.0,
        graphicsSettings,
      );

      // Apply fog
      final finalColor = ShaderEffects.applyFog(
        shadedColor,
        poly.distanceToCamera,
        graphicsSettings,
      );

      final path = Path()..moveTo(screenPoints[0].dx, screenPoints[0].dy);
      for (int i = 1; i < screenPoints.length; i++) {
        path.lineTo(screenPoints[i].dx, screenPoints[i].dy);
      }
      path.close();

      // Anti-aliasing stroke width based on quality
      final strokeWidth = graphicsSettings.quality == GraphicsQuality.ultra
          ? 0.5
          : graphicsSettings.quality == GraphicsQuality.high
              ? 0.8
              : 1.0;

      final paint = Paint()
        ..color = finalColor
        ..style = PaintingStyle.fill;

      canvas.drawPath(path, paint);

      // Wireframe outline for styling (only on higher quality)
      if (graphicsSettings.quality != GraphicsQuality.low) {
        final strokePaint = Paint()
          ..color = Colors.black.withOpacity(0.1)
          ..style = PaintingStyle.stroke
          ..strokeWidth = strokeWidth;

        canvas.drawPath(path, strokePaint);
      }
    }

    // Draw advanced shadows
    _drawAdvancedShadows(canvas, viewProjection, size, lightDir);
  }

  void _drawSkyAndFog(Canvas canvas, Size size) {
    // Dynamic sky gradient based on quality settings
    List<Color> skyColors;
    List<double> stops;

    switch (graphicsSettings.quality) {
      case GraphicsQuality.ultra:
        skyColors = [
          const Color(0xFF0D47A1),
          const Color(0xFF1976D2),
          const Color(0xFF42A5F5),
          const Color(0xFF90CAF9),
          const Color(0xFF87CEEB),
        ];
        stops = [0.0, 0.3, 0.5, 0.7, 1.0];
        break;
      case GraphicsQuality.high:
        skyColors = [
          const Color(0xFF1565C0),
          const Color(0xFF1E88E5),
          const Color(0xFF64B5F6),
          const Color(0xFF87CEEB),
        ];
        stops = [0.0, 0.3, 0.7, 1.0];
        break;
      case GraphicsQuality.medium:
        skyColors = [
          const Color(0xFF1976D2),
          const Color(0xFF42A5F5),
          const Color(0xFF87CEEB),
        ];
        stops = [0.0, 0.5, 1.0];
        break;
      case GraphicsQuality.low:
        skyColors = [
          const Color(0xFF1E88E5),
          const Color(0xFF87CEEB),
        ];
        stops = [0.0, 1.0];
        break;
    }

    final skyPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: skyColors,
        stops: stops,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), skyPaint);

    // Draw sun/moon on higher quality settings
    if (graphicsSettings.quality == GraphicsQuality.high ||
        graphicsSettings.quality == GraphicsQuality.ultra) {
      _drawSun(canvas, size);
    }
  }

  void _drawSun(Canvas canvas, Size size) {
    final sunPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.yellow.withOpacity(0.8),
          Colors.orange.withOpacity(0.4),
          Colors.transparent,
        ],
        stops: const [0.0, 0.5, 1.0],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.7, size.height * 0.15),
        radius: 60,
      ));

    canvas.drawCircle(
      Offset(size.width * 0.7, size.height * 0.15),
      60,
      sunPaint,
    );
  }

  void _generateTerrainPolygons(List<Polygon3D> polygons) {
    // Dynamic terrain size based on render distance
    final double limit = graphicsSettings.renderDistance * 0.8;
    final double step = graphicsSettings.quality == GraphicsQuality.ultra
        ? 3.0
        : graphicsSettings.quality == GraphicsQuality.high
            ? 5.0
            : 8.0;

    // Only generate terrain around camera position
    final camX = camera.position.x;
    final camZ = camera.position.z;

    for (double x = camX - limit; x < camX + limit; x += step) {
      for (double z = camZ - limit; z < camZ + limit; z += step) {
        final v1 = v.Vector3(x, 0, z);
        final v2 = v.Vector3(x + step, 0, z);
        final v3 = v.Vector3(x + step, 0, z + step);
        final v4 = v.Vector3(x, 0, z + step);

        final center = (v1 + v3) * 0.5;
        final dist = camera.position.distanceTo(center);

        // Skip if too far
        if (dist > graphicsSettings.renderDistance) continue;

        // Dynamic grass color with variation
        final noise = (math.sin(x * 0.5) * math.cos(z * 0.5) + 1) * 0.5;
        final green = (76 + noise * 30).toInt();
        final grassColor = Color.fromRGBO(76, green, 50, 1.0);

        polygons.add(Polygon3D(
          worldVertices: [v1, v2, v3, v4],
          color: grassColor,
          normal: v.Vector3(0, 1, 0),
          distanceToCamera: dist,
          textureType: BuildingTexture.concrete,
        ));
      }
    }
  }

  void _generateRoadPolygons(List<Polygon3D> polygons) {
    for (var road in worldState.roads) {
      final dir = (road.end - road.start).normalized();
      final perp = v.Vector3(-dir.z, 0, dir.x) * (road.width / 2.0);

      final v1 = road.start - perp + v.Vector3(0, 0.01, 0);
      final v2 = road.start + perp + v.Vector3(0, 0.01, 0);
      final v3 = road.end + perp + v.Vector3(0, 0.01, 0);
      final v4 = road.end - perp + v.Vector3(0, 0.01, 0);

      final center = (v1 + v3) * 0.5;

      polygons.add(Polygon3D(
        worldVertices: [v1, v2, v3, v4],
        color: const Color(0xFF424242),
        normal: v.Vector3(0, 1, 0),
        distanceToCamera: camera.position.distanceTo(center),
      ));
    }
  }

  void _generateBuildingPolygons(List<Polygon3D> polygons) {
    for (var b in worldState.buildings) {
      final hw = b.size.x / 2.0;
      final h = b.size.y;
      final hd = b.size.z / 2.0;
      final pos = b.position;

      final p = [
        v.Vector3(pos.x - hw, pos.y, pos.z - hd), // 0
        v.Vector3(pos.x + hw, pos.y, pos.z - hd), // 1
        v.Vector3(pos.x + hw, pos.y, pos.z + hd), // 2
        v.Vector3(pos.x - hw, pos.y, pos.z + hd), // 3
        v.Vector3(pos.x - hw, pos.y + h, pos.z - hd), // 4
        v.Vector3(pos.x + hw, pos.y + h, pos.z - hd), // 5
        v.Vector3(pos.x + hw, pos.y + h, pos.z + hd), // 6
        v.Vector3(pos.x - hw, pos.y + h, pos.z + hd), // 7
      ];

      final baseColor = Color(b.colorHex);

      // Walls with texture
      _addQuad(polygons, p[0], p[1], p[5], p[4], v.Vector3(0, 0, -1), baseColor, textureType: b.textureType); // Back
      _addQuad(polygons, p[2], p[3], p[7], p[6], v.Vector3(0, 0, 1), baseColor, textureType: b.textureType); // Front
      _addQuad(polygons, p[3], p[0], p[4], p[7], v.Vector3(-1, 0, 0), baseColor, textureType: b.textureType); // Left
      _addQuad(polygons, p[1], p[2], p[6], p[5], v.Vector3(1, 0, 0), baseColor, textureType: b.textureType); // Right

      // Roof with different color
      _addQuad(polygons, p[4], p[5], p[6], p[7], v.Vector3(0, 1, 0), const Color(0xFFB71C1C), textureType: BuildingTexture.concrete);
    }
  }

  void _generateCollectiblePolygons(List<Polygon3D> polygons) {
    for (var item in worldState.collectibles) {
      if (item.isCollected) continue;

      final p = item.position;
      const s = 0.4; // Size

      final top = v.Vector3(p.x, p.y + s, p.z);
      final bottom = v.Vector3(p.x, p.y - s, p.z);
      final p1 = v.Vector3(p.x - s, p.y, p.z - s);
      final p2 = v.Vector3(p.x + s, p.y, p.z - s);
      final p3 = v.Vector3(p.x + s, p.y, p.z + s);
      final p4 = v.Vector3(p.x - s, p.y, p.z + s);

      final color = item.type == CollectibleType.coffee
          ? const Color(0xFFFF9800)
          : const Color(0xFFFFD700);

      _addTriangle(polygons, top, p1, p2, v.Vector3(0, 1, -1).normalized(), color);
      _addTriangle(polygons, top, p2, p3, v.Vector3(1, 1, 0).normalized(), color);
      _addTriangle(polygons, top, p3, p4, v.Vector3(0, 1, 1).normalized(), color);
      _addTriangle(polygons, top, p4, p1, v.Vector3(-1, 1, 0).normalized(), color);

      _addTriangle(polygons, bottom, p2, p1, v.Vector3(0, -1, -1).normalized(), color);
      _addTriangle(polygons, bottom, p3, p2, v.Vector3(1, -1, 0).normalized(), color);
      _addTriangle(polygons, bottom, p4, p3, v.Vector3(0, -1, 1).normalized(), color);
      _addTriangle(polygons, bottom, p1, p4, v.Vector3(-1, -1, 0).normalized(), color);
    }
  }

  void _addQuad(List<Polygon3D> polys, v.Vector3 v1, v.Vector3 v2, v.Vector3 v3, v.Vector3 v4, v.Vector3 normal, Color color, {BuildingTexture textureType = BuildingTexture.concrete}) {
    final center = (v1 + v2 + v3 + v4) * 0.25;
    polys.add(Polygon3D(
      worldVertices: [v1, v2, v3, v4],
      color: color,
      normal: normal,
      distanceToCamera: camera.position.distanceTo(center),
      textureType: textureType,
    ));
  }

  void _addTriangle(List<Polygon3D> polys, v.Vector3 v1, v.Vector3 v2, v.Vector3 v3, v.Vector3 normal, Color color) {
    final center = (v1 + v2 + v3) / 3.0;
    polys.add(Polygon3D(
      worldVertices: [v1, v2, v3],
      color: color,
      normal: normal,
      distanceToCamera: camera.position.distanceTo(center),
      textureType: BuildingTexture.concrete,
    ));
  }

  void _drawAdvancedShadows(Canvas canvas, v.Matrix4 viewProj, Size size, v.Vector3 lightDir) {
    if (!graphicsSettings.shadowsEnabled) return;

    // Shadow opacity based on quality
    final shadowOpacity = graphicsSettings.shadowQuality * 0.4;
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(shadowOpacity);

    for (var b in worldState.buildings) {
      final hw = b.size.x / 2.0;
      final hd = b.size.z / 2.0;
      final pos = b.position;

      // Calculate shadow offset based on light direction
      final shadowOffset = v.Vector3(
        lightDir.x * b.size.y * 0.5,
        0,
        lightDir.z * b.size.y * 0.5,
      );

      final points = [
        v.Vector3(pos.x - hw + shadowOffset.x, 0.02, pos.z - hd + shadowOffset.z),
        v.Vector3(pos.x + hw + shadowOffset.x, 0.02, pos.z - hd + shadowOffset.z),
        v.Vector3(pos.x + hw + shadowOffset.x, 0.02, pos.z + hd + shadowOffset.z),
        v.Vector3(pos.x - hw + shadowOffset.x, 0.02, pos.z + hd + shadowOffset.z),
      ];

      final offsets = <Offset>[];
      bool valid = true;
      for (var pt in points) {
        final screenPoint = Pipeline3D.projectVertex(pt, viewProj, size);
        if (screenPoint == null) {
          valid = false;
          break;
        }
        offsets.add(screenPoint);
      }

      if (valid && offsets.length == 4) {
        final path = Path()..moveTo(offsets[0].dx, offsets[0].dy);
        for (int i = 1; i < 4; i++) {
          path.lineTo(offsets[i].dx, offsets[i].dy);
        }
        path.close();

        // Soft shadow gradient for higher quality
        if (graphicsSettings.quality == GraphicsQuality.ultra ||
            graphicsSettings.quality == GraphicsQuality.high) {
          final gradientPaint = Paint()
            ..shader = RadialGradient(
              colors: [
                Colors.black.withOpacity(shadowOpacity),
                Colors.black.withOpacity(shadowOpacity * 0.5),
                Colors.transparent,
              ],
              stops: const [0.0, 0.7, 1.0],
            ).createShader(Rect.fromPoints(offsets[0], offsets[2]));
          canvas.drawPath(path, gradientPaint);
        } else {
          canvas.drawPath(path, shadowPaint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant WorldPainter3D oldDelegate) => true;
}
