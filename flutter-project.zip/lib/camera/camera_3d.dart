import 'dart:math' as math;
import 'package:vector_math/vector_math_64.dart' as v;

class Camera3D {
  v.Vector3 position;
  double yaw;
  double pitch;
  double fov;
  double near;
  double far;

  Camera3D({
    v.Vector3? position,
    this.yaw = 0.0,
    this.pitch = 0.0,
    this.fov = 60.0,
    this.near = 0.1,
    this.far = 1000.0,
  }) : position = position ?? v.Vector3(0.0, 1.6, 0.0);

  v.Vector3 get forward {
    final cosPitch = math.cos(pitch);
    return v.Vector3(
      math.sin(yaw) * cosPitch,
      math.sin(pitch),
      math.cos(yaw) * cosPitch,
    ).normalized();
  }

  v.Vector3 get right {
    return v.Vector3(
      math.cos(yaw),
      0.0,
      -math.sin(yaw),
    ).normalized();
  }

  v.Vector3 get up => right.cross(forward).normalized();

  v.Matrix4 getViewMatrix() {
    final target = position + forward;
    return v.makeViewMatrix(position, target, v.Vector3(0, 1, 0));
  }

  v.Matrix4 getProjectionMatrix(double aspectRatio) {
    final fovRadian = fov * math.pi / 180.0;
    return v.makePerspectiveMatrix(fovRadian, aspectRatio, near, far);
  }
}
