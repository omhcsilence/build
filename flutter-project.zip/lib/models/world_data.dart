import 'package:vector_math/vector_math_64.dart' as v;

enum CollectibleType { coffee, coin, star }

class Building {
  final String id;
  final String name;
  final v.Vector3 position;
  final v.Vector3 size; // width(X), height(Y), depth(Z)
  final int colorHex;

  Building({
    required this.id,
    required this.name,
    required this.position,
    required this.size,
    required this.colorHex,
  });
}

class Road {
  final String id;
  final v.Vector3 start;
  final v.Vector3 end;
  final double width;

  Road({
    required this.id,
    required this.start,
    required this.end,
    required this.width,
  });
}

class Collectible {
  final String id;
  v.Vector3 position;
  final CollectibleType type;
  bool isCollected;

  Collectible({
    required this.id,
    required this.position,
    required this.type,
    this.isCollected = false,
  });
}

class WorldState {
  final double mapSize;
  final List<Building> buildings;
  final List<Road> roads;
  final List<Collectible> collectibles;

  WorldState({
    required this.mapSize,
    required this.buildings,
    required this.roads,
    required this.collectibles,
  });
}
