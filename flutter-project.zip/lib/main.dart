import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'blocs/camera/camera_bloc.dart';
import 'blocs/gallery/gallery_bloc.dart';
import 'blocs/settings/settings_bloc.dart';
import 'screens/camera_screen.dart';
import 'services/camera_service.dart';
import 'services/permission_service.dart';
import 'services/storage_service.dart';

late List<CameraDescription> cameras;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize cameras
  cameras = await availableCameras();
  
  // Set preferred orientations
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  // Set system UI overlay style
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.black,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  
  runApp(const ProCamApp());
}

class ProCamApp extends StatelessWidget {
  const ProCamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (context) => CameraBloc(
                cameraService: CameraService(),
                permissionService: PermissionService(),
              )..add(InitializeCamera()),
            ),
            BlocProvider(
              create: (context) => GalleryBloc(
                storageService: StorageService(),
              )..add(LoadGallery()),
            ),
            BlocProvider(
              create: (context) => SettingsBloc(
                storageService: StorageService(),
              )..add(LoadSettings()),
            ),
          ],
          child: MaterialApp(
            title: 'ProCam',
            debugShowCheckedModeBanner: false,
            theme: ThemeData.dark().copyWith(
              scaffoldBackgroundColor: Colors.black,
              primaryColor: const Color(0xFF007AFF),
              colorScheme: const ColorScheme.dark(
                primary: Color(0xFF007AFF),
                secondary: Color(0xFFFF9500),
                surface: Color(0xFF1C1C1E),
                background: Colors.black,
              ),
              textTheme: Typography.englishLike2018.apply(
                bodyColor: Colors.white,
                displayColor: Colors.white,
              ),
            ),
            home: const CameraScreen(),
          ),
        );
      },
    );
  }
}
