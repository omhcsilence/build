// lib/chat_page.dart
// Private WhatsApp chat (WhatsApp Web style).
// Access: owner & vip only (enforced by backend).
// Features:
//   - Pairing (QR or pairing code) via PairingScreen
//   - Chat list (recent conversations)
//   - Chat with WA contacts (text/image/voice)
//   - View & post status
//   - WhatsApp call via wa.me deep link
//   - Real-time incoming message via WebSocket

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:image_picker/image_picker.dart';

import 'models/wa_models.dart';
import 'services/whatsapp_service.dart';
import 'services/voice_recorder_service.dart';
import 'widgets/voice_note_player.dart';
import 'screens/pairing_screen.dart';
import 'screens/status_screen.dart';

// ── COLOR SCHEME ──────────────────────────────────────────────────────────────
class _C {
  static const bg      = Color(0xFF000000);
  static const bg2     = Color(0xFF0a0a0a);
  static const surface = Color(0xFF111111);
  static const card    = Color(0xFF111111);
  static const accent  = Color(0xFFFF3B30);
  static const accent2 = Color(0xFFFF6B6B);
  static const accent3 = Color(0xFFCC2E25);
  static const gold    = Color(0xFF333333);
  static const danger  = Color(0xFFFF3B30);
  static const text    = Color(0xFFE0E7FF);
  static const muted   = Color(0x73E0E7FF);
  static const muted2  = Color(0x38E0E7FF);
  static const border  = Color(0x1AFF3B30);
  static const border2 = Color(0x0FFFFFFF);
  static const waGreen = Color(0xFF25D366);
}

class ChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String androidId;
  final String role;

  const ChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
    this.androidId = '',
    this.role = 'member',
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  final String baseUrl = 'https://omhc-host-premium.yakuza.biz.id';

  final TextEditingController _msgController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  WAPairingInfo? _pairing;
  bool _checkingPair = true;
  bool _isOwnerOrVip = false;

  // Chat list & current chat
  List<WAChatPreview> _chats = [];
  String? _selectedJid;
  String? _selectedName;
  List<WAMessage> _messages = [];
  Timer? _refreshTimer;
  StreamSubscription<WAMessage>? _msgSub;

  // Send state
  bool _isSending = false;
  String? _pendingImageBase64;
  Uint8List? _pendingImageBytes;

  // Voice recording
  bool _isRecording = false;
  Duration _recordDuration = Duration.zero;
  Timer? _recordTimer;
  late AnimationController _recordPulse;

  late AnimationController _pulseController;
  String _androidId = 'unknown';

  @override
  void initState() {
    super.initState();
    _initBgVideo();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _recordPulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _isOwnerOrVip = widget.role.toLowerCase() == 'owner' || widget.role.toLowerCase() == 'vip';

    _initAndroidId().then((_) => _initService());
  }

  Future<void> _initAndroidId() async {
    String aid = widget.androidId;
    if (aid.isEmpty) {
      try {
        final info = await DeviceInfoPlugin().androidInfo;
        aid = info.id;
      } catch (_) {
        aid = 'unknown';
      }
    }
    if (mounted) setState(() => _androidId = aid);
  }

  void _initService() {
    WhatsAppService.instance.configure(
      baseUrl: baseUrl,
      sessionKey: widget.sessionKey,
      androidId: _androidId,
      username: widget.username,
    );
    WhatsAppService.instance.connectWebSocket();
    _msgSub = WhatsAppService.instance.incomingMessages.listen((msg) {
      if (_selectedJid == msg.from) {
        setState(() => _messages.add(msg));
        _scrollToBottom();
      } else {
        // refresh chat list to show new preview
        _loadChats();
      }
    });
    _checkPairingStatus();
  }

  Future<void> _checkPairingStatus() async {
    if (!_isOwnerOrVip) {
      if (mounted) setState(() => _checkingPair = false);
      return;
    }
    final info = await WhatsAppService.instance.getStatus();
    if (mounted) {
      setState(() {
        _pairing = info;
        _checkingPair = false;
      });
      if (info != null) {
        _loadChats();
        _refreshTimer = Timer.periodic(const Duration(seconds: 8), (_) => _loadChats());
      }
    }
  }

  Future<void> _loadChats() async {
    if (_pairing == null) return;
    final list = await WhatsAppService.instance.getChats();
    if (mounted) setState(() => _chats = list);
  }

  Future<void> _openConversation(String jid, String name) async {
    setState(() {
      _selectedJid = jid;
      _selectedName = name;
      _messages.clear();
    });
    final history = await WhatsAppService.instance.getChatHistory(jid);
    if (mounted) {
      setState(() => _messages = history);
      _scrollToBottom();
    }
  }

  Future<void> _sendMessage({String type = 'text'}) async {
    final text = _msgController.text.trim();
    if (type == 'text' && text.isEmpty && _pendingImageBase64 == null) return;
    if (_selectedJid == null) return;
    setState(() {
      _isSending = true;
      if (type == 'text') _msgController.clear();
    });
    try {
      WAMessage? sent;
      if (type == 'text') {
        sent = await WhatsAppService.instance.sendMessage(
          jid: _selectedJid!,
          type: 'text',
          text: text,
        );
      } else if (type == 'image' && _pendingImageBase64 != null) {
        sent = await WhatsAppService.instance.sendMessage(
          jid: _selectedJid!,
          type: 'image',
          mediaBase64: _pendingImageBase64,
          mimeType: 'image/jpeg',
          caption: text,
        );
        setState(() {
          _pendingImageBase64 = null;
          _pendingImageBytes = null;
          _msgController.clear();
        });
      }
      if (sent != null) {
        final s = sent;
        setState(() => _messages.add(s));
        _scrollToBottom();
      }
    } catch (_) {}
    if (mounted) setState(() => _isSending = false);
  }

  Future<void> _sendVoiceNote() async {
    final result = await VoiceRecorderService.instance.stop();
    if (result == null) return;
    if (_selectedJid == null) return;
    setState(() => _isSending = true);
    try {
      final sent = await WhatsAppService.instance.sendMessage(
        jid: _selectedJid!,
        type: 'voice',
        mediaBase64: result.base64,
        mimeType: 'audio/mp4',
        durationMs: result.durationMs,
      );
      if (sent != null) {
        final s = sent;
        setState(() => _messages.add(s));
        _scrollToBottom();
      }
    } catch (_) {}
    if (mounted) setState(() => _isSending = false);
  }

  Future<void> _pickImage() async {
    if (_isSending) return;
    try {
      final xfile = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 60, maxWidth: 1200);
      if (xfile == null) return;
      final bytes = await xfile.readAsBytes();
      final b64 = 'data:image/jpeg;base64,${base64Encode(bytes)}';
      if (mounted) {
        setState(() {
          _pendingImageBytes = bytes;
          _pendingImageBase64 = b64;
        });
      }
    } catch (_) {}
  }

  Future<void> _startRecording() async {
    await VoiceRecorderService.instance.start();
    if (!VoiceRecorderService.instance.isRecording) {
      _showSnack('Microphone permission denied', true);
      return;
    }
    setState(() {
      _isRecording = true;
      _recordDuration = Duration.zero;
    });
    _recordPulse.repeat(reverse: true);
    _recordTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _recordDuration += const Duration(seconds: 1));
    });
  }

  Future<void> _stopRecording() async {
    _recordTimer?.cancel();
    _recordPulse.stop();
    setState(() => _isRecording = false);
    await _sendVoiceNote();
  }

  Future<void> _cancelRecording() async {
    _recordTimer?.cancel();
    _recordPulse.stop();
    await VoiceRecorderService.instance.cancel();
    setState(() => _isRecording = false);
  }

  Future<void> _startCall() async {
    if (_selectedJid == null) return;
    final phone = _selectedJid!.split('@').first.replaceAll(RegExp(r'\D'), '');
    if (phone.isEmpty) {
      _showSnack('Cannot call — phone number not available', true);
      return;
    }
    final link = 'https://wa.me/$phone';
    if (await canLaunchUrl(Uri.parse(link))) {
      await launchUrl(Uri.parse(link), mode: LaunchMode.externalApplication);
    } else {
      _showSnack('Cannot open WhatsApp', true);
    }
  }

  Future<void> _unpair() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _C.surface,
        title: const Text('Unpair WhatsApp?', style: TextStyle(color: _C.text)),
        content: const Text('This will disconnect your WhatsApp account and wipe all session data.',
            style: TextStyle(color: _C.muted, fontSize: 12)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            child: const Text('Unpair'),
          ),
        ],
      ),
    );
    if (confirm != true) return;
    await WhatsAppService.instance.unpair();
    if (mounted) {
      setState(() {
        _pairing = null;
        _chats = [];
        _messages = [];
        _selectedJid = null;
      });
      _refreshTimer?.cancel();
      _showSnack('WhatsApp unpaired', false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showSnack(String msg, bool isError) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor: isError ? _C.danger : Colors.green.shade800,
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _recordTimer?.cancel();
    _pulseController.dispose();
    _recordPulse.dispose();
    _msgController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    _msgSub?.cancel();
    _bgVideoController.dispose();
    super.dispose();
  }

  Future<void> _initBgVideo() async {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4');
    await _bgVideoController.initialize().then((_) {
      if (mounted) {
        setState(() => _bgVideoReady = true);
        _bgVideoController.setLooping(true);
        _bgVideoController.setVolume(0.0);
        _bgVideoController.play();
      }
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    // Access control UI
    if (!_isOwnerOrVip) {
      return _buildAccessDenied();
    }
    if (_checkingPair) {
      return _buildLoading();
    }
    return Stack(
      children: [
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.6)),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                if (_pairing == null)
                  Expanded(child: _buildPairPrompt())
                else if (_selectedJid == null)
                  Expanded(child: _buildChatList())
                else
                  Expanded(child: _buildChatScreen()),
                if (_selectedJid != null) _buildInputArea(),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAccessDenied() {
    return Scaffold(
      backgroundColor: const Color(0xFF070D17),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.red.withOpacity(0.15),
                    border: Border.all(color: Colors.red, width: 2),
                  ),
                  child: const Icon(Icons.lock_outline, color: Colors.redAccent, size: 48),
                ),
                const SizedBox(height: 20),
                const Text(
                  'ACCESS DENIED',
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'MADEEvolveSansEVO',
                    letterSpacing: 2,
                  ),
                ),
                SizedBox(height: 12),
                Text(
                  'Private WhatsApp Chat is only available for Owner and VIP users.\n\nUpgrade your account to access this feature.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.6),
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                    height: 1.6,
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.arrow_back),
                  label: const Text('Go Back'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.cyanAccent,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoading() {
    return Scaffold(
      backgroundColor: const Color(0xFF070D17),
      body: const Center(
        child: CircularProgressIndicator(color: Colors.cyanAccent),
      ),
    );
  }

  // ── HEADER ────────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          height: 62,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: const Color(0xEB0A0A14),
            border: Border(bottom: BorderSide(color: _C.border)),
          ),
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  if (_selectedJid != null) {
                    setState(() {
                      _selectedJid = null;
                      _selectedName = null;
                      _messages.clear();
                    });
                    _loadChats();
                  } else {
                    Navigator.of(context).pop();
                  }
                },
                child: Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.border2),
                  ),
                  child: const Icon(Icons.arrow_back, color: _C.text, size: 16),
                ),
              ),
              SizedBox(width: 10),
              AnimatedBuilder(
                animation: _pulseController,
                builder: (_, __) => Container(
                  width: 7, height: 7,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _pairing != null ? _C.waGreen : Colors.orange,
                    boxShadow: [
                      BoxShadow(
                        color: (_pairing != null ? _C.waGreen : Colors.orange)
                            .withOpacity(0.3 + _pulseController.value * 0.4),
                        blurRadius: 5 + _pulseController.value * 5,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      _selectedName != null
                          ? _selectedName!
                          : (_pairing != null ? 'WhatsApp · ${_pairing!.phone}' : 'PRIVATE WA CHAT'),
                      style: const TextStyle(
                        color: _C.text,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'MADEEvolveSansEVO',
                        letterSpacing: 1,
                      ),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      _selectedJid != null
                          ? '${_messages.length} messages'
                          : (_pairing != null ? 'Connected as ${_pairing!.name}' : 'Not paired'),
                      style: const TextStyle(
                        color: _C.muted,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
              if (_selectedJid != null)
                GestureDetector(
                  onTap: _startCall,
                  child: Container(
                    width: 38, height: 38,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      color: _C.waGreen.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _C.waGreen.withOpacity(0.4)),
                    ),
                    child: const Icon(Icons.phone_in_talk_rounded, color: _C.waGreen, size: 16),
                  ),
                ),
              if (_pairing != null && _selectedJid == null) ...[
                GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => StatusScreen(sessionKey: widget.sessionKey, baseUrl: baseUrl),
                  )),
                  child: Container(
                    width: 38, height: 38,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      color: Colors.cyan.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.cyan.withOpacity(0.4)),
                    ),
                    child: const Icon(Icons.camera_alt_rounded, color: Colors.cyan, size: 16),
                  ),
                ),
                GestureDetector(
                  onTap: _unpair,
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.red.withOpacity(0.4)),
                    ),
                    child: const Icon(Icons.link_off_rounded, color: Colors.redAccent, size: 16),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ── PAIR PROMPT ───────────────────────────────────────────────────────────
  Widget _buildPairPrompt() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.waGreen.withOpacity(0.1),
                border: Border.all(color: _C.waGreen.withOpacity(0.4), width: 2),
                boxShadow: [
                  BoxShadow(color: _C.waGreen.withOpacity(0.2), blurRadius: 30, spreadRadius: 4),
                ],
              ),
              child: const Icon(FontAwesomeIcons.whatsapp, color: _C.waGreen, size: 56),
            ),
            const SizedBox(height: 24),
            const Text(
              'Connect WhatsApp',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
                fontFamily: 'MADEEvolveSansEVO',
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Pair your WhatsApp number to chat with your WA contacts, view status updates, and make calls — all from this private chat.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withOpacity(0.6),
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                height: 1.5,
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  await Navigator.push(context, MaterialPageRoute(
                    builder: (_) => PairingScreen(
                      sessionKey: widget.sessionKey,
                      androidId: _androidId,
                      username: widget.username,
                      baseUrl: baseUrl,
                      onPaired: () {
                        Navigator.pop(context);
                        _checkPairingStatus();
                      },
                    ),
                  ));
                },
                icon: const Icon(Icons.link_rounded, color: Colors.black),
                label: const Text('Start Pairing', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _C.waGreen,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Only ONE WhatsApp can be paired per account.\nRe-pairing unpairs the old one automatically.',
              textAlign: TextAlign.center,
              style: TextStyle(color: _C.muted, fontSize: 10, fontFamily: 'ShareTechMono', height: 1.4),
            ),
          ],
        ),
      ),
    );
  }

  // ── CHAT LIST ─────────────────────────────────────────────────────────────
  Widget _buildChatList() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
          child: Container(
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.border),
            ),
            child: Row(
              children: [
                const SizedBox(width: 14),
                const Icon(Icons.search, color: _C.muted2, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    style: const TextStyle(color: _C.text, fontFamily: 'ShareTechMono', fontSize: 13),
                    cursorColor: _C.accent,
                    decoration: const InputDecoration(
                      hintText: 'Cari nomor WA (628xxx)...',
                      hintStyle: TextStyle(color: _C.muted2, fontSize: 12),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 14),
                    ),
                    onSubmitted: (val) async {
                      if (val.trim().isEmpty) return;
                      final phone = val.trim().replaceAll(RegExp(r'\D'), '');
                      if (phone.isEmpty) return;
                      final jid = '$phone@s.whatsapp.net';
                      await _openConversation(jid, phone);
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: _chats.isEmpty
              ? _buildEmptyChatList()
              : RefreshIndicator(
                  onRefresh: _loadChats,
                  color: _C.waGreen,
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    itemCount: _chats.length,
                    itemBuilder: (ctx, i) => _buildChatTile(_chats[i]),
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildEmptyChatList() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(FontAwesomeIcons.whatsapp, color: _C.waGreen.withOpacity(0.3), size: 64),
          const SizedBox(height: 12),
          const Text(
            'No conversations yet.\nType a phone number above to start chatting with a WA contact.',
            textAlign: TextAlign.center,
            style: TextStyle(color: _C.muted, fontSize: 11, fontFamily: 'ShareTechMono', height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _buildChatTile(WAChatPreview chat) {
    return GestureDetector(
      onTap: () => _openConversation(chat.jid, chat.name),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _C.surface.withOpacity(0.85),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.border2),
        ),
        child: Row(
          children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [
                  _C.waGreen.withOpacity(0.3),
                  _C.waGreen.withOpacity(0.05),
                ]),
                border: Border.all(color: _C.waGreen.withOpacity(0.5), width: 1.5),
              ),
              child: const Icon(Icons.person, color: _C.waGreen, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    chat.name,
                    style: const TextStyle(color: _C.text, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'ShareTechMono'),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    chat.lastMessage,
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: chat.unread > 0 ? _C.text : _C.muted,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (chat.lastTime != null)
                  Text(
                    _fmtTime(chat.lastTime!),
                    style: const TextStyle(color: _C.muted2, fontSize: 9, fontFamily: 'ShareTechMono'),
                  ),
                if (chat.unread > 0)
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                    decoration: BoxDecoration(
                      color: _C.waGreen,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${chat.unread}',
                      style: const TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── CHAT SCREEN ───────────────────────────────────────────────────────────
  Widget _buildChatScreen() {
    if (_messages.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(FontAwesomeIcons.whatsapp, color: _C.waGreen.withOpacity(0.3), size: 48),
            const SizedBox(height: 8),
            const Text(
              'Say hi to start the conversation!',
              style: TextStyle(color: _C.muted, fontSize: 12, fontFamily: 'ShareTechMono'),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 16),
      itemCount: _messages.length,
      itemBuilder: (ctx, i) => _buildBubble(_messages[i]),
    );
  }

  Widget _buildBubble(WAMessage msg) {
    final isMine = msg.fromMe;
    final alignment = isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    return Container(
      margin: EdgeInsets.only(
        bottom: 10,
        left: isMine ? 50 : 0,
        right: isMine ? 0 : 50,
      ),
      child: Column(
        crossAxisAlignment: alignment,
        children: [
          Row(
            mainAxisAlignment: isMine ? MainAxisAlignment.end : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (!isMine)
                Container(
                  margin: const EdgeInsets.only(right: 6),
                  width: 26, height: 26,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.waGreen.withOpacity(0.2),
                    border: Border.all(color: _C.waGreen, width: 1),
                  ),
                  child: const Icon(Icons.person, color: _C.waGreen, size: 12),
                ),
              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: isMine
                          ? [_C.waGreen.withOpacity(0.4), _C.waGreen.withOpacity(0.2)]
                          : [_C.surface, _C.card],
                    ),
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(14),
                      topRight: const Radius.circular(14),
                      bottomLeft: isMine ? const Radius.circular(14) : const Radius.circular(2),
                      bottomRight: isMine ? const Radius.circular(2) : const Radius.circular(14),
                    ),
                    border: Border.all(color: isMine ? _C.waGreen.withOpacity(0.5) : _C.border2),
                  ),
                  child: _buildMessageContent(msg, isMine),
                ),
              ),
            ],
          ),
          Padding(
            padding: EdgeInsets.only(
              left: isMine ? 0 : 36,
              right: isMine ? 4 : 0,
              top: 3,
            ),
            child: Text(
              _fmtTime(msg.time),
              style: const TextStyle(color: _C.muted2, fontSize: 9, fontFamily: 'ShareTechMono'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageContent(WAMessage msg, bool isMine) {
    final textColor = isMine ? Colors.white : _C.text;
    switch (msg.type) {
      case WAMessageType.voice:
        return VoiceNotePlayer(
          url: msg.durationMs > 0 ? null : null,  // incoming voice URLs would need backend media endpoint
          durationMs: msg.durationMs,
          isMine: isMine,
        );
      case WAMessageType.image:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (msg.text.isNotEmpty)
              Text(msg.text, style: TextStyle(color: textColor, fontSize: 13, fontFamily: 'ShareTechMono', height: 1.3)),
            if (msg.text.isEmpty)
              const Text('[Image]', style: TextStyle(color: _C.muted)),
            if (msg.caption.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(msg.caption, style: TextStyle(color: textColor, fontSize: 12, fontFamily: 'ShareTechMono')),
            ],
          ],
        );
      case WAMessageType.video:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.videocam_rounded, color: _C.muted, size: 32),
            if (msg.caption.isNotEmpty)
              Text(msg.caption, style: TextStyle(color: textColor, fontSize: 12, fontFamily: 'ShareTechMono')),
          ],
        );
      case WAMessageType.document:
        return const Row(children: [Icon(Icons.insert_drive_file, color: _C.muted, size: 16), SizedBox(width: 6), Text('[Document]', style: TextStyle(color: _C.muted))]);
      case WAMessageType.sticker:
        return const Icon(Icons.emoji_emotions_outlined, color: Colors.amber, size: 48);
      case WAMessageType.unknown:
        return const Text('[Unknown message]', style: TextStyle(color: _C.muted, fontStyle: FontStyle.italic));
      case WAMessageType.text:
        return Text(
          msg.text,
          style: TextStyle(color: textColor, fontSize: 13, fontFamily: 'ShareTechMono', height: 1.3),
        );
    }
  }

  // ── INPUT AREA ────────────────────────────────────────────────────────────
  Widget _buildInputArea() {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          decoration: BoxDecoration(
            color: const Color(0xCC0A0A14),
            border: Border(top: BorderSide(color: _C.border)),
          ),
          child: SafeArea(
            top: false,
            child: _isRecording ? _buildRecordingBar() : _buildNormalInput(),
          ),
        ),
      ),
    );
  }

  Widget _buildNormalInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_pendingImageBytes != null)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.memory(_pendingImageBytes!, height: 80, fit: BoxFit.cover),
                ),
                Positioned(
                  top: 2, right: 2,
                  child: GestureDetector(
                    onTap: () => setState(() {
                      _pendingImageBytes = null;
                      _pendingImageBase64 = null;
                    }),
                    child: Container(
                      width: 22, height: 22,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: _C.accent),
                      child: const Icon(Icons.close, size: 14, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
        Row(
          children: [
            // Image picker button
            GestureDetector(
              onTap: _isSending ? null : _pickImage,
              child: Container(
                width: 40, height: 40,
                margin: const EdgeInsets.only(right: 6),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.surface,
                  border: Border.all(color: _C.border2),
                ),
                child: const Icon(Icons.attach_file, color: _C.muted, size: 18),
              ),
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _C.border),
                ),
                child: Row(
                  children: [
                    const SizedBox(width: 14),
                    Expanded(
                      child: TextField(
                        controller: _msgController,
                        minLines: 1,
                        maxLines: 5,
                        style: const TextStyle(color: _C.text, fontFamily: 'ShareTechMono', fontSize: 13),
                        cursorColor: _C.waGreen,
                        decoration: const InputDecoration(
                          hintText: 'Type a message...',
                          hintStyle: TextStyle(color: _C.muted2, fontSize: 12),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 10),
                        ),
                        onSubmitted: (_) => _sendMessage(),
                      ),
                    ),
                    GestureDetector(
                      onLongPress: _startRecording,
                      onTap: () => _showSnack('Hold to record voice note', false),
                      child: Container(
                        width: 34, height: 34,
                        margin: const EdgeInsets.only(right: 6),
                        decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.transparent),
                        child: const Icon(Icons.mic_rounded, color: _C.muted2, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(width: 8),
            GestureDetector(
              onTap: _isSending
                  ? null
                  : () => _sendMessage(type: _pendingImageBase64 != null ? 'image' : 'text'),
              child: Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [_C.waGreen, Color(0xFF128C7E)]),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: _C.waGreen.withOpacity(0.4), blurRadius: 10, spreadRadius: 1),
                  ],
                ),
                child: _isSending
                    ? const Padding(
                        padding: EdgeInsets.all(10),
                        child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation(Colors.white)),
                      )
                    : const Icon(Icons.send_rounded, color: Colors.white, size: 18),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildRecordingBar() {
    return Row(
      children: [
        AnimatedBuilder(
          animation: _recordPulse,
          builder: (_, __) => Container(
            width: 12, height: 12,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.accent.withOpacity(0.6 + _recordPulse.value * 0.4),
              boxShadow: [
                BoxShadow(color: _C.accent.withOpacity(0.4), blurRadius: 8, spreadRadius: 2),
              ],
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            'Recording... ${_recordDuration.inSeconds}s',
            style: const TextStyle(color: _C.accent, fontSize: 13, fontFamily: 'ShareTechMono'),
          ),
        ),
        GestureDetector(
          onTap: _cancelRecording,
          child: Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.2),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.red, width: 1.5),
            ),
            child: const Icon(Icons.close, color: Colors.redAccent, size: 18),
          ),
        ),
        SizedBox(width: 8),
        GestureDetector(
          onTap: _stopRecording,
          child: Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Colors.green, Colors.green.shade800]),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: Colors.green.withOpacity(0.5), blurRadius: 10, spreadRadius: 1),
              ],
            ),
            child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
          ),
        ),
      ],
    );
  }

  String _fmtTime(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'now';
    if (diff.inHours < 1) return '${diff.inMinutes}m';
    if (diff.inDays < 1) return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    if (diff.inDays < 7) return '${diff.inDays}d';
    return '${dt.day}/${dt.month}';
  }
}
