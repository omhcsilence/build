import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shimmer/shimmer.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  LEADERBOARD PAGE
//  ── Modern dark UI + red accent (#FF3B30).
//  ── Two tabs: TOP SENDERS & TOP VIP.
//  ── Real-time data dari /leaderboard?key=, auto-refresh 30 detik.
//  ── Animated number counters (count-up) + shimmer loading.
//  ── Trophy / medal icons buat top 3.
//  ── "SUPPORT US" section at bottom: top donors + Donate button.
// ═══════════════════════════════════════════════════════════════════════════

// ── Color scheme (sama dengan dashboard utama) ──
class _LC {
  static const bg        = Color(0xFF000000);
  static const bg2       = Color(0xFF0a0a0a);
  static const surface   = Color(0xFF111111);
  static const card      = Color(0xFF111111);
  static const cardDark  = Color(0xFF1a1a1a);
  static const accent    = Color(0xFFFF3B30);
  static const accent2   = Color(0xFFFF6B6B);
  static const accent3   = Color(0xFFCC2E25);
  static const gold      = Color(0xFFFFD700);
  static const silver    = Color(0xFFC0C0C0);
  static const bronze    = Color(0xFFCD7F32);
  static const text      = Color(0xFFE0E7FF);
  static const muted     = Color(0x73E0E7FF);
  static const muted2    = Color(0x38E0E7FF);
  static const border    = Color(0x1AFF3B30);
  static const border2   = Color(0x0FFFFFFF);
  static const success   = Color(0xFF34D399);
}

class LeaderboardPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  LeaderboardPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<LeaderboardPage> createState() => _LeaderboardPageState();
}

class _LeaderboardPageState extends State<LeaderboardPage>
    with TickerProviderStateMixin {
  static const String _baseUrl = "https://omhc-host-premium.yakuza.biz.id";

  // ── Tab state ──
  int _currentTab = 0; // 0 = TOP SENDERS, 1 = TOP VIP

  // ── Data ──
  List<Map<String, dynamic>> _senderLeaderboard = [];
  List<Map<String, dynamic>> _vipLeaderboard = [];
  Map<String, dynamic> _stats = {};
  bool _loading = true;
  bool _refreshing = false;
  String? _error;

  // ── Donation data ──
  List<Map<String, dynamic>> _topDonors = [];
  Map<String, dynamic> _donationStats = {};
  bool _donorsLoading = true;

  // ── Auto-refresh timer ──
  Timer? _refreshTimer;

  // ── Animations ──
  late AnimationController _pulseController;
  late AnimationController _shimmerController;
  late AnimationController _tabController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 3),
    )..repeat(reverse: true);
    _shimmerController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 2),
    )..repeat(reverse: true);
    _tabController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 250),
    );
    _fetchLeaderboard();
    _fetchTopDonors();
    _refreshTimer = Timer.periodic(
      Duration(seconds: 30),
      (_) {
        _fetchLeaderboard(isAutoRefresh: true);
        _fetchTopDonors();
      },
    );
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _pulseController.dispose();
    _shimmerController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  // ── API: fetch leaderboard ──
  Future<void> _fetchLeaderboard({bool isAutoRefresh = false}) async {
    if (widget.sessionKey.isEmpty) {
      if (mounted) setState(() {
        _loading = false;
        _error = 'Session key kosong. Silakan login ulang.';
      });
      return;
    }
    if (isAutoRefresh) {
      if (mounted) setState(() => _refreshing = true);
    } else {
      if (mounted) setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final res = await http.get(Uri.parse(
        "$_baseUrl/leaderboard?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 12));
      if (res.statusCode != 200) {
        if (mounted) setState(() {
          _loading = false;
          _refreshing = false;
          _error = 'Server returned ${res.statusCode}';
        });
        return;
      }
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final senders = (data['senderLeaderboard'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        final vips = (data['vipLeaderboard'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        final stats = data['stats'] is Map
            ? Map<String, dynamic>.from(data['stats'] as Map)
            : <String, dynamic>{};
        if (mounted) {
          setState(() {
            _senderLeaderboard = senders;
            _vipLeaderboard = vips;
            _stats = stats;
            _loading = false;
            _refreshing = false;
            _error = null;
          });
        }
      } else {
        if (mounted) setState(() {
          _loading = false;
          _refreshing = false;
          _error = (data['message'] ?? 'Gagal load leaderboard').toString();
        });
      }
    } catch (e) {
      if (mounted) setState(() {
        _loading = false;
        _refreshing = false;
        _error = 'Connection error: $e';
      });
    }
  }

  // ── API: fetch top donors ──
  Future<void> _fetchTopDonors() async {
    if (widget.sessionKey.isEmpty) return;
    try {
      final res = await http.get(Uri.parse(
        "$_baseUrl/topDonors?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 10));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final donors = (data['donors'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        final stats = data['stats'] is Map
            ? Map<String, dynamic>.from(data['stats'] as Map)
            : <String, dynamic>{};
        if (mounted) {
          setState(() {
            _topDonors = donors;
            _donationStats = stats;
            _donorsLoading = false;
          });
        }
      }
    } catch (_) {
      // silent fail — donation section is non-critical
      if (mounted) setState(() => _donorsLoading = false);
    }
  }

  // ── Format currency (IDR) ──
  String _formatRupiah(num amount) {
    if (amount >= 1000000) {
      final m = amount / 1000000;
      return 'Rp ${m.toStringAsFixed(m == m.roundToDouble() ? 0 : 1)}M';
    }
    if (amount >= 1000) {
      final k = amount / 1000;
      return 'Rp ${k.toStringAsFixed(k == k.roundToDouble() ? 0 : 1)}k';
    }
    return 'Rp $amount';
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _LC.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_LC.bg, _LC.bg2, _LC.bg],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildStatsHeader(),
              _buildTabs(),
              Expanded(
                child: _loading
                    ? _buildLoadingList()
                    : _error != null
                        ? _buildErrorState()
                        : _currentTab == 0
                            ? _buildSendersList()
                            : _buildVipList(),
              ),
              _buildDonationSection(),
            ],
          ),
        ),
      ),
    );
  }

  // ── HEADER ──
  Widget _buildHeader() {
    return Container(
      height: 62,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Color(0xEB0c0d15),
        border: Border(bottom: BorderSide(color: _LC.border)),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: _LC.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _LC.border2),
              ),
              child: Icon(Icons.arrow_back, color: _LC.text, size: 16),
            ),
          ),
          SizedBox(width: 10),
          AnimatedBuilder(
            animation: _pulseController,
            builder: (_, __) => Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: _LC.accent.withOpacity(0.12 + _pulseController.value * 0.06),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _LC.accent.withOpacity(0.3)),
              ),
              child: Center(
                child: FaIcon(FontAwesomeIcons.trophy, color: _LC.accent, size: 14),
              ),
            ),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'LEADERBOARD',
                  style: TextStyle(
                    color: _LC.text,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'MADEEvolveSansEVO',
                    letterSpacing: 1.5,
                  ),
                ),
                SizedBox(height: 1),
                Row(
                  children: [
                    AnimatedBuilder(
                      animation: _pulseController,
                      builder: (_, __) => Container(
                        width: 6, height: 6,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _LC.accent,
                          boxShadow: [
                            BoxShadow(
                              color: _LC.accent.withOpacity(0.4 + _pulseController.value * 0.4),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(width: 5),
                    Text(
                      _refreshing ? 'SYNCING...' : 'LIVE',
                      style: TextStyle(
                        color: _LC.muted,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Refresh button
          GestureDetector(
            onTap: () => _fetchLeaderboard(),
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: _LC.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _LC.border2),
              ),
              child: _refreshing
                  ? Padding(
                      padding: EdgeInsets.all(10),
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: _LC.accent,
                      ),
                    )
                  : Icon(Icons.refresh, color: _LC.text, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  // ── STATS HEADER ──
  // Total users, total VIP, total senders (count-up animated).
  Widget _buildStatsHeader() {
    final totalUsers = (_stats['totalUsers'] ?? 0) as num;
    final totalVIP = (_stats['totalVIP'] ?? 0) as num;
    final totalSenders = (_stats['totalSenderFolders'] ?? _stats['totalActiveSenders'] ?? 0) as num;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _LC.cardDark,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _LC.border),
        boxShadow: [
          BoxShadow(
            color: _LC.accent.withOpacity(0.08),
            blurRadius: 16,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  color: _LC.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _LC.accent.withOpacity(0.25)),
                ),
                child: Center(
                  child: FaIcon(FontAwesomeIcons.chartSimple, color: _LC.accent, size: 12),
                ),
              ),
              SizedBox(width: 10),
              Text(
                'GLOBAL STATS',
                style: TextStyle(
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                  color: _LC.text,
                ),
              ),
              Spacer(),
              Text(
                '30s',
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 9,
                  color: _LC.muted2,
                ),
              ),
              SizedBox(width: 4),
              FaIcon(FontAwesomeIcons.arrowsRotate, color: _LC.muted2, size: 9),
            ],
          ),
          SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  'USERS',
                  totalUsers.toInt(),
                  FontAwesomeIcons.users,
                  _LC.accent,
                ),
              ),
              Container(width: 1, height: 38, color: _LC.border2),
              Expanded(
                child: _buildStatItem(
                  'VIP',
                  totalVIP.toInt(),
                  FontAwesomeIcons.crown,
                  _LC.gold,
                ),
              ),
              Container(width: 1, height: 38, color: _LC.border2),
              Expanded(
                child: _buildStatItem(
                  'SENDERS',
                  totalSenders.toInt(),
                  FontAwesomeIcons.paperPlane,
                  _LC.success,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Single stat with count-up animation ──
  Widget _buildStatItem(String label, int target, FaIconData icon, Color color) {
    return Column(
      children: [
        FaIcon(icon, color: color, size: 12),
        SizedBox(height: 6),
        AnimatedNumber(
          target: target,
          style: TextStyle(
            fontFamily: 'ShareTechMono',
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            fontFamily: 'ShareTechMono',
            fontSize: 9,
            color: _LC.muted2,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }

  // ── TABS (TOP SENDERS / TOP VIP) ──
  Widget _buildTabs() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: _LC.cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _LC.border2),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildTabButton('TOP SENDERS', FontAwesomeIcons.paperPlane, 0),
          ),
          Expanded(
            child: _buildTabButton('TOP VIP', FontAwesomeIcons.crown, 1),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(String label, FaIconData icon, int index) {
    final isActive = _currentTab == index;
    return GestureDetector(
      onTap: () {
        if (_currentTab == index) return;
        setState(() => _currentTab = index);
        _tabController.forward(from: 0);
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: isActive ? _LC.accent : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          boxShadow: isActive
              ? [BoxShadow(color: _LC.accent.withOpacity(0.4), blurRadius: 10)]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: isActive ? Colors.white : _LC.muted2, size: 11),
            SizedBox(width: 7),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
                color: isActive ? Colors.white : _LC.muted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── LOADING (shimmer) ──
  Widget _buildLoadingList() {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      itemCount: 6,
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: _LC.surface,
        highlightColor: _LC.border,
        period: Duration(milliseconds: 1200),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _LC.surface,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _LC.surface,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(height: 12, width: 140, decoration: BoxDecoration(color: _LC.surface, borderRadius: BorderRadius.circular(4))),
                    SizedBox(height: 8),
                    Container(height: 8, width: 90, decoration: BoxDecoration(color: _LC.surface, borderRadius: BorderRadius.circular(4))),
                  ],
                ),
              ),
              Container(
                width: 50, height: 24,
                decoration: BoxDecoration(color: _LC.surface, borderRadius: BorderRadius.circular(6)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── ERROR STATE ──
  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                color: _LC.accent.withOpacity(0.08),
                shape: BoxShape.circle,
                border: Border.all(color: _LC.accent.withOpacity(0.25), width: 2),
              ),
              child: Icon(Icons.error_outline, color: _LC.accent, size: 32),
            ),
            SizedBox(height: 18),
            Text(
              'FAILED TO LOAD',
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: _LC.text,
                letterSpacing: 2,
              ),
            ),
            SizedBox(height: 8),
            Text(
              _error ?? 'Unknown error',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 11,
                color: _LC.muted,
                height: 1.5,
              ),
            ),
            SizedBox(height: 18),
            GestureDetector(
              onTap: () => _fetchLeaderboard(),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                decoration: BoxDecoration(
                  color: _LC.accent,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [BoxShadow(color: _LC.accent.withOpacity(0.3), blurRadius: 12)],
                ),
                child: Text(
                  'RETRY',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  DONATION SECTION — "SUPPORT US" at the bottom of leaderboard
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildDonationSection() {
    final totalDonors = (_donationStats['totalDonors'] ?? 0) as num;
    final totalDonated = (_donationStats['totalDonated'] ?? 0) as num;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _LC.cardDark,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _LC.border),
        boxShadow: [
          BoxShadow(
            color: _LC.accent.withOpacity(0.08),
            blurRadius: 16,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            children: [
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  color: _LC.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _LC.accent.withOpacity(0.25)),
                ),
                child: Center(
                  child: FaIcon(FontAwesomeIcons.handHoldingHeart,
                      color: _LC.accent, size: 12),
                ),
              ),
              SizedBox(width: 10),
              Text(
                'SUPPORT US',
                style: TextStyle(
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                  color: _LC.text,
                ),
              ),
              Spacer(),
              if (totalDonated.toInt() > 0)
                Text(
                  _formatRupiah(totalDonated),
                  style: TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: _LC.accent,
                  ),
                ),
            ],
          ),
          SizedBox(height: 4),
          Text(
            'Dukung developer biar server tetap hidup + fitur baru terus lahir.',
            style: TextStyle(
              fontFamily: 'ShareTechMono',
              fontSize: 9,
              color: _LC.muted2,
              height: 1.4,
            ),
          ),
          SizedBox(height: 12),

          // Top donors horizontal list
          if (_donorsLoading)
            SizedBox(
              height: 56,
              child: Center(
                child: SizedBox(
                  width: 18, height: 18,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: _LC.accent.withOpacity(0.6)),
                ),
              ),
            )
          else if (_topDonors.isEmpty)
            GestureDetector(
              onTap: _showDonateDialog,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                decoration: BoxDecoration(
                  color: _LC.surface,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _LC.border2),
                ),
                child: Row(
                  children: [
                    FaIcon(FontAwesomeIcons.seedling,
                        color: _LC.muted2, size: 12),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Jadilah yang pertama berdonasi 🌱',
                        style: TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize: 10,
                          color: _LC.muted,
                        ),
                      ),
                    ),
                    FaIcon(FontAwesomeIcons.arrowRight,
                        color: _LC.accent, size: 10),
                  ],
                ),
              ),
            )
          else
            SizedBox(
              height: 56,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                physics: BouncingScrollPhysics(),
                itemCount: _topDonors.length,
                separatorBuilder: (_, __) => SizedBox(width: 8),
                itemBuilder: (ctx, i) {
                  final d = _topDonors[i];
                  final name = (d['username'] ?? 'anon').toString();
                  final total = (d['totalAmount'] ?? 0) as num;
                  final count = (d['count'] ?? 0) as num;
                  final isMe = name == widget.username;
                  Color? medalColor;
                  if (i == 0) medalColor = _LC.gold;
                  else if (i == 1) medalColor = _LC.silver;
                  else if (i == 2) medalColor = _LC.bronze;
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: isMe
                          ? _LC.accent.withOpacity(0.08)
                          : _LC.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isMe
                            ? _LC.accent
                            : (medalColor != null
                                ? medalColor.withOpacity(0.25)
                                : _LC.border2),
                        width: isMe ? 1.5 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 22, height: 22,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: medalColor != null
                                ? medalColor.withOpacity(0.2)
                                : _LC.cardDark,
                          ),
                          child: Center(
                            child: Text(
                              '${i + 1}',
                              style: TextStyle(
                                fontFamily: 'ShareTechMono',
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: medalColor ?? _LC.muted,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 8),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: isMe ? _LC.accent : _LC.text,
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              '${_formatRupiah(total)} • ${count}x',
                              style: TextStyle(
                                fontFamily: 'ShareTechMono',
                                fontSize: 9,
                                color: medalColor ?? _LC.muted,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          SizedBox(height: 12),

          // Donate button
          GestureDetector(
            onTap: _showDonateDialog,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_LC.accent, Color(0xFF991133)],
                  begin: Alignment(-0.7, -0.4),
                  end: Alignment(0.7, 0.4),
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: _LC.accent.withOpacity(0.25),
                    blurRadius: 12,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FaIcon(FontAwesomeIcons.heart,
                      color: Colors.white, size: 13),
                  SizedBox(width: 8),
                  Text(
                    'DONATE',
                    style: TextStyle(
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      totalDonors.toInt() > 0
                          ? '${totalDonors.toInt()} donatur'
                          : 'mulai',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 9,
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Donation dialog ──
  void _showDonateDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => _DonationDialog(
        sessionKey: widget.sessionKey,
        baseUrl: _baseUrl,
        username: widget.username,
        onSubmitted: () {
          // Refresh top donors after submit
          _fetchTopDonors();
        },
      ),
    );
  }

  // ── SENDERS LIST (TOP SENDERS tab) ──
  Widget _buildSendersList() {
    if (_senderLeaderboard.isEmpty) {
      return _buildEmptyState(
        icon: FontAwesomeIcons.paperPlane,
        title: 'NO SENDERS',
        subtitle: 'Belum ada sender yang aktif.\nCheck back lagi nanti.',
      );
    }
    // Cari max sender count buat progress bar scaling.
    final maxSenders = _senderLeaderboard.fold<int>(0, (prev, e) {
      final v = (e['totalSenders'] ?? 0);
      if (v is num) return v.toInt() > prev ? v.toInt() : prev;
      return prev;
    });

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      itemCount: _senderLeaderboard.length,
      itemBuilder: (ctx, i) {
        final entry = _senderLeaderboard[i];
        final username = (entry['username'] ?? 'unknown').toString();
        final role = (entry['role'] ?? 'member').toString();
        final totalSenders = (entry['totalSenders'] ?? 0);
        final activeSenders = (entry['activeSenders'] ?? 0);
        final totalSendersInt = totalSenders is num ? totalSenders.toInt() : 0;
        final activeSendersInt = activeSenders is num ? activeSenders.toInt() : 0;
        final isMe = username == widget.username;
        return _buildSenderCard(
          rank: i + 1,
          username: username,
          role: role,
          totalSenders: totalSendersInt,
          activeSenders: activeSendersInt,
          maxSenders: maxSenders,
          isMe: isMe,
        );
      },
    );
  }

  Widget _buildSenderCard({
    required int rank,
    required String username,
    required String role,
    required int totalSenders,
    required int activeSenders,
    required int maxSenders,
    required bool isMe,
  }) {
    // Medal colors for top 3
    Color? medalColor;
    FaIconData? medalIcon;
    if (rank == 1) {
      medalColor = _LC.gold;
      medalIcon = FontAwesomeIcons.crown;
    } else if (rank == 2) {
      medalColor = _LC.silver;
      medalIcon = FontAwesomeIcons.medal;
    } else if (rank == 3) {
      medalColor = _LC.bronze;
      medalIcon = FontAwesomeIcons.medal;
    }

    final progress = maxSenders > 0 ? (totalSenders / maxSenders).clamp(0.0, 1.0) : 0.0;

    return AnimatedContainer(
      duration: Duration(milliseconds: 250),
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isMe ? _LC.accent.withOpacity(0.08) : _LC.cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isMe
              ? _LC.accent
              : (medalColor != null ? medalColor.withOpacity(0.25) : _LC.border2),
          width: isMe ? 1.5 : 1,
        ),
        boxShadow: medalColor != null
            ? [BoxShadow(color: medalColor.withOpacity(0.08), blurRadius: 10)]
            : null,
      ),
      child: Row(
        children: [
          // Rank badge / medal
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: medalColor != null
                  ? medalColor.withOpacity(0.15)
                  : _LC.surface,
              border: Border.all(
                color: medalColor != null
                    ? medalColor.withOpacity(0.5)
                    : _LC.border2,
                width: medalColor != null ? 1.5 : 1,
              ),
            ),
            child: Center(
              child: medalIcon != null
                  ? Icon(medalIcon, color: medalColor, size: 16)
                  : Text(
                      '$rank',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: _LC.muted,
                      ),
                    ),
            ),
          ),
          SizedBox(width: 12),

          // Username + role + progress
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        username,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: isMe ? _LC.accent : _LC.text,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    SizedBox(width: 6),
                    if (isMe)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: _LC.accent.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'YOU',
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 8,
                            color: _LC.accent,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                  ],
                ),
                SizedBox(height: 5),
                // Role badge
                Row(
                  children: [
                    _buildRoleBadge(role),
                    SizedBox(width: 8),
                    Text(
                      '$activeSenders/$totalSenders active',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 9,
                        color: _LC.muted2,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 7),
                // Progress bar (active vs total senders)
                ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: SizedBox(
                    height: 4,
                    child: Stack(
                      children: [
                        // Total track
                        Container(
                          color: _LC.surface,
                        ),
                        // Active progress (filled)
                        FractionallySizedBox(
                          widthFactor: progress,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [_LC.accent, _LC.accent2],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: 10),

          // Total senders count (big number)
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              AnimatedNumber(
                target: totalSenders,
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: medalColor ?? _LC.text,
                ),
              ),
              Text(
                'senders',
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 8,
                  color: _LC.muted2,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── VIP LIST (TOP VIP tab) ──
  Widget _buildVipList() {
    if (_vipLeaderboard.isEmpty) {
      return _buildEmptyState(
        icon: FontAwesomeIcons.crown,
        title: 'NO VIP',
        subtitle: 'Belum ada user VIP terdaftar.',
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      itemCount: _vipLeaderboard.length,
      itemBuilder: (ctx, i) {
        final entry = _vipLeaderboard[i];
        final username = (entry['username'] ?? 'unknown').toString();
        final role = (entry['role'] ?? 'vip').toString();
        final expiredDate = (entry['expiredDate'] ?? '--').toString();
        final senderCount = entry['senderCount'] ?? 0;
        final senderCountInt = senderCount is num ? senderCount.toInt() : 0;
        final isMe = username == widget.username;
        return _buildVipCard(
          rank: i + 1,
          username: username,
          role: role,
          expiredDate: expiredDate,
          senderCount: senderCountInt,
          isMe: isMe,
        );
      },
    );
  }

  Widget _buildVipCard({
    required int rank,
    required String username,
    required String role,
    required String expiredDate,
    required int senderCount,
    required bool isMe,
  }) {
    Color? medalColor;
    FaIconData? medalIcon;
    if (rank == 1) {
      medalColor = _LC.gold;
      medalIcon = FontAwesomeIcons.crown;
    } else if (rank == 2) {
      medalColor = _LC.silver;
      medalIcon = FontAwesomeIcons.medal;
    } else if (rank == 3) {
      medalColor = _LC.bronze;
      medalIcon = FontAwesomeIcons.medal;
    }

    // Parse expiry date untuk status badge
    final expiry = _parseExpiryStatus(expiredDate);

    return AnimatedContainer(
      duration: Duration(milliseconds: 250),
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isMe ? _LC.accent.withOpacity(0.08) : _LC.cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isMe
              ? _LC.accent
              : (medalColor != null ? medalColor.withOpacity(0.25) : _LC.border2),
          width: isMe ? 1.5 : 1,
        ),
        boxShadow: medalColor != null
            ? [BoxShadow(color: medalColor.withOpacity(0.08), blurRadius: 10)]
            : null,
      ),
      child: Row(
        children: [
          // Rank/medal
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: medalColor != null
                  ? medalColor.withOpacity(0.15)
                  : _LC.surface,
              border: Border.all(
                color: medalColor != null
                    ? medalColor.withOpacity(0.5)
                    : _LC.border2,
                width: medalColor != null ? 1.5 : 1,
              ),
            ),
            child: Center(
              child: medalIcon != null
                  ? Icon(medalIcon, color: medalColor, size: 16)
                  : Text(
                      '$rank',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: _LC.muted,
                      ),
                    ),
            ),
          ),
          SizedBox(width: 12),

          // Username + expiry
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        username,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: isMe ? _LC.accent : _LC.text,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    SizedBox(width: 6),
                    if (isMe)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: _LC.accent.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'YOU',
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 8,
                            color: _LC.accent,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                  ],
                ),
                SizedBox(height: 6),
                Row(
                  children: [
                    _buildRoleBadge(role),
                    SizedBox(width: 8),
                    // Expiry badge with status color
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: expiry.color.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: expiry.color.withOpacity(0.25)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          FaIcon(FontAwesomeIcons.calendarDay, size: 8, color: expiry.color),
                          SizedBox(width: 4),
                          Text(
                            expiredDate,
                            style: TextStyle(
                              fontFamily: 'ShareTechMono',
                              fontSize: 9,
                              color: expiry.color,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(width: 10),

          // Sender count (big number)
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              AnimatedNumber(
                target: senderCount,
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: medalColor ?? _LC.text,
                ),
              ),
              Text(
                'senders',
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 8,
                  color: _LC.muted2,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Role badge ──
  Widget _buildRoleBadge(String role) {
    final r = role.toLowerCase();
    Color color;
    FaIconData icon;
    if (r == 'owner' || r == 'founder' || r == 'high admin') {
      color = _LC.accent;
      icon = FontAwesomeIcons.crown;
    } else if (r == 'vip') {
      color = _LC.gold;
      icon = FontAwesomeIcons.star;
    } else if (r == 'seles' || r == 'admin') {
      color = _LC.success;
      icon = FontAwesomeIcons.shieldHalved;
    } else if (r == 'reseller') {
      color = Color(0xFF3B82F6);
      icon = FontAwesomeIcons.store;
    } else {
      color = _LC.muted;
      icon = FontAwesomeIcons.user;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          FaIcon(icon, size: 8, color: color),
          SizedBox(width: 4),
          Text(
            role.toUpperCase(),
            style: TextStyle(
              fontFamily: 'ShareTechMono',
              fontSize: 8,
              color: color,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ── Expiry status (parse date, return color) ──
  _ExpiryStatus _parseExpiryStatus(String dateStr) {
    if (dateStr.isEmpty || dateStr == '--') {
      return _ExpiryStatus(_LC.muted2);
    }
    try {
      // Try ISO format: "2026-08-20"
      final parts = dateStr.split('-');
      if (parts.length == 3) {
        final y = int.tryParse(parts[0]);
        final m = int.tryParse(parts[1]);
        final d = int.tryParse(parts[2]);
        if (y != null && m != null && d != null) {
          final expiry = DateTime(y, m, d);
          final now = DateTime.now();
          final days = expiry.difference(now).inDays;
          if (days < 0) return _ExpiryStatus(_LC.accent);          // expired
          if (days <= 7) return _ExpiryStatus(Color(0xFFFFA500)); // expiring soon
          return _ExpiryStatus(_LC.success);                          // active
        }
      }
    } catch (_) {}
    return _ExpiryStatus(_LC.muted2);
  }

  // ── Empty state ──
  Widget _buildEmptyState({
    required FaIconData icon,
    required String title,
    required String subtitle,
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                color: _LC.accent.withOpacity(0.06),
                shape: BoxShape.circle,
                border: Border.all(color: _LC.accent.withOpacity(0.2), width: 2),
              ),
              child: Center(
                child: FaIcon(icon, color: _LC.muted2, size: 26),
              ),
            ),
            SizedBox(height: 18),
            Text(
              title,
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: _LC.text,
                letterSpacing: 2,
              ),
            ),
            SizedBox(height: 8),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 10,
                color: _LC.muted2,
                height: 1.6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  AnimatedNumber — count-up animation when target changes.
// ═══════════════════════════════════════════════════════════════════════════
class AnimatedNumber extends StatefulWidget {
  final int target;
  final TextStyle? style;
  final Duration duration;

  AnimatedNumber({
    super.key,
    required this.target,
    this.style,
    this.duration = const Duration(milliseconds: 800),
  });

  @override
  State<AnimatedNumber> createState() => _AnimatedNumberState();
}

class _AnimatedNumberState extends State<AnimatedNumber>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<int> _animation;
  int _previous = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: widget.duration,
    );
    _setupAnimation(0, widget.target);
    _controller.forward();
    _previous = widget.target;
  }

  void _setupAnimation(int from, int to) {
    _animation = IntTween(begin: from, end: to).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
  }

  @override
  void didUpdateWidget(covariant AnimatedNumber oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.target != widget.target) {
      _setupAnimation(_previous, widget.target);
      _controller.forward(from: 0);
      _previous = widget.target;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (_, __) => Text(
        '${_animation.value}',
        style: widget.style,
      ),
    );
  }
}

// ── Expiry status helper ──
class _ExpiryStatus {
  final Color color;
  _ExpiryStatus(this.color);
}

// ═══════════════════════════════════════════════════════════════════════════
//  DONATION DIALOG — bottom sheet
//  ── Amount presets (10k, 25k, 50k, 100k, custom)
//  ── QRIS image (from assets/images/qris.jpg)
//  ── Upload proof (image picker)
//  ── Submit → POST /donate
// ═══════════════════════════════════════════════════════════════════════════
class _DonationDialog extends StatefulWidget {
  final String sessionKey;
  final String baseUrl;
  final String username;
  final VoidCallback onSubmitted;

  const _DonationDialog({
    required this.sessionKey,
    required this.baseUrl,
    required this.username,
    required this.onSubmitted,
  });

  @override
  State<_DonationDialog> createState() => _DonationDialogState();
}

class _DonationDialogState extends State<_DonationDialog> {
  static final List<Map<String, dynamic>> _presets = [
    {'label': '10k',  'value': 10000},
    {'label': '25k',  'value': 25000},
    {'label': '50k',  'value': 50000},
    {'label': '100k', 'value': 100000},
  ];

  int? _selectedPreset;     // null = custom mode
  final _customController = TextEditingController();
  File? _proofFile;
  String? _proofBase64;
  bool _isSubmitting = false;

  @override
  void dispose() {
    _customController.dispose();
    super.dispose();
  }

  int? get _currentAmount {
    if (_selectedPreset != null) return _selectedPreset;
    final v = int.tryParse(_customController.text.trim());
    return v;
  }

  Future<void> _pickProof() async {
    try {
      final picker = ImagePicker();
      final xfile = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
        maxWidth: 1280,
      );
      if (xfile == null) return;
      final bytes = await xfile.readAsBytes();
      final b64 = base64Encode(bytes);
      final mime = xfile.mimeType ?? 'image/jpeg';
      setState(() {
        _proofFile = File(xfile.path);
        _proofBase64 = 'data:$mime;base64,$b64';
      });
    } catch (e) {
      _showSnack('Gagal memilih gambar: $e');
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 11, color: Colors.white)),
      backgroundColor: isError ? _LC.accent : _LC.surface,
      duration: Duration(seconds: 3),
    ));
  }

  Future<void> _submit() async {
    if (_isSubmitting) return;
    final amt = _currentAmount;
    if (amt == null || amt < 1000) {
      _showSnack('Nominal donasi minimal Rp 1.000', isError: true);
      return;
    }
    if (_proofBase64 == null || _proofBase64!.length < 100) {
      _showSnack('Upload bukti transfer dulu', isError: true);
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      final res = await http
          .post(
            Uri.parse("${widget.baseUrl}/donate"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'amount': amt,
              'proofBase64': _proofBase64,
              'proofMime': 'image/jpeg',
            }),
          )
          .timeout(Duration(seconds: 30));

      if (res.statusCode != 200) {
        String errMsg = 'Server error (${res.statusCode})';
        try {
          final errData = jsonDecode(res.body);
          if (errData is Map && errData['message'] != null) {
            errMsg = errData['message'];
          }
        } catch (_) {}
        _showSnack(errMsg, isError: true);
        return;
      }
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        widget.onSubmitted();
        if (mounted) Navigator.of(context).pop();
        _showSuccess(amt);
      } else {
        _showSnack(
            (data['message'] ?? 'Gagal submit donasi').toString(),
            isError: true);
      }
    } catch (e) {
      _showSnack('Connection error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  void _showSuccess(int amount) {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: EdgeInsets.zero,
        child: Container(
          width: MediaQuery.of(context).size.width * 0.85,
          constraints: BoxConstraints(maxWidth: 360),
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
          decoration: BoxDecoration(
            color: _LC.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _LC.border, width: 1),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [_LC.accent, Color(0xFF991133)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(
                      color: _LC.accent.withOpacity(0.4), width: 2),
                ),
                child: Center(
                  child: FaIcon(FontAwesomeIcons.heart,
                      color: Colors.white, size: 30),
                ),
              ),
              SizedBox(height: 20),
              Text(
                'TERIMA KASIH!',
                style: TextStyle(
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                  color: _LC.text,
                ),
              ),
              SizedBox(height: 6),
              Container(
                  width: 40, height: 2,
                  decoration: BoxDecoration(
                      color: _LC.accent.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(1))),
              SizedBox(height: 16),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _LC.surface,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Text(
                      'Rp ${amount.toString().replaceAllMapped(
                          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
                          (m) => '${m[1]}.')}',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: _LC.accent,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Donasi kamu pending review owner.\nMuncul di top donors setelah di-approve.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                        color: _LC.muted,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: _LC.text,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text('CLOSE',
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                          color: _LC.bg,
                        )),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.only(bottom: bottomInset),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
        decoration: BoxDecoration(
          color: _LC.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _LC.border, width: 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle bar
            Container(
              margin: const EdgeInsets.only(top: 12),
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: _LC.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 14),
            // Title row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: _LC.accent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: _LC.accent.withOpacity(0.25)),
                    ),
                    child: Center(
                      child: FaIcon(FontAwesomeIcons.handHoldingHeart,
                          color: _LC.accent, size: 14),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('DONATE',
                            style: TextStyle(
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 2,
                                color: _LC.text)),
                        SizedBox(height: 2),
                        Text('Dukung developer 🙏',
                            style: TextStyle(
                                fontFamily: 'ShareTechMono',
                                fontSize: 10,
                                color: _LC.muted)),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.of(context).pop(),
                    child: Container(
                      width: 30, height: 30,
                      decoration: BoxDecoration(
                        color: _LC.surface,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _LC.border2),
                      ),
                      child: Icon(Icons.close,
                          color: _LC.muted2, size: 14),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 18),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Amount label
                    Row(
                      children: [
                        Container(width: 3, height: 14, color: _LC.accent),
                        SizedBox(width: 8),
                        Text('PILIH NOMINAL',
                            style: TextStyle(
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 2,
                                color: _LC.text)),
                      ],
                    ),
                    SizedBox(height: 10),
                    // Preset chips
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        ..._presets.map((p) {
                          final sel = _selectedPreset == p['value'];
                          return GestureDetector(
                            onTap: () => setState(() {
                              _selectedPreset = p['value'] as int;
                              _customController.clear();
                            }),
                            child: AnimatedContainer(
                              duration: Duration(milliseconds: 200),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 9),
                              decoration: BoxDecoration(
                                color: sel
                                    ? _LC.accent.withOpacity(0.12)
                                    : _LC.surface,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    color: sel ? _LC.accent : _LC.border2,
                                    width: sel ? 1.5 : 1),
                              ),
                              child: Text('Rp ${p['label']}',
                                  style: TextStyle(
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: sel ? _LC.accent : _LC.muted)),
                            ),
                          );
                        }),
                        // Custom chip
                        GestureDetector(
                          onTap: () => setState(() {
                            _selectedPreset = null;
                          }),
                          child: AnimatedContainer(
                            duration: Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 9),
                            decoration: BoxDecoration(
                              color: _selectedPreset == null
                                  ? _LC.accent.withOpacity(0.12)
                                  : _LC.surface,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: _selectedPreset == null
                                      ? _LC.accent
                                      : _LC.border2,
                                  width: _selectedPreset == null ? 1.5 : 1),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                FaIcon(FontAwesomeIcons.pen,
                                    size: 9,
                                    color: _selectedPreset == null
                                        ? _LC.accent
                                        : _LC.muted2),
                                SizedBox(width: 6),
                                Text('CUSTOM',
                                    style: TextStyle(
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700,
                                        color: _selectedPreset == null
                                            ? _LC.accent
                                            : _LC.muted)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                    // Custom input (visible when "CUSTOM" chip is selected)
                    if (_selectedPreset == null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                          decoration: BoxDecoration(
                            color: _LC.surface,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: _LC.border),
                          ),
                          child: Row(
                            children: [
                              Text('Rp',
                                  style: TextStyle(
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 14,
                                      color: _LC.accent)),
                              SizedBox(width: 10),
                              Expanded(
                                child: TextField(
                                  controller: _customController,
                                  keyboardType: TextInputType.number,
                                  style: TextStyle(
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 15,
                                      color: _LC.text),
                                  cursorColor: _LC.accent,
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: '5000',
                                    hintStyle: TextStyle(
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 14,
                                        color: _LC.muted2),
                                    contentPadding: EdgeInsets.symmetric(
                                        vertical: 14),
                                  ),
                                  onChanged: (_) => setState(() {}),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    SizedBox(height: 8),

                    // QRIS image
                    Row(
                      children: [
                        Container(width: 3, height: 14, color: _LC.accent),
                        SizedBox(width: 8),
                        Text('SCAN QRIS',
                            style: TextStyle(
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 2,
                                color: _LC.text)),
                      ],
                    ),
                    SizedBox(height: 10),
                    Center(
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: _LC.text,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.asset(
                            'assets/images/qris.jpg',
                            width: 180, height: 180, fit: BoxFit.cover,
                            errorBuilder: (ctx, e, _) => Container(
                              width: 180, height: 180,
                              color: _LC.text,
                              child: Icon(Icons.broken_image,
                                  color: _LC.muted2, size: 32),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 16),

                    // Proof upload
                    Row(
                      children: [
                        Container(width: 3, height: 14, color: _LC.accent),
                        SizedBox(width: 8),
                        Text('BUKTI TRANSFER',
                            style: TextStyle(
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 2,
                                color: _LC.text)),
                      ],
                    ),
                    SizedBox(height: 10),
                    GestureDetector(
                      onTap: _pickProof,
                      child: AnimatedContainer(
                        duration: Duration(milliseconds: 200),
                        height: 130,
                        decoration: BoxDecoration(
                          color: _LC.surface,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _proofFile != null
                                ? _LC.accent
                                : _LC.border2,
                            width: _proofFile != null ? 1.5 : 1,
                          ),
                        ),
                        child: _proofFile != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(11),
                                child: Stack(
                                  children: [
                                    Image.file(_proofFile!,
                                        width: double.infinity,
                                        height: double.infinity,
                                        fit: BoxFit.cover),
                                    Positioned(
                                      top: 8, right: 8,
                                      child: GestureDetector(
                                        onTap: () => setState(() {
                                          _proofFile = null;
                                          _proofBase64 = null;
                                        }),
                                        child: Container(
                                          padding: const EdgeInsets.all(6),
                                          decoration: BoxDecoration(
                                            color: _LC.accent,
                                            shape: BoxShape.circle,
                                          ),
                                          child: Icon(Icons.close,
                                              color: Colors.white, size: 12),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    FaIcon(FontAwesomeIcons.image,
                                        color: _LC.muted2, size: 22),
                                    SizedBox(height: 8),
                                    Text('Upload Bukti Transfer',
                                        style: TextStyle(
                                            fontFamily: 'ShareTechMono',
                                            fontSize: 11,
                                            color: _LC.muted)),
                                    SizedBox(height: 2),
                                    Text('JPG / PNG • tap untuk pilih',
                                        style: TextStyle(
                                            fontFamily: 'ShareTechMono',
                                            fontSize: 9,
                                            color: _LC.muted2)),
                                  ],
                                ),
                              ),
                      ),
                    ),
                    SizedBox(height: 18),

                    // Submit button
                    GestureDetector(
                      onTap: _isSubmitting ? null : _submit,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [_LC.accent, Color(0xFF991133)],
                            begin: Alignment(-0.7, -0.4),
                            end: Alignment(0.7, 0.4),
                          ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                                color: _LC.accent.withOpacity(0.25),
                                blurRadius: 12),
                          ],
                        ),
                        child: Center(
                          child: _isSubmitting
                              ? SizedBox(
                                  width: 18, height: 18,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2.5,
                                      color: Colors.white))
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    FaIcon(FontAwesomeIcons.paperPlane,
                                        color: Colors.white, size: 12),
                                    SizedBox(width: 8),
                                    Text(
                                      _currentAmount != null
                                          ? 'SUBMIT DONASI'
                                          : 'SUBMIT DONASI',
                                      style: TextStyle(
                                          fontFamily: 'MADEEvolveSansEVO',
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          letterSpacing: 2,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
