// main.dart — YakuzaXsilence RAT Controller (VIP Only)
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

import 'login_page.dart';
import 'device_dashboard.dart';
import 'control_panel.dart';

const String baseUrl = "https://api-service.yakuza.biz.id:1300";

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RATControllerApp());
}

class RATControllerApp extends StatelessWidget {
  const RATControllerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YakuzaXsilence RAT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFF0A0A14),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF6366F1),
          secondary: Color(0xFF818CF8),
          surface: Color(0xFF0A0A14),
        ),
        fontFamily: 'MADEEvolveSansEVO',
        useMaterial3: true,
      ),
      initialRoute: '/login',
      onGenerateRoute: (settings) {
        final args = settings.arguments as Map<String, dynamic>?;

        switch (settings.name) {
          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());

          case '/dashboard_rat':
            return MaterialPageRoute(
              builder: (_) => DeviceDashboardPage(
                username: args?['username'] ?? 'guest',
                sessionKey: args?['sessionKey'] ?? args?['key'] ?? '',
              ),
            );

          case '/control_panel':
            return MaterialPageRoute(
              settings: settings,
              builder: (_) => const ControlCenterPage(),
            );

          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(
                  child: Text(
                    '404 - PAGE NOT FOUND',
                    style: TextStyle(color: Color(0xFFF87171)),
                  ),
                ),
              ),
            );
        }
      },
    );
  }
}
