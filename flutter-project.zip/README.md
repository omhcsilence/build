# ☕ Kedai Mokka 3D - Open World HD

> Custom 3D Software Engine built entirely with Flutter Canvas with HD Realistic Graphics.

![Flutter](https://img.shields.io/badge/Flutter-Canvas-blue?logo=flutter)
![Dart](https://img.shields.io/badge/Dart-3.x-blue?logo=dart)
![Status](https://img.shields.io/badge/Status-Production-green)
![Graphics](https://img.shields.io/badge/Graphics-HD%20Realistic-purple)

---

# 📖 About

Kedai Mokka 3D adalah game eksplorasi 3D **Open World** dengan **Grafik HD Realistis** yang dibuat menggunakan Flutter dengan custom software renderer tanpa menggunakan Unity, Unreal Engine, Flame, maupun engine 3D lainnya.

Seluruh proses rendering dilakukan menggunakan Canvas, CustomPainter, Matrix4, dan Vector3 sehingga seluruh objek dirender secara manual dengan **Dynamic Shaders**, **Soft Shadows**, dan **Texture Patterns**.

---

# ✨ Features

## 🌍 Open World
- **500x500 meter map** dengan terrain dinamis
- **40+ bangunan** termasuk 12 landmark utama + 30 procedural building
- **7 jalan raya** termasuk highway, ring road, dan connector roads
- **28+ collectibles** tersebar di seluruh map
- Procedural generation untuk area terpencil

## 🎨 HD Realistic Graphics
- **Dynamic Lighting** - pencahayaan real-time dengan specular highlights
- **Soft Shadows** - PCF (Percentage Closer Filtering) dengan multi-sample
- **Ambient Occlusion** - depth shading untuk realisme
- **Bloom Effect** - glow pada area terang
- **Texture Patterns** - 6 jenis tekstur (Brick, Concrete, Glass, Residential, Luxury, Industrial)
- **Atmospheric Fog** - efek kabut jarak jauh
- **Dynamic Sky** - sky gradient berdasarkan kualitas

## ⚙️ Adjustable Graphics Settings
4 Quality Preset:

| Preset | Render Distance | Shadows | AO | Bloom | AA | Target Device |
|--------|----------------|---------|-----|-------|-----|---------------|
| Low    | 80m            | ❌      | ❌  | ❌    | ❌  | Low-end       |
| Medium | 120m           | ✅      | ❌  | ❌    | ✅  | Mid-range     |
| High   | 200m           | ✅      | ✅  | ✅    | ✅  | Modern        |
| Ultra  | 400m           | ✅      | ✅  | ✅    | ✅  | Flagship      |

Plus individual toggle untuk setiap fitur!

## 🎮 Game Features
- 🏢 3D Building Rendering dengan Texture
- 🛣 Road Rendering
- ☁ Dynamic Sky dengan Sun
- 🌫 Distance Fog
- 💡 Directional Lighting + Specular
- 👤 First Person Camera
- 🚧 Collision Detection
- 🎁 Collectible Items
- 🗺 Mini Map
- 🎮 Virtual Joystick
- ⬆ Jump Physics
- 💳 Redeem Code
- 📱 Android Ready

---

# 🗂 Project Structure

```
lib/
├── main.dart                    # Entry point + splash screen
├── camera/
│   └── camera_3d.dart          # 3D camera system
├── engine/
│   └── game_loop.dart          # Game loop with delta time
├── models/
│   ├── player_data.dart        # Player state
│   └── world_data.dart         # World data models (Building, Road, Collectible)
├── painters/
│   └── world_painter_3d.dart   # 3D rendering with shaders
├── render/
│   ├── graphics_settings.dart  # Graphics configuration (Low/Med/High/Ultra)
│   ├── shader_effects.dart     # Shader calculations (Lighting, Shadow, AO, Bloom)
│   ├── pipeline_3d.dart        # 3D rendering pipeline
│   └── environment_system.dart # Particles & environment details
├── screens/
│   └── game_screen_3d.dart     # Main game screen
├── services/
│   ├── map_service.dart        # World generation (Open World)
│   ├── osm_service.dart        # OSM data fetching
│   ├── save_game_service.dart  # Save system
│   └── redeem_service.dart     # Promo code system
├── utils/
│   └── collision_utils.dart    # Collision detection
└── widgets/
    ├── hud_3d.dart             # HUD overlay + minimap
    ├── graphics_settings_dialog.dart  # Graphics settings UI
    └── redeem_dialog.dart      # Redeem code dialog
```

---

# 🛠 Engine

## Rendering Pipeline
- View Matrix
- Projection Matrix (Perspective)
- Back Face Culling
- Painter's Algorithm
- Distance Culling (based on render distance)
- Directional Lighting
- Specular Highlights
- Soft Shadows (PCF)
- Ambient Occlusion
- Bloom Effect
- Texture Patterns
- Atmospheric Fog

## Physics
- Gravity
- Jump
- Collision Detection (Building)
- Collectible Detection

---

# 🎛️ Graphics Settings API

```dart
// Get singleton instance
final settings = GraphicsSettings();

// Set quality preset
settings.setQuality(GraphicsQuality.high);

// Individual settings
settings.setShadows(true);
settings.setAmbientOcclusion(true);
settings.setBloom(true);
settings.setAntiAliasing(true);
settings.setRenderDistance(200.0);
settings.setShadowQuality(1.0);
settings.setDynamicLighting(true);
settings.setTextureFiltering(true);
settings.setFogEnabled(true);

// Get current values
print(settings.qualityLabel); // "High"
print(settings.renderDistance); // 200.0
```

---

# 🚀 Build Instructions

## Prerequisites
- Flutter SDK 3.24.0+
- Java 17
- Android SDK

## Build APK
```bash
flutter pub get
flutter build apk --release
```

## Build Split APKs (Per ABI - Smaller Size)
```bash
flutter build apk --release --split-per-abi
```

---

# 📱 Controls

| Action | Control |
|--------|---------|
| Move | WASD / Virtual Joystick |
| Look | Mouse drag / Touch drag |
| Jump | Space / Jump button |
| Settings | Settings button (top right) |

---

# 🔧 Dependencies

```yaml
dependencies:
  flutter: sdk
  provider: ^6.1.0
  vector_math: ^2.1.4
  path_provider: ^2.1.0
  http: ^1.1.0
  latlong2: ^0.9.1
  shared_preferences: ^2.2.0
  flutter_displaymode: ^0.6.0
```

---

# 🎯 Roadmap

- ✅ Dynamic Lighting
- ✅ Shadow Rendering
- ✅ Texture Mapping
- ✅ Adjustable Graphics
- ✅ Open World Map
- ⏳ Weather System
- ⏳ Day & Night Cycle
- ⏳ Dynamic NPC
- ⏳ Vehicle System
- ⏳ Multiplayer
- ⏳ Sound Engine
- ⏳ Quest System
- ⏳ Inventory System

---

# 📄 License

MIT License

---

# ❤️ Credits

Developed with Flutter.

Built using a custom software rendering engine powered by:

- Flutter Canvas
- CustomPainter
- Matrix4
- Vector3
- Dart

No Unity.
No Unreal Engine.
No Flame.

Only Flutter.
