# ProCam - Professional Camera App

Aplikasi kamera profesional built with Flutter untuk Android dengan fitur lengkap setara iOS Camera.

## Fitur

### Kamera
- **Multiple Resolusi**: Low (480p) hingga Maximum
- **Aspect Ratio**: 4:3, 16:9, 1:1
- **Dual Camera**: Depan & Belakang
- **Zoom**: 0.5x - 5x dengan slider

### Mode
- **Foto**: Mode standar
- **Video**: Rekam video
- **Portrait**: Mode bokeh
- **Pano**: Panorama
- **Time-Lapse**: Time-lapse video

### Kontrol Manual
- **ISO**: 100-3200
- **Shutter Speed**: Manual control
- **Focus**: Manual focus
- **White Balance**: 2500K-8000K
- **Exposure**: Kompensasi exposure

### Filter (10 filter)
- Original, Vivid, Dramatic, Noir
- Chrome, Fade, Cool, Warm, Mono, Silvertone

### Fitur Tambahan
- Grid (Rule of Thirds)
- Level Indicator
- Timer (3s, 5s, 10s)
- Flash (Auto/On/Off/Torch)
- HDR Mode
- Geotag
- RAW Capture

## Cara Build APK

### 1. Setup Flutter
```bash
# Pastikan Flutter sudah terinstall
flutter doctor

# Install dependencies
flutter pub get
```

### 2. Build APK
```bash
# Build APK debug
flutter build apk --debug

# Build APK release
flutter build apk --release

# Build App Bundle untuk Play Store
flutter build appbundle
```

### 3. Install ke Device
```bash
# Install via USB debugging
flutter install

# Atau copy APK ke device
# APK location: build/app/outputs/flutter-apk/app-release.apk
```

## Struktur Project

```
procam/
├── android/                 # Android native code
├── ios/                     # iOS native code (jika diperlukan)
├── lib/
│   ├── blocs/              # BLoC state management
│   │   ├── camera/
│   │   ├── gallery/
│   │   └── settings/
│   ├── screens/            # UI Screens
│   │   ├── camera_screen.dart
│   │   ├── gallery_screen.dart
│   │   └── settings_screen.dart
│   ├── services/           # Business logic
│   │   ├── camera_service.dart
│   │   ├── permission_service.dart
│   │   └── storage_service.dart
│   ├── widgets/            # Reusable widgets
│   │   ├── camera_controls.dart
│   │   ├── mode_selector.dart
│   │   ├── zoom_control.dart
│   │   ├── filter_strip.dart
│   │   ├── grid_overlay.dart
│   │   └── focus_frame.dart
│   └── main.dart           # Entry point
├── assets/                 # Images, icons, sounds
├── pubspec.yaml           # Dependencies
└── README.md
```

## Dependencies

```yaml
camera: ^0.10.5+5          # Camera access
permission_handler: ^11.0.1 # Permissions
flutter_bloc: ^8.1.3       # State management
equatable: ^2.0.5          # Equality
image: ^4.1.3              # Image processing
path_provider: ^2.1.1      # File storage
shared_preferences: ^2.2.2 # Local storage
flutter_screenutil: ^5.9.0 # Responsive UI
photo_view: ^0.14.0        # Image viewer
share_plus: ^7.2.1         # Share functionality
geolocator: ^10.1.0        # GPS location
```

## Permissions

Aplikasi memerlukan izin berikut:
- **CAMERA**: Akses kamera
- **RECORD_AUDIO**: Rekam audio untuk video
- **READ/WRITE_EXTERNAL_STORAGE**: Simpan foto/video
- **ACCESS_FINE_LOCATION**: Geotag

## Konfigurasi Android

### AndroidManifest.xml
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
```

### build.gradle
```gradle
android {
    compileSdkVersion 34
    defaultConfig {
        minSdkVersion 21
        targetSdkVersion 34
    }
}
```

## Testing

```bash
# Run debug mode
flutter run

# Run release mode
flutter run --release

# Run tests
flutter test
```

## Troubleshooting

### Camera tidak berfungsi
1. Pastikan izin kamera diberikan
2. Check `flutter doctor` untuk setup yang benar
3. Pastikan device support camera2 API

### Build error
```bash
# Clean build
flutter clean
flutter pub get
cd android && ./gradlew clean && cd ..
flutter build apk
```

### Permission denied
- Buka Settings > Apps > ProCam > Permissions
- Aktifkan semua permissions

## Lisensi

MIT License - Free for personal and commercial use

## Pengembang

Dibuat dengan Flutter ❤️
